<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
include "ip.inc" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>


<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];



$INPUT_STR = trim($_GET['STR']);
$INPUT_STR = trim(base64_decode($INPUT_STR));
$PIECES = explode("|", $INPUT_STR);
$IP = htmlspecialchars($PIECES[0]);
$PORT = htmlspecialchars($PIECES[1]);

if (!filter_var($IP, FILTER_VALIDATE_IP)) {
	$BAD_IP = 'Y';
}

if (!filter_var($PORT, FILTER_VALIDATE_INT)) {
	$BAD_PORT = 'Y';
}

//echo "IP : $IP , PORT : $PORT <br>";


        if ($IP != '' and $PORT != '' and $BAD_IP != 'Y' and $BAD_PORT != 'Y')
	{


/*

# Ansible Directory
$ANSIBLE_DIR = "/home/ansible";
$ANSIBLE_PLAYBOOK_DIR = "$ANSIBLE_DIR/playbook";
$ANSIBLE_HOST_DIR = "$ANSIBLE_DIR/host";
$ANSIBLE_LOG_DIR = "$ANSIBLE_DIR/log";
$ANSIBLE_EXEC_DIR = "$ANSIBLE_DIR/exec";

*/


                $RANDOM_NUM = mt_rand(1,1000);
                $UTIME_F = explode('.',microtime(true));
                $UTIME = $UTIME_F[0] . $UTIME_F[1] . $RANDOM_NUM ;

		//$CMD_LINE = shell_exec("cp $ANSIBLE_PLAYBOOK_DIR/cmd.yml.copy $ANSIBLE_PLAYBOOK_DIR/");
		//$CMD_LINE = shell_exec("cp $ANSIBLE_PLAYBOOK_DIR/cmd.yml $ANSIBLE_PLAYBOOK_DIR/");

		$ANSIBLE_PLAYBOOK_ORG = "${ANSIBLE_PLAYBOOK_DIR}/setup.yml.copy" ;
		$ANSIBLE_PLAYBOOK_NICK_FILE = "${ANSIBLE_EXEC_DIR}/setup.yml" ;
		$ANSIBLE_PLAYBOOK_FILE = "${ANSIBLE_EXEC_DIR}/setup.yml" . $UTIME ;
	
		$FULLSTR = "sed \"s|#IP#|{$IP}|\" $ANSIBLE_PLAYBOOK_ORG > $ANSIBLE_PLAYBOOK_FILE";
        	$REPLACE_STR = exec($FULLSTR,$output,$return) ;

		//$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");
		//echo "<pre>$RESULT_DISPLAY</pre>";

		$CHECK_FILE = exec("cat $ANSIBLE_PLAYBOOK_FILE | grep '#IP#' | wc -l");
		if ($return == 0 and $CHECK_FILE == 0) {
			$ANSIBLE_HOST_FILE = "$ANSIBLE_HOST_DIR/hosts" . $UTIME ;
			$ANSIBLE_HOST_NICK_FILE = "$ANSIBLE_HOST_DIR/hosts" ;
			$ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log.txt" . $UTIME ;
			$ANSIBLE_LOG_NICK_FILE = "$ANSIBLE_LOG_DIR/log.txt" ;

                        $HOST_STR = "
[linux_test]
$IP ansible_ssh_port=$PORT
                        ";

                        $fp = fopen($ANSIBLE_HOST_FILE,'w');
                        fputs($fp,$HOST_STR);
                        fclose($fp);

			$CMD_LINE = shell_exec("ansible-playbook -i $ANSIBLE_HOST_FILE $ANSIBLE_PLAYBOOK_FILE > $ANSIBLE_LOG_FILE 2>&1");
                        $Fail_CNT1 = shell_exec("cat $ANSIBLE_LOG_FILE | grep 'failed=' | wc -l");
                        $Fail_CNT2 = shell_exec("cat $ANSIBLE_LOG_FILE | grep 'failed=0' | wc -l");
                        $OK_0_CNT = shell_exec("cat $ANSIBLE_LOG_FILE | grep 'ok=0' | wc -l");

                        if ($Fail_CNT1 == 0) {
				$MSG1 = "실패";
                                $SUCC = 'N';
                        }
                        else if ($OK_0_CNT == 0 and $Fail_CNT1 == $Fail_CNT2) {
				$MSG1 = "성공";
                                $SUCC = 'Y';
                        }
                        else {
				$MSG1 = "실패";
                                $SUCC = 'N';
                        }

			//echo "# Full Str : {$FULLSTR} <br>";
			echo "# 실행결과 : <b><font color=blue>{$MSG1} </font></b><br>";
			echo "# 입력 IP  : {$IP} <br>";
	
			//$WHO = exec("whoami");
			//echo "# USER : {$WHO} <br>";

			//$PID = getmypid();
			//echo "# PID : {$PID} <br>";

			$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
			echo "<pre>$RESULT_DISPLAY</pre>";

			$RESULT_INFO = shell_exec("cat $ANSIBLE_LOG_FILE | grep '#MSGM#'");
			if ($RESULT_INFO != '') {

				echo "
			  <br>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_warning' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Inventory 추가</font></b>
                              </div>

                              <div class='panel-body'>

				";

				$RESULT_INFO = str_replace("#MSGM#","$IP",$RESULT_INFO);
				$RESULT_INFO = preg_replace('/\t|\r\n|\r|\n|\"/','',$RESULT_INFO);
				$RESULT_INFO = str_replace('msg: ','',$RESULT_INFO);
				$RESULT_INFO = strtolower($RESULT_INFO);
				$RESULT_INFO = trim($RESULT_INFO);
				echo "<pre>$RESULT_INFO</pre>";
				
				$RESULT_INFO = $RESULT_INFO . "|" . $PORT;
				$PIECES = explode("|", $RESULT_INFO);
				$IPADDR = $PIECES[0];
				$HOSTNAME = $PIECES[1];
				$NODENAME = $PIECES[2];
				$ID = $PIECES[3];
				$RELEASE = $PIECES[4];
				$KERNEL_VER = $PIECES[5];

				$output = base64_encode($RESULT_INFO);

				echo "
                                <table width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                        <th>Linux 버젼</th>
                                        <th>Kernel 버젼</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
				    <tr><td>Linux</td><td>$HOSTNAME</td><td>$NODENAME</td><td>$IPADDR</td><td>{$ID}{$RELEASE}</td><td>$KERNEL_VER</td>
                        		<td width=50><form action=./ansible_linux_inventory_host_add.php>
                        		<center><button class='btn btn-success btn-xs' type=submit name=L_DATA value={$output}><b><font size=2>호스트 추가</font></b></button></center></form></td>
				    </tr>
				</tbody>
				</table>

                              </div>
                            </div>
                          </div>
				";
			}


			//$RESULT = shell_exec("$ANSIBLE_PLAYBOOK_DIR/parser.sh $ANSIBLE_LOG_DIR/log.txt 2>&1");
			//echo "<pre>$RESULT</pre>";
		}
		else {
			echo "NOT Success!! <br>";
			foreach($output as $line) {
				echo "$line <br>";
			}
		}

                $DELETE1 = shell_exec("rm -f $ANSIBLE_HOST_FILE");
                $DELETE2 = shell_exec("rm -f $ANSIBLE_LOG_FILE");
                $DELETE2 = shell_exec("rm -f $ANSIBLE_PLAYBOOK_FILE");

	}
	else {
		echo "<b><font color=red>ㅇ 입력된 정보가 문제가 있습니다. 확인바랍니다!!</font></b><br>";
	}



?> 

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>




</body>

</html>




