<?php

$MYSQL_HST = "localhost";
$MYSQL_USR = "root";
$MYSQL_DBI = "syslog";
$MYSQL_PWD = "MUJEczlKY1hiMzhEUm1BbkJRa3J5UT09";

$S_KEY = "This is my SECRET key";
$S_IV = "This is my SECRET iv";

?>
