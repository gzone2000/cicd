<?php
include "session_chk.inc" ;
include "ip.inc" ;

$PNAME = trim($_POST['PNAME']);
$PLAYBOOK = trim($_POST['PLAYBOOK']);
$PLAYBOOK = urldecode($PLAYBOOK);
$PLAYBOOK = base64_encode($PLAYBOOK);
$EXPALIN = trim($_POST['EXPALIN']);
$EXPALIN = base64_encode($EXPALIN);
$GUBUN = trim($_POST['GUBUN']);
$GUBUN1 = trim($_POST['GUBUN1']);
$GUBUN2 = trim($_POST['GUBUN2']);

#$PLAYBOOK_DEC = base64_decode($PLAYBOOK);
#echo "# Argument: PNAME > {$PNAME}<br>";
#echo "# Argument: PLAYBOOK > {$PLAYBOOK}<br>";
#echo "# Argument: PLAYBOOK Decoding > {$PLAYBOOK_DEC}<br>";
#echo "# Argument: EXPALIN > {$EXPALIN}<br>";
#echo "# Argument: GUBUN > {$GUBUN}<br>";


		if (mysqli_connect_errno()) {
        		printf("Connect failed: %s\n", mysqli_connect_error());
        		exit();
		} 
		else {

			# update playbook
			$FULLURL = "./ansible_window_playbook_CRUD.php?mod=$PNAME";

			$select_sql = "select p_name from Ansible_window_playbook where p_name = '{$PNAME}'" ;
			$res5 = mysqli_query($mysqli,$select_sql);
			//echo "# SQL: {$select_sql} " ;

			$data = mysqli_fetch_array($res5);
			$isset_num = $data['p_name'];

			if (isset($isset_num)) {

				# Update Ansible_window_playbook table
				$update_sql = "UPDATE Ansible_window_playbook set p_explain = '{$EXPALIN}' , p_content = '{$PLAYBOOK}' , p_gubun = '{$GUBUN}' , p_gubun1 = '{$GUBUN1}', p_gubun2 = '{$GUBUN2}' where p_name = '{$PNAME}'" ;
				$res = mysqli_query($mysqli,$update_sql);
				#echo "# SQL : {$update_sql} , Result : $res";
				#echo "<br>";

				header('Location: '.$FULLURL);

				mysqli_free_result($res);
				mysqli_close($mysqli); 
			}
			else {
				# add=2 : Playbook Not Found
				$FULLURL = "./ansible_window_playbook_CRUD.php?mod=2";
				#echo "# URL : {$FULLURL}";

				header('Location: '.$FULLURL);
			}
		}


?> 
