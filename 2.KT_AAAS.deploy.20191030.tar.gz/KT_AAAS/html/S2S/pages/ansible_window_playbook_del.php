<?php
include "session_chk.inc" ;

$P_NAME = trim($_POST['P_NAME']);
//echo "# Argument: Playbook Name > {$P_NAME}<br>";


	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		# delete Playbook
		$FULLURL = "./ansible_window_playbook_CRUD.php?del=$P_NAME";

		$select_sql = "select p_name from Ansible_window_playbook where p_name = '{$P_NAME}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		//echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['p_name'];

		if (isset($isset_num)) {

			# delete Ansible_window_playbook table
			$delete_sql = "delete from Ansible_window_playbook where p_name = '{$P_NAME}'" ;
			$res = mysqli_query($mysqli,$delete_sql);
			//echo "# SQL : {$delete_sql} , Result : $res";
			//echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			# del=2 : playbook not found
			$FULLURL = "./ansible_window_playbook_CRUD.php?del=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}

?> 
