<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->


<script>
function myFunction() {
    var text1 = document.getElementById('PLAYBOOK_CR').value;
    var playname = document.getElementById('NAME3').value;
    var explain = document.getElementById('EXPLAIN3').value;
    var gubun = document.getElementById('GUBUN3').value;
    var gubun1 = document.getElementById('GUBUN1').value;
    var gubun2 = document.getElementById('GUBUN2').value;

    document.getElementsByName("NAME3")[0].disabled = true;
    document.getElementsByName("EXPLAIN3")[0].disabled = true;
    document.getElementsByName("GUBUN3")[0].disabled = true;
    document.getElementsByName("GUBUN1")[0].disabled = true;
    document.getElementsByName("GUBUN2")[0].disabled = true;

    if( text1 != "") {

	text1 = text1.replace(/>/g,'UUcU');
	text1 = text1.replace(/</g,'UUeU');

        var url1 = './ansible_window_playbook_syntax_chk.php';
        var form = document.createElement("form");

        form.setAttribute("method","post");
        form.setAttribute("action",url1);

        var hiddenField1 = document.createElement("input");
        hiddenField1.setAttribute("type","hidden");
        hiddenField1.setAttribute("name","action");
        hiddenField1.setAttribute("value","check");
        form.appendChild(hiddenField1);

        var hiddenField2 = document.createElement("input");
        hiddenField2.setAttribute("type","hidden");
        hiddenField2.setAttribute("name","PNAME");
        hiddenField2.setAttribute("value",playname);
        form.appendChild(hiddenField2);

        var hiddenField3 = document.createElement("input");
        hiddenField3.setAttribute("type","hidden");
        hiddenField3.setAttribute("name","EXPALIN");
        hiddenField3.setAttribute("value",explain);
        form.appendChild(hiddenField3);

        var hiddenField4 = document.createElement("input");
        hiddenField4.setAttribute("type","hidden");
        hiddenField4.setAttribute("name","GUBUN");
        hiddenField4.setAttribute("value",gubun);
        form.appendChild(hiddenField4);

        var hiddenField5 = document.createElement("input");
        hiddenField5.setAttribute("type","hidden");
        hiddenField5.setAttribute("name","GUBUN1");
        hiddenField5.setAttribute("value",gubun1);
        form.appendChild(hiddenField5);

        var hiddenField6 = document.createElement("input");
        hiddenField6.setAttribute("type","hidden");
        hiddenField6.setAttribute("name","GUBUN2");
        hiddenField6.setAttribute("value",gubun2);
        form.appendChild(hiddenField6);

        var hiddenField7 = document.createElement("input");
        hiddenField7.setAttribute("type","hidden");
        hiddenField7.setAttribute("name","PLAYBOOK");
        hiddenField7.setAttribute("value",encodeURIComponent(text1));
        form.appendChild(hiddenField7);

        document.body.appendChild(form);
        form.submit();

    }
    else {
	alert("Playbook 항목이 비어 있습니다. 확인바랍니다!!");
    }

    document.getElementsByName("btn5_chk")[0].disabled = false;
}
</script>




</head>

<body>



<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>


<?php

	$P_NAME = trim($_GET['P_MOD']);
        $cmd_sql = "select * from Ansible_window_playbook where p_name = '{$P_NAME}'";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                        $newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
                        $p_name = $newArray['p_name'];
                        $p_explain= $newArray['p_explain'];
                        $p_explain_dec = base64_decode($p_explain);
                        $p_content = $newArray['p_content'];
                        $p_content_dec = base64_decode($p_content);
                        $p_gubun = $newArray['p_gubun'];
                        $p_gubun1 = $newArray['p_gubun1'];
                        $p_gubun2 = $newArray['p_gubun2'];

			$SELECT_STR5 = '';
                        $cmd_sql5 = "select * from Ansible_playbook_gubun";
                        $res5 = mysqli_query($mysqli,$cmd_sql5);
                	if ($res5) {
				$cnt=1;
                        	while ($newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                                	$gubun5 = $newArray5['gubun'];
                                	$gubun_name5 = $newArray5['gubun_name'];

					if($p_gubun == $gubun5) $SELECT_OPT = "selected";
					else $SELECT_OPT = '';

					$STR5 = "<option value=$cnt $SELECT_OPT>$gubun_name5</option>";
					$SELECT_STR5 = $SELECT_STR5 . $STR5 ;

					$cnt = $cnt + 1;
				}
			}

                        $SELECT_STR9 = '';
                        $cmd_sql9 = "select * from Ansible_playbook_gubun1";
                        $res9 = mysqli_query($mysqli,$cmd_sql9);
                        if ($res9) {
                                $cnt=1;
                                while ($newArray9 = mysqli_fetch_array($res9,MYSQLI_ASSOC)) {
                                        $gubun9 = $newArray9['gubun'];
                                        $gubun_name9 = $newArray9['gubun_name'];

                                        if($p_gubun1 == $gubun9) $SELECT_OPT = "selected";
                                        else $SELECT_OPT = '';

                                        $STR9 = "<option value=$cnt $SELECT_OPT>$gubun_name9</option>";
                                        $SELECT_STR9 = $SELECT_STR9 . $STR9 ;

                                        $cnt = $cnt + 1;
                                }
                        }

                        $SELECT_STR7 = '';
                        $cmd_sql7 = "select * from Ansible_playbook_gubun2";
                        $res7 = mysqli_query($mysqli,$cmd_sql7);
                        if ($res7) {
                                $cnt=1;
                                while ($newArray7 = mysqli_fetch_array($res7,MYSQLI_ASSOC)) {
                                        $gubun7 = $newArray7['gubun'];
                                        $gubun_name7 = $newArray7['gubun_name'];

                                        if($p_gubun2 == $gubun7) $SELECT_OPT = "selected";
                                        else $SELECT_OPT = '';

                                        $STR7 = "<option value=$cnt $SELECT_OPT>$gubun_name7</option>";
                                        $SELECT_STR7 = $SELECT_STR7 . $STR7 ;

                                        $cnt = $cnt + 1;
                                }
                        }

        }

	$p_content_dec = str_replace("UUcU",">",$p_content_dec);
	$p_content_dec = str_replace("UUeU","<",$p_content_dec);

	echo "

			 <div id='P_mod' class='row'>
                            <div class='col-lg-3'>
                              <div class='label_warning' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
                               <tr><td style='height:33px'><font size=3><b>Playbook 수정하기&nbsp;&nbsp;&nbsp;</b></font></td>
                               </table>

                              </div>
                            </div>

                            <div class='col-lg-9'>
                            </div>
			 </div>


                      <div id=wrapper>
                        <div class='panel-body'>
            		  <div class='row'>
                	    <div class='col-lg-4'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>'$P_NAME' playbook 수정하기</font></b>
                              </div>

<textarea rows=16 cols=100 id=PLAYBOOK_CR form='usrform'>$p_content_dec</textarea>

                	    </div>

                	    <div class='col-lg-2'>
                	    </div>

                	    <div class='col-lg-6'>


                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>수정할 playbook 문법 체크</font></b>
                              </div>

			      <br>
			      <table border=1>
			      <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 이름: </label></td>
			      <td width=400><input id=NAME3 name=NAME3 type='text' class='form-control' name=PNAME value='{$p_name}' readonly></td>
			      <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 설명: </label></td>
			      <td width=400><input id=EXPLAIN3 name=EXPLAIN3 type='text' class='form-control' name=EXPALIN value='{$p_explain_dec}'></td><td></td></tr>
			      <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 구분: </label></td>
			      <td width=400><select id=GUBUN3 name=GUBUN3 class=form-control>
			      {$SELECT_STR5}
			      </select></td><td></td></tr>

                              <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 분류: </label></td>
                              <td width=400><select class=form-control id=GUBUN1 name=GUBUN1>
                              {$SELECT_STR9}
                              </select></td><td></td></tr>

                              <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 사용범위: </label></td>
                              <td width=400><select class=form-control id=GUBUN2 name=GUBUN2>
                              {$SELECT_STR7}
                              </select></td><td></td></tr>

			      <tr><td align=center colspan=3>
			      <button type=submit id=btn5_chk name=btn5_chk class='btn btn-success' style='width:100%' onclick='myFunction()'>Playbook 문법체크 Click!!</button>
			      </td></tr>
			      </table>


                                  <div id='txt5'>
                                  </div>

<div id='wait' style='display:none;position:absolute;top:230px;left:60px;padding:2px;'>
<img src='../vendor/login/loading2.gif' width=110 height=110 />
<br>
<font size=4 color=red><b> Loading...</b></font>
</div>



			    </div>

            		  </div> 
                        </div'> 
                      </div>
	";



?>




    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




