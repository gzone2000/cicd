<?php
include "session_chk.inc" ;

$FNAME = trim($_POST['FNAME']);
$EXPALIN_ORG = trim($_GET['EXPALIN']);
$EXPALIN = base64_encode($EXPALIN_ORG);
$GUBUN = trim($_POST['GUBUN']);
$GUBUN1 = trim($_POST['GUBUN1']);
$PLAYBOOKLIST = trim($_POST['PLAYBOOKLIST']);
$MEMBERLIST = trim($_POST['MEMBERLIST']);
//echo "# Argument: FNAME > {$FNAME}<br>";
//echo "# Argument: EXPALIN > {$EXPALIN}<br>";
//echo "# Argument: PLAYBOOKLIST > {$PLAYBOOKLIST}<br>";
//echo "# Argument: MEMBERLIST > {$MEMBERLIST}<br>";
//echo "# Argument: EXPALIN_ORG > {$EXPALIN_ORG}<br>";


	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

                # insert flow
		$FULLURL = "./ansible_linux_playbookflow_oyw.php?add=$FNAME";

                $select_sql = "select f_name from Ansible_linux_playbookflow_Save2 where f_name = '{$FNAME}'" ;
                $res5 = mysqli_query($mysqli,$select_sql);
                #echo "# SQL: {$select_sql} " ;

                $data = mysqli_fetch_array($res5);
                $isset_num = $data['f_name'];

                if (!isset($isset_num)) {

			$TOTAL_STR = '';
			$STR = '';

			$insert_sql = "INSERT into Ansible_linux_playbookflow_Save2(f_name,f_explain,f_playbook_list,f_member_list,f_gubun,f_gubun1) values ('{$FNAME}', '{$EXPALIN}', '{$PLAYBOOKLIST}', '{$MEMBERLIST}', '{$GUBUN}', '{$GUBUN1}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			//echo "# SQL : {$insert_sql} , Result : $res <br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 

                }
                else {
                        # add=2 : host or ip duplicate : Fail
                        $FULLURL = "./ansible_linux_playbookflow_oyw.php?add=2";
                        #echo "# URL : {$FULLURL}";
                        header('Location: '.$FULLURL);
                }

	}

?> 
