<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>



</head>

<body>


<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>





<?php

        $FID = trim($_GET['FID']);
        $cmd_sql = "select * from Ansible_linux_playbookflow_history2 where flow_id = '{$FID}'";
        $res = mysqli_query($mysqli,$cmd_sql);

        $newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
        $f_name = $newArray['f_name'];
        $f_playbook_list = $newArray['f_playbook_list'];
        $f_member_list = $newArray['f_member_list'];


	echo "

            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div id='P_mod' class='panel-body'>


			 <div class='row'>
                            <div class='col-lg-5'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table id=table1 value='$F_NAME'>
                               <tr><td style='height:33px'><font size=3>Flow 이름:&nbsp;$F_NAME</font></td></tr>
                               </table>

                              </div>
                            </div>

                            <div class='col-lg-7'>
                            </div>
			 </div>


                      <div id=wrapper>
                        <div class='panel-body'>

            		  <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_danger' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Flow 실행 Host, Group 리스트</font></b>
                              </div>
			    </div>
                            <div class='col-lg-9'>
			    </div>
		          </div>

            		  <div class='row'>
                	    <div class='col-lg-10'>
	";

	
		// Host, Group List display //
		$HOST_LIST = '';
		$G_LIST = '';
        	$T_MEMBER = explode('|',$f_member_list);
        	foreach($T_MEMBER as $SubMember) {

                	$NODENAME = $SubMember;

                	$cmd_sql = "select * from Ansible_linux_host where nodename = '{$NODENAME}'";
                	$res = mysqli_query($mysqli,$cmd_sql);

                       	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
                	$data = mysqli_fetch_array($res);
                        $hostname = $newArray['hostname'];

                	if (isset($hostname)) {

                                $hostname = $newArray['hostname'];
                                $nodename= $newArray['nodename'];
                                $ip = $newArray['ip'];
				if(!$HOST_LIST) $HOST_LIST = "<a title='Nodename: {$nodename}\nIP: {$ip}'>" . $hostname . "</a>";
			else $HOST_LIST = $HOST_LIST . "&nbsp;<font color=red><b>,</b></font>&nbsp;" . "<a title='Nodename: {$nodename}\nIP: {$ip}'>" . $hostname . "</a>";
			}
			else {
				if(!$G_LIST) $G_LIST = $NODENAME;
				else $G_LIST = $G_LIST . '|' . $NODENAME;
			}
		}

		if($G_LIST) {

			$GROUP_LIST = '';
                	$G_MEMBER = explode('|',$G_LIST);
                	foreach($G_MEMBER as $SubGroup) {

                        	$GROUPNAME = $SubGroup;

                        	$cmd_sql = "select * from Ansible_linux_group where groupname = '{$GROUPNAME}'";
                        	$res = mysqli_query($mysqli,$cmd_sql);
                        	if ($res) {
                                	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);

                                	$groupname = $newArray['groupname'];
                                	$member= $newArray['member'];

					$SubGroup_Member_list = '';
					$G_member = explode('|',$member);
					foreach($G_member as $subgroup_member) {
						if(!$SubGroup_Member_list) $SubGroup_Member_list = $subgroup_member;
						else $SubGroup_Member_list = $SubGroup_Member_list . "\n" . $subgroup_member;
					}

					if(!$GROUP_LIST) $GROUP_LIST = "<a title='{$SubGroup_Member_list}'>" . $groupname . "</a>";
					else $GROUP_LIST =  $GROUP_LIST . "&nbsp;<font color=red><b>,</b></font>&nbsp;" . "<a title='{$SubGroup_Member_list}'>" . $groupname . "</a>";

				}
			}

		}


		if($HOST_LIST or $GROUP_LIST) {

			echo "<table border=1 width='100%' class='table table-striped table-bordered table-hover'>";
			if($HOST_LIST and $GROUP_LIST) {
				echo "
				<tr><td>ㅇ 호스트 리스트: </td>
				<td>$HOST_LIST</td></tr>
				<tr><td>ㅇ 그룹 리스트: </td>
				<td>$GROUP_LIST</td></tr>
				";

			}
			else if($HOST_LIST) {
				echo "
				<tr><td>ㅇ 호스트 리스트: </td>
				<td>$HOST_LIST</td></tr>
				";
			}
			else if($GROUP_LIST) {
				echo "
				<tr><td>ㅇ 그룹 리스트: </td>
				<td>$GROUP_LIST</td></tr>
				";
			}

			echo "</table>";

		}






	echo "
			    </div>
                	    <div class='col-lg-2'>
			    </div>

		 	    <div id='Inventory_Modify_Div'>
		 	    </div>


			  </div>
			  
			  <br>

            		  <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_warning' style='margin-bottom: 5px;padding: 4px 12px;'>
				  <table>
                                  <tr><td width=400><b><font size=3>Flow 관련 Playbook 리스트</font></b></td></tr>
				  </table>
                              </div>
			    </div>
                            <div class='col-lg-9'>
			    </div>
			  </div>

            		  <div class='row'>
                	    <div class='col-lg-10'>
				<div id='txt1'>

                                <div class='table-responsive'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>순서</th>
                                        <th>Playbook<br>구분</th>
                                        <th>Playbook<br>분류</th>
                                        <th>Playbook 이름</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable_flow_mod'>

        ";

	$TMP_CNT = 1;
        $T_FLOW = explode('|',$f_playbook_list);
        foreach($T_FLOW as $SubFlow) {

                $P_NAME = $SubFlow;

                $cmd_sql = "select * from Ansible_linux_playbook where p_name = '{$P_NAME}'";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                                $newArray = mysqli_fetch_array($res,MYSQLI_ASSOC) ;

                                $p_name = $newArray['p_name'];
                                $p_explain= $newArray['p_explain'];
                                $p_explain= base64_decode($p_explain);
                                $p_gubun = $newArray['p_gubun'];
                                $p_gubun1 = $newArray['p_gubun1'];

				if($BEFPLAYBOOK == $p_name) {
					$p_name = $SELECTPLY;
					$BTN_STR1 = "btn btn-danger btn-xs";

                			$cmd_sql1 = "select * from Ansible_linux_playbook where p_name = '{$p_name}'";
                			$res1 = mysqli_query($mysqli,$cmd_sql1);
                			if ($res) {
                                		$newArray1 = mysqli_fetch_array($res1,MYSQLI_ASSOC) ;
                                		$p_explain= $newArray1['p_explain'];
                                		$p_explain= base64_decode($p_explain);
                                		$p_gubun = $newArray1['p_gubun'];
                                		$p_gubun1 = $newArray1['p_gubun1'];
					}

				}
                                else {
					$p_name = $newArray['p_name'];
					$BTN_STR1 = "btn btn-success btn-xs";
				}

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                                echo "<tr id='ROW{$TMP_CNT}'><td>$TMP_CNT</td><td>$gubun_name</td><td>$gubun_name1</td><td><a title='{$p_explain}'><button id=PLY_NAME name=$p_name class='{$BTN_STR1}' onclick='popitup_ply1(\"$p_name\")'>$p_name</button></a></td></tr>";
                }

		$TMP_CNT = $TMP_CNT + 1;

        }

                echo "</tbody>";
                echo "</table>";
                echo "</div>";

?>




<?php
	echo "


                                </div>
				<div class='col-lg-2'>
                                </div>
                              </div>




                         </div>

			</div>






        ";


?>



                    </div>


                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




