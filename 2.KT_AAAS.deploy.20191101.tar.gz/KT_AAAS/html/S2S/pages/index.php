<?php
include "session_chk.inc" ;
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="refresh" content="600">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->


    <!-- Charts.js -->
    <script src="../vendor/chart/Chart.bundle.js"></script>
    <script src="../vendor/chart/utils.js"></script>
    <style>
    canvas{
             -moz-user-select: none;
             -webkit-user-select: none;
             -ms-user-select: none;
    }
    </style>


<script type="text/javascript" src="../vendor/jquery/jquery.min.js"></script>
<script type="text/javascript">
    var auto_refresh = setInterval(
    function ()
    {

<?php
                echo "$('#content_sub_all1').load('./index_panel.php');" ;
?>

    }, 10000); // refresh every 10000 milliseconds
</script>


</head>

<body>


<?php

if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

?>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->





            <ul class="nav navbar-top-links navbar-right">

		<li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
		</li>




                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->

        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Dashboard</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>





            <!-- /.row -->
            <div id="content_sub_all1" class="row">

                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tasks fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">

<?php

$sql = "select count(*) as count from Ansible_linux_host";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$linux_totalcount  = $row["count"];

$sql = "select count(*) as count from Ansible_window_host";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$window_totalcount  = $row["count"];

                                    echo "<div class=huge>$linux_totalcount/$window_totalcount</div>";

?>

                                    <div><b>Inventory Count (Linux / Window)</b></div>
                                </div>
                            </div>
                        </div>
                        <a href="./ansible_linux_inventory_search.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-warning fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">

<?php

$sql = "select count(*) as count from Ansible_linux_playbook";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$linux_plybookcount  = $row["count"];

$sql = "select count(*) as count from Ansible_window_playbook";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$window_plybookcount  = $row["count"];

                                    echo "<div class=huge>$linux_plybookcount/$window_plybookcount</div>";

?>

                                    <div><b>Playbook Count (Linux / Window)</b></div>
                                </div>
                            </div>
                        </div>
                        <a href="./ansible_linux_playbook_CRUD.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-rocket fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">

<?php

$sql = "select count(*) as count from Ansible_linux_playbookflow_Save2";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$linux_flowcount = $row["count"];

$sql = "select count(*) as count from Ansible_window_playbookflow_Save2";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$window_flowcount = $row["count"];

                                    echo "<div class=huge>$linux_flowcount/$window_flowcount</div>";

?>


                                    <div><b>Flow Count (Linux / Window)</b></div>
                                </div>
                            </div>
                        </div>
                        <a href="./ansible_linux_playbookflow_oyw.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>



                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-rocket fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">

<?php

$sql = "select count(*) as count from Ansible_linux_playbookflow_cron";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$linux_croncount  = $row["count"];

$sql = "select count(*) as count from Ansible_window_playbookflow_cron";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$window_croncount  = $row["count"];

                                    echo "<div class=huge>$linux_croncount/$window_croncount </div>";

?>


                                    <div><b>Cron Count (Linux / Window)</b></div>
                                </div>
                            </div>
                        </div>
                        <a href="./ansible_linux_playbookflow_cron.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>


            </div>
            <!-- /.row -->










            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Playbook, Flow Status Line Chart (30일간)
                            <div class="pull-right">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                                        Actions
                                        <span class="caret"></span>
                                    </button>
                                </div>
                            </div>

                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">




	<div id='charts.js'>
		<canvas id="canvas"></canvas>
	</div>

<?php

$DAYS = -30;
$INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));

$sql = "select s_date, (s_playbook_exe_lin + s_playbook_exe_win) as playbook_cnt from Ansible_statistic where s_date >= '{$INPUT_DATE}' order by s_date asc";
$res = mysqli_query($mysqli,$sql);

if ($res) {

	$CNT = 0;
	$Date_Str = '';
	$Count_Str = '';
	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                $date = $newArray['s_date'];
		$count = $newArray['playbook_cnt'];

        	if ($CNT == 0) {
                	$Date_Str = '\'' . $date . '\'';
                	$Count_Str = $count;
        	}
        	else {
                	$Date_Str = $Date_Str . ',' . '\'' . $date . '\'';
                	$Count_Str = $Count_Str . ',' . $count;
        	}

        	$CNT = $CNT + 1;

	}

}



$sql = "select s_date, (s_flow_exe_lin + s_flow_exe_win) as flow_cnt from Ansible_statistic where s_date >= '{$INPUT_DATE}' order by s_date asc";
$res = mysqli_query($mysqli,$sql);

if ($res) {

        $CNT = 0;
        $Date_Str1 = '';
        $Count_Str1 = '';
        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                $date = $newArray['s_date'];
                $count= $newArray['flow_cnt'];

                if ($CNT == 0) {
                        $Date_Str1 = '\'' . $date . '\'';
                        $Count_Str1 = $count;
                }
                else {
                        $Date_Str1 = $Date_Str1 . ',' . '\'' . $date . '\'';
                        $Count_Str1 = $Count_Str1 . ',' . $count;
                }

                $CNT = $CNT + 1;

        }

}



?>

	<script>
		var config = {
			type: 'line',
			data: {
<?php
				echo "labels: [{$Date_Str}],";
?>
				datasets: [{
					label: 'Playbook Run 건수',
					backgroundColor: window.chartColors.red,
					borderColor: window.chartColors.red,
					data: [
<?php
						echo "$Count_Str";
?>
					],
					fill: false,
				}, {
					label: 'Flow Run 건수',
					fill: false,
					backgroundColor: window.chartColors.blue,
					borderColor: window.chartColors.blue,
					data: [
<?php
						echo "$Count_Str1";
?>
					],
				}]
			},
			options: {
				responsive: true,
				title: {
					display: true,
					text: ''
				},
				tooltips: {
					mode: 'index',
					intersect: false,
				},
				hover: {
					mode: 'nearest',
					intersect: true
				},
				scales: {
					xAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Month'
						}
					}],
					yAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Value'
						}
					}]
				}
			}
		};

		window.onload = function() {
			var ctx = document.getElementById('canvas').getContext('2d');
			window.myLine = new Chart(ctx, config);
		};

	</script>


                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-8 -->



                <div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-table fa-fw"></i> 최근에 실행된 Flows  
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

			  <div class="table-responsive scrollClass">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Flow Name</th>
                                        <th>Time</th>
                                    </tr>
                                </thead>
                                <tbody>



<?php

$INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));

$sql = "select * from (
select * from (
select f_name, flow_starttime from Ansible_linux_playbookflow_history2 order by flow_starttime desc limit 12) AS a1 
union all 
select * from (
select f_name, flow_starttime from Ansible_window_playbookflow_history2 order by flow_starttime desc limit 12) AS a2
) AS a3 
order by flow_starttime desc limit 12";
$res = mysqli_query($mysqli,$sql);

if ($res) {

        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                $f_name = $newArray['f_name'];
                $flow_starttime= $newArray['flow_starttime'];
	
                        echo "<tr>";
                        echo "<td>{$f_name}</td><td>{$flow_starttime}</td>";
                        echo "</tr>";
                }
        }


?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
			  </div>




                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->




        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
