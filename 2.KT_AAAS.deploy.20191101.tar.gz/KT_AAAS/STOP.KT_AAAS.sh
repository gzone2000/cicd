docker stop KT_AAAS
