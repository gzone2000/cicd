#!/bin/bash

START="NO"
FILE=$1
IFS='
'
T_HOST_SUM=0
S_HOST_SUM=0
F_HOST_SUM=0
S_HOST_CNT=0
F_HOST_CNT=0
SUCC_HOST=''
FAIL_HOST=''

for LINE in $(cat $FILE | grep '| rc=')
do

HOST=$(echo $LINE | awk '{print $1}')
SUCC=$(echo $LINE | awk '{print $5}' | awk -F'=' '{print $2}')

if [[ $SUCC -eq 0 ]] ; then
        S_HOST_CNT=$((S_HOST_CNT+1))
        if [ $S_HOST_SUM -eq 0 ] ; then
                SUCC_HOST=$HOST
        else
                SUCC_HOST=$(echo "${SUCC_HOST}|${HOST}")
        fi
        S_HOST_SUM=$((S_HOST_SUM+1))
else
        F_HOST_CNT=$((F_HOST_CNT+1))
        if [ $F_HOST_SUM -eq 0 ] ; then
                FAIL_HOST=$HOST
        else
                FAIL_HOST=$(echo "${FAIL_HOST}|${HOST}")
        fi
        F_HOST_SUM=$((F_HOST_SUM+1))
fi

done

echo "$S_HOST_CNT:$F_HOST_CNT:$SUCC_HOST:$FAIL_HOST"
