<?php
include "session_chk.inc" ;


$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$P_NAME = $_GET['P_NAME'];
$content_dec = base64_decode($content);
//echo "# Argument: playbook content (encode) > {$content}<br>";
//echo "# Argument: playbook content (decode) > {$content_dec}<br>";

echo "<html>";
echo "<body>";

if($P_NAME) {
	$cmd_sql5 = "select * from Ansible_window_playbook where p_name = '{$P_NAME}'";
	$res5 = mysqli_query($mysqli,$cmd_sql5);
	if ($res5) {
        	$newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
        	$p_content = $newArray5['p_content'];
		$content_dec = base64_decode($p_content);
		$content_dec = str_replace("UUcU",">",$content_dec);
                $content_dec = str_replace("UUeU","&lt;",$content_dec);

	}
}


echo "<pre>$content_dec</pre>";

echo "</body>";
echo "</html>";

?> 
