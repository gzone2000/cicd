<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$FLOW = trim($_POST['FLOW']);
$MIN = trim($_POST['MIN']);
$EVERY_MIN_CHK = trim($_POST['EVERY_MIN_CHK']);
$HOUR = trim($_POST['HOUR']);
$EVERY_HOUR_CHK = trim($_POST['EVERY_HOUR_CHK']);
$DAY = trim($_POST['DAY']);
$MONTH = trim($_POST['MONTH']);
$WEEK = trim($_POST['WEEK']);
$MAIL_SEND = trim($_POST['MAIL_SEND']);
$COMMAND = trim($_POST['COMMAND']);

if (!$COMMAND) {
	$FULLURL = "./ansible_window_playbookflow_cron.php?FLOW={$FLOW}&add=1";
	#echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {
        
	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		$FULLURL = "./ansible_window_playbookflow_cron.php?FLOW={$FLOW}&add=9999";

		$select_sql = "select c_num from Ansible_window_playbookflow_cron where c_num = '{$NUM}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['c_num'];

		if (!isset($isset_num)) {

			if(!$EVERY_MIN_CHK) $EVERY_MIN_CHK = 'N';
			if(!$EVERY_HOUR_CHK) $EVERY_HOUR_CHK = 'N';

			# 설정 추가 화면
			# Insert Ansible_window_playbookflow_cron table
			$insert_sql = "INSERT into Ansible_window_playbookflow_cron values ('{$NUM}', '{$MIN}', '{$EVERY_MIN_CHK}', '{$HOUR}', '{$EVERY_HOUR_CHK}','{$DAY}','{$MONTH}','{$WEEK}','{$COMMAND}','{$MAIL_SEND}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			#echo "# SQL : {$insert_sql} , Result : $res";
			#echo "<br>";

			// Cron Add //

                	$LINE_CNT = shell_exec("crontab -l | grep 'WIN_{$NUM}_LINE' | wc -l");
                	if($LINE_CNT == 0) {
                        	if($EVERY_MIN_CHK == 'Y' and $MIN != '*') $MIN = '*/' . $MIN;
                        	if($EVERY_HOUR_CHK == 'Y' and $HOUR != '*') $HOUR = '*/' . $HOUR;

				$CRON_EXEC_STR1 = "/var/www/html/S2S/pages/ansible_window_playbookflow_CronExec.php $COMMAND $MAIL_SEND WIN_{$NUM}_LINE";
				$CRON_STR1 = $MIN . " " . $HOUR . " " . $DAY . " " . $MONTH . " " . $WEEK . " " . "php $CRON_EXEC_STR1 ";

				$EXEC_STR1 = "(crontab -l 2>/dev/null; echo \"$CRON_STR1\") | crontab -";
                		$RESULT = shell_exec("$EXEC_STR1");
			}

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			$FULLURL = "./ansible_window_playbookflow_cron.php?FLOW={$FLOW}&add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}
}

?> 
