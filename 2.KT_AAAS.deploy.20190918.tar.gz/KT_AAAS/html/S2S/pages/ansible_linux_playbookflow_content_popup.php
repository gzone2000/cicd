<?php
include "session_chk.inc" ;
include "sidemenu.php" ;
?> 

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>


            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$FNAME = $_GET['name'];
$sql="SELECT f_content FROM Ansible_linux_playbookflow_Save WHERE f_name='{$FNAME}'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$f_content  = $row["f_content"];


                        echo "<table>";
                        echo "<tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Flow 이름: $FNAME</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->


                        <div class="panel-body">
                          <div class="row">
                            <div class="col-lg-12">

<?php
			$MAX=$FLOW_MAX;
			
                        echo "<table border=0>";
                        echo "<tr align=center>";
			for($x=1;$x <= $MAX; $x++) {
				echo "<td><button class='btn btn-info' style='cursor:auto'>{$x}</button></td><td height=37 width=300><button style='width:100%;cursor:auto' id=button_playbook{$x} class='btn btn-warning'>Playbook</button></td>";
				if($x != $MAX) echo "<td width=70 rowspan=2><img src='../vendor/login/arrow_red.png' height=30 width=30>";
			}
                        echo "</tr>";


                        echo "<tr align=center>";
			for($x=1;$x <= $MAX; $x++) {
                        	echo "<td colspan=2 height=37 width=300><button style='width:100%;cursor:auto' id='button_inventory{$x}' class='btn btn-success'>Inventory</button></td>";
			}
                        echo "</tr>";
                        echo "</table>";


        echo "<script>";

	$FLOW = explode('||',$f_content);
	foreach($FLOW as $SubFlow) {
		$SUBFLOW = explode('|',$SubFlow);
		$STEP = $SUBFLOW[0];
		$P_NAME = $SUBFLOW[1];
		$MEMBERS = $SUBFLOW[2];
		$member_display1= str_replace(",","<br>",$MEMBERS);
                echo "document.getElementById('button_playbook{$STEP}').innerHTML = '{$P_NAME}';";
                echo "document.getElementById('button_inventory{$STEP}').innerHTML = '{$member_display1}';";

	}

        echo "</script>";


?>





                            </div>
                          </div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>








