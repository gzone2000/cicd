<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
include "ip.inc" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>


<?php

function dec_enc($action, $string, $secret_key, $secret_iv) {
    $output = false;

    $encrypt_method = "AES-256-CBC";

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}


$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];



	date_default_timezone_set("Asia/Seoul");
        $MEMBER_LIST = htmlspecialchars($_GET['member']);
        $MEMBER_LIST = str_replace("'","",$MEMBER_LIST);

        $COMMAND = trim(base64_decode($_GET['command']));
	$COMMAND = preg_replace("/[<>]/","",$COMMAND);
        $COMMAND = str_replace("'","\"",$COMMAND);
	$CNT1=substr_count($COMMAND,'"');
	$CNT2=substr_count($COMMAND,'\'');
	if ($CNT1 % 2 or $CNT2 % 2) $COMMAND = addslashes($COMMAND);

        if ($COMMAND != '' and $MEMBER_LIST !='')
	{


/*

# Ansible Directory
$ANSIBLE_DIR = "/home/ansible";
$ANSIBLE_PLAYBOOK_DIR = "$ANSIBLE_DIR/playbook";
$ANSIBLE_HOST_DIR = "$ANSIBLE_DIR/host";
$ANSIBLE_LOG_DIR = "$ANSIBLE_DIR/log";
$ANSIBLE_EXEC_DIR = "$ANSIBLE_DIR/exec";

*/


		$PIECES = explode(",", $MEMBER_LIST);

                $cnt = 0;
		$HOST_STR = '';
		$HOST_STR_T = '';
                while ($PIECES[$cnt]) {

			//host
                        $cmd_sql1 = "select * from Ansible_linux_host where nodename = '$PIECES[$cnt]'";
                        $res1 = mysqli_query($mysqli,$cmd_sql1);

                	$data = mysqli_fetch_array($res1);
                	$isset_check1 = $data['nodename'];

                	if ($isset_check1 != '') {
                                $hostname = $data['hostname'];
                                $nodename = $data['nodename'];
                                $ip = $data['ip'];
				$port = $data['port'];

                                // Linux RSA , ID/PWD
                                if ($data['username'] and $data['password']) {
                                        $ID_PWD = 'Y';
                                        $username = $data['username'];
                                        $password = dec_enc('decrypt',$data['password'],$S_KEY,$S_IV);
                                        $HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_user=$username ansible_ssh_pass='$password' ansible_port=$port\n";
                                        $HOST_STR_T = $HOST_STR_T . "$nodename ansible_host=$ip ansible_user=$username ansible_ssh_pass=********* ansible_port=$port\n";
                                }
                                else {
                                        $HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_ssh_port=$port \n";
                                        $HOST_STR_T = $HOST_STR_T . "$nodename ansible_host=$ip ansible_ssh_port=$port \n";
                                }
                        }
			else {
				//group
                        	$cmd_sql1 = "select * from Ansible_linux_group where groupname = '$PIECES[$cnt]'";
                        	$res1 = mysqli_query($mysqli,$cmd_sql1);
                		$data = mysqli_fetch_array($res1);
                		$isset_check1 = $data['groupname'];

                		if ($isset_check1 != '') {

					$HOST_STR = $HOST_STR . "\n";
					$HOST_STR = $HOST_STR . "[{$PIECES[$cnt]}]\n";
                                	$groupname = $data['groupname'];
                                	$member5= $data['member'];
					$PIECES5 = explode("|", $member5);

                        		$cnt5 = 0;
                        		while ($PIECES5[$cnt5]) {

                                		$cmd_sql1 = "select * from Ansible_linux_host where nodename = '$PIECES5[$cnt5]'";
                                		$res1 = mysqli_query($mysqli,$cmd_sql1);
                				$data = mysqli_fetch_array($res1);
                				$isset_check1 = $data['nodename'];

                				if ($isset_check1 != '') {
                                        		$hostname = $data['hostname'];
                                        		$nodename= $data['nodename'];
                                        		$ip = $data['ip'];
							$port = $data['port'];

                                                        // Linux RSA , ID/PWD
                                                        if ($data['username'] and $data['password']) {
                                                                $ID_PWD = 'Y';
                                                                $username = $data['username'];
                                                                $password = dec_enc('decrypt',$data['password'],$S_KEY,$S_IV);
                                                                $HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_user=$username ansible_ssh_pass='$password' ansible_port=$port\n";
                                                                $HOST_STR_T = $HOST_STR_T . "$nodename ansible_host=$ip ansible_user=$username ansible_ssh_pass=********* ansible_port=$port\n";
                                			}
                                                        else {
                                                                $HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_ssh_port=$port \n";
                                                                $HOST_STR_T = $HOST_STR_T . "$nodename ansible_host=$ip ansible_ssh_port=$port \n";
                                                        }
                                		}

                                		$cnt5 = $cnt5 + 1;

                        		}


                        	}
			}

                        $cnt = $cnt + 1;

                }


                $RANDOM_NUM = mt_rand(1,1000);
                $UTIME_F = explode('.',microtime(true));
                $UTIME = $UTIME_F[0] . $UTIME_F[1] . $RANDOM_NUM ;

                $ANSIBLE_HOST_FILE = "$ANSIBLE_HOST_DIR/host5" . $UTIME ;
                $ANSIBLE_HOST_NICK_FILE = "$ANSIBLE_HOST_DIR/host5" ;

		$HOST_CREATE = shell_exec("echo  '$HOST_STR' > $ANSIBLE_HOST_FILE");
		$HOST_DISPLAY = shell_exec("cat $ANSIBLE_HOST_FILE");

                $TARGET = "$MEMBER_LIST";

                $DISPLAY_FULLSTR = "ansible $TARGET -i $ANSIBLE_HOST_DIR/host5 -m shell -a '$COMMAND' --become";
                $FULLSTR = "ansible $TARGET -i $ANSIBLE_HOST_FILE -m shell -a '$COMMAND' --become";

                $ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log.txt" . $UTIME ;
                $ANSIBLE_LOG_NICK_FILE = "$ANSIBLE_LOG_DIR/log.txt" ;

		$ah_starttime = date("Y-m-d H:i:s");
		$CMD_LINE = shell_exec("$FULLSTR > $ANSIBLE_LOG_FILE 2>&1");
		$ah_endtime = date("Y-m-d H:i:s");

                $EXTRACT_HOST = shell_exec("$ANSIBLE_PLAYBOOK_DIR/extract_host_adhoc.sh $ANSIBLE_LOG_FILE");

                $SUCC_HOST_CNT  = 0;
                $FAIL_HOST_CNT  = 0;
                $SUCC_HOST_LIST = "";
                $FAIL_HOST_LIST = "";
                if($EXTRACT_HOST != "") {
                        $TEMP_HOST_LIST = explode(':',$EXTRACT_HOST);
                        $SUCC_HOST_CNT = $TEMP_HOST_LIST[0];
                        $FAIL_HOST_CNT = $TEMP_HOST_LIST[1];
                        $SUCC_HOST_LIST = str_replace("\n","",$TEMP_HOST_LIST[2]);
                        $SUCC_HOST_LIST = str_replace(" ","",$SUCC_HOST_LIST);
                        $FAIL_HOST_LIST = str_replace("\n","",$TEMP_HOST_LIST[3]);
                        $FAIL_HOST_LIST = str_replace(" ","",$FAIL_HOST_LIST);
                }

                $total_cnt = $SUCC_HOST_CNT + $FAIL_HOST_CNT;


                if ($SUCC_HOST_CNT == 0 and $FAIL_HOST_CNT != 0) {
                        $MSG1 = "<font color=red><b>실패</b></font>";
                        $SUCC = 'N';
                }
                else if ($SUCC_HOST_CNT != 0 and $FAIL_HOST_CNT == 0) {
                        $MSG1 = "<font color=blue><b>성공</b></font>";
                        $SUCC = 'Y';
                }
                else if ($SUCC_HOST_CNT == 0 and $FAIL_HOST_CNT == 0) {
                        $MSG1 = "<font color=red><b>실패</b></font>";
                        $SUCC = 'N';
                }
                else {
                        $MSG1 = "<font color=green><b>일부 성공</b></font>";
                        $SUCC = 'PY'; //partial success
                }

		$AH_ID = 'AH' . $UTIME;
                $T_FILE = "$ANSIBLE_LOG_DIR/Adhoc_result_{$UTIME}.txt";
                $fp = fopen($T_FILE,'w');

        	$P_RESULT_HEAD1 = "
	    	      <br>
                      <div id=wrapper>
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-6'>
                              <div class='label_danger' style='margin-bottom: 5px;padding: 4px 12px;'>
                               <table>
                               <tr><td width=1250><font size=3><b>&nbsp;Ad-hoc Command: $COMMAND<br>실행결과:&nbsp;</b></font><font size=3 color=blue><b>$MSG1</b></font></td>
                               </table>
                              </div>
                            </div>
                            <div class='col-lg-6'>
                            </div>
                          </div>
				<br>
                                <table id='table1' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Ad-hoc ID</th>
                                        <th width=70>Ad-hoc 결과</th>
                                        <th>실행 Command</th>
                                        <th>시작 시간</th>
                                        <th>종료 시간</th>
                                        <th width=60>Total 호스트</th>
                                        <th width=60>성공 호스트</th>
                                        <th width=60>실패 호스트</th>
                                        <th>성공 호스트 리스트</th>
                                        <th>실패 호스트 리스트</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                                <tr><td>$AH_ID</td><td>$MSG1</td><td>$COMMAND</td><td>$ah_starttime</td><td>$ah_endtime</td><td>$total_cnt</td><td>$SUCC_HOST_CNT</td><td>$FAIL_HOST_CNT</td><td>$SUCC_HOST_LIST</td><td>$FAIL_HOST_LIST</td></tr>
	                        </tbody>
        	                </table>
                ";

                fputs($fp,$P_RESULT_HEAD1);

		$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
                $P_RESULT_CONT1 = "
                      <br><br>
		      <button type='button' class='btn btn-primary btn-circle btn-md'><i class='fa fa-list'></i></button><font size=3><b>&nbsp;&nbsp;&nbsp;$COMMAND Ad-hoc 실행 내용</b></font><br><br>
                          <div class='row'>
                            <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Inventory 파일명: $ANSIBLE_HOST_DIR/host5</font>
                              </div>

			      <pre>$HOST_STR_T</pre>

                            </div>

                            <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Ad-hoc 실행결과: <b><font color=blue>{$MSG1} </font></b></font>
                              </div>
			      ㅇ Ansible Ad-hoc Command : <font color=blue>{$DISPLAY_FULLSTR}</font><br>
			      ㅇ 선택된 호스트/그룹: {$MEMBERS} <br>
			      ㅇ 결과 내용:&nbsp;&nbsp;&nbsp; <font color=red>(참고) rc=0 이면 성공으로 판단</font><br>
			      <pre>$RESULT_DISPLAY</pre>
                            </div>

                          </div>
                        </div>
                      </div>
                ";

                fputs($fp,$P_RESULT_CONT1);
                fclose($fp);

                $P_RESULT_DISPLAY = shell_exec("cat $T_FILE");
                echo "$P_RESULT_DISPLAY";

		// ad-hoc history Save
		$user = $_SESSION[id];
        	$ADHOC_RESULT_ENC = base64_encode($P_RESULT_DISPLAY);

                $insert_sql = "insert into Ansible_linux_adhoc_history(ah_id,ah_starttime,ah_endtime,ah_user,ah_command,ah_result,ah_result_content) values ('$AH_ID', '$ah_starttime', '$ah_endtime', '$user','$COMMAND', '$SUCC', '$ADHOC_RESULT_ENC');";

		//echo "<br>3. insert sql <br>";
		//echo "$insert_sql <br>";
                $res = mysqli_query($mysqli,$insert_sql);

                $DELETE1 = shell_exec("rm -f $ANSIBLE_HOST_FILE");
                $DELETE2 = shell_exec("rm -f $ANSIBLE_LOG_FILE");
                $DELETE2 = shell_exec("rm -f $ANSIBLE_PLAYBOOK_FILE");		
                $DELETE2 = shell_exec("rm -f $T_FILE");		


	}
	else {

        	if ($COMMAND == '') {
			echo "<br><font color=red>ㅇ Command 항목이 비어 있거나 잘못된 특수문자 사용하였습니다. 확인 바랍니다!! </font><br>";
		}
        	else if ($MEMBERS == '') {
			echo "<br><font color=red>ㅇ Inventory 항목이 비어 있습니다. 확인 바랍니다!! </font><br>";
		}

	}



?> 

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>




</body>

</html>




