<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
function FlowDelete1(F_name) {
        var total_str = F_name + '|YES';
        window.opener.sendMeDataDel(total_str);
        window.close();
}
</script>

<script>
function FlowDelete2(F_name) {
        window.close();
}
</script>



</head>

<body>


<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>





<?php

	$F_NAME = trim($_GET['F_NAME']);

        if ($F_NAME and preg_match("/[^a-z.\d_-]/i", $F_NAME)) {
                $FAULT = 'Y';
        }

if ($FAULT != 'Y') {

	echo "

            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div id='P_mod' class='panel-body'>


			 <div class='row'>
                            <div class='col-lg-6'>
                              <div class='label_danger' style='margin-bottom: 5px;padding: 4px 12px;'>
				  <table><tr>
                                  <td width=300><b><font size=3>$F_NAME</font></b></td>
				  </tr></table>
                              </div>
                            </div>

                            <div class='col-lg-6'>
                            </div>
			 </div>


                      <div id=wrapper>
                        <div class='panel-body'>


	";

	echo "
			  
            		  <div class='row'>
                	    <div class='col-lg-10'>
				<div id='txt1'>

                                <div class='table-responsive'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable_flow_mod'>

        ";

                $cmd_sql = "select * from Ansible_linux_playbookflow_Save2 where f_name = '{$F_NAME}'";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_playbook_list = $newArray['f_playbook_list'];
                                $f_member_list = $newArray['f_member_list'];
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

				echo "<tr><td>$f_name</td><td>$f_explain</td><td>$gubun_name</td><td><button id=$p_name name=$f_name class='btn btn-success btn-sm'>$f_name 내용보기</button></td></tr>";
		}


        echo "</tbody>";
        echo "</table>";
	echo "
	<br>
	<br>
	<p align=center><font size=4 color=blue><b>정말로 $F_NAME 삭제하겠습니까?</b></font></p>
	<table align=center>
	<tr><td width=70><button class='btn btn-danger btn-sm' onclick='FlowDelete1(\"$F_NAME\")'><b>YES</b></button></td>
	<td width=70><button class='btn btn-info btn-sm' onclick='FlowDelete2(\"$F_NAME\")'><b>NO</b></button></td></tr>
	</table>


	";

        echo "</div>";

}
else {
        echo "<b><font color=red>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</font></b>";
}




	echo "


                                </div>
				<div class='col-lg-2'>
                                </div>
                              </div>




                         </div>

			</div>






        ";


?>



                    </div>


                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>
