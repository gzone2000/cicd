<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$FLOW = trim($_POST['FLOW']);

if ($NUM and preg_match("/[^\d]/", $NUM)) {
        $FAULT = 'Y';
}

if ($FLOW and preg_match("/[^a-z.\d_-]/i", $FLOW)) {
        $FAULT = 'Y';
}

#echo "# Argument: NUM > {$NUM}\n";

if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

	if ($FAULT == 'Y') {
		$FULLURL = "./ansible_linux_playbookflow_cron.php?FLOW={$FLOW}&delete=3";
		#echo "# URL : {$FULLURL}";
		header('Location: '.$FULLURL);
		break;
	}


	$FULLURL = "./ansible_linux_playbookflow_cron.php?FLOW={$FLOW}&delete=1";

        $select_sql = "select c_num from Ansible_linux_playbookflow_cron where c_num = '{$NUM}'" ;
        $res5 = mysqli_query($mysqli,$select_sql);
        #echo "# SQL: {$select_sql} " ;

        $data = mysqli_fetch_array($res5);
        $isset_num = $data['c_num'];

        if (isset($isset_num)) {


		# 설정 삭제 화면
		# Delete User table
		$delete_sql = "Delete from Ansible_linux_playbookflow_cron where c_num = '{$NUM}'" ;
		echo "# SQL : {$delete_sql}";
		echo "<br>";
		$res = mysqli_query($mysqli,$delete_sql);

        	// Cron Delete //
                $LINE_CNT = shell_exec("crontab -l | grep 'LINUX_{$NUM}_LINE' | wc -l");
		if($LINE_CNT == 1) {

        		$CRON_SEARCH_STR1 = " LINUX_{$NUM}_LINE";
        		$EXEC_STR1 = "(crontab -l 2>/dev/null | sed '/$CRON_SEARCH_STR1/d') | crontab -";
			echo "Execute Command : $EXEC_STR1 <br>";
        		$RESULT = shell_exec("$EXEC_STR1");
		}



	}

	header('Location: '.$FULLURL);

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
