<?php
include "session_chk.inc" ;

$INPUT_IP = trim($_GET['L_DATA']);
//echo "# Argument: DATA > {$INPUT_IP}<br>";

if (preg_match("/[^.\d]/", $INPUT_IP)) {
        $FAULT = 'Y';
}



	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

                if ($FAULT == 'Y') {
                        $FULLURL = "./ansible_linux_inventory_search.php?del=3";
                        #echo "# URL : {$FULLURL}";
                        header('Location: '.$FULLURL);
                        break;
                }

		# del=IP : delete Success
		$FULLURL = "./ansible_linux_inventory_search.php?del=$INPUT_IP";

		$select_sql = "select ip from Ansible_linux_host where ip = '{$INPUT_IP}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['ip'];

		if (isset($isset_num)) {

			# delete Ansible_linux_host table
			$delete_sql = "delete from Ansible_linux_host where ip = '{$INPUT_IP}'" ;
			$res = mysqli_query($mysqli,$delete_sql);
			//echo "# SQL : {$delete_sql} , Result : $res";
			//echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			# del=2 : ip not found
			$FULLURL = "./ansible_linux_inventory_search.php?del=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}

?> 
