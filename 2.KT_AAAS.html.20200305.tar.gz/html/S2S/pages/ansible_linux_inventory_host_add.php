<?php
include "session_chk.inc" ;
include "Acase.php";

$DATA = trim($_GET['L_DATA']);

if (preg_match("/[^a-z+-\/=\d]/i", $DATA)) {
	$FAULT = 'Y';
}
else {

function dec_enc($action, $string, $secret_key, $secret_iv) {
    $output = false;

    $encrypt_method = "AES-256-CBC";

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}

	$DATA = base64_decode($DATA);
	//echo "# Argument: DATA > {$DATA}<br>";

	// Linux 
	$PIECES = explode("|", $DATA);
	$RSA = $PIECES[0];
	if($RSA == 'Y') {
		// RSA Auth
		$IPADDR = $PIECES[1];
		$HOSTNAME = $PIECES[2];
		$NODENAME = $PIECES[3];
		$ID = $PIECES[4];
		$RELEASE = $PIECES[5];
		$KERNEL_VER = $PIECES[6];
		$PORT = $PIECES[7];
		$USERNAME = "";
		$PASSWORD = "";
	}
	else {
		// ID/PWD Auth
		$IPADDR = $PIECES[1];
		$HOSTNAME = $PIECES[2];
		$NODENAME = $PIECES[3];
		$ID = $PIECES[4];
		$RELEASE = $PIECES[5];
		$KERNEL_VER = $PIECES[6];
		$USERNAME = $PIECES[7];
		$PASSWORD = base64_encode($PIECES[8]);
		$PORT = $PIECES[9];
	}


	if (preg_match("/[^.\d]/", $IPADDR)) {
        	$FAULT = 'Y';
	}

	if (preg_match("/[^a-z.\d_-]/i", $HOSTNAME)) {
        	$FAULT = 'Y';
	}

	if (preg_match("/[^a-z.\d_-]/i", $NODENAME)) {
        	$FAULT = 'Y';
	}

	if (preg_match("/[^a-z.\d_-]/i", $ID)) {
        	$FAULT = 'Y';
	}

	if (preg_match("/[^.\d]/", $RELEASE)) {
        	$FAULT = 'Y';
	}

	if (preg_match("/[^a-z.\d_-]/i", $KERNEL_VER)) {
        	$FAULT = 'Y';
	}

	if ($USERNAME and preg_match("/[^a-z.\d_-]/i", $USERNAME)) {
        	$FAULT = 'Y';
	}

	if ($PASSWORD and preg_match("/[ ;\'\"]/", $PASSWORD)) {
        	$FAULT = 'Y';
	}

	if (preg_match("/[^\d]/", $PORT)) {
        	$FAULT = 'Y';
	}

	//echo "$IPADDR , $HOSTNAME , $NODENAME , $ID , $RELEASE , $KERNEL_VER , $PORT , $USERNAME , $PASSWORD<br>";

}




	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

                if ($FAULT == 'Y') {
                        $FULLURL = "./ansible_linux_inventory_search.php?add=3";
                        #echo "# URL : {$FULLURL}";
                        header('Location: '.$FULLURL);
                        break;
                }

		# add=IP : insert Success
		$FULLURL = "./ansible_linux_inventory_search.php?add=$IPADDR";

		$select_sql = "select ip from Ansible_linux_host where nodename = '{$NODENAME}' or ip = '{$IPADDR}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['ip'];

		if (!isset($isset_num)) {

			# 설정 추가 화면
			# Insert Ansible_linux_host table
			if ($USERNAME and $PASSWORD) $PASSWORD = dec_enc('encrypt',$PASSWORD,$S_KEY,$S_IV);
			$insert_sql = "INSERT into Ansible_linux_host values ('{$HOSTNAME}', '{$NODENAME}', '{$IPADDR}', '{$PORT}', '{$ID}{$RELEASE}', '{$KERNEL_VER}', '{$USERNAME}', '{$PASSWORD}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			//echo "# SQL : {$insert_sql} , Result : $res";
			//echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			# add=2 : host or ip duplicate : Fail
			$FULLURL = "./ansible_linux_inventory_search.php?add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}

?> 
