<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
function myFunctionCRUD() {
    var String = "./ansible_linux_playbook_create.php";
    $("#txt1").load(String);
}
</script>

<script>
function playbookDEL(p_name) {
    var newWindow;
    var url = "./ansible_linux_playbook_del_popup.php?P_NAME=" + p_name;
    newWindow = window.open(url, "Playbook Delete", "width=1200,height=400,left=100,top=60");
}
</script>

<script>
function sendMeData_PlyDel(data) {

    var res1 = data.split('|');
    var P_name = res1[0];
    var Del_Go = res1[1];

    if (Del_Go == 'YES') {
        var url1 = './ansible_linux_playbook_del.php';
        var form = document.createElement("form");

        form.setAttribute("method","post");
        form.setAttribute("action",url1);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type","hidden");
        hiddenField.setAttribute("name","P_NAME");
        hiddenField.setAttribute("value",P_name);
        form.appendChild(hiddenField);

        document.body.appendChild(form);
        form.submit();
    }

}
</script>

<script>
function playbookMOD(p_name) {
    var String = "./ansible_linux_playbook_mod.php?P_MOD=" + p_name;
    $("#P_mod").load(String);
}
</script>

<script>
function popitup1(p_name) {
    var url = "./ansible_linux_playbook_content_popup.php?P_NAME=" + p_name;
    window.open(url,"TEST","width=900,height=600,left=100,top=60");
}
</script>



</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Playbook > Linux > Playbook 생성, 수정, 삭제</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
                        echo "<table>";
                        echo "<tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Ansible Playbook 만들고 수정하고 삭제하기</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->



<?php

if(!$_GET['add'] and !$_GET['del'] and !$_GET['mod']){

	echo "
                        <div id='P_mod' class='panel-body'>
            		  <div class='row'>
                	    <div class='col-lg-3'>
                              <div class='label_warning' style='margin-bottom: 5px;padding: 4px 12px;'>

			       <table>
                               <tr><td><font size=3><b>Playbook 생성:&nbsp;&nbsp;&nbsp;</b></font></td>
                               <td><button id=button1 name=btn1 class='btn btn-primary' onclick='myFunctionCRUD()'><b>만들기</b></button></td></tr> 
			       </table>

                              </div>
                	    </div>

                	    <div class='col-lg-9'>
			    </div>
            		  </div>

            		  <div class='row'>
                            <div class='col-lg-12'>
				<div id='txt1'>
				  <br>
				</div>
                            </div>
			  </div>



                        </div>
                        <!-- /.panel-body -->


                    </div>
                </div>
            </div>

<br>
<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Ansible Playbook 리스트 현황</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i><b>&nbsp;Linux Ansible Playbook 수정, 삭제 가능</b></font></td></tr>
                        	  </table>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-md'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>playbook ID</th>
                                        <th>playbook 이름</th>
                                        <th>playbook 설명</th>
                                        <th>playbook 구분</th>
                                        <th>playbook 분류</th>
                                        <th>playbook 사용범위</th>
                                        <th>playbook 내용</th>
                                        <th colspan=3>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>

                ";

        	$cmd_sql = "select * from Ansible_linux_playbook order by p_name";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $p_seq = $newArray['p_seq'];
                        	$p_name = $newArray['p_name'];
                        	$p_explain= $newArray['p_explain'];
                        	$p_explain= base64_decode($p_explain);
                        	$p_content = $newArray['p_content'];
				$p_content_dec = base64_decode($p_content);
                        	$p_gubun = $newArray['p_gubun'];
                        	$p_gubun1 = $newArray['p_gubun1'];
                        	$p_gubun2 = $newArray['p_gubun2'];

                		$p_seq = sprintf('%09d',$p_seq);
                		$p_seq = 'PLY' . $p_seq;

				$cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
				$res3 = mysqli_query($mysqli,$cmd_sql3);
				$newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
				$gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun2 where gubun = '{$p_gubun2}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name2 = $newArray3['gubun_name'];

                                echo "<tr><td>$p_seq</td><td>$p_name</td><td>$p_explain</td><td>$gubun_name</td><td>$gubun_name1</td><td>$gubun_name2</td><td><button id=$p_name name=$p_name value={$p_content} class='btn btn-success btn-xs' onclick='popitup1(\"$p_name\")'>내용보기</button></td>";
				echo "<td align=center><button name=P_MOD value={$p_name} type=submit class='btn btn-primary btn-xs'onclick='playbookMOD(\"$p_name\")'><b>수정</b></button></form></td>";
                                echo "<td align=center><button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs' onclick='playbookDEL(\"$p_name\")'><b>삭제</b></button></td>";
				//echo "<td align=center><form action=./ansible_linux_playbook_del.php>";
				//echo "<button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs'><b>삭제</b></button></form></td>";
				echo "<td align=center><form action=./ansible_linux_playbook_exec.php>";
				echo "<button name=PLAYBOOK value={$p_name} type=submit class='btn btn-info btn-xs'><b>실행</b></button></form></td></tr>";
                	}
        	}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";


                echo "

                            </div>
                          </div>


                        </div>
                ";


}

else if($_GET['add']) {

	$P_NAME = $_GET['add'];
	if($P_NAME != 2) {  
		
		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;$P_NAME 저장:</font><b></font><font size=3 color=blue>성공</font></b></td></tr>
                        	  </table>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>


                                <div class='table-responsive scrollClass-md'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>playbook ID</th>
                                        <th>playbook 이름</th>
                                        <th>playbook 설명</th>
                                        <th>playbook 구분</th>
                                        <th>playbook 분류</th>
                                        <th>playbook 사용범위</th>
                                        <th>playbook 내용</th>
                                        <th colspan=3>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";


        	$cmd_sql = "select * from Ansible_linux_playbook where p_name = '{$P_NAME}'";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        	$p_seq = $newArray['p_seq'];
                        	$p_name = $newArray['p_name'];
                        	$p_explain= $newArray['p_explain'];
                        	$p_explain= base64_decode($p_explain);
                        	$p_content = $newArray['p_content'];
				$p_content_dec = base64_decode($p_content);
                        	$p_gubun = $newArray['p_gubun'];
                        	$p_gubun1 = $newArray['p_gubun1'];
                        	$p_gubun2 = $newArray['p_gubun2'];

                                $p_seq = sprintf('%09d',$p_seq);
                                $p_seq = 'PLY' . $p_seq;

				$cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
				$res3 = mysqli_query($mysqli,$cmd_sql3);
				$newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
				$gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun2 where gubun = '{$p_gubun2}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name2 = $newArray3['gubun_name'];

                                echo "<tr><td>$p_seq</td><td>$p_name</td><td>$p_explain</td><td>$gubun_name</td><td>$gubun_name1</td><td>$gubun_name2</td><td><button id=$p_name name=$p_name value={$p_content} class='btn btn-success btn-xs' onclick='popitup1(\"$p_name\")'>내용보기</button></td>";
				echo "<td align=center><button name=P_MOD value={$p_name} type=submit class='btn btn-primary btn-xs' onclick='playbookMOD(\"$p_name\")'><b>수정</b></button></form></td>";
                                echo "<td align=center><button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs' onclick='playbookDEL(\"$p_name\")'><b>삭제</b></button></td>";
				//echo "<td align=center><form action=./ansible_linux_playbook_del.php>";
				//echo "<button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs'><b>삭제</b></button></form></td>";
				echo "<td align=center><form action=./ansible_linux_playbook_exec.php>";
				echo "<button name=PLAYBOOK value={$p_name} type=submit class='btn btn-info btn-xs'><b>실행</b></button></form></td></tr>";
                	}
        	}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";


	}
	else {

                echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Playbook 저장:</font><b></font><font size=3 color=blue>실패</font></b></td></tr>
                                  </table>
                              </div>
		  	      <font size=3 color=red>ㅇ playbook 저장 이름이 중복 됩니다!!</font>

                              <div id='txt' class='panel-body'>
                              </div>

		";


	}


	echo "
                        <a href=./ansible_linux_playbook_CRUD.php>
                        <button type='button' class='btn btn-primary'>
                        <b><font size=3>다른 playbook 만들기</font></b>
                        </button></a>

                            </div>
			  </div>



                        </div>
                        <!-- /.panel-body -->


                    </div>
                </div>
            </div>

<br>
<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Ansible Playbook 수정하고 삭제하기</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Ansible Playbook 수정/삭제</font></td></tr>
                        	  </table>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-md'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>playbook ID</th>
                                        <th>playbook 이름</th>
                                        <th>playbook 설명</th>
                                        <th>playbook 구분</th>
                                        <th>playbook 분류</th>
                                        <th>playbook 사용범위</th>
                                        <th>playbook 내용</th>
                                        <th colspan=3>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>

                ";

        	$cmd_sql = "select * from Ansible_linux_playbook order by p_name";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $p_seq = $newArray['p_seq'];
                                $p_name = $newArray['p_name'];
                                $p_explain= $newArray['p_explain'];
                                $p_explain= base64_decode($p_explain);
                                $p_content = $newArray['p_content'];
                                $p_content_dec = base64_decode($p_content);
                                $p_gubun = $newArray['p_gubun'];
                                $p_gubun1 = $newArray['p_gubun1'];
                                $p_gubun2 = $newArray['p_gubun2'];

                                $p_seq = sprintf('%09d',$p_seq);
                                $p_seq = 'PLY' . $p_seq;

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun2 where gubun = '{$p_gubun2}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name2 = $newArray3['gubun_name'];

                                echo "<tr><td>$p_seq</td><td>$p_name</td><td>$p_explain</td><td>$gubun_name</td><td>$gubun_name1</td><td>$gubun_name2</td><td><button id=$p_name name=$p_name value={$p_content} class='btn btn-success btn-xs' onclick='popitup1(\"$p_name\")'>내용보기</button></td>";
				echo "<td align=center><button name=P_MOD value={$p_name} type=submit class='btn btn-primary btn-xs' onclick='playbookMOD(\"$p_name\")'><b>수정</b></button></form></td>";
                                echo "<td align=center><button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs' onclick='playbookDEL(\"$p_name\")'><b>삭제</b></button></td>";
				//echo "<td align=center><form action=./ansible_linux_playbook_del.php>";
				//echo "<button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs'><b>삭제</b></button></form></td>";
                                echo "<td align=center><form action=./ansible_linux_playbook_exec.php>";
                                echo "<button name=PLAYBOOK value={$p_name} type=submit class='btn btn-info btn-xs'><b>실행</b></button></form></td></tr>";
                	}
        	}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";


                echo "

                            </div>
                          </div>


                        </div>
                ";

}

else if($_GET['del']) {

	$P_NAME = $_GET['del'];
	if($P_NAME != 2) {  
		
		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;$P_NAME 삭제:</font><b></font><font size=3 color=blue>성공</font></b></td></tr>
                        	  </table>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>
		";


	}
	else {

                echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Playbook 삭제:</font><b></font><font size=3 color=blue>실패</font></b></td></tr>
                                  </table>
                              </div>
		  	      <font size=3 color=red>ㅇ 해당 playbook 없습니다!!</font>

                              <div id='txt' class='panel-body'>
                              </div>

		";


	}


	echo "
                        <a href=./ansible_linux_playbook_CRUD.php>
                        <button type='button' class='btn btn-primary'>
                        <b><font size=3>playbook 만들기</font></b>
                        </button></a>

                            </div>
			  </div>



                        </div>
                        <!-- /.panel-body -->


                    </div>
                </div>
            </div>

<br>
<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Ansible Playbook 수정하고 삭제하기</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Ansible Playbook 수정/삭제</font></td></tr>
                        	  </table>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-md'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>playbook ID</th>
                                        <th>playbook 이름</th>
                                        <th>playbook 설명</th>
                                        <th>playbook 구분</th>
                                        <th>playbook 분류</th>
                                        <th>playbook 사용범위</th>
                                        <th>playbook 내용</th>
                                        <th colspan=3>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>

                ";

        	$cmd_sql = "select * from Ansible_linux_playbook order by p_name";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $p_seq = $newArray['p_seq'];
                                $p_name = $newArray['p_name'];
                                $p_explain= $newArray['p_explain'];
                                $p_explain= base64_decode($p_explain);
                                $p_content = $newArray['p_content'];
                                $p_content_dec = base64_decode($p_content);
                                $p_gubun = $newArray['p_gubun'];
                                $p_gubun1 = $newArray['p_gubun1'];
                                $p_gubun2 = $newArray['p_gubun2'];

                                $p_seq = sprintf('%09d',$p_seq);
                                $p_seq = 'PLY' . $p_seq;

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun2 where gubun = '{$p_gubun2}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name2 = $newArray3['gubun_name'];

                                echo "<tr><td>$p_seq</td><td>$p_name</td><td>$p_explain</td><td>$gubun_name</td><td>$gubun_name1</td><td>$gubun_name2</td><td><button id=$p_name name=$p_name value={$p_content} class='btn btn-success btn-xs' onclick='popitup1(\"$p_name\")'>내용보기</button></td>";
				echo "<td align=center><button name=P_MOD value={$p_name} type=submit class='btn btn-primary btn-xs' onclick='playbookMOD(\"$p_name\")'><b>수정</b></button></form></td>";
                                echo "<td align=center><button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs' onclick='playbookDEL(\"$p_name\")'><b>삭제</b></button></td>";
				//echo "<td align=center><form action=./ansible_linux_playbook_del.php>";
				//echo "<button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs'><b>삭제</b></button></form></td>";
                                echo "<td align=center><form action=./ansible_linux_playbook_exec.php>";
                                echo "<button name=PLAYBOOK value={$p_name} type=submit class='btn btn-info btn-xs'><b>실행</b></button></form></td></tr>";
                	}
        	}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";


                echo "

                            </div>
                          </div>


                        </div>
                ";

}


else if($_GET['mod']) {

	$P_NAME = $_GET['mod'];
	if($P_NAME != 2) {  
		
		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;$P_NAME 수정:</font><b></font><font size=3 color=blue>성공</font></b></td></tr>
                        	  </table>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>


                                <div class='table-responsive scrollClass-md'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>playbook ID</th>
                                        <th>playbook 이름</th>
                                        <th>playbook 설명</th>
                                        <th>playbook 구분</th>
                                        <th>playbook 분류</th>
                                        <th>playbook 사용범위</th>
                                        <th>playbook 내용</th>
                                        <th colspan=3>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";


        	$cmd_sql = "select * from Ansible_linux_playbook where p_name = '{$P_NAME}'";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $p_seq = $newArray['p_seq'];
                                $p_name = $newArray['p_name'];
                                $p_explain= $newArray['p_explain'];
                                $p_explain= base64_decode($p_explain);
                                $p_content = $newArray['p_content'];
                                $p_content_dec = base64_decode($p_content);
                                $p_gubun = $newArray['p_gubun'];
                                $p_gubun1 = $newArray['p_gubun1'];
                                $p_gubun2 = $newArray['p_gubun2'];

                                $p_seq = sprintf('%09d',$p_seq);
                                $p_seq = 'PLY' . $p_seq;

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun2 where gubun = '{$p_gubun2}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name2 = $newArray3['gubun_name'];

                                echo "<tr><td>$p_seq</td><td>$p_name</td><td>$p_explain</td><td>$gubun_name</td><td>$gubun_name1</td><td>$gubun_name2</td><td><button id=$p_name name=$p_name value={$p_content} class='btn btn-success btn-xs' onclick='popitup1(\"$p_name\")'>내용보기</button></td>";
				echo "<td align=center><button name=P_MOD value={$p_name} type=submit class='btn btn-primary btn-xs' onclick='playbookMOD(\"$p_name\")'><b>수정</b></button></form></td>";
                                echo "<td align=center><button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs' onclick='playbookDEL(\"$p_name\")'><b>삭제</b></button></td>";
				//echo "<td align=center><form action=./ansible_linux_playbook_del.php>";
				//echo "<button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs'><b>삭제</b></button></form></td>";
                                echo "<td align=center><form action=./ansible_linux_playbook_exec.php>";
                                echo "<button name=PLAYBOOK value={$p_name} type=submit class='btn btn-info btn-xs'><b>실행</b></button></form></td></tr>";
                	}
        	}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";



	}
	else {

                echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Playbook 저장:</font><b></font><font size=3 color=blue>실패</font></b></td></tr>
                                  </table>
                              </div>
		  	      <font size=3 color=red>ㅇ 해당 playbook 없습니다!!</font>

                              <div id='txt' class='panel-body'>
                              </div>

		";


	}


	echo " 
                        <a href=./ansible_linux_playbook_CRUD.php>
                        <button type='button' class='btn btn-primary'>
                        <b><font size=3>playbook 만들기</font></b>
                        </button></a>

                            </div>
			  </div>



                        </div>
                        <!-- /.panel-body -->


                    </div>
                </div>
            </div>

<br>
<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Ansible Playbook 수정하고 삭제하기</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Ansible Playbook 수정/삭제</font></td></tr>
                        	  </table>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-md'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>playbook ID</th>
                                        <th>playbook 이름</th>
                                        <th>playbook 설명</th>
                                        <th>playbook 구분</th>
                                        <th>playbook 분류</th>
                                        <th>playbook 내용</th>
                                        <th colspan=3>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>

                ";

        	$cmd_sql = "select * from Ansible_linux_playbook order by p_name";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $p_seq = $newArray['p_seq'];
                                $p_name = $newArray['p_name'];
                                $p_explain= $newArray['p_explain'];
                                $p_explain= base64_decode($p_explain);
                                $p_content = $newArray['p_content'];
                                $p_content_dec = base64_decode($p_content);
                                $p_gubun = $newArray['p_gubun'];
                                $p_gubun1 = $newArray['p_gubun1'];
                                $p_gubun2 = $newArray['p_gubun2'];

                                $p_seq = sprintf('%09d',$p_seq);
                                $p_seq = 'PLY' . $p_seq;

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun2 where gubun = '{$p_gubun2}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name2 = $newArray3['gubun_name'];

                                echo "<tr><td>$p_seq</td><td>$p_name</td><td>$p_explain</td><td>$gubun_name</td><td>$gubun_name1</td><td>$gubun_name2</td><td><button id=$p_name name=$p_name value={$p_content} class='btn btn-success btn-xs' onclick='popitup1(\"$p_name\")'>내용보기</button></td>";
				echo "<td align=center><button name=P_MOD value={$p_name} type=submit class='btn btn-primary btn-xs' onclick='playbookMOD(\"$p_name\")'><b>수정</b></button></form></td>";
                                echo "<td align=center><button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs' onclick='playbookDEL(\"$p_name\")'><b>삭제</b></button></td>";
				//echo "<td align=center><form action=./ansible_linux_playbook_del.php>";
				//echo "<button name=P_DEL value={$p_name} type=submit class='btn btn-warning btn-xs'><b>삭제</b></button></form></td>";
                                echo "<td align=center><form action=./ansible_linux_playbook_exec.php>";
                                echo "<button name=PLAYBOOK value={$p_name} type=submit class='btn btn-info btn-xs'><b>실행</b></button></form></td></tr>";
                	}
        	}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";


                echo "

                            </div>
                          </div>


                        </div>
                ";

}


?>



                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>

