<?php
include "session_chk.inc" ;

$HOST = trim($_POST['HOST']);
$IP = trim($_POST['IP']);
#echo "# Argument: NUM > {$NUM}\n";
#echo "# Argument: IP > {$IP}\n";


if (!$HOST or !$IP) {
	$FULLURL = "./ansible_inventory.php?add=1";
	#echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {
        
	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		$FULLURL = "./ansible_inventory.php?add=9999";

		$select_sql = "select num from Ansible_host_list where id = '{$HOST}' " ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['num'];

		if (!isset($isset_num)) {


                	$insert_sql = "INSERT into Ansible_host_list(id,gubun,ip) values ('{$HOST}', 'H', '{$IP}')" ;
                	$res = mysqli_query($mysqli,$insert_sql);

			$res = mysqli_query($mysqli,$insert_sql);
			#echo "# SQL : {$insert_sql} , Result : $res";
			#echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			$FULLURL = "./ansible_inventory.php?add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}
}

?> 
