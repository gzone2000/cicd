<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
function myFunction() {
    var String = "./ansible_linux_playbook_list.php";
    $("#list1").load(String);
}
</script>

<script>
function myFunction1() {
    var p_name = document.getElementById('button_inventory').value;
    var String;
    if(p_name) {
        document.getElementById('button1').disabled = true;
    	String = "./ansible_linux_playbook_hostInventory.php?PLAYBOOK=" + p_name;
    	$("#txt1").load(String);
    }
    else {
	alert("먼저 Playbook 선택을 하세요!!");
    }
}
</script>

<script>
function myFunction5() {

    var p_arg = document.getElementById('button_exec5').value;
    if (p_arg) {

    	document.getElementsByName("btn5")[0].disabled = true;
    	document.getElementsByName("Display_btn")[0].disabled = true;

    	$(document).ajaxStart(function(){
      		$("#wait").css("display", "block");
    	});
    	$(document).ajaxComplete(function(){
      		$("#wait").css("display", "none");
      		document.getElementsByName("btn5")[0].disabled = false;
    		document.getElementsByName('btn1')[0].disabled = false;
    		document.getElementsByName('button_inventory')[0].disabled = false;
    		document.getElementsByName("Display_btn")[0].disabled = false;
    	});

    	var String = "./ansible_linux_playbook_execSUB.php?ARG=" + btoa(p_arg) ;
	//alert(String);
    	$("#txt5").load(String);
    }
    else {
	alert("Playbook이나 Inventory 항목이 비어 있습니다. 확인 바랍니다!!");
    }

}
    document.getElementsByName("btn5")[0].disabled = false;
</script>

<script>
function popitup1(p_name) {
    var url = "./ansible_linux_playbook_content_popup.php?P_NAME=" + p_name;
    window.open(url,"TEST","width=900,height=600,left=100,top=60");
}
</script>



</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Playbook > Linux > Playbook 실행</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
                        echo "<table>";
                        echo "<tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible Playbook 통한 Linux 명령 실행 및 자동화</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->


                        <div class="panel-body">

            		  <div class="row">
                	    <div class="col-lg-3">
                              <div class="label_info" style="margin-bottom: 5px;padding: 4px 12px;">

			       <table>
                               <tr><td width=70><font size=3><b>1.&nbsp;Playbook&nbsp;&nbsp;</b></font></td>

<?php
                               echo "<td><button id=button1 name=btn1 value='$MEMBER_LIST' class='btn btn-primary' onclick='myFunction()'><b>선택</b></button></td></tr> ";
?>

			       </table>

                              </div>
                	    </div>
                	    <div class="col-lg-9">
			    </div>
            		  </div>


            		  <div class="row">
                            <div class="col-lg-11">
			      <div id="list1">

<?php
	$PLAYBOOK = '';
        if ($_GET['PLAYBOOK']) {
                $PLAYBOOK = $_GET['PLAYBOOK'];
                echo "<div class='panel-body'>";
                echo "<div>";
                echo "<font color=blue>ㅇ 선택된 Playbook</font><br>";


		echo "
				<div class='table-responsive scrollClass-vsm'>
                                <table id='table1' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>playbook 이름</th>
                                        <th>playbook 설명</th>
                                        <th>playbook 구분</th>
                                        <th>playbook 분류</th>
                                        <th>playbook 사용범위</th>
                                        <th>playbook 내용</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                ";

                $cmd_sql = "select * from Ansible_linux_playbook where p_name = '{$PLAYBOOK}'";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $p_name = $newArray['p_name'];
                                $p_explain= $newArray['p_explain'];
                                $p_explain= base64_decode($p_explain);
                                $p_content = $newArray['p_content'];
                                $p_content_dec = base64_decode($p_content);
                                $p_gubun = $newArray['p_gubun'];
                                $p_gubun1 = $newArray['p_gubun1'];
                                $p_gubun2 = $newArray['p_gubun2'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun2 where gubun = '{$p_gubun2}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name2 = $newArray3['gubun_name'];

                                echo "<tr><td>$p_name</td><td>$p_explain</td><td>$gubun_name</td><td>$gubun_name1</td><td>$gubun_name2</td><td><button id=$p_name name=Display_btn value={$p_content} class='btn btn-success btn-xs' onclick='popitup1(\"$p_name\")'>내용보기</button></td>";
                        }
                }

        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";  //scrollClass-vsm

                echo "</div>";
                echo "</div>";

        }
        else echo "<br>";

?>




			      </div>
                            </div>
			  </div>

			  <br>
            		  <div class="row">
                            <div class="col-lg-3">
                              <div class="label_warning" style="margin-bottom: 5px;padding: 4px 12px;">

                               <table>
                               <tr><td width=70><font size=3><b>2.&nbsp;Inventory&nbsp;&nbsp;</b></font></td>
<?php
	if($PLAYBOOK) {
 			       echo "<td><button id='button_inventory' name=button_inventory value={$PLAYBOOK} class='btn btn-primary' onclick='myFunction1()'><b>선택</b></button></td></tr>";
	}
	else {
 			       echo "<td><button id='button_inventory' name=button_inventory class='btn btn-primary' onclick='myFunction1()'><b>선택</b></button></td></tr>";
	}
?>
                               </table>

                              </div>

                            </div>
                            <div class="col-lg-9">
                            </div>
                          </div>


                          <div class="row">
                            <div class="col-lg-11">
                              <div id="txt1">


<?php

	if ($_GET['MEMBER']) {
		$MEMBER_LIST = $_GET['MEMBER'];
		$MEMBER_DISPLAY = str_replace(",","<br>",$MEMBER_LIST);
		echo "<div class='panel-body'>";
		echo "<div>";
                echo "<font color=blue>ㅇ 선택된 호스트/그룹</font><br>";
		echo "<pre name='member1' value='$MEMBER_LIST'>$MEMBER_DISPLAY</pre>";	
                echo "</div>";
                echo "</div>";

        	echo "<script>";
                echo "document.getElementById('button1').disabled = true;";
                echo "document.getElementById('button_inventory').disabled = true;";
        	echo "</script>";

	}
	else echo "<br>";

?>

                              </div>

                            </div>
                          </div>



			  <br>
                          <div class="row">
                            <div class="col-lg-3">
                              <div class="label_success" style="margin-bottom: 5px;padding: 4px 12px;">

                               <table>
                               <tr><td width=140><font size=3><b>3.&nbsp;Playbook 실행&nbsp;&nbsp;</b></font></td>

<?php


	if( $PLAYBOOK and $MEMBER_LIST) $Argument = $PLAYBOOK . ' ' . $MEMBER_LIST ;
	else $Argument ='';
                               echo "<td><button id=button_exec5 name=btn5 value='$Argument' class='btn btn-primary' onclick='myFunction5()'><b>실행 선택</b></button></td></tr> ";
?>

                               </table>

                              </div>
                            </div>

                            <div class="col-lg-9">
                            </div>


            		  <div class="row">
                            <div class="col-lg-12">

                              <div id="txt5" class="panel-body">
                              </div>

<div id='wait' style='display:none;position:absolute;top:30px;left:550px;padding:2px;'>
<img src='../vendor/login/loading2.gif' width=110 height=110 />
<br>
<font size=4 color=red><b> Loading...</b></font>
</div>




                	    </div>
            		  </div>


                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div>
                <a style='display:scroll;position:fixed;bottom:30px;right:20px;' href='#' title=Top><font color=red size=5><b>TOP</b></font></a>
            </div>

        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




