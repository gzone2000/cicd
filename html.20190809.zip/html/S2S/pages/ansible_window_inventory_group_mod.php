<?php
include "session_chk.inc" ;

$GROUP_NAME = trim($_GET['GROUP_NAME']);
$MEMBER = trim($_GET['MEMBER']);
$MEMBER = str_replace(",","|",$MEMBER);
//echo "# Argument: GROUP_NAME > {$GROUP_NAME}<br>";
//echo "# Argument: MEMBER > {$MEMBER}<br>";


	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		# Update Ansible_window_group table
		$FULLURL = "./ansible_window_inventory_group.php?mod=$GROUP_NAME";

		$select_sql = "select groupname from Ansible_window_group where groupname = '{$GROUP_NAME}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['groupname'];

		if (isset($isset_num)) {

			# 설정 추가 화면
			# Update Ansible_window_group table
			$update_sql = "UPDATE Ansible_window_group set member = '{$MEMBER}' where groupname = '{$GROUP_NAME}'" ;
			$res = mysqli_query($mysqli,$update_sql);
			//echo "# SQL : {$update_sql} , Result : $res";
			//echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			# add=2 : host or ip duplicate : Fail
			$FULLURL = "./ansible_window_inventory_group.php?mod=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}

?> 
