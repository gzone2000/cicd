<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->




<script src="../vendor/jquery/jquery-2.2.4.js"></script>
<script>
function GroupMOD(g_name) {
    var String = "./ansible_window_inventory_group_modSUB.php?G_MOD=" + g_name;
    $("#P_mod").load(String);
}
</script>

         <script type="text/javascript">
                           $(document).ready(function() {
                                   $("#move_to_down").on("click", function() {
                                            $('#table_source').find('tr').each(function () {
                                                     var row = $(this);
                                                     if (row.find('input[type="checkbox"]').is(':checked')) {
                                                              $("#table_dest tbody").append(row);
                                                     }
                                            });

                                   });

                                   $("#move_to_up").on("click", function() {
                                            $('#table_dest').find('tr').each(function () {
                                                     var row = $(this);
                                                     if (row.find('input[type="checkbox"]').is(':checked')) {
                                                              $("#table_source tbody").append(row);
                                                     }

                                            });

                                   });

                           });

        </script>



<script>

function GetCellValues() {
    var group_name = document.getElementById('GROUP_NAME').value;

var blank_pattern = /[\s]/g;
if( blank_pattern.test(group_name) == true){
alert('이름 항목엔 공백을 사용할수 없습니다.. ');
return false;
}

var special_pattern = /[`~!@#$%^&*()\[\]{}+|\\\'\";:\/?]/gi;
if( special_pattern.test(group_name) == true ){
alert('이름 항목엔 특수 문자를 사용할수 없습니다.');
return false;
}

var hangul_pattern = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
if( hangul_pattern.test(group_name) == true ){
alert('이름 항목엔 한글을 사용할수 없습니다.');
return false;
}

    var res = '';
    var str1 = '' ;
    var table = document.getElementById('table_dest');
    for (var r = 1, n = table.rows.length; r < n; r++) {
            str1 = table.rows[r].cells[2].innerHTML;
	    if ( res == '') {
	    	res = str1;
            }
	    else {
	    	res = res + ',' + str1;
	    }
    }

    if(res == '') {
	alert("선택된 호스트 항목이 없습니다. 확인 바랍니다!!");
    }
    else {
    	var url1 = './ansible_window_inventory_group_add.php?GROUP_NAME=' + group_name + '&MEMBER=' + res;
    	location.replace(url1);
    }
}

</script>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Inventory > Window > 호스트 그룹 추가, 수정, 삭제</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
                        echo "<table>";
                        echo "<tr><td width=350><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible Window 호스트 그룹 생성, 수정, 삭제</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->



<?php

if(!$_GET['add'] and !$_GET['del'] and !$_GET['mod']){

	echo "
                        <div id='P_mod' class='panel-body'>
            		  <div class='row'>
                	    <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Ansible Window 호스트 </font></b>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

				<div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>체크</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";


        $cmd_sql = "select * from Ansible_window_host order by hostname";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $hostname = $newArray['hostname'];
                        $nodename= $newArray['nodename'];
                        $ip = $newArray['ip'];
                        $window_ver = $newArray['window_ver'];
                        $kernel_ver = $newArray['kernel_ver'];

                        echo "<tr><td><input type='checkbox' name=NODE value=$nodename></td><td>$hostname</td><td>$nodename</td><td>$ip</td></tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";


	$INPUT_DATE = date("Y-m-d");
	$INPUT_G_NAME = "Group_" . $INPUT_DATE ;

        echo "
			    </div>
                            <div class='col-lg-1'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>이동</font></b>
                              </div>
                              
                              <div id='txt' class='panel-body'>
                              </div>


                                <table align=center>
				    <tr><td>&nbsp;</td></tr>
                                    <tr><td><img id='move_to_down' src='../vendor/login/arrow_right.PNG'></td></tr>
                                    <tr><td><img id='move_to_up' src='../vendor/login/arrow_left.PNG'></td></tr>
				</table>

                            </div>


                            <div class='col-lg-5'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Ansible Window 그룹 생성</font></b>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

                                <table id='table_dest' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>체크</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                    </tr>
                                </thead>
				<tbody>
				</tbody>
				</table>
				
			  	<br>
                                <div class='form-group has-error'>
                                     <label class='control-label' for='inputError'>Input Group Name</label>
				     <table><tr><td width=230>
                                     <input type='text' class='form-control' id='GROUP_NAME' value='{$INPUT_G_NAME}'></td><td>&nbsp;&nbsp;</td>
				     <td><button class='btn btn-primary' onClick='GetCellValues()'><b>그룹 생성</b></button></td>
				     </table>
                                </div>


                    </div>
	";


		echo "

                </div>
            </div>

<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=350><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible Window 호스트 그룹</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Ansible Window 호스트 그룹 리스트 및 수정/삭제</font></b>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

				<div class='table-responsive scrollClass-lg'>
                                <table width='100%' class='table table-sm table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>그룹 이름</th>
                                        <th>멤버 리스트</th>
                                        <th colspan=2>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                ";


        $cmd_sql = "select * from Ansible_window_group order by groupname";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $groupname = $newArray['groupname'];
                        $member= $newArray['member'];
			$PIECES = explode("|", $member);

			echo "<tr>";
			echo "<td>Window</td>";
			echo "<td>$groupname</td>";
			echo "<td>";

			echo "<table width='100%' class='table table-striped table-bordered table-hover'>";
	
			$cnt = 0;
			while ($PIECES[$cnt]) {

				$cmd_sql1 = "select * from Ansible_window_host where nodename = '$PIECES[$cnt]'";
				$res1 = mysqli_query($mysqli,$cmd_sql1);
				if ($res1) {
					$newArray1 = mysqli_fetch_array($res1,MYSQLI_ASSOC);
                        		$hostname = $newArray1['hostname'];
                        		$nodename= $newArray1['nodename'];
                        		$ip = $newArray1['ip'];
					echo "<tr><td>$hostname</td><td>$nodename</td><td>$ip</td></tr>";
				}

				$cnt = $cnt + 1;

			}

			echo "</table>";

			echo "</td>";

			echo "<td width=50><button name=G_MOD value={$groupname} type=submit class='btn btn-primary btn-sm' onclick='GroupMOD(\"$groupname\")'><b>수정</b></button></td>";
                        echo "<td width=50><form action=./ansible_window_inventory_group_del.php>";
                        echo "<center><button class='btn btn-danger btn-sm' type=submit name=L_DATA value={$groupname}><b><font size=2>삭제</font></b></button></center></form></td>";
			echo "</tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";



                echo "

                            </div>
                          </div>


                        </div>
                ";





}

else if($_GET['add']) {

	if($_GET['add'] != "2"){
	
		$GROUP_NAME = $_GET['add'];
		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>그룹 추가 결과 : </font><font size=3 color=blue>성공</font></b>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

				<div class='table-responsive scrollClass-sm'>
                                <table width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>그룹 이름</th>
                                        <th>멤버 리스트</th>
                                        <th colspan=2>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
		";


        $cmd_sql = "select * from Ansible_window_group where groupname = '{$GROUP_NAME}'";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $groupname = $newArray['groupname'];
                        $member= $newArray['member'];
			$PIECES = explode("|", $member);

			echo "<tr>";
			echo "<td>Window</td>";
			echo "<td>$groupname</td>";
			echo "<td>";

			echo "<table width='100%' class='table table-striped table-bordered table-hover'>";
	
			$cnt = 0;
			while ($PIECES[$cnt]) {

				$cmd_sql1 = "select * from Ansible_window_host where nodename = '$PIECES[$cnt]'";
				$res1 = mysqli_query($mysqli,$cmd_sql1);
				if ($res1) {
					$newArray1 = mysqli_fetch_array($res1,MYSQLI_ASSOC);
                        		$hostname = $newArray1['hostname'];
                        		$nodename= $newArray1['nodename'];
                        		$ip = $newArray1['ip'];
					echo "<tr><td>$hostname</td><td>$nodename</td><td>$ip</td></tr>";
				}

				$cnt = $cnt + 1;

			}

			echo "</table>";

			echo "</td>";

			echo "<td width=50><button name=G_MOD value={$groupname} type=submit class='btn btn-primary btn-sm' onclick='GroupMOD(\"$groupname\")'><b>수정</b></button></td>";
                        echo "<td width=50><form action=./ansible_window_inventory_group_del.php>";
                        echo "<center><button class='btn btn-danger btn-sm' type=submit name=L_DATA value={$groupname}><b><font size=2>삭제</font></b></button></center></form></td>";
			echo "</tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";

		echo "

			<br>
			<a href=./ansible_window_inventory_group.php>
			<button type='button' class='btn btn-primary'>
			<b><font size=3> 다른 그룹 추가 </font></b>
			</button></a>
			
        	";  


	}
	else if($_GET['add'] == "2"){

		echo "
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>그룹 추가 결과 : </font><font size=3 color=red>실패</font></b>
				  <br><font size=2 color=blue>그룹이름이 중복 됩니다.!!</font>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

                ";

	}

                echo "
			
                            </div>
                          </div>


                        </div>


<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=350><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible Window 호스트 그룹</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Ansible Window 호스트 그룹 리스트 및 수정/삭제</font></b>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

				<div class='table-responsive scrollClass-lg'>
                                <table width='100%' class='table table-sm table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>그룹 이름</th>
                                        <th>멤버 리스트</th>
                                        <th colspan=2>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                ";


        $cmd_sql = "select * from Ansible_window_group order by groupname";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $groupname = $newArray['groupname'];
                        $member= $newArray['member'];
                        $PIECES = explode("|", $member);

                        echo "<tr>";
                        echo "<td>Window</td>";
                        echo "<td>$groupname</td>";
                        echo "<td>";

                        echo "<table width='100%' class='table table-striped table-bordered table-hover'>";

                        $cnt = 0;
                        while ($PIECES[$cnt]) {

                                $cmd_sql1 = "select * from Ansible_window_host where nodename = '$PIECES[$cnt]'";
                                $res1 = mysqli_query($mysqli,$cmd_sql1);
                                if ($res1) {
                                        $newArray1 = mysqli_fetch_array($res1,MYSQLI_ASSOC);
                                        $hostname = $newArray1['hostname'];
                                        $nodename= $newArray1['nodename'];
                                        $ip = $newArray1['ip'];
                                        echo "<tr><td>$hostname</td><td>$nodename</td><td>$ip</td></tr>";
                                }

                                $cnt = $cnt + 1;

                        }

                        //echo "</tbody>";
                        echo "</table>";

                        echo "</td>";

			echo "<td width=50><button name=G_MOD value={$groupname} type=submit class='btn btn-primary btn-sm' onclick='GroupMOD(\"$groupname\")'><b>수정</b></button></td>";
                        echo "<td width=50><form action=./ansible_window_inventory_group_del.php>";
                        echo "<center><button class='btn btn-danger btn-sm' type=submit name=L_DATA value={$groupname}><b><font size=2>삭제</font></b></button></center></form></td>";
                        echo "</tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";

                echo "

                            </div>
                          </div>


                        </div>
                ";


}

else if($_GET['del']) {

	$INPUT_GROUPNAME = $_GET['del'];
	if($_GET['del'] != "2"){
	
		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>$INPUT_GROUPNAME 그룹 삭제 결과 : </font><font size=3 color=blue>성공</font></b>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>


			<br>
			<a href=./ansible_window_inventory_group.php>
			<button type='button' class='btn btn-primary'>
			<b><font size=3>그룹 추가 </font></b>
			</button></a>
			
        	";  



	}
	else if($_GET['del'] == "2"){

		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>그룹 삭제 결과 : </font><font size=3 color=red>실패</font></b>
				  <br><font size=2 color=blue>삭제할 그룹이 없습니다.!!</font>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

			<br>
			<a href=./ansible_window_inventory_group.php>
			<button type='button' class='btn btn-primary'>
			<b><font size=3>그룹 추가 </font></b>
			</button></a>
			
        	";  
	}


                echo "
			
                            </div>
                          </div>


                        </div>


<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=350><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible Window 호스트 그룹</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Ansible Window 호스트 그룹 리스트 및 수정/삭제</font></b>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

				<div class='table-responsive scrollClass-lg'>
                                <table width='100%' class='table table-sm table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>그룹 이름</th>
                                        <th>멤버 리스트</th>
                                        <th colspan=2>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                ";


        $cmd_sql = "select * from Ansible_window_group order by groupname";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $groupname = $newArray['groupname'];
                        $member= $newArray['member'];
                        $PIECES = explode("|", $member);

                        echo "<tr>";
                        echo "<td>Window</td>";
                        echo "<td>$groupname</td>";
                        echo "<td>";

                        echo "<table width='100%' class='table table-striped table-bordered table-hover'>";
                        //echo "<thead><tr><th>È£½ºÆ® ÀÌ¸§</th><th>³ëµå ÀÌ¸§</th><th>IP</th></tr></thead><tbody>";

                        $cnt = 0;
                        while ($PIECES[$cnt]) {

                                $cmd_sql1 = "select * from Ansible_window_host where nodename = '$PIECES[$cnt]'";
                                $res1 = mysqli_query($mysqli,$cmd_sql1);
                                if ($res1) {
                                        $newArray1 = mysqli_fetch_array($res1,MYSQLI_ASSOC);
                                        $hostname = $newArray1['hostname'];
                                        $nodename= $newArray1['nodename'];
                                        $ip = $newArray1['ip'];
                                        echo "<tr><td>$hostname</td><td>$nodename</td><td>$ip</td></tr>";
                                }

                                $cnt = $cnt + 1;

                        }

                        //echo "</tbody>";
                        echo "</table>";

                        echo "</td>";

			echo "<td width=50><button name=G_MOD value={$groupname} type=submit class='btn btn-primary btn-sm' onclick='GroupMOD(\"$groupname\")'><b>수정</b></button></td>";
                        echo "<td width=50><form action=./ansible_window_inventory_group_del.php>";
                        echo "<center><button class='btn btn-danger btn-sm' type=submit name=L_DATA value={$groupname}><b><font size=2>삭제</font></b></button></center></form></td>";
                        echo "</tr>";
                }
        }

        echo "</tbody>";
        echo "</table>";
        echo "</div>";



                echo "
			
                            </div>
                          </div>


                        </div>
        	";  

}

else if($_GET['mod']) {

	if($_GET['mod'] != "2"){
	
		$GROUP_NAME = $_GET['mod'];
		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>그룹 수정 결과 : </font><font size=3 color=blue>성공</font></b>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

				<div class='table-responsive scrollClass-sm'>
                                <table width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>그룹 이름</th>
                                        <th>멤버 리스트</th>
                                        <th colspan=2>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
		";


        $cmd_sql = "select * from Ansible_window_group where groupname = '{$GROUP_NAME}'";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $groupname = $newArray['groupname'];
                        $member= $newArray['member'];
			$PIECES = explode("|", $member);

			echo "<tr>";
			echo "<td>Window</td>";
			echo "<td>$groupname</td>";
			echo "<td>";

			echo "<table width='100%' class='table table-striped table-bordered table-hover'>";
	
			$cnt = 0;
			while ($PIECES[$cnt]) {

				$cmd_sql1 = "select * from Ansible_window_host where nodename = '$PIECES[$cnt]'";
				$res1 = mysqli_query($mysqli,$cmd_sql1);
				if ($res1) {
					$newArray1 = mysqli_fetch_array($res1,MYSQLI_ASSOC);
                        		$hostname = $newArray1['hostname'];
                        		$nodename= $newArray1['nodename'];
                        		$ip = $newArray1['ip'];
					echo "<tr><td>$hostname</td><td>$nodename</td><td>$ip</td></tr>";
				}

				$cnt = $cnt + 1;

			}

			echo "</table>";

			echo "</td>";

			echo "<td width=50><button name=G_MOD value={$groupname} type=submit class='btn btn-primary btn-sm' onclick='GroupMOD(\"$groupname\")'><b>수정</b></button></td>";
                        echo "<td width=50><form action=./ansible_window_inventory_group_del.php>";
                        echo "<center><button class='btn btn-danger btn-sm' type=submit name=L_DATA value={$groupname}><b><font size=2>삭제</font></b></button></center></form></td>";
			echo "</tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";

		echo "

			<br>
			<a href=./ansible_window_inventory_group.php>
			<button type='button' class='btn btn-primary'>
			<b><font size=3>그룹 추가 </font></b>
			</button></a>
			
        	";  


	}
	else if($_GET['mod'] == "2"){

		echo "
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>그룹 수정 결과 : </font><font size=3 color=red>실패</font></b>
				  <br><font size=2 color=blue>수정할 그룹이 없습니다.!!</font>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

			<br>
			<a href=./ansible_window_inventory_group.php>
			<button type='button' class='btn btn-primary'>
			<b><font size=3>그룹 추가 </font></b>
			</button></a>

                ";

	}

                echo "
			
                            </div>
                          </div>


                        </div>


<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=350><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible Window 호스트 그룹</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Ansible Window 호스트 그룹 리스트 및 수정/삭제</font></b>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

				<div class='table-responsive scrollClass-lg'>
                                <table width='100%' class='table table-sm table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>그룹 이름</th>
                                        <th>멤버 리스트</th>
                                        <th colspan=2>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                ";


        $cmd_sql = "select * from Ansible_window_group order by groupname";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $groupname = $newArray['groupname'];
                        $member= $newArray['member'];
                        $PIECES = explode("|", $member);

                        echo "<tr>";
                        echo "<td>Window</td>";
                        echo "<td>$groupname</td>";
                        echo "<td>";

                        echo "<table width='100%' class='table table-striped table-bordered table-hover'>";

                        $cnt = 0;
                        while ($PIECES[$cnt]) {

                                $cmd_sql1 = "select * from Ansible_window_host where nodename = '$PIECES[$cnt]'";
                                $res1 = mysqli_query($mysqli,$cmd_sql1);
                                if ($res1) {
                                        $newArray1 = mysqli_fetch_array($res1,MYSQLI_ASSOC);
                                        $hostname = $newArray1['hostname'];
                                        $nodename= $newArray1['nodename'];
                                        $ip = $newArray1['ip'];
                                        echo "<tr><td>$hostname</td><td>$nodename</td><td>$ip</td></tr>";
                                }

                                $cnt = $cnt + 1;

                        }

                        //echo "</tbody>";
                        echo "</table>";

                        echo "</td>";

			echo "<td width=50><button name=G_MOD value={$groupname} type=submit class='btn btn-primary btn-sm' onclick='GroupMOD(\"$groupname\")'><b>수정</b></button></td>";
                        echo "<td width=50><form action=./ansible_window_inventory_group_del.php>";
                        echo "<center><button class='btn btn-danger btn-sm' type=submit name=L_DATA value={$groupname}><b><font size=2>삭제</font></b></button></center></form></td>";
                        echo "</tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";

                echo "

                            </div>
                          </div>


                        </div>
                ";



}


?>


                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




