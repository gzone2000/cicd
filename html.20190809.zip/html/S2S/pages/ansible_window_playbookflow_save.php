<?php
include "session_chk.inc" ;

$FNAME = trim($_GET['FNAME']);
$EXPALIN_ORG = trim($_GET['EXPALIN']);
$EXPALIN = base64_encode($EXPALIN_ORG);
$GUBUN = trim($_GET['GUBUN']);
$GUBUN1 = trim($_GET['GUBUN1']);
//echo "# Argument: FNAME > {$FNAME}<br>";
//echo "# Argument: EXPALIN > {$EXPALIN}<br>";
//echo "# Argument: GUBUN > {$GUBUN}<br>";


	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

                # insert flow
		$FULLURL = "./ansible_window_playbookflow.php?add=$FNAME";

                $select_sql = "select f_name from Ansible_window_playbookflow_Save where f_name = '{$FNAME}'" ;
                $res5 = mysqli_query($mysqli,$select_sql);
                #echo "# SQL: {$select_sql} " ;

                $data = mysqli_fetch_array($res5);
                $isset_num = $data['f_name'];

                if (!isset($isset_num)) {

			$TOTAL_STR = '';
			$STR = '';

                	$select_sql = "select * from Ansible_window_playbookflow_op";
                	$res = mysqli_query($mysqli,$select_sql);
			#echo "# SQL: {$select_sql} " ;
                	if ($res) {
				$CNT=0;
                        	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                	$step = $newArray['step'];
                                	$p_name = $newArray['p_name'];
                                	$member = $newArray['member'];
					$STR = $step . '|' . $p_name . '|' . $member;
					if($CNT == 0 ) $TOTAL_STR = $STR;
					else $TOTAL_STR = $TOTAL_STR . '||' . $STR;
					$CNT = $CNT + 1;
				}
			}

			$insert_sql = "INSERT into Ansible_window_playbookflow_Save(f_name,f_explain,f_content,f_gubun,f_gubun1) values ('{$FNAME}', '{$EXPALIN}', '{$TOTAL_STR}', '{$GUBUN}', '{$GUBUN1}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			//echo "# All Flow String : $TOTAL_STR <br>";
			//echo "# SQL : {$insert_sql} , Result : $res <br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 

                }
                else {
                        # add=2 : host or ip duplicate : Fail
                        $FULLURL = "./ansible_window_playbookflow.php?add=2";
                        #echo "# URL : {$FULLURL}";
                        header('Location: '.$FULLURL);
                }

	}

?> 
