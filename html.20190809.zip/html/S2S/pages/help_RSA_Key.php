<?php

echo "<html>";
echo "<body>";

echo "<pre>";
echo "<font size=3 color=blue>[Ansible Server Public Key 복사]</font><br>";
echo "<table><tr><td>";
echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCxxII5tIHC9Q+nZJdFdmayfWly3FzEkaCnO1jP1AbQs4905te2h21ZsRYnwZU640WWNy1RZ/4qk15TDtLpWAd2Xjn47zNKWVwXZ3oxI/Ve89EG2q6b/zXaaRwr3jL1O+jAmusnK6dVidt4uV2oWgTeu6di84AaEUkOFIg7eUNiOW4tocGUa8rpDr58SMzn3oxgZNNdRe9EmO4vDDTBGTZSUJRqn+3buI2lQuh9ZsM00W7b6HQ7Ny9ZfU3X6NsTdasdpDRvaOOD+W0mKCmJ4dxCYhKvW8GjLYZtMP5M4N2PPkLxlLa6TMptSbUQ3kixwWacU/ZBOO3/xaPOoiT+6q2r ansible@46c921b61750";
echo "</td></tr></table>";
echo "</pre>";

echo "</body>";
echo "</html>";

?>
