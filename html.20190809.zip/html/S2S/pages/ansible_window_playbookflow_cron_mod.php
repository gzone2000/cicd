<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$FLOW = trim($_POST['FLOW']);
$MIN = trim($_POST['MIN']);
$EVERY_MIN_CHK = trim($_POST['EVERY_MIN_CHK']);
$HOUR = trim($_POST['HOUR']);
$EVERY_HOUR_CHK = trim($_POST['EVERY_HOUR_CHK']);
$DAY = trim($_POST['DAY']);
$MONTH = trim($_POST['MONTH']);
$WEEK = trim($_POST['WEEK']);
$MAIL_SEND = trim($_POST['MAIL_SEND']);
$COMMAND = trim($_POST['COMMAND']);

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

        if(!$EVERY_MIN_CHK) $EVERY_MIN_CHK = 'N';
        if(!$EVERY_HOUR_CHK) $EVERY_HOUR_CHK = 'N';

	$FULLURL = "./ansible_window_playbookflow_cron.php?FLOW={$FLOW}&modify=1";

	# 설정 수정 화면
	# Update Ansible_window_playbookflow_cron table

        $select_sql = "select c_num from Ansible_window_playbookflow_cron where c_num = '{$NUM}'" ;
        $res5 = mysqli_query($mysqli,$select_sql);
        #echo "# SQL: {$select_sql} " ;

        $data = mysqli_fetch_array($res5);
        $isset_num = $data['c_num'];

        if (isset($isset_num)) {

		$update_sql = "UPDATE Ansible_window_playbookflow_cron set c_min = '{$MIN}' , c_min_chk = '{$EVERY_MIN_CHK}' , c_hour = '{$HOUR}', c_hour_chk = '{$EVERY_HOUR_CHK}' , c_day = '{$DAY}' , c_month = '{$MONTH}' , c_week = '{$WEEK}', c_cmd = '{$COMMAND}', c_mail = '{$MAIL_SEND}' where c_num = '{$NUM}'" ;

		#echo "# SQL : {$update_sql}";
		#echo "<br>";
		$res = mysqli_query($mysqli,$update_sql);

        	// Cron modify //
        	if($EVERY_MIN_CHK == 'Y' and $MIN != '*') $MIN = '*/' . $MIN;
        	if($EVERY_HOUR_CHK == 'Y' and $HOUR != '*') $HOUR = '*/' . $HOUR;

                $LINE_CNT = shell_exec("crontab -l | grep 'WIN_{$NUM}_LINE' | wc -l");
                if($LINE_CNT == 1) {

			$CRON_SEARCH_STR1 = " WIN_{$NUM}_LINE";
        		$CRON_EXEC_STR1 = "/var/www/html/S2S/pages/ansible_window_playbookflow_CronExec.php $COMMAND $MAIL_SEND WIN_{$NUM}_LINE";
        		$CRON_STR1 = $MIN . " " . $HOUR . " " . $DAY . " " . $MONTH . " " . $WEEK . " " . "php $CRON_EXEC_STR1 ";

        		$EXEC_STR1 = "(crontab -l 2>/dev/null | sed '/$CRON_SEARCH_STR1/c $CRON_STR1') | crontab -";
        		$RESULT = shell_exec("$EXEC_STR1");
		}

	}

	header('Location: '.$FULLURL);

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
