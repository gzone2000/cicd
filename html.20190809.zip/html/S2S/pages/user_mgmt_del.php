<?php
include "session_chk.inc" ;

$ID = trim($_POST['ID']);
#echo "# Argument: ID > {$ID}\n";

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

	$FULLURL = "./user_mgmt.php?delete=1";

	# 설정 삭제 화면
	# Delete User table
	$delete_sql = "Delete from User where id = '{$ID}'" ;
	#echo "# SQL : {$delete_sql}";
	#echo "<br>";
	$res = mysqli_query($mysqli,$delete_sql);

	header('Location: '.$FULLURL);

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
