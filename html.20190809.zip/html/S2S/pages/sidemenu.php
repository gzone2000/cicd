<?php

# Menu Name
$MENU0 = " Dashboard";
$MENU1 = " Linux";
$MENU1_1 = " Ad-Hoc Command";
$MENU1_2 = " Copy";
$MENU1_3 = " Edit";
$MENU2 = " Window";
$MENU2_1 = " Ad Hoc Command";
$MENU2_2 = " Copy";
$MENU2_3 = " Edit";
$MENU3 = " Network";
$MENU3_1 = " Ad Hoc Command";
$MENU3_2 = " Copy";
$MENU3_3 = " Edit";
$MENU4 = " Inventory";
$MENU4_1 = " Linux";
$MENU4_2 = " Window";
$MENU4_3 = " Network";
$MENU4_1_1 = " 호스트 검색, 추가, 삭제";
$MENU4_1_2 = " 호스트 그룹 추가 수정, 삭제";
$MENU5 = " Playbook";
$MENU5_1 = " Linux";
$MENU5_1_1 = " Playbook 생성, 수정, 삭제";
$MENU5_1_2 = " Playbook 실행";
$MENU5_2 = " Window";
$MENU5_3 = " Network";
$MENU6 = " Flow";
$MENU6_1 = " Linux";
$MENU6_1_1 = " Flow 생성, 수정, 삭제";
$MENU6_1_2 = " Flow 실행";
$MENU6_1_3 = " Flow Cron 등록, 수정, 삭제";
$MENU6_2 = " Window";
$MENU6_3 = " Network";
$MENU7 = " History";
$MENU7_1 = " Linux";
$MENU7_1_0 = " Ad-Hoc 실행 이력";
$MENU7_1_1 = " Playbook 실행 이력";
$MENU7_1_2 = " Flow 실행 이력";
$MENU7_2 = " Window";
$MENU7_3 = " Network";
$MENU8 = " 계정";
$MENU8_1 = " 계정관리";
$MENU8_2 = " MGMT IP 설정";
$MENU9 = " 로그인";
$MENU9_1 = " 활성 로그인 현황";
$MENU9_2 = " 로그인 접속 히스토리";
$MENU10 = " 도움말";
$MENU11 = " Job 등록, 수정, 삭제";
$MENU11_1 = " Linux";
$MENU11_2 = " Window";
$MENU11_3 = " Network";
$MENU12 = " Mail 수신자 관리";
$MENU13 = " 통계";

$TITLE = "AAAS (Agile Automation Ansible System)";
$HomePageName = "KT-AAAS";
$LOGO = "ansible_logo1.png";
$FLOW_MAX = 5;
$INPUT_DAYS = -5;

?>

