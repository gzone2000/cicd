<?php
include "session_chk.inc" ;

	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		# init Ansible_window_playbookflow_op table
		$delete_sql = "delete from Ansible_window_playbookflow_op" ;
		$res = mysqli_query($mysqli,$delete_sql);
		//echo "# SQL : {$delete_sql} , Result : $res";
		//echo "<br>";

		mysqli_free_result($res);
		mysqli_close($mysqli); 
	}

?> 
