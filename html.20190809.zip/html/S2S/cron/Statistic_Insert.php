<?php


function SQL_EXE($sql) {

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

        $res = mysqli_query($mysqli,$sql);
        $row = mysqli_fetch_array($res);

        return $row["count"];
}


$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

date_default_timezone_set("Asia/Seoul");
$DAYS = -1;
$INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));

# Inventory Count
$sql = "select count(*) as count from Ansible_linux_host";
$s_inventory_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_host";
$s_inventory_win = SQL_EXE($sql);

# Playbook Count
$sql = "select count(*) as count from Ansible_linux_playbook";
$s_playbook_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_playbook";
$s_playbook_win = SQL_EXE($sql);

# Flow Count
$sql = "select count(*) as count from Ansible_linux_playbookflow_Save2";
$s_flow_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_playbookflow_Save2";
$s_flow_win = SQL_EXE($sql);

# Ad-hoc Execution Count
$sql = "select count(*) as count from Ansible_linux_adhoc_history where date_format(ah_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_adhoc_exe_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_adhoc_history where date_format(ah_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_adhoc_exe_win = SQL_EXE($sql);

# Playbook Execution Count
$sql = "select count(*) as count from Ansible_linux_playbook_history where date_format(p_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_playbook_exe_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_playbook_history where date_format(p_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_playbook_exe_win = SQL_EXE($sql);

# Flow Execution Count
$sql = "select count(*) as count from Ansible_linux_playbookflow_history2 where date_format(flow_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_flow_exe_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_playbookflow_history2 where date_format(flow_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_flow_exe_win = SQL_EXE($sql);


$insert_sql = "INSERT into Ansible_statistic values ('{$INPUT_DATE}', '{$s_inventory_lin}', '{$s_inventory_win}', '{$s_playbook_lin}', '{$s_playbook_win}', '{$s_flow_lin}', '{$s_flow_win}', '{$s_adhoc_exe_lin}', '{$s_adhoc_exe_win}', '{$s_playbook_exe_lin}', '{$s_playbook_exe_win}', '{$s_flow_exe_lin}', '{$s_flow_exe_win}')" ;

//echo "$insert_sql \n";
$res = mysqli_query($mysqli,$insert_sql);


?>
