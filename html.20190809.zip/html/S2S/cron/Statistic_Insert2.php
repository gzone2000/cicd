<?php


function SQL_EXE($sql) {

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

	$res = mysqli_query($mysqli,$sql);
	$row = mysqli_fetch_array($res);

	return $row["count"];
}


$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}


$DAYS = -1;
$INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));

$sql = "select * from Statistic where date = '{$INPUT_DATE}' ";
$res = mysqli_query($mysqli,$sql);
$num_rows = mysqli_num_rows($res);

if ($num_rows <= 0) {

	echo "Data Not Found!! \n";
	echo "Insert OK!! \n";


$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_gubun = 'N'";
$cmd_normal = SQL_EXE($sql);

$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' ";
$cmd_total = SQL_EXE($sql);

$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_gubun = 'N'";
$cmd_normal = SQL_EXE($sql);

$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_gubun = 'C'";
$cmd_crit = SQL_EXE($sql);

$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_status = 'B'";
$cmd_block = SQL_EXE($sql);


$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_gubun = 'C' and cmd_status = 'C'";
$cmd_crit_cancel = SQL_EXE($sql);

$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_gubun = 'C' and cmd_status = 'R'";
$cmd_crit_reject = SQL_EXE($sql);

$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_gubun = 'C' and cmd_status = 'E'";
$cmd_crit_execute = SQL_EXE($sql);


$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_status = 'B' and block_gubun = 'T'";
$cmd_block_time = SQL_EXE($sql);

$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_status = 'B' and block_gubun = 'I'";
$cmd_block_ip = SQL_EXE($sql);

$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_status = 'B' and block_gubun = 'C'";
$cmd_block_cmd = SQL_EXE($sql);


$insert_sql = "INSERT into Statistic values ('{$INPUT_DATE}', '{$cmd_total}', '{$cmd_normal}', '{$cmd_crit}', '{$cmd_crit_execute}', '{$cmd_crit_reject}', '{$cmd_crit_cancel}', '{$cmd_block}', '{$cmd_block_time}', '{$cmd_block_ip}', '{$cmd_block_cmd}')" ;

//echo "$insert_sql \n";
$res = mysqli_query($mysqli,$insert_sql);

}


?>
