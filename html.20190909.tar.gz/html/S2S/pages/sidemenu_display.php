<?php
echo "
                    <ul class='nav' id='side-menu'>
                        <li>
                            <a href='index.php'><i class='fa fa-dashboard fa-fw'></i> Dashboard</a>
                        </li>

                        <li>
                            <a href='#'><i class='fa fa-linux fa-fw'></i> $MENU1<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='ansible_linux_command.php'> $MENU1_1</a>
                                </li>
                                <li>
                                    <a href='set_ip.php'> $MENU1_2</a>
                                </li>
                                <li>
                                    <a href='set_command.php'> $MENU1_3</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

                        <li>
                            <a href='#'><i class='fa fa-windows fa-fw'></i> $MENU2<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='ansible_window_command.php'> $MENU2_1</a>
                                </li>
                                <li>
                                    <a href='ansible_inventory.php'> $MENU2_2</a>
                                </li>
                                <li>
                                    <a href='ansible_playbook.php'> $MENU2_3</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

                        <li>
                            <a href='#'><i class='fa fa-cube fa-fw'></i> $MENU3<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='#'> $MENU3_1</a>
                                </li>
                                <li>
                                    <a href='#'> $MENU3_2</a>
                                </li>
                                <li>
                                    <a href='#'> $MENU3_3</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
";

if($_SESSION[auth_level] == '0') {
        echo "

                        <li>
                            <a href='#'><i class='fa fa-list-ul fa-fw'></i> $MENU4<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>

                                <li>
                                    <a href='#'> $MENU4_1<span class='fa arrow'></span></a>
                                    <ul class='nav nav-third-level'>
                                        <li>
                                            <a href='ansible_linux_inventory_search.php'> $MENU4_1_1</a>
                                        </li>
                                        <li>
                                            <a href='ansible_linux_inventory_group.php'> $MENU4_1_2</a>
                                        </li>
                                        <li>
                                            <a href='ansible_linux_inventory_bulk_upload.php'> $MENU4_1_3</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->

                                <li>
                                    <a href='#'> $MENU4_2<span class='fa arrow'></span></a>
                                    <ul class='nav nav-third-level'>
                                        <li>
                                            <a href='ansible_window_inventory_search.php'> $MENU4_1_1</a>
                                        </li>
                                        <li>
                                            <a href='ansible_window_inventory_group.php'> $MENU4_1_2</a>
                                        </li>
                                        <li>
                                            <a href='ansible_window_inventory_bulk_upload.php'> $MENU4_1_3</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>
                                <li>
                                    <a href='#'> $MENU4_3</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
	";
}


echo "
                        <li>
                            <a href='#'><i class='glyphicon glyphicon-play'></i> $MENU5<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>

                                <li>
                                    <a href='#'> $MENU5_1<span class='fa arrow'></span></a>
                                    <ul class='nav nav-third-level'>
";

if($_SESSION[auth_level] == '0') {
        echo "
                                        <li>
                                            <a href='ansible_linux_playbook_CRUD.php'> $MENU5_1_1</a>
                                        </li>
	";
}


echo "
                                        <li>
                                            <a href='ansible_linux_playbook_exec.php'> $MENU5_1_2</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->

                                <li>

                                <li>
                                    <a href='#'> $MENU5_2<span class='fa arrow'></span></a>
                                    <ul class='nav nav-third-level'>
";


if($_SESSION[auth_level] == '0') {
        echo "
                                        <li>
                                            <a href='ansible_window_playbook_CRUD.php'> $MENU5_1_1</a>
                                        </li>
	";
}


echo "
                                        <li>
                                            <a href='ansible_window_playbook_exec.php'> $MENU5_1_2</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>
                                <li>
                                    <a href='#'> $MENU5_3</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

                        <li>
                            <a href='#'><i class='fa fa-youtube-play fa-fw'></i> $MENU6<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>

                                <li>
                                    <a href='#'> $MENU6_1<span class='fa arrow'></span></a>
                                    <ul class='nav nav-third-level'>
";


if($_SESSION[auth_level] == '0') {      
        echo " 
                                        <li>
                                            <a href='ansible_linux_playbookflow_oyw.php'> $MENU6_1_1</a>
                                        </li>
	";
}


echo "
                                        <li>
                                            <a href='ansible_linux_playbookflow_exec_oyw.php'> $MENU6_1_2</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->

                                <li>

                                <li>
                                    <a href='#'> $MENU6_2<span class='fa arrow'></span></a>
                                    <ul class='nav nav-third-level'>
";

if($_SESSION[auth_level] == '0') {
        echo " 
                                        <li>
                                            <a href='ansible_window_playbookflow_oyw.php'> $MENU6_1_1</a>
                                        </li>
	";
}


echo "

                                        <li>
                                            <a href='ansible_window_playbookflow_exec_oyw.php'> $MENU6_1_2</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>
                                <li>
                                    <a href='#'> $MENU6_3</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
";

if($_SESSION[auth_level] == '0') {
        echo "  
                        <li>
                            <a href='#'><i class='glyphicon glyphicon-plane'></i> $MENU11<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='ansible_linux_playbookflow_cron.php'> $MENU11_1</a>
                                </li>
                                <li>
                                    <a href='ansible_window_playbookflow_cron.php'> $MENU11_2</a>
                                </li>
                                <li>
                                    <a href='#'> $MENU11_3</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
	";
}

echo "    
                        <li>
                            <a href='#'><i class='fa fa-history fa-fw'></i> $MENU7<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='#'> $MENU7_1<span class='fa arrow'></span></a>
                                    <ul class='nav nav-third-level'>
                                        <li>
                                            <a href='ansible_linux_adhoc_history.php'> $MENU7_1_0</a>
                                        </li>
                                        <li>
                                            <a href='ansible_linux_playbook_history.php'> $MENU7_1_1</a>
                                        </li>
                                        <li>
                                            <a href='ansible_linux_playbookflow_history.php'> $MENU7_1_2</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>

                                <li>
                                    <a href='#'> $MENU7_2<span class='fa arrow'></span></a>
                                    <ul class='nav nav-third-level'>
                                        <li>
                                            <a href='ansible_window_adhoc_history.php'> $MENU7_1_0</a>
                                        </li>
                                        <li>
                                            <a href='ansible_window_playbook_history.php'> $MENU7_1_1</a>
                                        </li>
                                        <li>
                                            <a href='ansible_window_playbookflow_history.php'> $MENU7_1_2</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>
                                <li>
                                    <a href='#'> $MENU7_3</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
";

if($_SESSION[auth_level] == '0') {
        echo "
                        <li>
                            <a href='#'><i class='glyphicon glyphicon-user'></i> $MENU8<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='user_mgmt.php'> $MENU8_1</a>
                                </li>
                                <li>
                                    <a href='set_mgmt_ip.php'> $MENU8_2</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

                        <li>
                            <a href='#'><i class='fa fa-desktop fa-fw'></i> $MENU9<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='login_active_list.php'> $MENU9_1</a>
                                </li>
                                <li>
                                    <a href='login_history.php'> $MENU9_2</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
	";
}

echo "

                        <li>
                            <a href='set_mgmt_mail.php'><i class='fa fa-envelope-o'></i> $MENU12</a>
                        </li>
                        <li>
                            <a href='ansible_stats.php'><i class='glyphicon glyphicon-stats'></i> $MENU13</a>
                        </li>
                        <li>
                            <a href='help.php'><i class='fa fa-wrench fa-fw'></i> $MENU10</a>
                        </li>
                        <li>
                            <a href='license.php'><i class='fa fa-institution fa-fw'></i> $MENU14</a>
                        </li>

                    </ul>


";

?>
