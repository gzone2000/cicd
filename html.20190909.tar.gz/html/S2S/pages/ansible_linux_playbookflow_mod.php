<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
$(function() {
$("[id^=button_playbook]").on('click', function(event){
    var id = $(this).attr("id");
    var Step = document.getElementById(id).value;
    var String = "./ansible_linux_playbookflow_Plist.php?STEP=" + Step;
    $("#list1").load(String);
});
});
</script>

<script>
$(function() {
$("[id^=button_inventory]").on('click', function(event){
    var id = $(this).attr("id");
    var P_name = document.getElementById(id).value;
    var String = "./ansible_linux_playbookflow_Ilist.php?PLAYBOOK=" + P_name;
    $("#list1").load(String);
});
});
</script>

<script>
function flowchk_CR() {

    var msg;
    var p_arg = document.getElementById('button_flowchk_CR').value;
    if (p_arg == '0') {

<?php
	$T_MAX = $FLOW_MAX;
	for($x=1; $x <= $T_MAX ; $x++) {
		echo "document.getElementById('button_playbook{$x}').disabled = true;";
		echo "document.getElementById('button_inventory{$x}').disabled = true;";
	}
?>

	var String = "./ansible_linux_playbookflow_saveSUB.php";
    	$("#txt5").load(String);

    }
    else {
	if (p_arg == 'NO') msg = "먼저 Flow 항목을 채워 주시기 바랍니다!!";
        else msg = p_arg + "단계 Flow Inventory항목이 비어 있습니다. 확인 바랍니다!!";

	alert(msg);
    }

}
</script>

<script>
function flowchk_MOD(fname,act) {

    var msg;
    var p_arg = document.getElementById('button_flowchk_MOD').value;
    if (p_arg == '0') {

<?php
        $T_MAX = $FLOW_MAX;
        for($x=1; $x <= $T_MAX ; $x++) {
                echo "document.getElementById('button_playbook{$x}').disabled = true;";
                echo "document.getElementById('button_inventory{$x}').disabled = true;";
        }
?>

        var String = "./ansible_linux_playbookflow_saveMOD_SUB.php?F_NAME=" + fname + "&ACT=" + act;
        $("#txt5").load(String);

    }
    else {
	if (p_arg == 'NO') msg = "먼저 Flow 항목을 채워 주시기 바랍니다!!";
        else msg = p_arg + "단계 Flow Inventory항목이 비어 있습니다. 확인 바랍니다!!";

	alert(msg);
    }

}
</script>

<script>
function popitup1(f_name) {
    var url = "./ansible_linux_playbookflow_content_popup.php?name=" + f_name;
    window.open(url,"Flow Show","width=1400,height=400,left=100,top=60");
}
</script>

</head>

<body>



<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];



	$ACT = trim($_GET['ACT']);
	$F_NAME = trim($_GET['F_MOD']);
        $cmd_sql = "select * from Ansible_linux_playbookflow_Save where f_name = '{$F_NAME}'";
        $res = mysqli_query($mysqli,$cmd_sql);

        $newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
        $f_name = $newArray['f_name'];
        $f_explain= $newArray['f_explain'];
        $f_explain_dec = base64_decode($f_explain);
        $f_content = $newArray['f_content'];
        $f_gubun = $newArray['f_gubun'];

	$SELECT_STR5 = '';
        $cmd_sql5 = "select * from Ansible_playbookflow_gubun";
        $res5 = mysqli_query($mysqli,$cmd_sql5);
        if ($res5) {
		$cnt=1;
               	while ($newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                       	$gubun5 = $newArray5['gubun'];
                	$gubun_name5 = $newArray5['gubun_name'];

			if($f_gubun == $gubun5) $SELECT_OPT = "selected";
			else $SELECT_OPT = '';

			$STR5 = "<option value=$cnt $SELECT_OPT>$gubun_name5</option>";
			$SELECT_STR5 = $SELECT_STR5 . $STR5 ;

			$cnt = $cnt + 1;
		}
	}


        $cmd_sql = "delete from Ansible_linux_playbookflow_op";
        $res = mysqli_query($mysqli,$cmd_sql);

	$T_FLOW = explode('||',$f_content);
        foreach($T_FLOW as $SubFlow) {
                $SUBFLOW = explode('|',$SubFlow);
                $STEP = $SUBFLOW[0];
                $P_NAME = $SUBFLOW[1];
                $MEMBERS = $SUBFLOW[2];

        	$cmd_sql = "insert into Ansible_linux_playbookflow_op values('{$STEP}','{$P_NAME}','{$MEMBERS}')";
        	$res = mysqli_query($mysqli,$cmd_sql);
        }




	echo "

			 <div id='P_mod' class='row'>
                            <div class='col-lg-4'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table id=table1 value='$F_NAME'>
                               <tr><td style='height:33px'><font size=3>Flow 수정하기:&nbsp;'$F_NAME'</font></td></tr>
                               </table>

                              </div>
                            </div>

                            <div class='col-lg-8'>
                            </div>
			 </div>


                      <div id=wrapper>
                        <div class='panel-body'>
            		  <div class='row'>
                	    <div class='col-lg-12'>
				<div id='txt1'>

	";


			// 버튼 갯수 늘어 나면 T_MAX 수정 필요 
			$T_MAX = $FLOW_MAX;

			$TOTAL_FLOW = '';
			$SUB_FLOW = '';
			$PIECES = explode("yYuYQ",$_GET['PLAYBOOK']);
			$PLAYBOOK = $PIECES[0];
			$STEP = $PIECES[1];


                        echo "<table border=0>";
                        echo "<tr align=center>";
			for($x=1;$x <= $T_MAX; $x++) {
                        	echo "<td><button class='btn btn-info' style='cursor:auto'>{$x}</button></td><td height=37 width=300><button style='width:100%' id=button_playbook{$x} value='{$x}yYuYQ{$F_NAME}' name=btn_p{$x} class='btn btn-warning'>Playbook</button></td>";
				if($x != $T_MAX) echo "<td width=70 rowspan=2><img src='../vendor/login/arrow_red.png' height=30 width=30></td>";
			}
                        echo "</tr>";


                        echo "<tr align=center>";
			for($x=1;$x <= $T_MAX; $x++) {
				echo "<td colspan=2 height=37 width=300><button style='width:100%' id='button_inventory{$x}' value='{$PLAYBOOK}yYuYQ{$x}yYuYQ{$F_NAME}' class='btn btn-success'>Inventory</button></td>";
			}
                        echo "</tr>";
                        echo "</table>";


?>

                                 </div>
                              </div>
                              </div>
                              </div>

                            </div>
                          </div>


            		  <div class="row">
                            <div class="col-lg-12">
			      <div id="list1">

<?php


	echo "<script>";
        for($x=1; $x <= $T_MAX ; $x++) {
		if($x != 1) echo "document.getElementById('button_playbook{$x}').disabled = true;";
                echo "document.getElementById('button_inventory{$x}').disabled = true;";
        }
	echo "</script>";

	$sql="SELECT count(*) as COUNT FROM Ansible_linux_playbookflow_op";
	$res = mysqli_query($mysqli,$sql);
	$row = mysqli_fetch_array($res);
	$MAX  = $row["COUNT"];

        echo "<script type='text/javascript'>";
        for ($x=1;$x <= $MAX ; $x++) {

                $sql="SELECT * FROM Ansible_linux_playbookflow_op WHERE step='{$x}'";
                $res = mysqli_query($mysqli,$sql);

                $row = mysqli_fetch_array($res);
                $p_name1  = $row["p_name"];
                $member1 = $row["member"];
		if($member1) $member_display1= str_replace(",","<br>",$member1);
		else $member_display1="Inventory";

                echo "document.getElementById('button_playbook{$x}').innerHTML = '{$p_name1}';";
                echo "document.getElementById('button_inventory{$x}').innerHTML = '{$member_display1}';";

		$T_Playbook = $p_name1 . "yYuYQ" . $x . "yYuYQ" . $F_NAME;
		echo "document.getElementById('button_inventory{$x}').value = '{$T_Playbook}';";

                echo "document.getElementById('button_playbook{$x}').disabled = false;";
                echo "document.getElementById('button_inventory{$x}').disabled = false;";
        }
	$I_MAX = $MAX + 1;
	echo "document.getElementById('button_playbook{$I_MAX}').disabled = false;";
        echo "</script>";


        if ($PLAYBOOK and $_GET['MEMBER']) {
		$MEMBER_LIST = $_GET['MEMBER'];
		$MEMBER_DISPLAY = str_replace(",","<br>",$MEMBER_LIST);
                echo "<div class='panel-body'>";
                echo "<div>";
                //echo "<font color=blue>ㅇ 선택된 Playbook: $PLAYBOOK , Step : $STEP , MAX : $MAX</font><br>";
                //echo "<font color=blue>ㅇ 선택된 호스트/그룹: $MEMBER_LIST</font><br>";
                echo "</div>";
                echo "</div>";
		$SUB_FLOW = $STEP . "|" . $PLAYBOOK . "|" . $MEMBER_LIST;
		$TOTAL_FLOW = $TOTAL_FLOW . $SUB_FLOW ;

		$sql="insert into Ansible_linux_playbookflow_op values('{$STEP}','{$PLAYBOOK}','{$MEMBER_LIST}') on duplicate key UPDATE p_name='{$PLAYBOOK}',member='{$MEMBER_LIST}'";
		$res = mysqli_query($mysqli,$sql);

		if($STEP > $MAX) $MAX = $STEP;

		$CNT = $STEP + 1;
		$sql="SELECT * FROM Ansible_linux_playbookflow_op WHERE step='{$CNT}'";
		$res = mysqli_query($mysqli,$sql);

		$row = mysqli_fetch_array($res);
		$p_name1  = $row["p_name"];

		echo "<script type='text/javascript'>";
		echo "document.getElementById('button_playbook{$STEP}').innerHTML = '{$PLAYBOOK}';";
		echo "document.getElementById('button_inventory{$STEP}').innerHTML = '{$MEMBER_DISPLAY}';";
		$T_Playbook = $p_name1 . "yYuYQ" . $STEP . "yYuYQ" . $F_NAME;
		//echo "document.getElementById('button_playbook{$STEP}').value = '{$PLAYBOOK}';";
		echo "document.getElementById('button_inventory{$STEP}').value = '{$T_Playbook}';";

		echo "document.getElementById('button_playbook{$STEP}').disabled = false;";
		echo "document.getElementById('button_inventory{$STEP}').disabled = false;";
		if(!$p_name1) { echo "document.getElementById('button_playbook{$CNT}').disabled = false;"; }
		if($MAX > $STEP) {
			$T_CNT = $MAX + 1;
			echo "document.getElementById('button_playbook{$T_CNT}').disabled = false;";
		}
		echo "</script>";
        }
	else if ($_GET['PLAYBOOK']) {
		$PIECES = explode("yYuYQ",$_GET['PLAYBOOK']);
		$PLAYBOOK = $PIECES[0];
		$STEP = $PIECES[1];
                echo "<div class='panel-body'>";
                echo "<div>";
                //echo "<font color=blue>ㅇ 선택된 Playbook: $PLAYBOOK , Step : $STEP</font><br>";
                echo "</div>";
                echo "</div>";

		$sql="insert into Ansible_linux_playbookflow_op values('{$STEP}','{$PLAYBOOK}','') on duplicate key UPDATE p_name='{$PLAYBOOK}'";
		$res = mysqli_query($mysqli,$sql);

		echo "<script type='text/javascript'>";
		echo "document.getElementById('button_playbook{$STEP}').innerHTML = '{$PLAYBOOK}';";
		echo "document.getElementById('button_playbook{$STEP}').disabled = false;";
		echo "document.getElementById('button_inventory{$STEP}').disabled = false;";
		if($MAX > $STEP) {
			$T_CNT = $MAX + 1;
			echo "document.getElementById('button_playbook{$T_CNT}').disabled = false;";
		}
		echo "</script>";


	}
	else echo "<br>";


?>

			      </div>

                            </div>
			  </div>


                        <div class="panel-body">

                          <div class="row">
                            <div class="col-lg-12">

                                  <div id='txt5'>

<?php


        $sql="SELECT count(*) as COUNT FROM Ansible_linux_playbookflow_op";
        $res = mysqli_query($mysqli,$sql);
        $row = mysqli_fetch_array($res);
        $MAX  = $row["COUNT"];

	$SKIP = 0;
        for ($x=1;$x <= $MAX ; $x++) {

                $sql="SELECT * FROM Ansible_linux_playbookflow_op WHERE step='{$x}'";
                $res = mysqli_query($mysqli,$sql);

                $row = mysqli_fetch_array($res);
                $member1 = $row["member"];
                if(!$member1) {
			$SKIP=$x;
			break;
		}
        }


	if($ACT == "MOD") {
		if($MAX == 0) echo "<button id='button_flowchk_MOD' value='NO' class='btn btn-danger' onclick='flowchk_MOD(\"$F_NAME\",\"$ACT\")'>Flow 체크</button>";
		else echo "<button id='button_flowchk_MOD' value='{$SKIP}' class='btn btn-danger' onclick='flowchk_MOD(\"$F_NAME\",\"$ACT\")'>Flow 체크</button>";
	}
	else {
		if($MAX == 0) echo "<button id='button_flowchk_CR' value='NO' class='btn btn-danger' onclick='flowchk_CR()'>Flow 체크</button>";
		else echo "<button id='button_flowchk_CR' value='{$SKIP}' class='btn btn-danger' onclick='flowchk_CR()'>Flow 체크</button>";

	}



        echo "


			    </div>

            		  </div> 
                        </div'> 
                      </div>

	";


?>





    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




