<?php

session_start();
if (!$_SESSION[ss_id]) {
        header('Location: ./logout.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
include "ip.inc" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->


<script>
function myFunctionMOD(playname,explain,gubun,gubun1,gubun2,playbook) {

        var url1 = "./ansible_window_playbook_modifysave.php?PNAME='" + playname + "'&EXPALIN='" + explain + "'&GUBUN='" + gubun + "'&GUBUN1='" + gubun1 + "'&GUBUN2='" + gubun2 + "'&PLAYBOOK='" + playbook +"'";
        //alert(url1);
        location.replace(url1);
}
</script>

<script type="text/javascript">
function checkNsave(){

var pname = document.getElementById('PNAME').value;
var playbook = document.getElementById('PLAYBOOK').value;
var explain = document.getElementById('EXPALIN').value;
var gubun = document.getElementById('GUBUN').value;
var gubun1 = document.getElementById('GUBUN1').value;
var gubun2 = document.getElementById('GUBUN2').value;


var blank_pattern = /[\s]/g;
if( blank_pattern.test( pname) == true){
alert('이름 항목엔 공백은 사용할 수 없습니다. ');
return false;
}

var special_pattern = /[`~!@#$%^&*()\[\]{}+|\\\'\";:\/?]/gi;
if( special_pattern.test(pname) == true ){
alert('이름 항목엔 특수문자는 사용할 수 없습니다.');
return false;
}

var hangul_pattern = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
if( hangul_pattern.test(pname) == true ){
alert('이름 항목엔 한글을 사용할 수 없습니다.');
return false;
}

        var url1 = './ansible_window_playbook_save.php';
        var form = document.createElement("form");

        form.setAttribute("method","post");
        form.setAttribute("action",url1);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type","hidden");
        hiddenField.setAttribute("name","PNAME");
        hiddenField.setAttribute("value",pname);
        form.appendChild(hiddenField);

        var hiddenField1 = document.createElement("input");
        hiddenField1.setAttribute("type","hidden");
        hiddenField1.setAttribute("name","PLAYBOOK");
        hiddenField1.setAttribute("value",playbook);
        form.appendChild(hiddenField1);

        var hiddenField2 = document.createElement("input");
        hiddenField2.setAttribute("type","hidden");
        hiddenField2.setAttribute("name","EXPALIN");
        hiddenField2.setAttribute("value",explain);
        form.appendChild(hiddenField2);

        var hiddenField3 = document.createElement("input");
        hiddenField3.setAttribute("type","hidden");
        hiddenField3.setAttribute("name","GUBUN");
        hiddenField3.setAttribute("value",gubun);
        form.appendChild(hiddenField3);

        var hiddenField4 = document.createElement("input");
        hiddenField4.setAttribute("type","hidden");
        hiddenField4.setAttribute("name","GUBUN1");
        hiddenField4.setAttribute("value",gubun1);
        form.appendChild(hiddenField4);

        var hiddenField5 = document.createElement("input");
        hiddenField5.setAttribute("type","hidden");
        hiddenField5.setAttribute("name","GUBUN2");
        hiddenField5.setAttribute("value",gubun2);
        form.appendChild(hiddenField5);

        document.body.appendChild(form);
        form.submit();


}
</script>




</head>

<body>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];


        $ACTION = trim($_GET['action']);
        $T_PNAME = trim($_GET['PNAME']);
	$T_PNAME = str_replace("'","",$T_PNAME);
        $T_EXPALIN_ORG = trim($_GET['EXPALIN']);
	$T_EXPALIN_ORG = str_replace("'","",$T_EXPALIN_ORG);
        $T_EXPALIN = urlencode($T_EXPALIN_ORG);
        $T_EXPALIN = base64_decode($T_EXPALIN);
        $T_GUBUN = trim($_GET['GUBUN']);
	$T_GUBUN = str_replace("'","",$T_GUBUN);
        $T_GUBUN1 = trim($_GET['GUBUN1']);
        $T_GUBUN1 = str_replace("'","",$T_GUBUN1);
        $T_GUBUN2 = trim($_GET['GUBUN2']);
        $T_GUBUN2 = str_replace("'","",$T_GUBUN2);
        $PLAYBOOK_ORG = trim($_GET['PLAYBOOK']);
	$PLAYBOOK_ORG = str_replace("'","",$PLAYBOOK_ORG);
        $PLAYBOOK = base64_decode($PLAYBOOK_ORG);
	//echo "<pre>$PLAYBOOK_ORG</pre>";
	//echo "<pre>$PLAYBOOK</pre>";


	if ($PLAYBOOK_ORG)
	{


/*

# Ansible Directory
$ANSIBLE_DIR = "/home/ansible";
$ANSIBLE_PLAYBOOK_DIR = "$ANSIBLE_DIR/playbook";
$ANSIBLE_HOST_DIR = "$ANSIBLE_DIR/host";
$ANSIBLE_LOG_DIR = "$ANSIBLE_DIR/log";
$ANSIBLE_EXEC_DIR = "$ANSIBLE_DIR/exec";

*/

        $PLAYBOOK_SAVE = $PLAYBOOK;
        $PLAYBOOK = str_replace("$","UUaU",$PLAYBOOK);
        $PLAYBOOK = str_replace("'","UUbU",$PLAYBOOK);

        $PLAYBOOK_CREATE = shell_exec("echo '$PLAYBOOK' > $ANSIBLE_EXEC_DIR/playbook5.yml");

        $EXEC2 = "sed -i \"s|UUaU|$|g\" $ANSIBLE_EXEC_DIR/playbook5.yml";
        $PLAYBOOK_CREATE = shell_exec("$EXEC2");

        $EXEC3 = "sed -i \"s|UUbU|'|g\" $ANSIBLE_EXEC_DIR/playbook5.yml";
        $PLAYBOOK_CREATE = shell_exec("$EXEC3");

        $EXEC3 = "sed -i \"s|UUcU|>|g\" $ANSIBLE_EXEC_DIR/playbook5.yml";
        $PLAYBOOK_CREATE = shell_exec("$EXEC3");

        $EXEC3 = "sed -i \"s|UUeU|<|g\" $ANSIBLE_EXEC_DIR/playbook5.yml";
        $PLAYBOOK_CREATE = shell_exec("$EXEC3");

        $PLAYBOOK_DISPALY = shell_exec("cat $ANSIBLE_EXEC_DIR/playbook5.yml");
        //echo "<pre>$PLAYBOOK_DISPALY</pre>";
        //echo "<br>";

	$ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log5.txt";
        $FULLSTR = "ansible-playbook --syntax-check -i $ANSIBLE_HOST_DIR/hosts $ANSIBLE_EXEC_DIR/playbook5.yml";
        $CMD_LINE = shell_exec("$FULLSTR > $ANSIBLE_LOG_FILE 2>&1");
        $Fail_CNT1 = shell_exec("cat $ANSIBLE_LOG_FILE | grep 'playbook: $ANSIBLE_EXEC_DIR/playbook5.yml' | wc -l");

        if ($Fail_CNT1 == 1) {
		$MSG1 = "성공";
		$SUCC = 'Y';
	}
	else {
		$MSG1 = "실패";
                $SUCC = 'N';
        }



	if($ACTION == 'check') {

		echo "<br>ㅇ Playbook Syntax 체크 결과 : <b><font color=blue>$MSG1</font></b><br>";
        	$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
        	echo "<pre>$RESULT_DISPLAY</pre>";

		//$RESULT = shell_exec("$ANSIBLE_PLAYBOOK_DIR/parser.sh $ANSIBLE_LOG_FILE 2>&1");
		//echo "<pre>$RESULT</pre>";

		if ($SUCC == 'Y') {
        		echo "
			      <br>
			      <br>

                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>playbook 수정</font></b>
                              </div>

			      <br>
                              <div class='form-group has-error'>
                                     <table><tr><td width=230>
                                     <input type='text' class='form-control' id='PLAYBOOK' value='{$T_PNAME}' disabled></td><td>&nbsp;&nbsp;</td>
			             <td><button type=submit id=button1_save name=btn1_save onclick='myFunctionMOD(\"$T_PNAME\",\"$T_EXPALIN_ORG\",\"$T_GUBUN\",\"$T_GUBUN1\",\"$T_GUBUN2\",\"$PLAYBOOK_ORG\")' class='btn btn-danger' style='width:100%'>Playbook 수정완료 Click!!</button></td></tr>
                                     </table>
                              </div>



			      <br>
			";
		}

	}
	else {

        	echo "
                      <div id=wrapper>
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>신규 playbook 만들기</font></b>
                              </div>

<textarea rows=16 cols=100 id=PLAYBOOK_CR disabled form='usrform'>
$PLAYBOOK_DISPALY</textarea>

                            </div>

                            <div class='col-lg-3'>
                            </div>

                            <div class='col-lg-6'>

                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>신규 playbook 문법 체크</font></b>
                              </div>

		";

		echo "<br>ㅇ Playbook Syntax 체크 결과 : <b><font color=blue>$MSG1</font></b><br>";
        	$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
        	echo "<pre>$RESULT_DISPLAY</pre>";

		//$RESULT = shell_exec("$ANSIBLE_PLAYBOOK_DIR/parser.sh $ANSIBLE_LOG_FILE 2>&1");
		//echo "<pre>$RESULT</pre>";


		if ($SUCC == 'Y') {


                        $SELECT_STR5 = '';
                        $cmd_sql5 = "select * from Ansible_playbook_gubun";
                        $res5 = mysqli_query($mysqli,$cmd_sql5);
                        if ($res5) {
                                $cnt=1;
                                while ($newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                                        $gubun5 = $newArray5['gubun'];
                                        $gubun_name5 = $newArray5['gubun_name'];

                                        $STR5 = "<option value=$cnt>$gubun_name5</option>";
                                        $SELECT_STR5 = $SELECT_STR5 . $STR5 ;

                                        $cnt = $cnt + 1;
                                }
                        }

                        $SELECT_STR9 = '';
                        $cmd_sql9 = "select * from Ansible_playbook_gubun1";
                        $res9 = mysqli_query($mysqli,$cmd_sql9);
                        if ($res9) {
                                $cnt=1;
                                while ($newArray9 = mysqli_fetch_array($res9,MYSQLI_ASSOC)) {
                                        $gubun9 = $newArray9['gubun'];
                                        $gubun_name9 = $newArray9['gubun_name'];

                                        $STR9 = "<option value=$cnt>$gubun_name9</option>";
                                        $SELECT_STR9 = $SELECT_STR9 . $STR9 ;

                                        $cnt = $cnt + 1;
                                }
                        }

                        $SELECT_STR7 = '';
                        $cmd_sql7 = "select * from Ansible_playbook_gubun2";
                        $res7 = mysqli_query($mysqli,$cmd_sql7);
                        if ($res7) {
                                $cnt=1;
                                while ($newArray7 = mysqli_fetch_array($res7,MYSQLI_ASSOC)) {
                                        $gubun7 = $newArray7['gubun'];
                                        $gubun_name7 = $newArray7['gubun_name'];

                                        $STR7 = "<option value=$cnt>$gubun_name7</option>";
                                        $SELECT_STR7 = $SELECT_STR7 . $STR7 ;

                                        $cnt = $cnt + 1;
                                }
                        }

        		echo "
			      <br>
			      <br>

                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>신규 playbook 저장</font></b>
                              </div>

			      <br>
			      <table border=1>
			      <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 이름: </label></td>
			      <td width=400><input type='text' class='form-control' id=PNAME value='Play_OS_Install.yml'></td>
			      <td><input type='hidden' id=PLAYBOOK value={$PLAYBOOK_ORG}></td></tr>
			      <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 설명: </label></td>
			      <td width=400><input type='text' class='form-control' id=EXPALIN value='설명기재'></td><td></td></tr>
			      <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 구분: </label></td>
			      <td width=400><select class=form-control id=GUBUN>
			      {$SELECT_STR5}
			      </select></td><td></td></tr>

                              <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 분류: </label></td>
                              <td width=400><select class=form-control id=GUBUN1>
                              {$SELECT_STR9}
                              </select></td><td></td></tr>

                              <tr><td width=100><label class='control-label' for='inputSuccess'>ㅇ 사용범위: </label></td>
                              <td width=400><select class=form-control id=GUBUN2>
                              {$SELECT_STR7}
                              </select></td><td></td></tr>

			      <tr><td align=center colspan=3>
			      <button id=button1_save name=btn1_save class='btn btn-success' style='width:100%' onClick='checkNsave()'>Playbook Save Click!!</button>
			      </td></tr>
			      </table>

			      </form>

		";
		}

		echo "
                            </div>
                          </div>
                        </div>
                      </div>

		";

		}

	}
	else {
		echo "<br><font color=red>ㅇ Playbook 항목이 비어 있습니다. 확인 바랍니다!! </font><br>";

	}



?> 

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>




</body>

</html>




