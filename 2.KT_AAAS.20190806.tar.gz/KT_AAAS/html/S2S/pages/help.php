<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->


<script>
function popitup1(f_name) {
    var url = "./help_RSA_Key.php";
    window.open(url,"Ansible Public Key","width=760,height=400,left=100,top=60,location=no");
}
</script>


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">도움말</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
                        echo "<table colnum=3>";
                        echo "<tr><td width=250><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;&nbsp;KT Star 도움말</font>";
                        echo "</td></tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->

<?php

        $CMD_COND = " where date >= '{$INPUT_DATE}' and date <= '{$INPUT_DATE1}' " ;
        $ORDER = "order by date asc, time asc" ;
        $cmd_sql = "select * from input_cmd_list " . $CMD_COND . $ORDER;
        ###echo "# SQL : {$cmd_sql}";
?>

                        <div class="panel-body">




            <div class="row">
                <div class="col-lg-6">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            Linux Agent용 ansible 연결
                        </div>
                        <div class="panel-body">
                            <p>Ansible 연결하려는 Linux서버에서 ansible 연동을 위한 설정 내용</p>
			  <ol>
			    <li> ansible 계정 생성 : # useradd -m ansible</li>
			    <li> ansible 계정 패스워드 만료 설정 : # passwd -x 99999 ansible</li>
			    <li> sudo 추가 : # visudo </li>
			     ansible ALL=(ALL) NOPASSWD: ALL 
			    <li> ansible 계정 로그인 : # su - ansible</li>
			    <li> .ssh 디렉토리 만들기 : $ mkdir .ssh</li>
			    <li> .ssh 디렉토리 모드 변경 : $ chmod 700 .ssh</li>
			    <li> .ssh 디렉토리 이동 : $ cd .ssh</li>
			    <li> authorized_keys 파일 만들기 : $ vi authorized_keys</li>
			    <li> authorized_keys 파일에 내용 넣기 : <button name=POPUP1 value='POPUP1' class='btn btn-success btn-xs' onclick='popitup1()'>Public Key 복사</button></li>
			    <li> authorized_keys 파일 모드 변경 : $ chmod 600 authorized_keys</li>
			  </ol>

			  <br><b><font color=red># CentOS5 경우 Python2.6 이상 설치와 패키지 업그레이드 필요: 지원불가</font></b>

                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            Window Agent용 ansible 연결
                        </div>
                        <div class="panel-body">
                            <p>Ansible 연결하려는 Window서버에서 ansible 연동을 위한 설정 내용</p>

<?php

echo "(참고) Download : <a href='./help_download.php'>ConfigureRemotingForAnsible.ps1</a>&nbsp;,&nbsp;<a href='./help_download1.php'>Upgrade-PowerShell.ps1</a>";

$DIR = "[DIR]";
$DISPLAY1 = "

1. 파워쉘 창 띄우기 및 ansible 계정 생성하고 계정 만료없게 만듬.

- 관리자권한으로 파워쉘 실행하기
PS C:\> net user ansible 패스워드입력 /add /active
PS C:\> net user ansible /expires:never
PS C:\> WMIC UserAccount Where \"Name='ansible'\" Set PasswordExpires=FALSE
PS C:\> net localgroup administrators ansible /add


2. 파워쉘 버젼과 .NET Framework 버젼 확인

PS C:\> \$PSVersionTable

Name                           Value
----                           -----
PSVersion                      5.0.10240.16384
WSManStackVersion              3.0
SerializationVersion           1.1.0.1
CLRVersion                     4.0.30319.42000
BuildVersion                   10.0.10240.16384
PSCompatibleVersions           {1.0, 2.0, 3.0, 4.0...}
PSRemotingProtocolVersion      2.3


PS C:\> dir c:\Windows\Microsoft.NET\Framework | findstr v
2015-07-10  오후 05:28    $DIR          .
2015-07-10  오후 05:28    $DIR          .
2015-07-10  오후 05:28    $DIR          v1.0.3705
2015-07-10  오후 05:28    $DIR          v1.1.4322
2015-07-10  오후 05:28    $DIR          v2.0.50727
2019-01-15  오후 04:21    $DIR          v4.0.30319


-----------------------------------------------------------------------
<font color=blue>ㅇ window2008일 경우 파워쉘 버젼업 해야함.</font>
-----------------------------------------------------------------------
\$file = \"C:\Upgrade-PowerShell.ps1\"
\$username = \"Administrator\"
\$password = \"패스워드입력\"
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force
&\$file -Version 5.1 -Username \$username -Password \$password -Verbose

<font color=red><b>(주의) 위의 작업 끝나고 자동 리부팅됨.</b></font>
-----------------------------------------------------------------------



3. WinRM (Windows Remote Management)  상태 보기 : 기본적으로 정지된 상태임.

PS C:\Users\Administrator> Get-Service -Name winrm

Status   Name               DisplayName
------   ----               -----------
Stopped  winrm              Windows Remote Management (WS-Manag...



4. ConfigureRemotingForAnsible.ps1 파일을 윈도우 C:\ 복사 후 아래 명령 실행

PS C:\> \$file = \"C:\ConfigureRemotingForAnsible.ps1\"
PS C:\> powershell.exe -ExecutionPolicy ByPass -File \$file

Self-signed SSL certificate generated; thumbprint: B4892877F97919023A166926D70F7EA9D754B35F

wxf                 : http://schemas.xmlsoap.org/ws/2004/09/transfer
a                   : http://schemas.xmlsoap.org/ws/2004/08/addressing
w                   : http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd
lang                : ko-KR
Address             : http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous
ReferenceParameters : ReferenceParameters



5.  WinRM (Windows Remote Management) 상태가 \"running\" 확인 

PS C:\> Get-Service -Name winrm

Status   Name               DisplayName
------   ----               -----------
Running  winrm              Windows Remote Management (WS-Manag...




6. winrm enumerate winrm/config/Listener 명령으로 리스너 확인이 되어야 함.

PS C:\> winrm enumerate winrm/config/Listener
Listener
    Address = *
    Transport = HTTP
    Port = 5985
    Hostname
    Enabled = true
    URLPrefix = wsman
    CertificateThumbprint
    ListeningOn = 127.0.0.1, 192.168.85.128, ::1, 2001:0:9d38:6abd:3c63:1584:883b:3199

Listener
    Address = *
    Transport = HTTPS
    Port = 5986
    Hostname = DESKTOP-FUK90I2
    Enabled = true
    URLPrefix = wsman
    CertificateThumbprint = B09503B5A1F8308B0CF9FEF6D8078A230429FC2F
    ListeningOn = 127.0.0.1, 192.168.85.128, ::1, 2001:0:9d38:6abd:3c63:1584:883b:3199

";

	echo "<pre>$DISPLAY1</pre>";
	echo "<br><b><font color=red># Window2008 경우 PowerShell 3.0 이상으로 업그레이드 필요</font></b>";

?>



			  </ul>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-6 -->

            </div>
            <!-- /.row -->


            <div class="row">
                <div class="col-lg-6">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            Ansible Master에 Ansible 패키지 설치
                        </div>
                        <div class="panel-body">
<?php

echo "<p>Ansible 패키지 설치</p>";
$DISPLAY_STR = "
# yum install epel-release -y
# yum install ansible -y
";

echo "<pre>$DISPLAY_STR</pre>";
?>


                        </div>
                    </div>
                </div>
                <!-- /.col-lg-6 -->
                <div class="col-lg-6">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            Window Agent용 연결 위한 Ansible Master 설정
                        </div>
                        <div class="panel-body">

<?php

echo "<p>Ansible Master에서 Window Agent용 연결을 위한 설정 내용</p>";
echo "(참고) Download : <a href='./help_download2.php'>get-pip.py</a>";
$DISPLAY_STR = "
# python get-pip.py  // 위의 get-pip.py 링크 클릭 및 다운로드  
# pip2 install \"pywinrm>=0.2.2\"
# pip freeze | grep -i winrm
pywinrm==0.3.0
";

echo "<pre>$DISPLAY_STR</pre>";
?>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-6 -->
            </div>
            <!-- /.row -->







                        </div>
                        <!-- /.panel-body -->


                        <div class="panel-footer">
                            <img src="../vendor/login/ansible_logo.png" width=150>
                        </div>



                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
