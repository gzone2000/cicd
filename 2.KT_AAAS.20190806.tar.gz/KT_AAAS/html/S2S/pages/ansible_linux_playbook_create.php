<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->


<script>
function myFunction() {
    var text1 = document.getElementById('PLAYBOOK_CR').value;
    if( text1 != "") {
    	document.getElementsByName("btn1_chk")[0].disabled = true;

    	$(document).ajaxStart(function(){
      		$("#wait").css("display", "block");
    	});
    	$(document).ajaxComplete(function(){
      		$("#wait").css("display", "none");
      		document.getElementsByName("btn1_chk")[0].disabled = false;
    	});

	text1 = text1.replace(/>/g,'UUcU');
	text1 = text1.replace(/</g,'UUeU');
	text1 = text1.replace(/~/g,'UUdU'); // Linux
    	var String = "./ansible_linux_playbook_syntax_chk.php?PLAYBOOK=" + btoa(text1);
    	//alert(String);
    	$("#txt1").load(String);
    }
    else {
	alert("Playbook 항목이 비어 있습니다. 확인 바랍니다!!");
    }
}
    document.getElementsByName("btn1_chk")[0].disabled = false;
</script>


</head>

<body>



<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>


<?php


	echo "
                      <div id=wrapper>
                        <div class='panel-body'>
            		  <div class='row'>
                	    <div class='col-lg-3'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>신규 playbook 만들기 </font></b>
                              </div>

<textarea rows=16 cols=100 id=PLAYBOOK_CR name=PLAYBOOK_CR form='usrform'>
---
- hosts: webservers
  become: true
  tasks:
  - name: shell command
    shell: \"df -h\"
    register: result

  - name: print Result
    debug: 
      msg: \"{{ result.stdout }}\"
</textarea>

                	    </div>

                	    <div class='col-lg-3'>
                	    </div>

                	    <div class='col-lg-6'>

                                <div>
				     <button id=button1 name=btn1_chk class='btn btn-success' onclick='myFunction()'>Playbook 문법 체크</button>
                                  <div id='txt1'>
                                  </div>

<div id='wait' style='display:none;position:absolute;top:80px;left:60px;padding:2px;'>
<img src='../vendor/login/loading2.gif' width=110 height=110 />
<br>
<font size=4 color=red><b> Loading...</b></font>
</div>


                                </div>

			    </div>

            		  </div> 
                        </div'> 
                      </div>
	";



?>




    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




