<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];


?>



        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Mail 수신자 관리</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">


<?php

$cmd_sql = "select * from Mail_list" ;

                        echo "<table>";
                        echo "<tr><td width=400><font size=3><i class='fa fa-envelope fa-fw'></i>&nbsp;Mail 수신자 관리(추가/삭제/변경)</font>";

			echo "<form action=./set_mgmt_mail.php>";
                        echo "<td><button class='btn btn-info btn-xs' type=submit name='ADD_NUM' value=9999><b>추가</b></button></td></form>";
                        echo "</tr>";
                        echo "</table>";
?>



                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">


                                 <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                 <thead>
                                    <tr>
                                        <th>Mail 주소</th>
                                        <th>이름</th>
                                        <th>운용부서</th>
                                        <th>메일발송 여부</th>
                                        <th>수정</th>
                                        <th>삭제</th>
                                    </tr>
                                 </thead>
                                 <tbody>


<?php
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $mail_id = $newArray['mail_id'];
                        $name = $newArray['name'];
                        $department = $newArray['department'];
                        $mail_send = $newArray['mail_send'];

			if($mail_send == 'Y') $MSG1 = "발송";
			else $MSG1 = "미발송";

                        echo "<tr>";
                        echo "<td width=80>{$mail_id}</td><td width=60>{$name}</td><td width=120>{$department}</td><td width=80>{$MSG1}</td>";
                        echo "<td width=50><form action=./set_mgmt_mail.php>";
                        echo "<center><button class='btn btn-warning btn-xs' type=submit name=MOD_NUM value={$mail_id}><b><font size=2>수정</font></b></button></center></form></td>";
                        echo "<td width=50><form action=./set_mgmt_mail.php>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=DEL_NUM value={$mail_id}><b><font size=2>삭제</font></b></button></center></form></td>";

                        echo "</tr>";   
                }
        }

	echo "</table>"	;

?>




                                </div>
                                <!-- /.col-lg-7 (nested) -->

                		<div class='col-lg-1'>
                		</div>

                                <div class="col-lg-5">

<?php

if($_GET['MOD_NUM']){

	$mail_id = trim($_GET['MOD_NUM']);
	$cmd_sql = "select * from Mail_list where mail_id = '{$mail_id}' " ;
	###echo "# SQL : {$cmd_sql}";
	###echo "<br>";
	$res5 = mysqli_query($mysqli,$cmd_sql);

        if ($res5) {
                while ($newArray = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                        $mail_id = $newArray['mail_id'];
                        $name = $newArray['name'];
                        $department = $newArray['department'];
                        $mail_send = $newArray['mail_send'];
                }
        }

	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 수정 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<form action=./set_mgmt_mail_mod.php method=POST>";

	echo "<table border=1>";
	echo "<tr><td width=200>";
	echo "<label class='control-label' for='inputSuccess'>ㅇ Mail 주소 : </label>";
	echo "</td>";
	echo "<td width=400>";
	echo "<input type='email' class='form-control' name=MAIL_ID value={$mail_id} readonly>";
	echo "</td></tr>";

        echo "<tr><td>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 이름 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=NAME value={$name}>";
        echo "</td></tr>";

        echo "<tr><td>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 운용부서 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=DEPARTMENT value={$department} maxlength=45>";
	echo "</td></tr>";
	echo "<tr><td>";
	echo "<label class='control-label' for='inputSuccess'>ㅇ 메일발송 여부 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<select class=form-control name=MAIL_SEND>";
        if($mail_send == 'Y') {
                echo "<option value=Y selected=selected>발송</option>";
                echo "<option value=N>미발송</option>";
        }
        else {
                echo "<option value=Y>발송</option>";
                echo "<option value=N selected=selected>미발송</option>";
        }
        echo "</select>";
        echo "</td></tr>";

        echo "</table>";

	echo "<br>";
	echo "수정 하시겠습니까? &nbsp;&nbsp;&nbsp;";
	echo "<button type=submit class='btn btn-success'>수정</button>";
	echo "</form>";

	echo "</div>";

}

elseif($_GET['modify']){
	if($_GET['modify'] == 1) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 수정 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 수정 완료되었습니다.!! </b></font>";
		echo "</div>";
	}

}

elseif($_GET['ADD_NUM']){

        echo "<div id=header>";
        echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
        echo "<br>";
        echo "<br>";
	echo "<form action=./set_mgmt_mail_add.php method=POST>";

	echo "<table border=1>";
	echo "<tr><td width=200>";
	echo "<label class='control-label' for='inputSuccess'>ㅇ Mail 주소 : </label>";
	echo "</td>";
	echo "<td width=400>";
	echo "<input type='email' class='form-control' name=MAIL_ID placeholder='test01@naver.com'>";
	echo "</td></tr>";

        echo "<tr><td>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 이름 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=NAME placeholder='이름' maxlength=45>";
        echo "</td></tr>";

        echo "<tr><td>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 운용부서 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=DEPARTMENT placeholder='부서이름' maxlength=45>";
	echo "</td></tr>";
	echo "<tr><td>";
	echo "<label class='control-label' for='inputSuccess'>ㅇ 메일발송 여부 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<select class=form-control name=MAIL_SEND>";
        echo "<option value=Y selected=selected>발송</option>";
        echo "<option value=N>미발송</option>";
        echo "</select>";
        echo "</td></tr>";
        echo "</table>";

	echo "<br>";
	echo "추가 하시겠습니까? &nbsp;&nbsp;&nbsp;";
	echo "<button type=submit class='btn btn-success'>추가</button>";
	echo "</form>";

	echo "</div>";

}

elseif($_GET['add']){
	if ($_GET['add'] == 9999){
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 추가 완료되었습니다.!! </b></font>";
		echo "</div>";
	}
	elseif($_GET['add'] == 1) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>빈 항목이 있습니다. 채워주시기 바랍니다.!! </b></font>";
		echo "</div>";
	}
	elseif($_GET['add'] == 2) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>Mail 주소가 중복됩니다. 확인 바랍니다.!! </b></font>";
		echo "</div>";
	}

}

elseif($_GET['DEL_NUM']){

	$mail_id = trim($_GET['DEL_NUM']);
	$cmd_sql = "select * from Mail_list where mail_id = '{$mail_id}' " ;
	###echo "# SQL : {$cmd_sql}";
	###echo "<br>";
	$res5 = mysqli_query($mysqli,$cmd_sql);

        if ($res5) {
                while ($newArray = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                        $mail_id = $newArray['mail_id'];
                        $name = $newArray['name'];
                        $department = $newArray['department'];
                        $mail_send = $newArray['mail_send'];
                }
        }


	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='fa fa-trash-o'></i> 삭제 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<form action=./set_mgmt_mail_del.php method=POST>";

	echo "<table border=1>";
	echo "<tr><td width=200>";
	echo "<label class='control-label' for='inputSuccess'>ㅇ Mail 주소 : </label>";
	echo "</td>";
	echo "<td width=400>";
	echo "<input type='email' class='form-control' name=MAIL_ID value='{$mail_id}' readonly>";
	echo "</td></tr>";

        echo "<tr><td>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 이름  : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=NAME value='$name' disabled>";
        echo "</td></tr>";

        echo "<tr><td>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 운용부서  : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=DEPARTMENT value='$department' maxlength=45 disabled>";
	echo "</td></tr>";
	echo "<tr><td>";
	echo "<label class='control-label' for='inputSuccess'>ㅇ 메일발송 여부 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<select class=form-control name=MAIL_SEND disabled>";
        if($mail_send == 'Y') {
                echo "<option value=Y selected=selected>발송</option>";
                echo "<option value=N>미발송</option>";
        }
        else {
                echo "<option value=Y>발송</option>";
                echo "<option value=N selected=selected>미발송</option>";
        }
        echo "</select>";
        echo "</td></tr>";
        echo "</table>";

	echo "<br>";
	echo "정말로 삭제하시겠습니다까? &nbsp;&nbsp;&nbsp;";
	echo "<button type=submit class='btn btn-success'>삭제</button>";
	echo "</form>";

	echo "</div>";

}

elseif($_GET['delete']){
	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='fa fa-trash-o'></i> 삭제 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 삭제 완료되었습니다.!! </b></font>";
	echo "</div>";

}

mysqli_free_result($res);
mysqli_close($mysqli); 

?>


                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->



<!---

            <div class="row">
                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">


	<form action=./set_mgmt_mail_relay.php>
	<table width="100%" class="table table-striped table-bordered table-hover">
	<tr><td colspan=3><label class='control-label' for='inputSuccess'><font size=3 color=blue><b>ㅇ Mail Relay Host가 필요한 경우에만 아래 Relay Mail 입력해 주세요!!<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mail Relay Host가 필요없는 경우에는 입력하지 않아도 됩니다.</b></font></label></td></tr>
        <tr><td width=270><label class='control-label' for='inputSuccess'> # Mail Relay Host IP / Domain 입력  : </label></td>
        <td width=270><input type='text' class='form-control' name=RELAY_MAIL placeholder='148.56.5.100 OR gateway.my.domain'></td>
        <td algin=center widh=100><button class='btn btn-info btn-sm' type=submit name='RELAY' value=CHANGE><b>적용</b></button></td></tr>
	</form>


			    </dv>
                        </div>
                    </div>
                </div>
            </div>

-->





        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
