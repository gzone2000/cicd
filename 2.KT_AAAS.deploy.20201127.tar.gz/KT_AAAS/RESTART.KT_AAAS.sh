docker restart KT_AAAS
