<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>

<script>
$(function() {
$("[id^=button_playbook]").on('click', function(event){ 
    var id = $(this).attr("id"); 
    var Step = document.getElementById(id).value;
    var String = "./ansible_linux_playbookflow_Plist.php?STEP=" + Step;
    $("#list1").load(String);
});
});
</script>

<script>
$(function() {
$("[id^=button_inventory]").on('click', function(event){
    var id = $(this).attr("id");
    var P_name = document.getElementById(id).value;
    var String = "./ansible_linux_playbookflow_Ilist.php?PLAYBOOK=" + P_name;
    $("#list1").load(String);
});
});
</script>

<script>
function myFunctionCRUD() {
    var String = "./ansible_linux_morning_chk_Create.php";
    location.replace(String);
    //$("#P_mod").load(String);
}
</script>

<script>
function popitup1(f_name) {
    var url = "./ansible_linux_playbookflow_content_popup_oyw.php?F_NAME=" + f_name;
    window.open(url,"Flow Show","width=1200,height=700,left=100,top=60");
}
</script>



</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$DAYS=$INPUT_DAYS ;
$INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));
$INPUT_DATE1 = date("Y-m-d",strtotime("0 days"));

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];


if($_SESSION[auth_level] != '0') {
        echo "<center><font color=red size=5><b>접근권한이 없습니다. 확인해 보시기 바랍니다!!</b></font></center>";
        exit(0);
}

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">조근 점검 > Linux > DashBoard </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
		echo "<table>";
		echo "<tr><td width=550><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux 조근 점검</font></td>";
		echo "</tr>";
		echo "</table>";
?>

		</div>
		<!-- /.panel-heading -->




<?php


$CRON = $_GET['CRON'];

if ($CRON and preg_match("/[^\d]/", $CRON)) {
        $FAULT = 'Y';
}

if ($MC_NUM and preg_match("/[^\d]/", $MC_NUM)) {
        $FAULT = 'Y';
}

if ($_GET['add'] and preg_match("/[^\d]/", $_GET['add'])) {
        $FAULT = 'Y';
}

if ($_GET['mod'] and preg_match("/[^\d]/", $_GET['mod'])) {
        $FAULT = 'Y';
}

if ($_GET['del'] and preg_match("/[^\d]/", $_GET['del'])) {
        $FAULT = 'Y';
}


	//echo "<p>NUMBER : $MC_NUM</p>";

	if($CRON) $cmd_sql = "select c_itemlist from Ansible_linux_morning_chk_cron where c_num = '{$CRON}' " ;
        else $cmd_sql = "select c_itemlist from Ansible_linux_morning_chk_cron" ;
        $res = mysqli_query($mysqli,$cmd_sql);

        $row = mysqli_fetch_array($res);
        $c_itemlist = $row["c_itemlist"];


        echo "

                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
	";

        echo "<tr><td width=190><font size=3><b>&nbsp;Linux 조근점검 Cron</b></font></td>";
	if(! $c_itemlist) {
	       echo "<td><button id=button1 name=btn1 class='btn btn-primary' onclick='myFunctionCRUD()'><b>만들기</b></button></td></tr>";
	}

	echo "
                               </table>

                              </div>
                            </div>
                            <div class='col-lg-7'>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-6'>
				<div id='txt1'>
	";

	if($c_itemlist) {

                // ITEM List display //
                $T_CNT = 0;
                $ITEM_LIST = '';
                $T_ITEM = explode('|',$c_itemlist);
                foreach($T_ITEM as $SubITEM) {

                        $itemname = $SubITEM;
                        if(!$ITEM_LIST) $ITEM_LIST = $itemname ;
                        else {
                             $ITEM_LIST = $ITEM_LIST . ",&nbsp;" . $itemname ;
                        }
                }



        	echo "
                                 <table width='100%' class='table table-striped table-bordered table-hover' id='dataTables-example'>
                                    <tr>
                                        <td>아이템 리스트</td><td>$ITEM_LIST</td>
				    </tr>
				 </table>	
                                 <table width='100%' class='table table-striped table-bordered table-hover' id='dataTables-example'>
                                 <thead>
                                    <tr>
                                        <th>번호</th>
                                        <th>Minute</th>
                                        <th>Hour</th>
                                        <th>Day</th>
                                        <th>Month</th>
                                        <th>Week</th>
                                        <th>Command</th>
                                        <th>수정</th>
                                        <th>삭제</th>
                                        <th>메일 발송</th>
                                    </tr>
                                 </thead>
                                 <tbody>
        	";


        $cmd_sql = "select * from Ansible_linux_morning_chk_cron" ;
        $res = mysqli_query($mysqli,$cmd_sql);

        $row = mysqli_fetch_array($res);
        $row_OK  = $row["c_num"];

        $cmd_sql = "select * from Ansible_linux_morning_chk_cron" ;
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($row_OK) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_num = $newArray['c_num'];
                        $c_min = $newArray['c_min'];
                        $c_min_chk = $newArray['c_min_chk'];
                        $c_hour = $newArray['c_hour'];
                        $c_hour_chk = $newArray['c_hour_chk'];
                        $c_day = $newArray['c_day'];
                        $c_month = $newArray['c_month'];
                        $c_week = $newArray['c_week'];
                        $c_cmd = $newArray['c_cmd'];
                        $c_mail = $newArray['c_mail'];

                        if($c_min_chk == 'Y' and $c_min != '*') $c_min = '* / ' . $c_min;
                        if($c_hour_chk == 'Y' and $c_hour != '*') $c_hour = '* / ' . $c_hour;

                        if($c_week == "*") $S_MSG="*";
                        else if($c_week == '0') $S_MSG="Sun";
                        else if($c_week == '1') $S_MSG="Mon";
                        else if($c_week == '2') $S_MSG="Tus";
                        else if($c_week == '3') $S_MSG="Wed";
                        else if($c_week == '4') $S_MSG="Thu";
                        else if($c_week == '5') $S_MSG="Fri";
                        else if($c_week == '6') $S_MSG="Sat";

                        echo "<tr>";
                        echo "<td>{$c_num}</td><td>{$c_min}</td><td>{$c_hour}</td><td>{$c_day}</td><td>{$c_month}</td><td>{$S_MSG}</td><td>{$c_cmd}</td>";

                        echo "<td width=50><form action=./ansible_linux_morning_chk_Modify.php>";
                        //echo "<input type=hidden name=FLOW value={$FLOW}></input>";
                        echo "<center><button class='btn btn-warning btn-xs' type=submit name=C_NUM value={$c_num}><b><font size=2>수정</font></b></button></center></form></td>";

                        echo "<td width=50><form action=./ansible_linux_morning_chk_Delete.php>";
                        //echo "<input type=hidden name=FLOW value={$FLOW}></input>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=C_NUM value={$c_num}><b><font size=2>삭제</font></b></button></center></form></td>";

                        if($c_mail == 'Y') $MSG5 = "YES";
                        else $MSG5 = "NO";
                        echo"<td align=center>$MSG5</td>";

                        echo "</tr>";  
                }
           }
           echo "</table>" ;

	}







	echo "
			        </div>
			      </div>

			      <div class='col-lg-6'>
			      </div>


                            </div>


                        <div class='panel-body'>

                          <div class='row'>
                            <div class='col-lg-12'>

                                  <div id='txt5'>

	";

if($_GET['add']){
        if ($_GET['add'] == 9999){
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 추가 완료되었습니다.!! </b></font>";
                echo "</div>";
        }
        elseif($_GET['add'] == 1) {
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ Flow 항목이 비어 있습니다. 채워주시기 바랍니다.!! </b></font>";
                echo "</div>";
        }
        elseif($_GET['add'] == 2) {
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 클라이언트 IP가 중복됩니다. 확인 바랍니다.!! </b></font>";
                echo "</div>";
        }
        elseif($_GET['add'] == 3) {
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</b></font>";
                echo "</div>";
        }

}
else if($_GET['delete']){
        if($_GET['delete'] == 1) {
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 삭제 완료되었습니다.!! </b></font>";
                echo "</div>";
        }
        elseif($_GET['delete'] == 2) {
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 삭제할 Flow가 없습니다. 확인바랍니다!! </b></font>";
                echo "</div>";
        }
        elseif($_GET['delete'] == 3) {
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</b></font>";
                echo "</div>";
        }

}
else if($_GET['modify']){
        if($_GET['modify'] == 1) {
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 수정 완료되었습니다.!! </b></font>";
                echo "</div>";
        }
        elseif($_GET['modify'] == 2) {
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 수정할 번호가 없습니다. 확인 바랍니다.!! </b></font>";
                echo "</div>";
        }
        elseif($_GET['modify'] == 3) {
                echo "<div id=header>";
                echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</b></font>";
                echo "</div>";
        }

}


	echo "
<br>
<br>
<br>
<br>
<br>
<br>
                                 </div>
                            </div>
                          </div>



                        </div>
                        <!-- /.panel-body -->


                    </div>
                </div>
                </div>
                </div>
                </div>



<br>
	";

        echo "
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux 조근 점검 히스토리</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>조근점검번호</th>
                                        <th>실행시간</th>
                                        <th>종료시간</th>
                                        <th>실행ITEM</th>
                                        <th>조근점검결과</th>
                                        <th>실행서버수</th>
                                        <th>성공서버수</th>
                                        <th>실패서버수</th>
                                        <th>WARN 서버수</th>
                                        <th>CRIT 서버수</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
				<tbody id='myTable'>

        ";



		$CMD_COND = " where date_format(mc_starttime,'%Y-%m-%d') >= '{$INPUT_DATE}' and date_format(mc_starttime,'%Y-%m-%d') <= '{$INPUT_DATE1}' " ;
        	$ORDER = " order by mc_starttime desc" ;
        	$cmd_sql = "select * from Ansible_linux_morning_chk_Item_Result" . $CMD_COND . $ORDER;
        	#echo "# SQL : {$cmd_sql}";

                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $mc_seq = $newArray['mc_seq'];
                                $mc_starttime = $newArray['mc_starttime'];
                                $mc_endtime= $newArray['mc_endtime'];
                                $mc_item= $newArray['mc_item'];
                                $mc_result= $newArray['mc_result'];
                                $mc_total_cnt= $newArray['mc_total_cnt'];
                                $mc_succ_cnt = $newArray['mc_succ_cnt'];
                                $mc_fail_cnt = $newArray['mc_fail_cnt'];
                                $mc_warn_cnt = $newArray['mc_warn_cnt'];
                                $mc_crit_cnt = $newArray['mc_crit_cnt'];

				if ($mc_result == 'Y') $MSG1 = "성공";
				else $MSG1 = "실패";

				if ($mc_warn_cnt > 0) $WARN_MSG = "<b><font size=3 color=blue>$mc_warn_cnt</font></b>";
				else $WARN_MSG = "{$mc_warn_cnt}";

				if ($mc_crit_cnt > 0) $CRIT_MSG = "<b><font size=3 color=red>$mc_warn_cnt</font></b>";
				else $CRIT_MSG = "{$mc_crit_cnt}";

                        	echo "<tr><td>{$mc_seq}</td><td>{$mc_starttime}</td><td>{$mc_endtime}</td><td>{$mc_item}</td>";
                        	echo "<td>{$MSG1}</td><td>{$mc_total_cnt}</td><td>{$mc_succ_cnt}</td>";
                        	echo "<td>{$mc_fail_cnt}</td>";
                        	echo "<td>{$WARN_MSG}</td>";
                        	echo "<td>{$CRIT_MSG}</td>";
                        	echo "<td></td></tr>";

                        }
                }


                echo "</tbody>";
                echo "</table>";
                echo "</div>";

                echo "

                            </div>
                          </div>


                        </div>


                ";


?>



                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>
