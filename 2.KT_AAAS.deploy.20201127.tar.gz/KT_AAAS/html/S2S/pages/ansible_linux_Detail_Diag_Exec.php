<?php

$HTML_HEADER = "
<html lang='ko'>
<head>

    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <meta name='description' content=''>
    <meta name='author' content=''>

    <!-- Bootstrap Core CSS -->
    <link href='../vendor/bootstrap/css/bootstrap.min.css' rel='stylesheet'>

    <!-- MetisMenu CSS -->
    <link href='../vendor/metisMenu/metisMenu.min.css' rel='stylesheet'>

    <!-- DataTables CSS -->
    <link href='../vendor/datatables-plugins/dataTables.bootstrap.css' rel='stylesheet'>

    <!-- DataTables Responsive CSS -->
    <link href='../vendor/datatables-responsive/dataTables.responsive.css' rel='stylesheet'>

    <!-- Custom CSS -->
    <link href='../dist/css/sb-admin-2.css' rel='stylesheet'>

    <!-- Custom Fonts -->
    <link href='../vendor/font-awesome/css/font-awesome.min.css' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src='../vendor/datatables/js/html5shiv.js'></script>
        <script src='../vendor/datatables/js/respond.min.js'></script>
    <![endif]-->

</head>

<body>
";


$MAIL_HEADER = "
<html lang='ko'>
<head>

    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <meta name='description' content=''>
    <meta name='author' content=''>

<style>
table {
  border-collapse: collapse;width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #4CAF50;
  color: white;
}
</style>

</head>

<body>
";



include "css.php" ;
include "ip.inc" ;
include "Acase.php";

////// dec_enc Function Start //////

    $output = false;

    $encrypt_method = "AES-256-CBC";
    $action = "decrypt";
    $string = $MYSQL_PWD;
    $secret_key = $S_KEY;
    $secret_iv = $S_IV;

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

////// dec_enc Function End //////

$mysqli = new mysqli($MYSQL_HST,$MYSQL_USR,$output,$MYSQL_DBI);
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}


function dec_enc($action, $string, $secret_key, $secret_iv) {
    $output = false;

    $encrypt_method = "AES-256-CBC";

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}

$mysqli = new mysqli($MYSQL_HST,$MYSQL_USR,$output,$MYSQL_DBI);
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

/*****************************************************************
ㅇ 서버 정밀점점
- 인자 : 서버명 
- 분석 내용
  . CPU, MEM, Disk, Swap, Top 5 데몬 , 포트 리스트.......
*****************************************************************/


date_default_timezone_set("Asia/Seoul");
$UTIME_F = explode('.',microtime(true));
$T_UTIME = $UTIME_F[0];

$CMD_TIMEOUT_SEC = 2;

$EVENT = $_POST['EVENT'];
if ($EVENT and  preg_match("/[^a-z. :;,\||\d-]/i", $EVENT)) {
	$FAULT = 'Y';
}

$SERVER = $_GET['MEMBER'];
if ($SERVER and preg_match("/[^a-z.|\d_-]/i", $SERVER)) {
    	$FAULT = 'Y';
}

if ($EVENT and ! $SERVER) {
	$EVENT_SPLIT = explode('|',$EVENT);
	$EVENT_SERVER_NAME = $EVENT_SPLIT[0];
	$EVENT_CONT = $EVENT_SPLIT[1];

	$SERVER = $EVENT_SERVER_NAME;
}


$cmd_sql = "select count(*) as cnt from Ansible_linux_host where hostname = '$SERVER';";
$res5 = mysqli_query($mysqli,$cmd_sql);
$newArray3 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
$server_cnt = $newArray3['cnt'];

//echo "######################################\n";
//echo "EVENT MSG : $EVENT\n";
//echo "EVENT SERVER : $EVENT_SERVER_NAME\n";
//echo "EVENT CONTENT : $EVENT_CONT\n";


if ($FAULT != 'Y' and $server_cnt != 0) {

        $cnt = 0;
	$HOST_STR = '';
	$HOST_STR_T = '';

	// Linux 호스트 검색
        $cmd_sql1 = "select * from Ansible_linux_host where hostname = '$SERVER';";
        $res = mysqli_query($mysqli,$cmd_sql1);

       	while ($data = mysqli_fetch_array($res)) {
                $hostname = $data['hostname'];
                $nodename = $data['nodename'];
                $ip = $data['ip'];
		$port = $data['port'];
		$PING_CMD = "ping -c 1 -w 1 $ip | grep '64 bytes' | awk -F'=' '{print \$NF}' | awk '{print $1}'";
		$PING_CMD_MS = shell_exec("$PING_CMD");
		//echo "Ping CMD : $PING_CMD , Ping MS : $PING_CMD_MS\n";
		
		if ($PING_CMD_MS > 1 or $PING_CMD_MS == "") {
			$SERVER_NOT_PING = 'YES';
			break;
		}
				
		// Linux RSA , ID/PWD
		if ($data['username'] and $data['password']) {
			$ID_PWD = 'Y';
			$username = $data['username'];
			$password = dec_enc('decrypt',$data['password'],$S_KEY,$S_IV);
			$HOST_STR = $HOST_STR . "$hostname ansible_host=$ip ansible_user=$username ansible_ssh_pass='$password' ansible_port=$port\n";
			$HOST_STR_T = $HOST_STR_T . "$hostname ansible_host=$ip ansible_user=$username ansible_ssh_pass=********* ansible_port=$port\n";
		}
		else {
			$HOST_STR = $HOST_STR . "$hostname ansible_host=$ip ansible_ssh_port=$port \n";
			$HOST_STR_T = $HOST_STR_T . "$hostname ansible_host=$ip ansible_ssh_port=$port \n";
		}

		$cnt = $cnt + 1;
        }


	if ($SERVER_NOT_PING != 'YES') {



	// 1. CPU, Memory, Swap, Disk 임계치 정의
        $cpu_sql = "select item_warn_thres, item_crit_thres from Ansible_linux_morning_chk_Item where item_name = 'CPU' ";
        $cpu_res = mysqli_query($mysqli,$cpu_sql);
       	$cpu_data = mysqli_fetch_array($cpu_res);
	$CPU_WARN = $cpu_data['item_warn_thres'];
	$CPU_CRIT = $cpu_data['item_crit_thres'];

        $mem_sql = "select item_warn_thres, item_crit_thres from Ansible_linux_morning_chk_Item where item_name = 'Memory' ";
        $mem_res = mysqli_query($mysqli,$mem_sql);
       	$mem_data = mysqli_fetch_array($mem_res);
	$MEM_WARN = $mem_data['item_warn_thres'];
	$MEM_CRIT = $mem_data['item_crit_thres'];

        $swap_sql = "select item_warn_thres, item_crit_thres from Ansible_linux_morning_chk_Item where item_name = 'Swap' ";
        $swap_res = mysqli_query($mysqli,$swap_sql);
       	$swap_data = mysqli_fetch_array($swap_res);
	$SWAP_WARN = $swap_data['item_warn_thres'];
	$SWAP_CRIT = $swap_data['item_crit_thres'];

        $disk_sql = "select item_warn_thres, item_crit_thres from Ansible_linux_morning_chk_Item where item_name = 'Disk' ";
        $disk_res = mysqli_query($mysqli,$disk_sql);
       	$disk_data = mysqli_fetch_array($disk_res);
	$DISK_WARN = $disk_data['item_warn_thres'];
	$DISK_CRIT = $disk_data['item_crit_thres'];
	
	$PORT_WARN = 0;
	$PORT_CRIT = 0;

	$DAEMON_WARN = 0;
	$DAEMON_CRIT = 0;

	$INFO_WARN = 0;
	$INFO_CRIT = 0;

	$LOAD_WARN = 0;
	$LOAD_CRIT = 0;

	$IP_WARN = 0;
	$IP_CRIT = 0;

	$DNS_WARN = 0;
	$DNS_CRIT = 0;

	$ROUTING_WARN = 0;
	$ROUTING_CRIT = 0;

	$WHO_WARN = 0;
	$WHO_CRIT = 0;

	$VMSTAT_WARN = 0;
	$VMSTAT_CRIT = 0;




	if ($cnt < 10 ) $T_CMD_TIMEOUT = 60;	
	else $T_CMD_TIMEOUT = ($CMD_TIMEOUT_SEC * $cnt) + 60 ;


	// ITEM 별로 Loop 실행 & ITEM별 playbook 실행하여 결과 도출 //

	// 2. ITEM 별 Count 변수 정의
	$CPU_WARN_CNT = 0;
	$CPU_CRIT_CNT = 0;
	$MEM_WARN_CNT = 0;
	$MEM_CRIT_CNT = 0;
	$SWAP_WARN_CNT = 0;
	$SWAP_CRIT_CNT = 0;
	$DISK_WARN_CNT = 0;
	$DISK_CRIT_CNT = 0;
	$PORT_WARN_CNT = 0;
	$PORT_CRIT_CNT = 0;
	$DAEMON_WARN_CNT = 0;
	$DAEMON_CRIT_CNT = 0;



	$ALARM_MSG1 = '';

        #$cmd_sql1 = "select c_itemlist from Ansible_linux_morning_chk_cron";
        #$res = mysqli_query($mysqli,$cmd_sql1);
       	#$data = mysqli_fetch_array($res); 
	#$ITEM_LIST = $data['c_itemlist'];

	$ITEM_LIST = "Info|Load|IP|DNS|Routing|Who|CPU|Memory|Vmstat|Disk|Swap|Port|Daemon";

        $T_ITEM = explode('|',$ITEM_LIST);
        foreach($T_ITEM as $EXE_ITEM) {

        	$cmd_sql1 = "select * from Ansible_linux_Detail_Diag_Item where item_name = '$EXE_ITEM' ";
        	$res5 = mysqli_query($mysqli,$cmd_sql1);
        	$data5 = mysqli_fetch_array($res5);
		$PLAYBOOK_NAME = $data5['item_playook'];
		$WARN_THRES = $data5['item_warn_thres'];
		$CRIT_THRES = $data5['item_crit_thres'];

                $RANDOM_NUM = mt_rand(1,1000);
                $UTIME_F = explode('.',microtime(true));
                $UTIME = $UTIME_F[0] . $UTIME_F[1] . $RANDOM_NUM ;

                $ANSIBLE_HOST_FILE = "$ANSIBLE_HOST_DIR/host5" . $UTIME ;
                $ANSIBLE_HOST_NICK_FILE = "$ANSIBLE_HOST_DIR/host5" ;

		$HOST_CREATE = shell_exec("echo  '$HOST_STR' > $ANSIBLE_HOST_FILE");
		$HOST_DISPLAY = shell_exec("cat $ANSIBLE_HOST_FILE");

        	$cmd_sql = "select * from Ansible_linux_playbook where p_name = '{$PLAYBOOK_NAME}'";
        	$res = mysqli_query($mysqli,$cmd_sql);
                $data = mysqli_fetch_array($res);
                $p_seq = $data['p_seq'];
		$p_seq = sprintf('%09d',$p_seq);
		$p_seq = 'PLY' . $p_seq;
                $p_content = base64_decode($data['p_content']);
		$STRING = $SERVER;

                $ANSIBLE_PLAYBOOK_FILE = "${ANSIBLE_EXEC_DIR}/$PLAYBOOK_NAME" . $UTIME ;

		$p_content = str_replace("$","UUaU",$p_content);
		$p_content = str_replace("'","UUbU",$p_content);

                $PB_CREATE = shell_exec("echo  '$p_content' > $ANSIBLE_PLAYBOOK_FILE");
                $PB_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");

		#$EXEC1 = "sed -i '/- hosts:/c $STRING' $ANSIBLE_PLAYBOOK_FILE";
		$EXEC1 = "sed -i \"s/- hosts: .*/- hosts: $STRING/\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC1");

		$EXEC2 = "sed -i \"s|UUaU|$|g\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC2");

		$EXEC3 = "sed -i \"s|UUbU|'|g\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC3");

                $EXEC3 = "sed -i \"s|UUcU|>|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");

		// Linux
                $EXEC3 = "sed -i \"s|UUdU|~|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");


		// add 2019.6.17
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");
                $EXEC3 = "sed -i \"s|UUeU|<|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");

		//$PLAYBOOK_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");
		//echo "<pre>$PLAYBOOK_DISPLAY</pre>";


		$RESULT = '';

		$FULLSTR = "timeout $T_CMD_TIMEOUT ansible-playbook -i $ANSIBLE_HOST_FILE $ANSIBLE_PLAYBOOK_FILE";
               	$ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log.txt" . $UTIME ;

		$p_starttime = date("Y-m-d H:i:s");
		$CMD_LINE = shell_exec("$FULLSTR > $ANSIBLE_LOG_FILE 2>&1");
		$p_endtime = date("Y-m-d H:i:s");

		$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
		$RESULT = shell_exec("$ANSIBLE_PLAYBOOK_DIR/moring_chk_parser.sh $ANSIBLE_LOG_FILE $EXE_ITEM 2>&1");

		//echo "<pre>$RESULT_DISPLAY</pre>";


		$VAR1 = ": UNREACHABLE! => {";
		if (strpos($RESULT_DISPLAY, $VAR1)) {
			// Ansible UNREACHABLE

        		$UNREACHABLE = 'Y';
			//echo "<pre>[Critical] Ansible UNREACHABLE!! </pre>";

		}
		else {

			// OK : REACHABLE
			$UNREACHABLE = 'N';
			//echo "<pre>[OK] Ansible REACHABLE!! </pre>";

		$T_LINE = preg_split("/\r\n|\n|\r/",$RESULT);
		foreach($T_LINE as $LINE) {

			if ($LINE) {
				
				if ($EXE_ITEM == "CPU") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('#',$S_LINE[2]);

					$CPU_SUM1 = $R_LINE[0] + $R_LINE[1] + $R_LINE[2];
					if ($CPU_SUM1 >= $CPU_CRIT) {
						$CPU_RESULT = 'C';
						$CPU_CRIT_CNT = $CPU_CRIT_CNT + 1;
						$CPU_ALARM_MSG1 = "# $S_LINE[1] \n - CPU Critical : CPU Usage ({$CPU_SUM1}%) > Threshold ($CPU_CRIT) <br>"; 
					}
					elseif ($CPU_SUM1 >= $CPU_WARN) {
						$CPU_RESULT = 'W';
						$CPU_WARN_CNT = $CPU_WARN_CNT + 1;
						$CPU_ALARM_MSG1 = "# $S_LINE[1] \n - CPU Warning : CPU Usage ({$CPU_SUM1}%) > Threshold ($CPU_WARN) <br>"; 
					}
					else {
						$CPU_RESULT = 'N';
					}

                			$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_CPU values ('$T_UTIME', '$p_starttime', '$p_endtime', '$S_LINE[1]', '$PLAYBOOK_NAME', '$R_LINE[0]','$R_LINE[1]', '$R_LINE[2]', '$R_LINE[3]', '$CPU_WARN','$CPU_CRIT', '$CPU_RESULT');";
                			$result55 = mysqli_query($mysqli,$insert_sql);

				}

				elseif ($EXE_ITEM == "Memory") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('#',$S_LINE[2]);

					$P_USED = ($R_LINE[2]/$R_LINE[0])*100;
					if ($P_USED >= $MEM_CRIT) {
						$MEM_RESULT = 'C';
						$MEM_CRIT_CNT = $MEM_CRIT_CNT + 1;
						$MEM_ALARM_MSG1 = "# $S_LINE[1] \n - MEM Critical : MEM Usage ({$P_USED}%) > Threshold ($MEM_CRIT) <br>"; 
					}
					elseif ($P_USED >= $MEM_WARN) {
						$MEM_RESULT = 'W';
						$MEM_WARN_CNT = $MEM_WARN_CNT + 1;
						$MEM_ALARM_MSG1 = "# $S_LINE[1] \n - MEM Warning : MEM Usage ({$P_USED}%) > Threshold ($MEM_WARN) <br>"; 
					}
					else {
						$MEM_RESULT = 'N';
					}

                			$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Memory values ('$T_UTIME', '$p_starttime', '$p_endtime', '$S_LINE[1]', '$PLAYBOOK_NAME', '$R_LINE[0]','$R_LINE[1]', '$R_LINE[2]', '$R_LINE[3]', '$MEM_WARN','$MEM_CRIT', '$MEM_RESULT');";
                			$result55 = mysqli_query($mysqli,$insert_sql);
					
				}

				elseif ($EXE_ITEM == "Swap") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('#',$S_LINE[2]);

					// total 0 으로 나누기 방지
					if ($R_LINE[0] == 0) {
						$SWAP_RESULT = 'N';
					}
					else {
						$P_USED = ($R_LINE[2]/$R_LINE[0])*100;
						if ($P_USED >= $SWAP_CRIT) {
							$SWAP_RESULT = 'C';
							$SWAP_CRIT_CNT = $SWAP_CRIT_CNT + 1;
							$SWAP_ALARM_MSG1 = "# $S_LINE[1] \n - SWAP Critical : SWAP Usage ({$P_USED}%) > Threshold ($SWAP_CRIT) <br>"; 
						}
						elseif ($P_USED >= $SWAP_WARN) {
							$SWAP_RESULT = 'W';
							$SWAP_WARN_CNT = $SWAP_WARN_CNT + 1;
							$SWAP_ALARM_MSG1 = "# $S_LINE[1] \n - SWAP Warning : SWAP Usage ({$P_USED}%) > Threshold ($SWAP_WARN) <br>"; 
						}
						else {
							$SWAP_RESULT = 'N';
						}
					}

                			$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Swap values ('$T_UTIME', '$p_starttime', '$p_endtime', '$S_LINE[1]', '$PLAYBOOK_NAME', '$R_LINE[0]','$R_LINE[1]', '$R_LINE[2]', '$SWAP_WARN','$SWAP_CRIT', '$SWAP_RESULT');";
                			$result55 = mysqli_query($mysqli,$insert_sql);

				}

				elseif ($EXE_ITEM == "Disk") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',$S_LINE[2]);
					
					$T_DISK_RESULT = 'N';
					$DISK_ALARM_MSG1 = '';
        				foreach($R_LINE as $DISK_ITEM) {

						if ($DISK_ITEM) {

							$S_DISK_ITEM = explode('#',$DISK_ITEM);
							$P_USED = preg_replace("/%/","",$S_DISK_ITEM[4]);

							$DISK_MOUNT_ON = substr($S_DISK_ITEM[5],0,40);

							if ($P_USED >= $DISK_CRIT) {
								$DISK_RESULT = 'C';
								$DISK_ALARM_MSG1 = $DISK_ALARM_MSG1 . "# $S_LINE[1] \n - DISK Critical : $DISK_MOUNT_ON DISK Usage ({$P_USED}%) > Threshold ($DISK_CRIT) <br>"; 
							}
							elseif ($P_USED >= $DISK_WARN) {
								$DISK_RESULT = 'W';
								$DISK_ALARM_MSG1 = $DISK_ALARM_MSG1 . "# $S_LINE[1] \n - DISK Warning : $DISK_MOUNT_ON DISK Usage ({$P_USED}%) > Threshold ($DISK_WARN) <br>"; 
							}
							else {
								$DISK_RESULT = 'N';
							}

                					$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Disk values ('$T_UTIME', '$p_starttime', '$p_endtime', '$S_LINE[1]', '$PLAYBOOK_NAME', '$S_DISK_ITEM[0]','$S_DISK_ITEM[1]', '$S_DISK_ITEM[2]', '$S_DISK_ITEM[3]', '$P_USED', '$DISK_MOUNT_ON','$DISK_WARN', '$DISK_CRIT', '$DISK_RESULT');";
                					$result55 = mysqli_query($mysqli,$insert_sql);

						}

						// 여러개의 디스크에 Warn, Crit 발생해도 HOST 건수는 제일 높은 알람으로 1개로 처리
						if ($DISK_RESULT == 'C' or $DISK_RESULT == 'W') {
							if ($T_DISK_RESULT == 'N' and $DISK_RESULT == 'W') {
								$T_DISK_RESULT = 'W';
								$DISK_WARN_CNT = $DISK_WARN_CNT + 1;
							}
							elseif ($T_DISK_RESULT == 'N' and $DISK_RESULT == 'C') {
								$T_DISK_RESULT = 'C';
								$DISK_CRIT_CNT = $DISK_CRIT_CNT + 1;
							}
							elseif ($T_DISK_RESULT == 'W' and $DISK_RESULT == 'C') {
								$T_DISK_RESULT = 'C';
								$DISK_CRIT_CNT = $DISK_CRIT_CNT + 1;
							}

						}


					}  // foreach($R_LINE as $DISK_ITEM) 

                        	}

				elseif ($EXE_ITEM == "Info") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],'AaA:'));

					$HOSTNAME = $S_LINE[1];
					$c_product = $R_LINE[0];
					$c_kernel = $R_LINE[1];
					$c_os_ver = $R_LINE[2];
					$c_cpu_cnt = $R_LINE[3];
					$c_mem = $R_LINE[4];

					$INFO_RESULT = 'N';

                			$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Info values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$c_product','$c_kernel', '$c_os_ver', '$c_cpu_cnt', '$c_mem', '$INFO_WARN', '$INFO_CRIT', '$INFO_RESULT');";
               				$result55 = mysqli_query($mysqli,$insert_sql);

						
                        	} // elseif ($EXE_ITEM == "Info") 

				elseif ($EXE_ITEM == "Load") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode(' ',$S_LINE[2]);

					$HOSTNAME = $S_LINE[1];
					$c_uptime = $R_LINE[0];
					$c_load1 = $R_LINE[1];
					$c_load5 = $R_LINE[2];
					$c_load15 = $R_LINE[3];

					if ($c_load1 >= 10 or $c_load5 >= 6 or $c_load15 >= 4) {
						$LOAD_RESULT = 'C';
						$LD_ALARM_MSG1 = "# $S_LINE[1] \n - Load Critical : Load Usage 1m $c_load1, 5m $c_load5, 15m $c_load15 <br>"; 
					}
					else if ($c_load1 >= 5 or $c_load5 >= 4 or $c_load15 >= 3) {
						$LOAD_RESULT = 'W';
						$LD_ALARM_MSG1 = "# $S_LINE[1] \n - Load Warning : Load Usage 1m $c_load1, 5m $c_load5, 15m $c_load15 <br>"; 
					}
					else $LOAD_RESULT = 'N';

                			$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Load values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$c_uptime','$c_load1', '$c_load5','$c_load15','$LOAD_WARN', '$LOAD_CRIT', '$LOAD_RESULT');";
               				$result55 = mysqli_query($mysqli,$insert_sql);

                        	} // elseif ($EXE_ITEM == "Load") 

				elseif ($EXE_ITEM == "IP") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],'AaA:'));

					$HOST_PORT = explode(':',$S_LINE[0]);
					$HOSTNAME = $S_LINE[1];

        				foreach($R_LINE as $IP_ITEM) {
						$S_PORT_ITEM = explode('#',$IP_ITEM);
						$IP_RESULT = 'N';

                				$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_IP values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$S_PORT_ITEM[0]','$S_PORT_ITEM[1]', '$S_PORT_ITEM[2]', '$S_PORT_ITEM[3]', '$IP_WARN', '$IP_CRIT', '$IP_RESULT');";
               					$result55 = mysqli_query($mysqli,$insert_sql);

					}

						
                        	} // elseif ($EXE_ITEM == "IP") 


				elseif ($EXE_ITEM == "DNS") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],'AaA:'));

					$HOST_PORT = explode(':',$S_LINE[0]);
					$HOSTNAME = $S_LINE[1];

        				foreach($R_LINE as $DNS_ITEM) {

						if ($DNS_ITEM and preg_match("/[^\d.]/", trim($DNS_ITEM))) $DNS_ITEM='';

						if ($DNS_ITEM) $DNS_RESULT = 'N';
						else $DNS_RESULT = 'C';

                				$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_DNS values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$DNS_ITEM','$DNS_WARN', '$DNS_CRIT', '$DNS_RESULT');";
               					$result55 = mysqli_query($mysqli,$insert_sql);

					}

						
                        	} // elseif ($EXE_ITEM == "DNS") 

				elseif ($EXE_ITEM == "Routing") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],'AaA:'));

					$HOST_PORT = explode(':',$S_LINE[0]);
					$HOSTNAME = $S_LINE[1];

        				foreach($R_LINE as $RT_ITEM) {
						$S_RT_ITEM = explode('#',$RT_ITEM);
						$RT_RESULT = 'N';

                				$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Routing values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$S_RT_ITEM[0]','$S_RT_ITEM[1]','$S_RT_ITEM[2]','$S_RT_ITEM[3]','$S_RT_ITEM[4]','$ROUTING_WARN', '$ROUTING_CRIT', '$RT_RESULT');";
               					$result55 = mysqli_query($mysqli,$insert_sql);

					}

						
                        	} // elseif ($EXE_ITEM == "Routing") 


				elseif ($EXE_ITEM == "Who") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],'AaA:'));

					$HOST_PORT = explode(':',$S_LINE[0]);
					$HOSTNAME = $S_LINE[1];

        				foreach($R_LINE as $WHO_ITEM) {
						$S_WHO_ITEM = explode('#',$WHO_ITEM);
						$WHO_RESULT = 'N';

                				$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Who values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$S_WHO_ITEM[0]','$S_WHO_ITEM[1]','$S_WHO_ITEM[2]','$S_WHO_ITEM[3]','$S_WHO_ITEM[4]','$S_WHO_ITEM[5]','$WHO_WARN', '$WHO_CRIT', '$WHO_RESULT');";
               					$result55 = mysqli_query($mysqli,$insert_sql);

					}

						
                        	} // elseif ($EXE_ITEM == "Who") 

				elseif ($EXE_ITEM == "Vmstat") {

					$VM_WARN_CNT = 0;
					$VM_CRIT_CNT = 0;

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],'AaA:'));

					$HOST_PORT = explode(':',$S_LINE[0]);
					$HOSTNAME = $S_LINE[1];

					$VM_ALARM_MSG1 = '';
        				foreach($R_LINE as $VM_ITEM) {
						$S_VM_ITEM = explode('#',$VM_ITEM);

						// 주의 > $S_VM_ITEM[0] Procs_r > 3 ,  $S_VM_ITEM[7] swap_so > 500 , $S_VM_ITEM[14] cpu_id < 20
						// 위험 > $S_VM_ITEM[0] Procs_r > 5 ,  $S_VM_ITEM[7] swap_so > 700 , $S_VM_ITEM[14] cpu_id < 10
						if ($S_VM_ITEM[0] > 5 or  $S_VM_ITEM[7] > 700 or $S_VM_ITEM[14] < 10) {
							$VMSTAT_RESULT = 'C';
							$VM_CRIT_CNT = $VM_CRIT_CNT + 1;
							$VM_ALARM_MSG1 = $VM_ALARM_MSG1 . "# $HOSTNAME - Vmstat Critical : Procs_r $S_VM_ITEM[0], swap_so $S_VM_ITEM[7], cpu_id $S_VM_ITEM[14] <br>"; 
						}
						else if ($S_VM_ITEM[0] > 3 or  $S_VM_ITEM[7] > 500 or $S_VM_ITEM[14] < 20) {
							$VMSTAT_RESULT = 'W';
							$VM_WARN_CNT = $VM_WARN_CNT + 1;
							$VM_ALARM_MSG1 = $VM_ALARM_MSG1 . "# $HOSTNAME - Vmstat Warning : Procs_r $S_VM_ITEM[0], swap_so $S_VM_ITEM[7], cpu_id $S_VM_ITEM[14] <br>"; 
						}
						else $VMSTAT_RESULT = 'N';

                				$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Vmstat values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$S_VM_ITEM[0]','$S_VM_ITEM[1]','$S_VM_ITEM[2]','$S_VM_ITEM[3]','$S_VM_ITEM[4]','$S_VM_ITEM[5]','$S_VM_ITEM[6]','$S_VM_ITEM[7]','$S_VM_ITEM[8]','$S_VM_ITEM[9]','$S_VM_ITEM[10]','$S_VM_ITEM[11]','$S_VM_ITEM[12]','$S_VM_ITEM[13]','$S_VM_ITEM[14]','$S_VM_ITEM[15]','$VMSTAT_WARN', '$VMSTAT_CRIT', '$VMSTAT_RESULT');";
               					$result55 = mysqli_query($mysqli,$insert_sql);

					}

						
                        	} // elseif ($EXE_ITEM == "Vmstat") 

				elseif ($EXE_ITEM == "Port") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],'AaA:'));

					$HOST_PORT = explode(':',$S_LINE[0]);
					$HOSTNAME = $S_LINE[1];

					$PORT_LIST_ALL = array();

        				foreach($R_LINE as $PORT_ITEM) {
						$S_PORT_ITEM = explode('#',$PORT_ITEM);
						$TT_SPLIT = explode(':',$S_PORT_ITEM[3]);
						$T1_PORT = end($TT_SPLIT);
						$PORT_RESULT = 'N';

                				$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Port values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$S_PORT_ITEM[0]','$S_PORT_ITEM[1]', '$S_PORT_ITEM[2]', '$S_PORT_ITEM[3]', '$S_PORT_ITEM[4]', '$S_PORT_ITEM[5]','$S_PORT_ITEM[6]','$T1_PORT','$PORT_WARN', '$PORT_CRIT', '$PORT_RESULT');";
               					$result55 = mysqli_query($mysqli,$insert_sql);

						array_push($PORT_LIST_ALL, $T1_PORT);

					}

					$PORT_ALARM_MSG1 = '';

        				$cmd_sql = "select c_port from Ansible_linux_morning_chk_Item_Port_List where c_hostname = '$HOSTNAME' ";
        				$res = mysqli_query($mysqli,$cmd_sql);
					$newArray = mysqli_fetch_array($res);
					$sql_CNT = mysqli_num_rows($res);
				
					if($sql_CNT != 0) {
        					$T_PORT_LIST = $newArray['c_port'];
						$TT_PORT_LIST = explode('|',$T_PORT_LIST);

						$PORT_LIST_DB = array();
						foreach($TT_PORT_LIST as $PORT_ITEM) {
							array_push($PORT_LIST_DB, $PORT_ITEM);
						}


                				$BEF_DIFF = array_diff($PORT_LIST_DB, $PORT_LIST_ALL);
                				if($BEF_DIFF) {
                        				$CNT_DIFF = sizeof($BEF_DIFF);
                        				for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
                                				$DATA = array_pop($BEF_DIFF);
								$PORT_ALARM_MSG1 = $PORT_ALARM_MSG1 . "# $HOSTNAME - Critical : Monitor Port $DATA Not Found!! <br>"; 
                        				}
                				}

                				if ($PORT_ALARM_MSG1) $PORT_CRIT_CNT = $PORT_CRIT_CNT + 1;
					}


						
                        	} // elseif ($EXE_ITEM == "Port") 

				elseif ($EXE_ITEM == "Daemon") {

					$DM_WARN_CNT = 0;
					$DM_CRIT_CNT = 0;

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],':'));

					$HOSTNAME = $S_LINE[1];

					$COUNT = 0;
					$DM_ALARM_MSG1 = '';
        				foreach($R_LINE as $DAEMON_ITEM) {
						$S_DAEMON_ITEM = explode('#',$DAEMON_ITEM);

						// cpu, mem top 5 추출
						// Warn : $S_DAEMON_ITEM[2] CPU% > 80% , $S_DAEMON_ITEM[3] MEM% > 80% 
						// Crit : $S_DAEMON_ITEM[2] CPU% > 90% , $S_DAEMON_ITEM[3] MEM% > 90% 

						if ($S_DAEMON_ITEM[2] > 90 or $S_DAEMON_ITEM[3] > 90) {
							$DAEMON_RESULT = 'C';
							$DM_CRIT_CNT = $DM_CRIT_CNT + 1;
							$DM_ALARM_MSG1 = $DM_ALARM_MSG1 . "# $HOSTNAME - Top 5 Critical :  $S_DAEMON_ITEM[8] cpu $S_DAEMON_ITEM[2], mem $S_DAEMON_ITEM[3] <br>"; 
						}
						else if ($S_DAEMON_ITEM[2] > 80 or $S_DAEMON_ITEM[3] > 80) {
							$DAEMON_RESULT = 'W';
							$DM_WARN_CNT = $DM_WARN_CNT + 1;
							$DM_ALARM_MSG1 = $DM_ALARM_MSG1 . "# $HOSTNAME - Top 5 Warning :  $S_DAEMON_ITEM[8] cpu $S_DAEMON_ITEM[2], mem $S_DAEMON_ITEM[3] <br>"; 
						}
						else $DAEMON_RESULT = 'N';

						if ($S_DAEMON_ITEM[0] and $S_DAEMON_ITEM[1]) {

							if ($S_DAEMON_ITEM[0] == 'root' and $S_DAEMON_ITEM[8] == '/usr/bin/python') continue;
							else if ($S_DAEMON_ITEM[0] == 'ansible' and $S_DAEMON_ITEM[8] == 'sshd:') continue;
							else if ($COUNT < 10) {

               							$insert_sql = "insert into Ansible_linux_Detail_Diag_Result_Daemon values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$S_DAEMON_ITEM[0]','$S_DAEMON_ITEM[1]', '$S_DAEMON_ITEM[2]', '$S_DAEMON_ITEM[3]', '$S_DAEMON_ITEM[4]', '$S_DAEMON_ITEM[5]','$S_DAEMON_ITEM[6]', '$S_DAEMON_ITEM[7]','$S_DAEMON_ITEM[8]','$DAEMON_WARN', '$DAEMON_CRIT', '$DAEMON_RESULT');";
              							$result55 = mysqli_query($mysqli,$insert_sql);

								$COUNT = $COUNT + 1;
							}
						}


					}


                        	} // elseif ($EXE_ITEM == "Daemon") 

				// echo "* Processing : $EXE_ITEM , $S_LINE[1] \n";

			} // if ($LINE) {

		} // foreach($T_LINE as $LINE) {

		} // if (strpos($Line, $VAR1)) else



        } /* foreach($T_ITEM as $EXE_ITEM) */


	$STR1 = '';


	// 정밀 점검 결과 출력 


	//*************************************************************************************************************************
	// 이전 데이터 보여주기 
	// 비교할 이전 데이터의 c_seq 찾기

        $cmd_sql = "select max(c_seq) as max1 from Ansible_linux_Detail_Diag_Result_Info where c_seq <> '$T_UTIME' and c_hostname='$SERVER' ";
        $res = mysqli_query($mysqli,$cmd_sql);
	$newArray3 = mysqli_fetch_array($res,MYSQLI_ASSOC);
	$max1 = $newArray3['max1'];


if ($max1) {


	// INFO

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Info where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_product= $newArray['c_product'];
                        $c_kernel = $newArray['c_kernel'];
                        $c_os_ver = $newArray['c_os_ver'];
                        $c_cpu_cnt = $newArray['c_cpu_cnt'];
                        $c_mem = $newArray['c_mem'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$STR2 = "
				<font size=3 color=black><b>[ BEFORE ]</b></font><br>
				<font size=2>* HOSTNAME : $c_hostname</font><br>
				<font size=2>* Start Time : $c_starttime</font><br>
				<font size=2>* End Time : $c_endtime</font><br>
				<br><br><font color=blue size=3><b>System Info</b></font><br>
		
				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>Product</th><th>Kernel</th><th>OS Version</th><th>CPU</th><th>MEM (K)</th></tr>
				<tr><td>$c_product</td><td>$c_kernel</td><td>$c_os_ver</td><td>$c_cpu_cnt</td><td>$c_mem</td></tr>
				</table><br>
			";
			$STR1 = $STR1 . $STR2 ;

                }
        }


	// LOAD

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Load where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_uptime= $newArray['c_uptime'];
                        $c_load5 = $newArray['c_load5'];
                        $c_load10 = $newArray['c_load10'];
                        $c_load15 = $newArray['c_load15'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'N') $MSG1 = "Normal";
			else if ($c_result == 'W') $MSG1 = "<font color=green>Warning</font>";
			else if ($c_result == 'C') $MSG1 = "<font color=red>Critical</font>";

			$STR2 = "
				<br><br><font color=blue size=3><b>Load Info : $MSG1</b></font><br>

				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>Uptime</th><th>5m Load</th><th>10m Load</th><th>15m Load</th></tr>
				<tr><td>$c_uptime</td><td>$c_load5</td><td>$c_load10</td><td>$c_load15</td></tr>
				</table><br>
			";
			$STR1 = $STR1 . $STR2 ;

                }
        }


	// IP

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_IP where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$IP_LIST_BEF = array();

		$STR2 = "
			<br><br><font color=blue size=3><b>IP Info</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>NIC</th><th>Status</th><th>IP Addr</th><th>MAC</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_nic= $newArray['c_nic'];
                        $c_status = $newArray['c_status'];
                        $c_ip = $newArray['c_ip'];
                        $c_mac = $newArray['c_mac'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$IP1 = $c_nic . '/' . $c_ip . '/' . $c_mac;
			array_push($IP_LIST_BEF, $IP1);
		
			$STR2 = "<tr><td>$c_nic</td><td>$c_status</td><td>$c_ip</td><td>$c_mac</td></tr>";
			$STR1 = $STR1 . $STR2 ;

                }
		$STR1 = $STR1 . "</table><br>" ;
        }


	// DNS

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_DNS where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$DNS_LIST_BEF = array();

		$STR2 = "
			<br><br><font color=blue size=3><b>DNS Info</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>NameServer</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_name_server= $newArray['c_name_server'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			array_push($DNS_LIST_BEF, $c_name_server);
		
			$STR2 = "<tr><td>$c_name_server</td></tr>";
			$STR1 = $STR1 . $STR2 ;

                }
		$STR1 = $STR1 . "</table><br>";
        }


	// ROUTING

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Routing where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$RT_LIST_BEF = array();

		$STR2 = "
			<br><br><font color=blue size=3><b>Routing Info</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>Dest</th><th>Gateway</th><th>Mask</th><th>Flag</th><th>Interfaceth</tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_dest= $newArray['c_dest'];
                        $c_gw = $newArray['c_gw'];
                        $c_mask = $newArray['c_mask'];
                        $c_flag = $newArray['c_flag'];
                        $c_iface = $newArray['c_iface'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$RT1 = $c_dest . '/' . $c_mask . '/gw:' . $c_gw;
			array_push($RT_LIST_BEF, $RT1);

			$STR2 = "<tr><td>$c_dest</td><td>$c_gw</td><td>$c_mask</td><td>$c_flag</td><td>$c_iface</td></tr>";
			$STR1 = $STR1 . $STR2 ; 

                }
		$STR1 = $STR1 . "</table><br>";
        }


	// WHO

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Who where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$STR2 = "
			<br><br><font color=blue size=3><b>Logging Info</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>User</th><th>tty</th><th>From</th><th>Login</th><th>Idle</th><th>What</th></tr>
		";
		$STR1 = $STR1 . $STR2 ; 

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_user= $newArray['c_user'];
                        $c_tty = $newArray['c_tty'];
                        $c_from = $newArray['c_from'];
                        $c_login = $newArray['c_login'];
                        $c_idle = $newArray['c_idle'];
                        $c_what = $newArray['c_what'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$STR2 = "<tr><td>$c_user</td><td>$c_tty</td><td>$c_from</td><td>$c_login</td><td>$c_idle</td><td>$c_what</td></tr>";
			$STR1 = $STR1 . $STR2 ;
		
                }
		$STR1 = $STR1 . "</table><br>";
        }



	// PORT

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Port where c_seq = $max1 and (c_state = 'LISTEN' or c_state = 'ESTABLISHED')";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$PORT_LIST_BEF = array();
		$STR2 = "
			<br><br><font color=blue size=3><b>Network Connection Info</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>Proto</th><th>Recv Q</th><th>Send Q</th><th>Local Addr</th><th>Foreign Addr</th><th>State</th><th>Pid</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_proto= $newArray['c_proto'];
                        $c_recv_q = $newArray['c_recv_q'];
                        $c_send_q = $newArray['c_send_q'];
                        $c_local_addr = $newArray['c_local_addr'];
                        $c_foreign_addr = $newArray['c_foreign_addr'];
                        $c_state = $newArray['c_state'];
                        $c_pid = $newArray['c_pid'];
			$c_daemon = explode('/',$c_pid);
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if($c_state == 'LISTEN') {
				$PORT1 = $c_proto . '/' . $c_local_addr . '/' . $c_foreign_addr . '/' . $c_state . '/' . $c_daemon[1];
				array_push($PORT_LIST_BEF, $PORT1);
			}

			$STR2 = "<tr><td>$c_proto</td><td>$c_recv_q</td><td>$c_send_q</td><td>$c_local_addr</td><td>$c_foreign_addr</td><td>$c_state</td><td>$c_pid</td></tr>";
			$STR1 = $STR1 . $STR2 ;
		
                }
		$STR1 = $STR1 . "</table><br>";
        }


	// CPU

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_CPU where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_user= $newArray['c_user'];
                        $c_system = $newArray['c_system'];
                        $c_iowait = $newArray['c_iowait'];
                        $c_idle = $newArray['c_idle'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'N') $MSG1 = "Normal";
			else if ($c_result == 'W') $MSG1 = "<font color=green>Warning</font>";
			else if ($c_result == 'C') $MSG1 = "<font color=red>Critical</font>";

			$STR2 = "
				<br><br><font color=blue size=3><b>CPU Usage : $MSG1</b></font><br>
		
				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>CPU User</th><th>CPU Sytem</th><th>CPU Iowait</th><th>CPU Idle</th></tr>
				<tr><td>$c_user</td><td>$c_system</td><td>$c_iowait</td><td>$c_idle</td></tr>
				</table><br>
			";
			$STR1 = $STR1 . $STR2 ;

                }
        }


	// Memory

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Memory where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_total= $newArray['c_total'];
                        $c_free = $newArray['c_free'];
                        $c_used = $newArray['c_used'];
                        $c_buffcache = $newArray['c_buffcache'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'N') $MSG1 = "Normal";
			else if ($c_result == 'W') $MSG1 = "<font color=green>Warning</font>";
			else if ($c_result == 'C') $MSG1 = "<font color=red>Critical</font>";

			$STR2 = "
				<br><br><font color=blue size=3><b>MEM Usage : $MSG1</b></font><br>

				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>MEM Total (K)</th><th>MEM Free (K)</th><th>MEM Used (K)</th><th>MEM Buffer/Cache (K)</th></tr>
				<tr><td>$c_total</td><td>$c_free</td><td>$CONTENT1</td><td>$c_buffcache</td></tr>
				</table>
			";
			$STR1 = $STR1 . $STR2 ;

                }
        }


	// Swap

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Swap where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_total= $newArray['c_total'];
                        $c_free = $newArray['c_free'];
                        $c_used = $newArray['c_used'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'N') $MSG1 = "Normal";
			else if ($c_result == 'W') $MSG1 = "<font color=green>Warning</font>";
			else if ($c_result == 'C') $MSG1 = "<font color=red>Critical</font>";

			$STR2 = "
				<br><br><font color=blue size=3><b>Swap Usage : $MSG1</b></font><br>

				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>Swap Total (K)</th><th>Swap Free (K)</th><th>Swap Used (K)</th></tr>
				<tr><td>$c_total</td><td>$c_free</td><td>$c_used</td></tr>
				</table>
			";
			$STR1 = $STR1 . $STR2 ;
		
                }
        }

	// Disk

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Disk where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

        	$cmd_sql = "select count(*) as cnt from Ansible_linux_Detail_Diag_Result_Disk where c_seq = $max1 and c_result = 'C'";
        	$res5 = mysqli_query($mysqli,$cmd_sql);
        	$newArray3 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
        	$count_c = $newArray3['cnt'];

        	$cmd_sql = "select count(*) as cnt from Ansible_linux_Detail_Diag_Result_Disk where c_seq = $max1 and c_result = 'W'";
        	$res5 = mysqli_query($mysqli,$cmd_sql);
        	$newArray3 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
        	$count_w = $newArray3['cnt'];

		if ($count_c != 0) $MSG1 = "<font color=red>Critical</font>";
		else if ($count_w != 0) $MSG1 = "<font color=green>Warning</font>";
		else $MSG1 = "Normal";

		$STR2 = "
			<br><br><font color=blue size=3><b>Disk Usage : $MSG1</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>Filesystem</th><th>Size</th><th>Used</th><th>Avail</th><th>Use%</th><th>Mounted on</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

		$DISK_LIST_BEF = array();
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_device= $newArray['c_device'];
                        $c_size = $newArray['c_size'];
                        $c_used = $newArray['c_used'];
                        $c_avail = $newArray['c_avail'];
                        $c_p_used = $newArray['c_p_used'];
                        $c_mount = $newArray['c_mount'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$DISK1 = 'Filesystem:' . $c_device . ':' . $c_mount;
			array_push($DISK_LIST_BEF, $DISK1);

			$STR2 = "<tr><td>$c_device</td><td>$c_size</td><td>$c_used</td><td>$c_avail</td><td>$c_p_used</td><td>$c_mount</td></tr>";
			$STR1 = $STR1 . $STR2 ;

                }
		$STR1 = $STR1 . "</table><br>";
        }


	// VMSTAT

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Vmstat where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

        	$cmd_sql = "select count(*) as cnt from Ansible_linux_Detail_Diag_Result_Vmstat where c_seq = $max1 and c_result = 'C'";
        	$res5 = mysqli_query($mysqli,$cmd_sql);
        	$newArray3 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
        	$count_c = $newArray3['cnt'];

        	$cmd_sql = "select count(*) as cnt from Ansible_linux_Detail_Diag_Result_Vmstat where c_seq = $max1 and c_result = 'W'";
        	$res5 = mysqli_query($mysqli,$cmd_sql);
        	$newArray3 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
        	$count_w = $newArray3['cnt'];

		if ($count_c != 0) $MSG1 = "<font color=red>Critical</font>";
		else if ($count_w != 0) $MSG1 = "<font color=green>Warning</font>";
		else $MSG1 = "Normal";

		$STR2 = "
			<br><br><font color=blue size=3><b>Vmstat Info : $MSG1</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th colspan=2>Proc</th><th colspan=4>Mem</th><th colspan=2>Swap</th><th colspan=2>IO</th><th colspan=2>System</th><th colspan=4>CPU</th></tr>
			<tr><th>Run</th><th>Blk</th><th>Swapd</th><th>Free</th><th>Buff</th><th>Cache</th><th>si</th><th>so</th><th>bi</th><th>bo</th><th>int</th><th>cs</th><th>us</th><th>sy</th><th>id</th><th>wa</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_procs_r= $newArray['c_procs_r'];
                        $c_procs_b = $newArray['c_procs_b'];
                        $c_mem_swapd = $newArray['c_mem_swapd'];
                        $c_mem_free = $newArray['c_mem_free'];
                        $c_mem_buff = $newArray['c_mem_buff'];
                        $c_mem_cache = $newArray['c_mem_cache'];
                        $c_swap_si = $newArray['c_swap_si'];
                        $c_swap_so = $newArray['c_swap_so'];
                        $c_io_bi = $newArray['c_io_bi'];
                        $c_io_bo = $newArray['c_io_bo'];
                        $c_system_in = $newArray['c_system_in'];
                        $c_system_cs = $newArray['c_system_cs'];
                        $c_cpu_us = $newArray['c_cpu_us'];
                        $c_cpu_sy = $newArray['c_cpu_sy'];
                        $c_cpu_id = $newArray['c_cpu_id'];
                        $c_cpu_wa = $newArray['c_cpu_wa'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$STR2 = "<tr><td>$c_procs_r</td><td>$c_procs_b</td><td>$c_mem_swapd</td><td>$c_mem_free</td><td>$c_mem_buff</td><td>$c_mem_cache</td><td>$c_swap_si</td><td>$c_swap_so</td><td>$c_io_bi</td><td>$c_io_bo</td><td>$c_system_in</td><td>$c_system_cs</td><td>$c_cpu_us</td><td>$c_cpu_sy</td><td>$c_cpu_id</td><td>$c_cpu_wa</td></tr>";
			$STR1 = $STR1 . $STR2 ; 

                }
		$STR1 = $STR1 . "</table><br>";
        }



	// Deamon Top 5

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Daemon where c_seq = $max1 ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

        	$cmd_sql = "select count(*) as cnt from Ansible_linux_Detail_Diag_Result_Daemon where c_seq = $max1 and c_result = 'C'";
        	$res5 = mysqli_query($mysqli,$cmd_sql);
        	$newArray3 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
        	$count_c = $newArray3['cnt'];

        	$cmd_sql = "select count(*) as cnt from Ansible_linux_Detail_Diag_Result_Daemon where c_seq = $max1 and c_result = 'W'";
        	$res5 = mysqli_query($mysqli,$cmd_sql);
        	$newArray3 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
        	$count_w = $newArray3['cnt'];

		if ($count_c != 0) $MSG1 = "<font color=red>Critical</font>";
		else if ($count_w != 0) $MSG1 = "<font color=green>Warning</font>";
		else $MSG1 = "Normal";

		$T_CNT1 = 0;
		$STR2 = "
			<br><br><font color=blue size=3><b>CPU/MEM Top 5 : $MSG1</b></font><br>
			<font size=2><b>[MEM Top 5]</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>User</th><th>Pid</th><th>Cpu</th><th>Mem</th><th>Vsz</th><th>Rss</th><th>Stime</th><th>Time</th><th>Comand</th></tr>
		";
		$STR1 = $STR1 . $STR2 ; 

		$DM_CPU_LIST_BEF = array();
		$DM_MEM_LIST_BEF = array();
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
			
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_user= $newArray['c_user'];
                        $c_pid = $newArray['c_pid'];
                        $c_cpu = $newArray['c_cpu'];
                        $c_mem_T = $newArray['c_mem'];
                        $c_vsz = $newArray['c_vsz'];
                        $c_rss = $newArray['c_rss'];
                        $c_stime = $newArray['c_stime'];
                        $c_time = $newArray['c_time'];
                        $c_cmd = $newArray['c_cmd'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($T_CNT1 < 5) array_push($DM_MEM_LIST_BEF, $c_cmd);
			else array_push($DM_CPU_LIST_BEF, $c_cmd);

			if($T_CNT1 == 5) {
				$STR2 = "
					</table>
					<font size=2><b>[CPU Top 5]</b></font><br>
					<table width='100%' class='table table-striped table-bordered table-hover'>
					<tr><th>User</th><th>Pid</th><th>Cpu</th><th>Mem</th><th>Vsz</th><th>Rss</th><th>Stime</th><th>Time</th><th>Comand</th></tr>
				";
				$STR1 = $STR1 . $STR2 ; 
			}

			$STR2 = "<tr><td>$c_user</td><td>$c_pid</td><td>$c_cpu</td><td>$c_mem_T</td><td>$c_vsz</td><td>$c_rss</td><td>$c_stime</td><td>$c_time</td><td>$c_cmd</td></tr>";
			$STR1 = $STR1 . $STR2 ;

			$T_CNT1 = $T_CNT1 + 1;

                }
		$STR1 = $STR1 . "</table><br>";
        }
	//************************************************************************************************************************/

} # if ($max1)
else {
	$STR2 = "<font color=blue size=3><b>Previos Data Not Found!!</b></font><br>";
	$STR1 = $STR1 . $STR2 ;
}


        $STR2 = "
                                </div>

			<div class='col-lg-6'>
	";
	$STR1 = $STR1 . $STR2 ;


	$HOSTNAME = $SERVER;

	//*************************************************************************************************************************
	// 정밀 점검 신규 데이터 보여주기 


if ($UNREACHABLE != 'Y') {

	// INFO

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Info where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_product1= $newArray['c_product'];
                        $c_kernel1 = $newArray['c_kernel'];
                        $c_os_ver1 = $newArray['c_os_ver'];
                        $c_cpu_cnt1 = $newArray['c_cpu_cnt'];
                        $c_mem1 = $newArray['c_mem'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$STR2 = "
				<font size=3 color=green><b>[ NEW ]</b></font><br>
				<font size=2>* HOSTNAME : $c_hostname</font><br>
				<font size=2>* Start Time : $c_starttime</font><br>
				<font size=2>* End Time : $c_endtime</font><br>
				<br><br><font color=blue size=3><b>System Info</b></font><br>

				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>Product</th><th>Kernel</th><th>OS Version</th><th>CPU</th><th>MEM (K)</th></tr>
				<tr><td>$c_product1</td><td>$c_kernel1</td><td>$c_os_ver1</td><td>$c_cpu_cnt1</td><td>$c_mem1</td></tr>
				</table><br>
			";
			$STR1 = $STR1 . $STR2 ;

			if ($max1 and ($c_product != $c_product1 or $c_kernel != $c_kernel1 or $c_os_ver != $c_os_ver1 or $c_cpu_cnt != $c_cpu_cnt1 or $c_mem != $c_mem1)) {
				$STR2 = "<font color=purple><b>[Check] System Info Changed!!</b></font><br>";
				$STR1 = $STR1 . $STR2 ;
			}

		}
	}



	// LOAD

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Load where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_uptime= $newArray['c_uptime'];
                        $c_load5 = $newArray['c_load5'];
                        $c_load10 = $newArray['c_load10'];
                        $c_load15 = $newArray['c_load15'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'N') $MSG1 = "Normal";
			else if ($c_result == 'W') $MSG1 = "<font color=green>Warning</font>";
			else if ($c_result == 'C') $MSG1 = "<font color=red>Critical</font>";

			if ($c_load5 >= 10) $c_load5 = "<font color=red><b>$c_load5</b></font>";
			else if ($c_load5 >= 5) $c_load5 = "<font color=red><b>$c_load5</b></font>";

			if ($c_load10 >= 6) $c_load10 = "<font color=red><b>$c_load10</b></font>";
			else if ($c_load10 >= 4) $c_load10 = "<font color=red><b>$c_load10</b></font>";

			if ($c_load15 >= 4) $c_load15 = "<font color=red><b>$c_load15</b></font>";
			else if ($c_load15 >= 3) $c_load15 = "<font color=red><b>$c_load15</b></font>";

			$STR2 = "
				<br><br><font color=blue size=3><b>Load Info : $MSG1</b></font><br>

				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>Uptime</th><th>5m Load</th><th>10m Load</th><th>15m Load</th></tr>
				<tr><td>$c_uptime</td><td>$c_load5</td><td>$c_load10</td><td>$c_load15</td></tr>
				</table><br>
			";
			$STR1 = $STR1 . $STR2 ;

                }
        }




	// IP

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_IP where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$STR2 = "
			<br><br><font color=blue size=3><b>IP Info</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>NIC</th><th>Status</th><th>IP Addr</th><th>MAC</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;
 
		$IP_CHK = '';
		$IP_WARN_CNT = 0;
		$IP_LIST_AFT = array();
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_nic= $newArray['c_nic'];
                        $c_status = $newArray['c_status'];
                        $c_ip = $newArray['c_ip'];
                        $c_mac = $newArray['c_mac'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$IP1 = $c_nic . '/' . $c_ip . '/' . $c_mac;
			array_push($IP_LIST_AFT, $IP1);
		
        		$cmd_sql5 = "select * from Ansible_linux_Detail_Diag_Result_IP where c_seq = $max1 and c_nic='$c_nic'";
        		$res5 = mysqli_query($mysqli,$cmd_sql5);
			$newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
                        $c_status5 = $newArray5['c_status'];
                        $c_ip5 = $newArray5['c_ip'];
                        $c_mac5 = $newArray5['c_mac'];

			if($max1 and ! $c_status) {
				$STR2 = "<tr><td><font color=red></b>$c_nic</b></font></td><td>$c_status</td><td>$c_ip</td><td>$c_mac</td></tr>";
				$IP_CHK = $IP_CHK . "[Check] $c_nic NIC Added!!<br>";
			}
			else if ($max1 and ($c_status != $c_status5 or $c_ip != $c_ip5 or $c_mac != $c_mac5)) {
				$STR2 = "<tr><td><font color=red></b>$c_nic</b></font></td><td>$c_status</td><td>$c_ip</td><td>$c_mac</td></tr>";
				$IP_CHK = $IP_CHK . "[Check] $c_nic Info Changed!!<br>";
			}
			else $STR2 = "<tr><td>$c_nic</td><td>$c_status</td><td>$c_ip</td><td>$c_mac</td></tr>";
			$STR1 = $STR1 . $STR2 ;

                }
		$STR1 = $STR1 . "</table><br>";
		
		$BEF_DIFF = array_diff($IP_LIST_BEF, $IP_LIST_AFT);
		if($BEF_DIFF) {
			$CNT_DIFF = sizeof($BEF_DIFF);
			for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
				$DATA = array_pop($BEF_DIFF);
				$IP_CHK = $IP_CHK . "[Check] $DATA NIC Not Found!!<br>";
			}
		}

		if ($IP_CHK) {
			$STR2 = "<font color=purple><b>$IP_CHK</b></font><br>";
			$STR1 = $STR1 . $STR2 ;
			$IP_WARN_CNT = $IP_WARN_CNT + 1;
		}


        }


	// DNS

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_DNS where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$DNS_LIST_AFT = array();
		$DNS_WARN_CNT = 0;
		$STR2 = "
			<br><br><font color=blue size=3><b>DNS Info</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>NameServer</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_name_server= $newArray['c_name_server'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			array_push($DNS_LIST_AFT, $c_name_server);
		
        		$cmd_sql5 = "select * from Ansible_linux_Detail_Diag_Result_DNS where c_seq = $max1 and c_name_server='$c_name_server'";
        		$res5 = mysqli_query($mysqli,$cmd_sql5);
			$newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
                        $c_name_server5 = $newArray5['c_name_server'];

			if($max1 and $c_name_server and ! $c_name_server5) {
				$STR2 = "<tr><td><font color=red></b>$c_name_server</b></font></td></tr>";
				$DNS_CHK = $DNS_CHK . "[Check] DNS $c_name_server NameServer Added!!<br>";
			}
			else if($max1 and $c_name_server != $c_name_server5) {
				$STR2 = "<tr><td><font color=red></b>$c_name_server</b></font></td></tr>";
				$DNS_CHK = $DNS_CHK . "[Check] DNS $c_name_server Info Changed!!<br>";
			}
			else $STR2 = "<tr><td>$c_name_server</td></tr>";
			$STR1 = $STR1 . $STR2 ;

                }
		$STR1 = $STR1 . "</table><br>";

		$BEF_DIFF = array_diff($DNS_LIST_BEF, $DNS_LIST_AFT);
		if($BEF_DIFF) {
			$CNT_DIFF = sizeof($BEF_DIFF);
			for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
				$DATA = array_pop($BEF_DIFF);
				$DNS_CHK = $DNS_CHK . "[Check] $DATA NameServer Not Found!!<br>";
			}
		}

		if ($DNS_CHK) {
			$STR2 = "<font color=purple><b>$DNS_CHK</b></font><br>";
			$STR1 = $STR1 . $STR2 ;
			$DNS_WARN_CNT = $DNS_WARN_CNT + 1;
		}
        }


	// ROUTING

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Routing where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$RT_WARN_CNT = 0;
		$RT_LIST_AFT = array();
		$STR2 = "
		<br><br><font color=blue size=3><b>Routing Info</b></font><br>
		<table width='100%' class='table table-striped table-bordered table-hover'>
		<tr><th>Dest</th><th>Gateway</th><th>Mask</th><th>Flag</th><th>Interfaceth</tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_dest= $newArray['c_dest'];
                        $c_gw = $newArray['c_gw'];
                        $c_mask = $newArray['c_mask'];
                        $c_flag = $newArray['c_flag'];
                        $c_iface = $newArray['c_iface'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$RT1 = $c_dest . '/' . $c_mask . '/gw:' . $c_gw;
			array_push($RT_LIST_AFT, $RT1);

        		$cmd_sql5 = "select * from Ansible_linux_Detail_Diag_Result_Routing where c_seq = $max1 and c_dest='$c_dest' and c_iface='$c_iface'";
        		$res5 = mysqli_query($mysqli,$cmd_sql5);
			$newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC);
                        $c_dest5 = $newArray5['c_dest'];
                        $c_gw5 = $newArray5['c_gw'];
                        $c_mask5 = $newArray5['c_mask'];
                        $c_iface5 = $newArray5['c_iface'];

			if($max1 and ! $c_dest5) {
				$STR2 = "<tr><td><font color=red></b>$c_dest</b></font></td><td>$c_gw</td><td>$c_mask</td><td>$c_flag</td><td>$c_iface</td></tr>";
				$RT_CHK = $RT_CHK . "[Check] Routing $c_dest/$c_mask gw $c_gw Added!!<br>";
			}
			else if ($max1 and ($c_gw != $c_gw5 or $c_mask != $c_mask5 or $c_iface != $c_iface5)) {
				$STR2 = "<tr><td><font color=red></b>$c_dest</b></font></td><td>$c_gw</td><td>$c_mask</td><td>$c_flag</td><td>$c_iface</td></tr>";
				$RT_CHK = $RT_CHK . "[Check] Routing $c_dest/$c_mask gw $c_gw Changed!!<br>";
			}
			else $STR2 = "<tr><td>$c_dest</td><td>$c_gw</td><td>$c_mask</td><td>$c_flag</td><td>$c_iface</td></tr>";
			$STR1 = $STR1 . $STR2 ;

                }
		$STR1 = $STR1 . "</table><br>";

		$BEF_DIFF = array_diff($RT_LIST_BEF, $RT_LIST_AFT);
		if($BEF_DIFF) {
			$CNT_DIFF = sizeof($BEF_DIFF);
			for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
				$DATA = array_pop($BEF_DIFF);
				$RT_CHK = $RT_CHK . "[Check] Routing Info : $DATA  Not Found!!<br>";
			}
		}

		if ($RT_CHK) {
			$STR2 = "<font color=purple><b>$RT_CHK</b></font><br>";
			$STR1 = $STR1 . $STR2 ;
			$RT_WARN_CNT = $RT_WARN_CNT + 1;
		}
        }


	// WHO

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Who where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$STR2 = "
			<br><br><font color=blue size=3><b>Logging Info</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>User</th><th>tty</th><th>From</th><th>Login</th><th>Idle</th><th>What</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_user= $newArray['c_user'];
                        $c_tty = $newArray['c_tty'];
                        $c_from = $newArray['c_from'];
                        $c_login = $newArray['c_login'];
                        $c_idle = $newArray['c_idle'];
                        $c_what = $newArray['c_what'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$STR2 = "<tr><td>$c_user</td><td>$c_tty</td><td>$c_from</td><td>$c_login</td><td>$c_idle</td><td>$c_what</td></tr>";
			$STR1 = $STR1 . $STR2 ;
		
                }
		$STR1 = $STR1 . "</table><br>";
        }



	// PORT

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Port where c_seq = $T_UTIME and (c_state = 'LISTEN' or c_state = 'ESTABLISHED')";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$PORT_LIST_AFT = array();
		$PORT_WARN_CNT = 0;
		$STR2 = "
			<br><br><font color=blue size=3><b>Network Connection Info</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>Proto</th><th>Recv Q</th><th>Send Q</th><th>Local Addr</th><th>Foreign Addr</th><th>State</th><th>Pid</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_proto= $newArray['c_proto'];
                        $c_recv_q = $newArray['c_recv_q'];
                        $c_send_q = $newArray['c_send_q'];
                        $c_local_addr = $newArray['c_local_addr'];
                        $c_foreign_addr = $newArray['c_foreign_addr'];
                        $c_state = $newArray['c_state'];
                        $c_pid = $newArray['c_pid'];
			$c_daemon = explode('/',$c_pid);
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if($c_state == 'LISTEN') {
				$PORT1 = $c_proto . '/' . $c_local_addr . '/' . $c_foreign_addr . '/' . $c_state . '/' . $c_daemon[1];
				array_push($PORT_LIST_AFT, $PORT1);
			}

        		$cmd_sql5 = "select * from Ansible_linux_Detail_Diag_Result_Port where c_seq = $max1 and c_local_addr='$c_local_addr' and c_state = 'LISTEN' ";
        		$res5 = mysqli_query($mysqli,$cmd_sql5);
			$newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC);

                        $c_local_addr5 = $newArray5['c_local_addr'];
                        $c_foreign_addr5 = $newArray5['c_foreign_addr'];
                        $c_pid5 = $newArray5['c_pid'];
			$c_daemon5 = explode('/',$c_pid5);

			if ($max1 and ($c_state == 'LISTEN' and ! $c_local_addr5)) {
				$STR2 = "<tr><td>$c_proto</td><td>$c_recv_q</td><td>$c_send_q</td><td><font color=red></b>$c_local_addr</b></font></td><td>$c_foreign_addr</td><td>$c_state</td><td>$c_pid</td></tr>";
				$PORT_CHK = $PORT_CHK . "[Check] Listening Port : $c_local_addr/$c_foreign_addr, $c_daemon[1] Added!!<br>";
			}
			else if ($max1 and $c_state == 'LISTEN' and ($c_foreign_addr != $c_foreign_addr5 or $c_daemon[1] != $c_daemon5[1])) {
				$STR2 = "<tr><td>$c_proto</td><td>$c_recv_q</td><td>$c_send_q</td><td><font color=red></b>$c_local_addr</b></font></td><td>$c_foreign_addr</td><td>$c_state</td><td>$c_pid</td></tr>";
				$PORT_CHK = $PORT_CHK . "[Check] Listening Port : $c_local_addr/$c_foreign_addr, $c_daemon[1] Changed!!<br>";
			}
			else $STR2 = "<tr><td>$c_proto</td><td>$c_recv_q</td><td>$c_send_q</td><td>$c_local_addr</td><td>$c_foreign_addr</td><td>$c_state</td><td>$c_pid</td></tr>";
			$STR1 = $STR1 . $STR2 ;
		
                }
		$STR1 = $STR1 . "</table><br>";

		$BEF_DIFF = array_diff($PORT_LIST_BEF, $PORT_LIST_AFT);
		if($BEF_DIFF) {
			$CNT_DIFF = sizeof($BEF_DIFF);
			for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
				$DATA = array_pop($BEF_DIFF);
				$PORT_CHK = $PORT_CHK . "[Check] Listening Port : $DATA  Not Found!!<br>";
			}
		}

		if ($PORT_CHK) {
			$STR2 = "<font color=purple><b>$PORT_CHK</b></font><br>";
			$STR1 = $STR1 . $STR2 ;
			$PORT_WARN_CNT = $PORT_WARN_CNT + 1;
		}
        }


	// CPU

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_CPU where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_endtime = $newArray['c_endtime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_user= $newArray['c_user'];
                        $c_system = $newArray['c_system'];
                        $c_iowait = $newArray['c_iowait'];
                        $c_idle = $newArray['c_idle'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'N') $MSG1 = "Normal";
			else if ($c_result == 'W') $MSG1 = "<font color=green>Warning</font>";
			else if ($c_result == 'C') $MSG1 = "<font color=red>Critical</font>";

			if ($c_user + $c_system + $c_iowait >= $CPU_CRIT) $c_idle = "<font color=red><b>$c_idle</b></font>";
			else if ($c_user + $c_system + $c_iowait >= $CPU_WARN) $c_idle = "<font color=blue><b>$c_idle</b></font>";

			$STR2 = "
				<br><br><font color=blue size=3><b>CPU Usage : $MSG1</b></font><br>
		
				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>CPU User</th><th>CPU Sytem</th><th>CPU Iowait</th><th>CPU Idle</th></tr>
				<tr><td>$c_user</td><td>$c_system</td><td>$c_iowait</td><td>$c_idle</td></tr>
				</table><br>
			";
			$STR1 = $STR1 . $STR2 ;

                }
        }


	// Memory

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Memory where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_total= $newArray['c_total'];
                        $c_free = $newArray['c_free'];
                        $c_used = $newArray['c_used'];
                        $c_buffcache = $newArray['c_buffcache'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'N') $MSG1 = "Normal";
			else if ($c_result == 'W') $MSG1 = "<font color=green>Warning</font>";
			else if ($c_result == 'C') $MSG1 = "<font color=red>Critical</font>";

			$STR2 = "
				<br><br><font color=blue size=3><b>MEM Usage : $MSG1</b></font><br>

				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>MEM Total (K)</th><th>MEM Free (K)</th><th>MEM Used (K)</th><th>MEM Buffer/Cache (K)</th></tr>
				<tr><td>$c_total</td><td>$c_free</td><td>$CONTENT1</td><td>$c_buffcache</td></tr>
				</table>
			";
			$STR1 = $STR1 . $STR2 ;

                }
        }


	// Swap

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Swap where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_total= $newArray['c_total'];
                        $c_free = $newArray['c_free'];
                        $c_used = $newArray['c_used'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'N') $MSG1 = "Normal";
			else if ($c_result == 'W') $MSG1 = "<font color=green>Warning</font>";
			else if ($c_result == 'C') $MSG1 = "<font color=red>Critical</font>";

			$STR2 = "
				<br><br><font color=blue size=3><b>Swap Usage : $MSG1</b></font><br>

				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>Swap Total (K)</th><th>Swap Free (K)</th><th>Swap Used (K)</th></tr>
				<tr><td>$c_total</td><td>$c_free</td><td>$c_used</td></tr>
				</table>
			";
			$STR1 = $STR1 . $STR2 ;
		
                }
        }

	// Disk

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Disk where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$DISK_LIST_AFT = array();

		if ($DISK_CRIT_CNT != 0) $MSG1 = "<font color=red>Critical</font>";
		else if ($DISK_WARN_CNT != 0) $MSG1 = "<font color=green>Warning</font>";
		else $MSG1 = "Normal";

		$STR2 = "
			<br><br><font color=blue size=3><b>Disk Usage : $MSG1</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>Filesystem</th><th>Size</th><th>Used</th><th>Avail</th><th>Use%</th><th>Mounted on</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_device= $newArray['c_device'];
                        $c_size = $newArray['c_size'];
                        $c_used = $newArray['c_used'];
                        $c_avail = $newArray['c_avail'];
                        $c_p_used = $newArray['c_p_used'];
                        $c_mount = $newArray['c_mount'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			$DISK1 = 'Filesystem:' . $c_device . ':' . $c_mount;
			array_push($DISK_LIST_AFT, $DISK1);

			if ($c_p_used > $DISK_CRIT) $c_p_used = "<font color=red><b>$c_p_used</b></font>";
			else if ($c_p_used > $DISK_WARN) $c_p_used = "<font color=blue><b>$c_p_used</b></font>";

			$cmd_sql5 = "select * from Ansible_linux_Detail_Diag_Result_Disk where c_seq = $max1 and c_device='$c_device' and c_mount = '$c_mount'";
        		$res5 = mysqli_query($mysqli,$cmd_sql5);
			$newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC);

                        $c_device5 = $newArray5['c_device'];
                        $c_mount5 = $newArray5['c_mount'];

			if ($max1 and ! $c_device5) {
				$STR2 = "<tr><td><font color=red><b>$c_device</b></font></td><td>$c_size</td><td>$c_used</td><td>$c_avail</td><td>$c_p_used</td><td>$c_mount</td></tr>";
				$DISK_CHK = $DISK_CHK . "[Check] FileSystem : $c_device, $c_mount Added!!<br>";
			}
			else if ($max1 and $c_mount != $c_mount5) {
				$STR2 = "<tr><td>$c_device</td><td>$c_size</td><td>$c_used</td><td>$c_avail</td><td>$c_p_used</td><td><font color=red><b>$c_mount</b></font></td></tr>";
				$DISK_CHK = $DISK_CHK . "[Check] FileSystem : $c_device, $c_mount mount point Changed!!<br>";
			}
			else $STR2 = "<tr><td>$c_device</td><td>$c_size</td><td>$c_used</td><td>$c_avail</td><td>$c_p_used</td><td>$c_mount</td></tr>";
			$STR1 = $STR1 . $STR2 ;

                }
		$STR1 = $STR1 . "</table><br>";

                $BEF_DIFF = array_diff($DISK_LIST_BEF, $DISK_LIST_AFT);
                if($BEF_DIFF) {
                        $CNT_DIFF = sizeof($BEF_DIFF);
                        for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
                                $DATA = array_pop($BEF_DIFF);
                                $DISK_CHK = $DISK_CHK . "[Check] FileSystem : $DATA  Not Found!!<br>";
                        }
                }

                if ($DISK_CHK) {
                        $STR2 = "<font color=purple><b>$DISK_CHK</b></font><br>";
                        $STR1 = $STR1 . $STR2 ;
                }

        }


	// VMSTAT

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Vmstat where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
		if ($VM_CRIT_CNT != 0) $MSG1 = "<font color=red>Critical</font>";
		else if ($VM_WARN_CNT != 0) $MSG1 = "<font color=green>Warning</font>";
		else $MSG1 = "Normal";

		$STR2 = "
			<br><br><font color=blue size=3><b>Vmstat Info : $MSG1</b></font><br>
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th colspan=2>Proc</th><th colspan=4>Mem</th><th colspan=2>Swap</th><th colspan=2>IO</th><th colspan=2>System</th><th colspan=4>CPU</th></tr>
			<tr><th>Run</th><th>Blk</th><th>Swapd</th><th>Free</th><th>Buff</th><th>Cache</th><th>si</th><th>so</th><th>bi</th><th>bo</th><th>int</th><th>cs</th><th>us</th><th>sy</th><th>id</th><th>wa</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_procs_r= $newArray['c_procs_r'];
                        $c_procs_b = $newArray['c_procs_b'];
                        $c_mem_swapd = $newArray['c_mem_swapd'];
                        $c_mem_free = $newArray['c_mem_free'];
                        $c_mem_buff = $newArray['c_mem_buff'];
                        $c_mem_cache = $newArray['c_mem_cache'];
                        $c_swap_si = $newArray['c_swap_si'];
                        $c_swap_so = $newArray['c_swap_so'];
                        $c_io_bi = $newArray['c_io_bi'];
                        $c_io_bo = $newArray['c_io_bo'];
                        $c_system_in = $newArray['c_system_in'];
                        $c_system_cs = $newArray['c_system_cs'];
                        $c_cpu_us = $newArray['c_cpu_us'];
                        $c_cpu_sy = $newArray['c_cpu_sy'];
                        $c_cpu_id = $newArray['c_cpu_id'];
                        $c_cpu_wa = $newArray['c_cpu_wa'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_procs_r > 5)  $c_procs_r = "<font color=red><b>$c_procs_r</b></font>";
			else if ($c_procs_r > 3)  $c_procs_r = "<font color=blue><b>$c_procs_r</b></font>";

			if ($c_swap_so > 500)  $c_swap_so = "<font color=red><b>$c_swap_so</b></font>";
			else if ($c_swap_so > 0)  $c_swap_so = "<font color=blue><b>$c_swap_so</b></font>";

			if ($c_cpu_id < 10)  $c_cpu_id = "<font color=red><b>$c_cpu_id</b></font>";
			else if ($c_cpu_id < 20)  $c_cpu_id = "<font color=blue><b>$c_cpu_id</b></font>";

			$STR2 = "<tr><td>$c_procs_r</td><td>$c_procs_b</td><td>$c_mem_swapd</td><td>$c_mem_free</td><td>$c_mem_buff</td><td>$c_mem_cache</td><td>$c_swap_si</td><td>$c_swap_so</td><td>$c_io_bi</td><td>$c_io_bo</td><td>$c_system_in</td><td>$c_system_cs</td><td>$c_cpu_us</td><td>$c_cpu_sy</td><td>$c_cpu_id</td><td>$c_cpu_wa</td></tr>";
			$STR1 = $STR1 . $STR2 ;

                }
		$STR1 = $STR1 . "</table><br>";
        }



	// Deamon Top 5

        $cmd_sql = "select * from Ansible_linux_Detail_Diag_Result_Daemon where c_seq = $T_UTIME ";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {

		$T_CNT1 = 0;
                $DM_CPU_LIST_AFT = array();
                $DM_MEM_LIST_AFT = array();
		
		if ($DM_CRIT_CNT != 0) $MSG1 = "<font color=red>Critical</font>";
		else if ($DM_WARN_CNT != 0) $MSG1 = "<font color=green>Warning</font>";
		else $MSG1 = "Normal";

		$STR2 = "
		<br><br><font color=blue size=3><b>CPU/MEM Top 5 : $MSG1</b></font><br>
		<font size=2><b>[MEM Top 5]</b></font><br>
		<table width='100%' class='table table-striped table-bordered table-hover'>
		<tr><th>User</th><th>Pid</th><th>Cpu</th><th>Mem</th><th>Vsz</th><th>Rss</th><th>Stime</th><th>Time</th><th>Comand</th></tr>
		";
		$STR1 = $STR1 . $STR2 ;

                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
			
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_user= $newArray['c_user'];
                        $c_pid = $newArray['c_pid'];
                        $c_cpu = $newArray['c_cpu'];
                        $c_mem_T = $newArray['c_mem'];
                        $c_vsz = $newArray['c_vsz'];
                        $c_rss = $newArray['c_rss'];
                        $c_stime = $newArray['c_stime'];
                        $c_time = $newArray['c_time'];
                        $c_cmd = $newArray['c_cmd'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($T_CNT1 == 5) {
				$STR2 = "
				</table>
				<font size=2><b>[CPU Top 5]</b></font><br>
				<table width='100%' class='table table-striped table-bordered table-hover'>
				<tr><th>User</th><th>Pid</th><th>Cpu</th><th>Mem</th><th>Vsz</th><th>Rss</th><th>Stime</th><th>Time</th><th>Comand</th></tr>
				";
				$STR1 = $STR1 . $STR2 ;
			}


        		$cmd_sql5 = "select * from Ansible_linux_Detail_Diag_Result_Daemon where c_seq = $max1 and c_cmd='$c_cmd' and c_pid = '$c_pid'";
        		$res5 = mysqli_query($mysqli,$cmd_sql5);
			$newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC);

                        $c_cmd5 = $newArray5['c_cmd'];
                        $c_user5 = $newArray5['c_user'];
                        $c_pid5 = $newArray5['c_pid'];

			if ($T_CNT1 < 5) {

				if ($c_mem_T > 90) $c_cpu = "<font color=red><b>$c_mem_T</b></font>"; 
				else if ($c_mem_T > 80) $c_cpu = "<font color=blue><b>$c_mem_T</b></font>";

				array_push($DM_MEM_LIST_AFT, $c_cmd);
				if ($max1 and ! $c_cmd5) {
					$STR2 = "<tr><td>$c_user</td><td>$c_pid</td><td>$c_cpu</td><td>$c_mem_T</td><td>$c_vsz</td><td>$c_rss</td><td>$c_stime</td><td>$c_time</td><td><font color=red><b>$c_cmd</b></font></td></tr>";
					$DAEMON_CHK = $DAEMON_CHK . "[Check] Daemon Top 5 (MEM) : $c_cmd Added!!<br>";
				}
				else if ($max1 and ($c_user != $c_user5 or $c_pid != $c_pid5)) {
					$STR2 = "<tr><td><font color=blue>$c_user</font></td><td><font color=blue>$c_pid</font></td><td>$c_cpu</td><td>$c_mem_T</td><td>$c_vsz</td><td>$c_rss</td><td>$c_stime</td><td>$c_time</td><td>$c_cmd</td></tr>";
					$DAEMON_CHK = $DAEMON_CHK . "[Check] Daemon Top 5 (MEM) : $c_cmd Pid/User Info Changed!!<br>";
				}
				else $STR2 = "<tr><td>$c_user</td><td>$c_pid</td><td>$c_cpu</td><td>$c_mem_T</td><td>$c_vsz</td><td>$c_rss</td><td>$c_stime</td><td>$c_time</td><td>$c_cmd</td></tr>";

			}
                        else {

				if ($c_cpu > 90) $c_cpu = "<font color=red><b>$c_cpu</b></font>"; 
				else if ($c_cpu > 80) $c_cpu = "<font color=blue><b>$c_cpu</b></font>";

				array_push($DM_CPU_LIST_AFT, $c_cmd);
				if ($max1 and ! $c_cmd5) {
					$STR2 = "<tr><td>$c_user</td><td>$c_pid</td><td>$c_cpu</td><td>$c_mem_T</td><td>$c_vsz</td><td>$c_rss</td><td>$c_stime</td><td>$c_time</td><td><font color=red><b>$c_cmd</b></font></td></tr>";
					$DAEMON_CHK = $DAEMON_CHK . "[Check] Daemon Top 5 (CPU) : $c_cmd Added!!<br>";
				}
				else if ($max1 and ($c_user != $c_user5 or $c_pid != $c_pid5)) {
					$STR2 = "<tr><td><font color=blue>$c_user</font></td><td><font color=blue>$c_pid</font></td><td>$c_cpu</td><td>$c_mem_T</td><td>$c_vsz</td><td>$c_rss</td><td>$c_stime</td><td>$c_time</td><td>$c_cmd</td></tr>";
					$DAEMON_CHK = $DAEMON_CHK . "[Check] Daemon Top 5 (CPU) : $c_cmd Pid/User Info Changed!!<br>";
				}
				else $STR2 = "<tr><td>$c_user</td><td>$c_pid</td><td>$c_cpu</td><td>$c_mem_T</td><td>$c_vsz</td><td>$c_rss</td><td>$c_stime</td><td>$c_time</td><td>$c_cmd</td></tr>";

			}

			$STR1 = $STR1 . $STR2 ;

			$T_CNT1 = $T_CNT1 + 1;


                }
		$STR1 = $STR1 . "</table><br>";

                $BEF_DIFF = array_diff($DM_CPU_LIST_BEF, $DM_CPU_LIST_AFT);
                if ($BEF_DIFF) {
                        $CNT_DIFF = sizeof($BEF_DIFF);
                        for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
                                $DATA = array_pop($BEF_DIFF);
                                $DAEMON_CHK = $DAEMON_CHK . "[Check] Daemon Top 5 (CPU) : $DATA  Not Found!!<br>";
                        }
                }

                $BEF_DIFF = array_diff($DM_MEM_LIST_BEF, $DM_MEM_LIST_AFT);
                if ($BEF_DIFF) {
                        $CNT_DIFF = sizeof($BEF_DIFF);
                        for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
                                $DATA = array_pop($BEF_DIFF);
                                $DAEMON_CHK = $DAEMON_CHK . "[Check] Daemon Top 5 (MEM) : $DATA  Not Found!!<br>";
                        }
                }

                if ($DAEMON_CHK) {
                        $STR2 = "<font color=purple><b>$DAEMON_CHK</b></font><br>";
                        $STR1 = $STR1 . $STR2 ;
                }

        }

} // if ($UNREACHABLE != 'Y') {
else {
	$STR2 = "
		<font size=3 color=green><b>[ NEW ]</b></font><br>
		<font size=2>* HOSTNAME : $HOSTNAME</font><br>
		<font size=2>* Start Time : $p_starttime</font><br>
		<font size=2>* End Time : $p_endtime</font><br>
		<br><br><font color=red size=3><b>Authentication Error : ID/PWD Not Correct !!</b></font><br>
	";
	$STR1 = $STR1 . $STR2 ;
}


	//************************************************************************************************************************/

	$STR2 = "
			</div>

                              </div>
                              </div>

                                 </div>
                            </div>
                          </div>

                        </div>
                        </div>

                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>

	";



	$TOT_CRIT_CNT = 0;
	$TOT_WARN_CNT = 0;

if ($UNREACHABLE != 'Y') {

	$SYSTEM_INFO = "<td>System Info</td><td>Ok</td><td></td></tr>";
	$LOGGING_INFO = "<tr><td>Logging Info</td><td>Ok</td><td></td></tr>";

	if ($CPU_CRIT_CNT > 0) {
		$T_RES = "<font color=red><b>Critical</b></font>"; 
		$TOT_CRIT_CNT = $TOT_CRIT_CNT + 1;
	}
	else if ($CPU_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>"; 
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$CPU_MSG1 = "<tr><td>CPU</td><td>$T_RES</td><td>$CPU_ALARM_MSG1</td></tr>";

	if ($MEM_CRIT_CNT > 0) {
		$T_RES = "<font color=red><b>Critical</b></font>";
		$TOT_CRIT_CNT = $TOT_CRIT_CNT + 1;
	}
	else if ($MEM_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$MEM_MSG1 = "<tr><td>MEM</td><td>$T_RES</td><td>$MEM_ALARM_MSG1</td></tr>";

	if ($SWAP_CRIT_CNT > 0) {
		$T_RES = "<font color=red><b>Critical</b></font>";
		$TOT_CRIT_CNT = $TOT_CRIT_CNT + 1;
	}
	else if ($SWAP_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$SWAP_MSG1 = "<tr><td>SWAP</td><td>$T_RES</td><td>$SWAP_ALARM_MSG1</td></tr>";

	if ($DISK_CRIT_CNT > 0) {
		$T_RES = "<font color=red><b>Critical</b></font>";
		$TOT_CRIT_CNT = $TOT_CRIT_CNT + 1;
	}
	else if ($DISK_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$DISK_ALARM_MSG1 = $DISK_ALARM_MSG1 . $DISK_CHK;
	$DISK_MSG1 = "<tr><td>DISK</td><td>$T_RES</td><td>$DISK_ALARM_MSG1</td></tr>";

	if ($LOAD_RESULT == 'C') {
		$T_RES = "<font color=red><b>Critical</b></font>";
		$TOT_CRIT_CNT = $TOT_CRIT_CNT + 1;
	}
	else if ($LOAD_RESULT == 'W') {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$LOAD_MSG1 = "<tr><td>LOAD</td><td>$T_RES</td><td>$LD_ALARM_MSG1</td></tr>";

	if ($PORT_CRIT_CNT > 0) {
		$PORT_CHK = $PORT_ALARM_MSG1 . $PORT_CHK;
		$T_RES = "<font color=red><b>Critical</b></font>";
		$TOT_CRIT_CNT = $TOT_CRIT_CNT + 1;
	}
	else $T_RES = 'Ok';

	$PORT_MSG1 = "<tr><td>Port Info</td><td>$T_RES</td><td>$PORT_CHK</td></tr>";

	if ($VM_CRIT_CNT > 0) {
		$T_RES = "<font color=red><b>Critical</b></font>";
		$TOT_CRIT_CNT = $TOT_CRIT_CNT + 1;
	}
	else if ($VM_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$VM_MSG1 = "<tr><td>VMstat</td><td>$T_RES</td><td>$VM_ALARM_MSG1</td></tr>";

	if ($DM_CRIT_CNT > 0) {
		$T_RES = "<font color=red><b>Critical</b></font>";
		$TOT_CRIT_CNT = $TOT_CRIT_CNT + 1;
	}
	else if ($DM_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$DM_ALARM_MSG1 = $DM_ALARM_MSG1 . $DAEMON_CHK;
	$DM_MSG1 = "<tr><td>Daemon Top 5</td><td>$T_RES</td><td>$DM_ALARM_MSG1</td></tr>";

	if ($DNS_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$DNS_MSG1 = "<tr><td>DNS</td><td>$T_RES</td><td>$DNS_CHK</td></tr>";

	if ($IP_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$IP_MSG1 = "<tr><td>IP Info</td><td>$T_RES</td><td>$IP_CHK</td></tr>";

	if ($RT_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';

	$RT_MSG1 = "<tr><td>Routing Info</td><td>$T_RES</td><td>$RT_CHK</td></tr>";

	if ($PORT_WARN_CNT > 0) {
		$T_RES = "<font color=blue><b>Warning</b></font>";
		$TOT_WARN_CNT = $TOT_WARN_CNT + 1;
	}
	else $T_RES = 'Ok';


	$TOT_ALARM_MSG = $LD_ALARM_MSG1 . $IP_CHK . $DNS_CHK . $RT_CHK . $PORT_CHK . $CPU_ALARM_MSG1 . $MEM_ALARM_MSG1 . $SWAP_ALARM_MSG1 . $DISK_ALARM_MSG1 . $VM_ALARM_MSG1 . $DM_ALARM_MSG1;

} // if ($UNREACHABLE != 'Y') {
else {

	$T_RES = "Check";
	$SYSTEM_INFO = "<td>System Info</td><td>$T_RES</td><td></td></tr>";
	$LOGGING_INFO = "<tr><td>Logging Info</td><td>$T_RES</td><td></td></tr>";
	$CPU_MSG1 = "<tr><td>CPU</td><td>$T_RES</td><td></td></tr>";
	$MEM_MSG1 = "<tr><td>MEM</td><td>$T_RES</td><td></td></tr>";
	$SWAP_MSG1 = "<tr><td>SWAP</td><td>$T_RES</td><td></td></tr>";
	$DISK_MSG1 = "<tr><td>DISK</td><td>$T_RES</td><td></td></tr>";
	$LOAD_MSG1 = "<tr><td>LOAD</td><td>$T_RES</td><td></td></tr>";
	$PORT_MSG1 = "<tr><td>Port Info</td><td>$T_RES</td><td></td></tr>";
	$VM_MSG1 = "<tr><td>VMstat</td><td>$T_RES</td><td></td></tr>";
	$DM_MSG1 = "<tr><td>Daemon Top 5</td><td>$T_RES</td><td></td></tr>";
	$DNS_MSG1 = "<tr><td>DNS</td><td>$T_RES</td><td></td></tr>";
	$IP_MSG1 = "<tr><td>IP Info</td><td>$T_RES</td><td></td></tr>";
	$RT_MSG1 = "<tr><td>Routing Info</td><td>$T_RES</td><td></td></tr>";

	$TOT_ALARM_MSG = "Authentication Error : ID/PWD Not Correct !!";

}


	if ($EVENT_SERVER_NAME) {

		$EVENT_MSG = "
			  <br>
                          <div class='row'>
        			<div class='col-lg-9'>
        			<div class='label_danger' style='margin-bottom: 5px;padding: 4px 12px;'>
        			<table>
        			<tr><td><font size=4><b>&nbsp;이벤트 메시지 : [$EVENT_SERVER_NAME] $EVENT_CONT </b></font></td></tr>
        			</table>
        			</div>
        			</div>
        			<div class='col-lg-3'>
				</div>
			  <br>
			  <br>
			  <br>
		";

		$EVENT_MSG1 = "
			<br>
        		<table>
        		<tr><td><font size=4><b>&nbsp;이벤트 메시지 : [$EVENT_SERVER_NAME] $EVENT_CONT </b></font></td></tr>
        		</table>
			<br>
			<br>
			<br>
		";

	}
	else {
		$EVENT_MSG = "";
		$EVENT_MSG1 = "";
	}


	$H_STR1 = "
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=6>Linux 정밀 점검 상세보기</font></td>
                        </tr>
                        </table>

		       </div>


                        <div id='P_mod' class='panel-body'>

			  $EVENT_MSG
			  <br>
                          <div class='row'>
        			<div class='col-lg-3'>
        			<div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
        			<table>
        			<tr><td width=220><font size=3><b>&nbsp;Linux 정밀점검 요약</b></font></td></tr>
        			</table>
        			</div>
        			</div>
        			<div class='col-lg-9'>
				</div>

                            <div class='col-lg-12'>


                              <div class='panel-body'>
                              <div class='row'>

                                <table border=1 width='100%' class='table table-striped table-bordered table-hover'>
                                <tr><th>Check No</th><th>Start Time</th><th>Hostname</th><th>Check Item</th><th>Result</th><th>Messages</th></tr>
                                <tr><td rowspan=13>$T_UTIME</td><td rowspan=13>$p_starttime</td><td rowspan=13>$HOSTNAME</td>
				$SYSTEM_INFO
				$LOAD_MSG1
				$IP_MSG1
				$DNS_MSG1
				$RT_MSG1
				$LOGGING_INFO
				$PORT_MSG1
				$CPU_MSG1
				$MEM_MSG1
				$SWAP_MSG1
				$DISK_MSG1
				$VM_MSG1
				$DM_MSG1
                                </table><br>


			      </div>
			      </div>

			    </div>
                          </div>


			  <br>
                          <div class='row'>
        <div class='col-lg-3'>
        <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
        <table>
        <tr><td width=220><font size=3><b>&nbsp;Linux 정밀점검 상세 내역</b></font></td></tr>
        </table>
	</div>
	</div>

                            <div class='col-lg-12'>



                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-6'>


	";

	$H_MAIL_STR1 = "
            <div style='float:left;width:98%;padding-right:5px;padding-left:5px;'>
                <div style='float:left;width:100%;padding-right:5px;padding-left:5px;'>
                    <div style='margin-bottom:20px;background-color:#fff;border:1px solid transparent;border-radius:4px;-webkit-box-shadow:0 1px 1px rgba(0,0,0,.05);box-shadow:0 1px 1px rgba(0,0,0,.05);border-color:#ddd'>
                        <div style='padding:10px 15px;border-bottom:1px solid transparent;border-top-left-radius:3px;border-top-right-radius:3px'>

                        <table>
                        <tr><td width=450><font size=6>Linux 정밀 점검 상세보기</font></td>
                        </tr>
                        </table>

		       </div>


                        <div id='P_mod' style='padding:15px'>

			  <br>
                          <div style='float:left;width:98%;padding-right:5px;padding-left:5px;'>
        			<div style='position:relative;float:left;width:23%;padding-right:5px;padding-left:5px;'>
        			<div style='background-color: #e7f3fe;border-left: 6px solid #2196F3; margin-bottom: 5px;padding: 4px 12px;'>
				$EVENT_MSG1
        			<table>
        			<tr><td width=220><font size=3><b>&nbsp;Linux 정밀점검 요약</b></font></td></tr>
        			</table>
        			</div>
        			</div>
                                <div style='position:relative;float:left;width:73%;padding-right:5px;padding-left:5px;'>
                                </div>

                            <div style='float:left;width:100%;padding-right:5px;padding-left:5px;'>


                              <div style='padding:15px'>
                              <div style='float:left;width:98%;padding-right:5px;padding-left:5px;'>

                                <table border=1 style='border-collapse: collapse;width: 100%;'>
                                <tr><th>Check No</th><th>Start Time</th><th>Hostname</th><th>Check Item</th><th>Result</th><th>Messages</th></tr>
                                <tr><td rowspan=13>$T_UTIME</td><td rowspan=13>$p_starttime</td><td rowspan=13>$HOSTNAME</td>
				$SYSTEM_INFO
				$LOAD_MSG1
				$IP_MSG1
				$DNS_MSG1
				$RT_MSG1
				$LOGGING_INFO
				$PORT_MSG1
				$CPU_MSG1
				$MEM_MSG1
				$SWAP_MSG1
				$DISK_MSG1
				$VM_MSG1
				$DM_MSG1
                                </table><br>


			      </div>
			      </div>

			    </div>
                          </div>


			  <br>
                          <div style='float:left;width:98%;padding-right:5px;padding-left:5px;'>
        <div style='position:relative;float:left;width:23%;padding-right:5px;padding-left:5px;'>
        <div style='background-color: #e7f3fe;border-left: 6px solid #2196F3;margin-bottom: 5px;padding: 4px 12px;'>
        <table>
        <tr><td width=220><font size=3><b>&nbsp;Linux 정밀점검 상세 내역</b></font></td></tr>
        </table>
	</div>
	</div>

                            <div style='float:left;width:100%;padding-right:5px;padding-left:5px;'>



                              <div style='padding:15px'>
                              <div style='float:left;width:98%;padding-right:5px;padding-left:5px;'>
                              <div style='position:relative;border:1px solid blue;float:left;width:49%;padding-right:5px;padding-left:5px;'>


	";


	$MAIL_STR1 = $STR1 . $STR2;
	$EXE_STR1 = $HTML_HEADER . $H_STR1 . $STR1 . $STR2;

	echo $EXE_STR1;

	// DB insert
	$ALL_MSG = base64_encode(gzdeflate($EXE_STR1, 9));
	$ALARM_MSG = base64_encode($TOT_ALARM_MSG);

	$insert_sql = "insert into Ansible_linux_Detail_Diag_history values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', $TOT_CRIT_CNT, $TOT_WARN_CNT, '$ALL_MSG', '$ALARM_MSG');";

        $res = mysqli_query($mysqli,$insert_sql);



	// Mail Sending

	$MAIL_STR1 = str_replace("table width='100%' class='table table-striped table-bordered table-hover'","table border=1 style='border-collapse: collapse;width: 100%;'",$MAIL_STR1);
	$MAIL_STR1 = str_replace("div class='col-lg-6'","div style='position:relative;border:1px solid gold;float:left;width:49%;padding-right:5px;padding-left:5px;'",$MAIL_STR1);

	$MAIL_CONTENT = $MAIL_HEADER . $H_MAIL_STR1 . $MAIL_STR1;



	} // if ($SERVER_NOT_PING != 'YES') {




function send_htmlmail($fromEmail, $fromName, $toEmail, $toName, $subject, $message){

  $charset='utf-8'; // 문자셋 : UTF-8
  $body = iconv('utf-8', 'euc-kr', $message);  //본문 내용 UTF-8화
  $encoded_subject="=?".$charset."?B?".base64_encode($subject)."?=\n"; // 인코딩된 제목
  //$to= "\"=?".$charset."?B?".base64_encode($toName)."?=\" <".$toEmail.">" ; // 인코딩된 받는이
  $from= "\"=?".$charset."?B?".base64_encode($fromName)."?=\" <".$fromEmail.">" ; // 인코딩된 보내는이

  $headers="MIME-Version: 1.0\n".
  "Content-Type: text/html; charset=euc-kr; format=flowed\n".
  "To: ". $to ."\n".
  "From: ".$from."\n".
  "Return-Path: ".$from."\n".
  "urn:content-classes:message\n".
  "Content-Transfer-Encoding: 8bit\n"; // 헤더 설정
  //send the email
  $mail_sent = @mail( $toEmail, $encoded_subject, $body, $headers );
  //if the message is sent successfully print "Mail sent". Otherwise print "Mail failed"

  return $mail_sent;
 }

        $MAIL_LIST = '';
        $cmd_sql5 = "select mail_id from Mail_list where mail_send = 'Y'";
        $res5 = mysqli_query($mysqli,$cmd_sql5);
        if ($res5) {
                while ($newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                        $mail_id = $newArray5['mail_id'];
                        $MAIL_LIST = $MAIL_LIST . ',' . $mail_id;
                }
        }

	$MAIL_LIST = "oh.yunwoo1@gmail.com,gzone2000@naver.com";

	$fromEmail = "ansible@docker.mailexample.com";
	$fromName = "ansible";
	//$toEmail = "oh.yunwoo1@gmail.com";
	$toEmail = $MAIL_LIST;
	$toName = "오윤우";
	
	if ($SERVER_NOT_PING != 'YES') {
		$subject = "[$SERVER] Ansible Detail Checking - Problem Happened!!".date("Y-m-d H:i:s", time());
		$message = "$MAIL_CONTENT";
	} 
	else {
		$subject = "[$SERVER] Ansible Detail Checking - Ping Loss 100% Happened!!".date("Y-m-d H:i:s", time());
		$message = "
<font color=red size=3><b>[Critical]</b></font><br>
- Hostname : <font color=blue>$SERVER</font><br>
- Problem  : <font color=blue>Ping Loss 100%</font><br>
- Ansible detail checking Impossible and $SERVER checking now!! <br>
";
	}

	$result = send_htmlmail($fromEmail, $fromName, $toEmail, $toName, $subject, $message);

	//echo "<br><br><br><br><br><br>";
	//echo "<pre>Mail Send Result : $result</pre>";
	//echo "<pre>Mail Content : <br>$MAIL_CONTENT</pre>";


        $DELETE1 = shell_exec("rm -f $ANSIBLE_EXEC_DIR/Linux_Morning_Check_*");
        $DELETE2 = shell_exec("rm -f $ANSIBLE_HOST_DIR/host51*");
        $DELETE2 = shell_exec("rm -f $ANSIBLE_LOG_DIR/log.txt1*");		



} /* if ($FAULT != 'Y' and $server_cnt != 0) { */
else {

       	if ($server_cnt == 0) {
		echo "<br><font color=red>ㅇ Inventory 항목이 문제가 있습니다. 확인 바랍니다!! </font><br>";
	}
       	else if ($FAULT == 'Y') {
		echo "<br><font color=red>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</font><br><br><br>";
	}

}



?> 





    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>


</body>

</html>


