<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
function Inventory_Select(c_num) {
    var String = "./ansible_linux_morning_chk_Ilist_mod.php?ACT=MOD&C_NUM=" +  c_num;
    $("#Inventory_Select_Div").load(String);
}
</script>


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$DAYS=$INPUT_DAYS ;
$INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));
$INPUT_DATE1 = date("Y-m-d",strtotime("0 days"));

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">조근 점검 > Linux > DashBoard</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
		echo "<table>";
		echo "<tr><td width=550><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux 조근 점검</font></td>";
		echo "</tr>";
		echo "</table>";
?>

		</div>
		<!-- /.panel-heading -->








<?php

        if($_POST['C_NUM']) $C_NUM = $_POST['C_NUM'];
        else if($_GET['C_NUM']) $C_NUM = $_GET['C_NUM'];

	$ITEM = $_POST['ITEM'];

	if ($C_NUM and preg_match("/[^\d]/", $C_NUM)) {
		$FAULT = 'Y';
	}

	if ($ITEM and preg_match("/[^a-z|]/i", $ITEM)) {
		$FAULT = 'Y';
	}


	if (! $ITEM) {
        	$cmd_sql = "select c_itemlist from Ansible_linux_morning_chk_cron where c_num = '$C_NUM'" ;
        	$res = mysqli_query($mysqli,$cmd_sql);
		$row = mysqli_fetch_array($res);
		$ITEM  = $row["c_itemlist"];
	}
        
        echo "

            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>

                        <div id='P_mod' class='panel-body'>

                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
                               <tr><td width=220 style='height:33px'><font size=3><b>&nbsp;Linux 조근점검 Cron 수정</b></font></td>
                               </table>

                              </div>
                            </div>
                            <div class='col-lg-9'>
                            </div>
                          </div>


                          <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
                               <tr><td width=190 height=25><font size=3><b>&nbsp;1. 실행할 아이템 선택</b></font></td>
			       <td><button id=button1 value='{$ITEM}' name=btn1 class='btn btn-primary' onclick='Inventory_Select(\"$C_NUM\")'><b>선택</b></button></td></tr>
                               </table>

                              </div>
                            </div>
                            <div class='col-lg-9'>
                            </div>
                          </div>
	";


	if($ITEM and $FAULT != 'Y') {
		echo "
                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-6'>
                                <div id='Inventory_Select_Div'>
		";

                // ITEM List display //
                $T_CNT = 0;
		$ITEM_LIST = '';
        	$T_ITEM = explode('|',$ITEM);
        	foreach($T_ITEM as $SubITEM) {

                	$itemname = $SubITEM;
			if(!$ITEM_LIST) $ITEM_LIST = $itemname ;
                        else {
                             $ITEM_LIST = $ITEM_LIST . ",&nbsp;" . $itemname ;
                        }
		}

		if($ITEM_LIST) {

			echo "<table border=1 width='100%' class='table table-striped table-bordered table-hover'>";
			if($ITEM_LIST) {
				echo "
				<tr><td>ㅇ 아이템 리스트: </td>
				<td>$ITEM_LIST</td></tr>
				";
			}

			echo "</table>";

		}


		echo "

                                </div>
			      <div class='col-lg-6'>
			      </div>

                              </div>
                              </div>
                              </div>

                            </div>
                          </div>
		";
	}
	else {

		if($FAULT == 'Y') $MSG1="<b><font color=red>잘못된 값이 입력되었습니다. 확인 바랍니다!!</font></b>";
                echo "
                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>
                                <div id='Inventory_Select_Div'>
				$MSG1
                                </div>
                              </div>
                              </div>
                              </div>

                            </div>
                          </div>
                ";

	}


        echo "
                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
                               <tr><td width=190 height=25><font size=3><b>&nbsp;2. 실행할 Cron 주기</b></font></td>
                               <td><button id=button2 name=btn1 class='btn btn-primary' disabled><b>선택</b></button></td></tr>
                               </table>

                              </div>
                            </div>
                            <div class='col-lg-9'>
                            </div>
                          </div>
	";


	if($C_NUM and $FAULT != 'Y') {


        	echo "
                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>
				<div id='playbook_Select_Div'>
		";

                echo "<div class='row'>";
                echo "<div class='col-lg-6'>";

		echo "
                                 <table width='100%' class='table table-striped table-bordered table-hover' id='dataTables-example'>
                                 <thead>
                                    <tr>
                                        <th>번호</th>
                                        <th>Minute</th>
                                        <th>Hour</th>
                                        <th>Day</th>
                                        <th>Month</th>
                                        <th>Week</th>
                                        <th>Command</th>
                                        <th>수정</th>
                                        <th>삭제</th>
                                        <th>메일 발송</th>
                                    </tr>
                                 </thead>
                                 <tbody>
		";



	$cmd_sql = "select * from Ansible_linux_morning_chk_cron where c_num = {$C_NUM} " ;
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
		$ACT = "MOD";
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_num = $newArray['c_num'];
                        $c_min = $newArray['c_min'];
                        $c_min_chk = $newArray['c_min_chk'];
                        $c_hour = $newArray['c_hour'];
                        $c_hour_chk = $newArray['c_hour_chk'];
                        $c_day = $newArray['c_day'];
                        $c_month = $newArray['c_month'];
                        $c_week = $newArray['c_week'];
                        $c_cmd = $newArray['c_cmd'];
                        $c_mail = $newArray['c_mail'];

			if($c_min_chk == 'Y' and $c_min != '*') $c_min = '* / ' . $c_min;
			if($c_hour_chk == 'Y' and $c_hour != '*') $c_hour = '* / ' . $c_hour;

                	if($c_week == "*") $S_MSG="*";
                	else if($c_week == '0') $S_MSG="Sun";
                	else if($c_week == '1') $S_MSG="Mon";
                	else if($c_week == '2') $S_MSG="Tus";
                	else if($c_week == '3') $S_MSG="Wed";
                	else if($c_week == '4') $S_MSG="Thu";
                	else if($c_week == '5') $S_MSG="Fri";
                	else if($c_week == '6') $S_MSG="Sat";

                        echo "<tr>";
                        echo "<td>{$c_num}</td><td>{$c_min}</td><td>{$c_hour}</td><td>{$c_day}</td><td>{$c_month}</td><td>{$S_MSG}</td><td>{$c_cmd}</td>";

                        echo "<td width=50><form action=./ansible_linux_morning_chk_Modify.php>";
                        echo "<center><button class='btn btn-warning btn-xs' type=submit name=MOD_NUM value={$c_num} disabled><b><font size=2>수정</font></b></button></center></form></td>";

                        echo "<td width=50><form action=./ansible_linux_morning_chk_Delete.php>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=DEL_NUM value={$c_num}><b><font size=2>삭제</font></b></button></center></form></td>";

			if($c_mail == 'Y') $MSG5 = "YES";
			else $MSG5 = "NO";
			echo"<td align=center>$MSG5</td>";

                        echo "</tr>";   
                }
        }
	else {
		$ACT = "ADD";
	}

	echo "</table>"	;



                echo "</div>"; //col-lg-6

                echo "<div class='col-lg-1'>";
                echo "</div>"; //col-lg-1

                echo "<div class='col-lg-5'>";



	$DISABLED ='';
	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 수정 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<form action=./ansible_linux_morning_chk_cron_mod.php method=POST>";

	echo "<table border=1>";

        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 번호 : </label>";
        	echo "</td>";
        	echo "<td width=350 colspan=2>";
        	echo "<input type='text' class='form-control' name=NUM value={$c_num} readonly>";
        	echo "</td><td><input type=hidden name=ITEM value={$ITEM}></input></td></tr>";

        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ Minute : </label>";
        	echo "</td>";
        	echo "<td width=200>";
                echo "<select class='form-control' name=MIN>";

                if($c_min == '*') {
                        echo "<option value='*' selected=selected>*</option>";
                        for($i=0;$i < 60; $i++) echo "<option value=$i>$i</option>";
                }
                else {
                        echo "<option value='*'>*</option>";
                        for($i=0;$i < 60; $i++) {
                                if($i == $c_min) echo "<option value=$i selected=selected>$i</option>";
                                else echo "<option value=$i>$i</option>";
                        }
                }

                echo "</select>";
		echo "</td>";
        	echo "<td align=center>";
		if($c_min_chk == 'Y') echo "<div class=checkbox><label><input type=checkbox name=EVERY_MIN_CHK value=Y checked>Every Minutes</label></div>";
                else echo "<div class=checkbox><label><input type=checkbox name=EVERY_MIN_CHK value=Y>Every Minutes</label></div>";
		echo "</td>";
        	echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Hour : </label>";
                echo "</td>";
                echo "<td>";
                echo "<select class='form-control' name=HOUR>";
		if($c_hour == '*') {
			echo "<option value='*' selected=selected>*</option>";
                	for($i=0;$i < 24; $i++) echo "<option value=$i>$i</option>";
		}
                else {
			echo "<option value='*'>*</option>";
                	for($i=0;$i < 24; $i++) {
				if($i == $c_hour) echo "<option value=$i selected=selected>$i</option>";
                        	else echo "<option value=$i>$i</option>";
                	}
		}
                echo "</select>";
                echo "</td>";
                echo "<td align=center>";
		if($c_hour_chk == 'Y') echo "<div class=checkbox><label><input type=checkbox name=EVERY_HOUR_CHK value=Y checked>Every Minutes</label></div>";
                else echo "<div class=checkbox><label><input type=checkbox name=EVERY_HOUR_CHK value=Y>Every Minutes</label></div>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Day : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=DAY>";
		if($c_day == '*') echo "<option value='*' selected=selected>*</option>";
                else echo "<option value='*'>*</option>";
                for($i=1;$i < 32; $i++) {
			if($i == $c_day) echo "<option value=$i selected=selected>$i</option>";
                        else echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Month : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=MONTH>";
		if($c_month == '*') echo "<option value='*' selected=selected>*</option>";
                else echo "<option value='*'>*</option>";
                for($i=1;$i <= 12; $i++) {
			if($i == $c_month) echo "<option value=$i selected=selected>$i</option>";
                        else echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Week : </label>";
                echo "</td>";
                echo "<td colspan=2>";
		if($c_week == '*') $S_MSG1="selected=selected";
		else if($c_week == '0') $S_MSG2="selected=selected";
		else if($c_week == '1') $S_MSG3="selected=selected";
		else if($c_week == '2') $S_MSG4="selected=selected";
		else if($c_week == '3') $S_MSG5="selected=selected";
		else if($c_week == '4') $S_MSG6="selected=selected";
		else if($c_week == '5') $S_MSG7="selected=selected";
		else if($c_week == '6') $S_MSG8="selected=selected";
                echo "<select class='form-control' name=WEEK>";
                	echo "<option value='*' $S_MSG1>*</option>";
                        echo "<option value=0 $S_MSG2>Sun</option>";
                        echo "<option value=1 $S_MSG3>Mon</option>";
                        echo "<option value=2 $S_MSG4>Tus</option>";
                        echo "<option value=3 $S_MSG5>Wed</option>";
                        echo "<option value=4 $S_MSG6>Thu</option>";
                        echo "<option value=5 $S_MSG7>Fri</option>";
                        echo "<option value=6 $S_MSG8>Sat</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ 메일 발송: </label>";
                echo "</td>";
                echo "<td colspan=2>";
                if($c_mail == 'Y') $M_MSG1="selected=selected";
                else $M_MSG2="selected=selected";
                echo "<select class='form-control' name=MAIL_SEND>";
                        echo "<option value=Y $M_MSG1>YES</option>";
                        echo "<option value=N $M_MSG2>NO</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ 등록 Flow : </label>";
                echo "</td>";
                echo "<td colspan=2>";

                echo "<input type='text' class='form-control' name=COMMAND value='{$c_cmd}' readonly>";
                echo "</td>";
                echo "<td></td></tr>";


        echo "</table>";

	echo "<br>";
	echo "수정 하시겠습니까? &nbsp;&nbsp;&nbsp;";
	echo "<button type=submit class='btn btn-success'>수정</button>";
	echo "</form>";

	echo "</div>";


	}
	else {

		if($FAULT == 'Y') $MSG2="<b><font color=red>잘못된 값이 입력되었습니다. 확인 바랍니다!!</font></b>";
                echo "
                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>
                                <div id='playbook_Select_Div'>
				$MSG2
                                </div>
                              </div>
                              </div>
                              </div>

                            </div>
                          </div>
                ";
	}


        echo "



                    </div>
                </div>


			</div>
			</div>
			</div>
			</div>
			</div>

			</div>
			</div>
			</div>
			</div>


<br>
        ";



        echo "
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux 조근 점검 히스토리</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>조근점검번호</th>
                                        <th>실행시간</th>
                                        <th>종료시간</th>
                                        <th>실행ITEM</th>
                                        <th>조근점검결과</th>
                                        <th>실행서버수</th>
                                        <th>성공서버수</th>
                                        <th>실패서버수</th>
                                        <th>WARN 서버수</th>
                                        <th>CRIT 서버수</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>

        ";



                $CMD_COND = " where date_format(mc_starttime,'%Y-%m-%d') >= '{$INPUT_DATE}' and date_format(mc_starttime,'%Y-%m-%d') <= '{$INPUT_DATE1}' " ;
                $ORDER = " order by mc_starttime desc" ;
                $cmd_sql = "select * from Ansible_linux_morning_chk_Item_Result" . $CMD_COND . $ORDER;
                #echo "# SQL : {$cmd_sql}";

                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $mc_seq = $newArray['mc_seq'];
                                $mc_starttime = $newArray['mc_starttime'];
                                $mc_endtime= $newArray['mc_endtime'];
                                $mc_item= $newArray['mc_item'];
                                $mc_result= $newArray['mc_result'];
                                $mc_total_cnt= $newArray['mc_total_cnt'];
                                $mc_succ_cnt = $newArray['mc_succ_cnt'];
                                $mc_fail_cnt = $newArray['mc_fail_cnt'];
                                $mc_warn_cnt = $newArray['mc_warn_cnt'];
                                $mc_crit_cnt = $newArray['mc_crit_cnt'];

                                if ($mc_result == 'Y') $MSG1 = "성공";
                                else $MSG1 = "실패";

                                if ($mc_warn_cnt > 0) $WARN_MSG = "<b><font size=3 color=blue>$mc_warn_cnt</font></b>";
                                else $WARN_MSG = "{$mc_warn_cnt}";

                                if ($mc_crit_cnt > 0) $CRIT_MSG = "<b><font size=3 color=red>$mc_warn_cnt</font></b>";
                                else $CRIT_MSG = "{$mc_crit_cnt}";

                                echo "<tr><td>{$mc_seq}</td><td>{$mc_starttime}</td><td>{$mc_endtime}</td><td>{$mc_item}</td>";
                                echo "<td>{$MSG1}</td><td>{$mc_total_cnt}</td><td>{$mc_succ_cnt}</td>";
                                echo "<td>{$mc_fail_cnt}</td>";
                                echo "<td>{$WARN_MSG}</td>";
                                echo "<td>{$CRIT_MSG}</td>";
                                echo "<td></td></tr>";

                        }
                }


                echo "</tbody>";
                echo "</table>";
                echo "</div>";

                echo "

                            </div>
                          </div>



                        </div>


                ";




?>



                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>
