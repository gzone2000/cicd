<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
include "ip.inc" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery-2.2.4.js"></script>
<script>
function GetCellValues5() {
    var group_name = document.getElementById('GROUP_NAME5').value;
    var res = '';
    var str1 = '' ;
    var table = document.getElementById('table_dest5');
    for (var r = 1, n = table.rows.length; r < n; r++) {
            str1 = table.rows[r].cells[2].innerHTML;
            if ( res == '') {
                res = str1;
            }
            else {
                res = res + ',' + str1;
            }
    }

    if(res == '') {
        alert("선택된 호스트 항목이 없습니다. 확인 바랍니다!!");
    }
    else {
    	var url1 = './ansible_linux_inventory_group_mod.php?GROUP_NAME=' + group_name + '&MEMBER=' + res;
        location.replace(url1);
    }
}
</script>

         <script type="text/javascript">
                           $(document).ready(function() {
                                   $("#move_to_down").on("click", function() {
                                            $('#table_source5').find('tr').each(function () {
                                                     var row = $(this);
                                                     if (row.find('input[type="checkbox"]').is(':checked')) {
                                                              $("#table_dest5 tbody").append(row);
                                                     }
                                            });

                                   });

                                   $("#move_to_up").on("click", function() {
                                            $('#table_dest5').find('tr').each(function () {
                                                     var row = $(this);
                                                     if (row.find('input[type="checkbox"]').is(':checked')) {
                                                              $("#table_source5 tbody").append(row);
                                                     }

                                            });

                                   });

                           });

        </script>


</head>

<body>


<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

$GROUP_NAME = $_GET['G_MOD'];

if (preg_match("/[^a-z.\d_-]/i", $GROUP_NAME)) {
        echo "<b><font color=red>ㅇ 입력된 Group 이름이 문제가 있습니다. 확인 바랍니다!!</font></b><br><br><br><br><br><br>";
        exit();
}

$cmd_sql = "select * from Ansible_linux_group where groupname = '{$GROUP_NAME}' ";
$res = mysqli_query($mysqli,$cmd_sql);
$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
$member= $newArray['member'];
$PIECES = explode("|", $member);

$MEMBER_STR = '(';
$CNT = 1;
foreach($PIECES as $MEMBER) {
	if($CNT == 1) $MEMBER_STR = $MEMBER_STR . "'" . $MEMBER . "'";
        else $MEMBER_STR = $MEMBER_STR . ",'" . $MEMBER . "'";
	$CNT++;
}
$MEMBER_STR = $MEMBER_STR . ')';




	echo "
            		  <div class='row'>
                	    <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Ansible 호스트</font></b>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

				<div class='table-responsive scrollClass-sm'>
                                <table id='table_source5' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>체크</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";


        $cmd_sql = "select * from Ansible_linux_host where nodename NOT IN {$MEMBER_STR} order by hostname";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $hostname = $newArray['hostname'];
                        $nodename= $newArray['nodename'];
                        $ip = $newArray['ip'];
                        $linux_ver = $newArray['linux_ver'];
                        $kernel_ver = $newArray['kernel_ver'];

                        echo "<tr><td><input type='checkbox' name=NODE value=$nodename></td><td>$hostname</td><td>$nodename</td><td>$ip</td></tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";



        echo "
			    </div>
                            <div class='col-lg-1'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>이동</font></b>
                              </div>
                              
                              <div id='txt' class='panel-body'>
                              </div>


                                <table align=center>
				    <tr><td>&nbsp;</td></tr>
                                    <tr><td><img id='move_to_down' src='../vendor/login/arrow_right.PNG'></td></tr>
                                    <tr><td><img id='move_to_up' src='../vendor/login/arrow_left.PNG'></td></tr>
				</table>

                            </div>


                            <div class='col-lg-5'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Ansible 그룹 수정:</font><font size=3 color=blue> $GROUP_NAME</font></b>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

				<div class='table-responsive scrollClass-sm'>
                                <table id='table_dest5' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>체크</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                    </tr>
                                </thead>
				<tbody>
                ";

        $cmd_sql = "select * from Ansible_linux_host where nodename IN {$MEMBER_STR} order by hostname";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $hostname = $newArray['hostname'];
                        $nodename= $newArray['nodename'];
                        $ip = $newArray['ip'];
                        $linux_ver = $newArray['linux_ver'];
                        $kernel_ver = $newArray['kernel_ver'];

                        echo "<tr><td><input type='checkbox' name=NODE value=$nodename></td><td>$hostname</td><td>$nodename</td><td>$ip</td></tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";

        echo "
				
                                <div class='form-group has-error'>
				     <label class='control-label' for='inputError'>호스트를 원하는 방향으로 이동후</label>
				     <table><tr><td width=230>
                                     <input type='text' class='form-control' id='GROUP_NAME5' value='{$GROUP_NAME}' disabled></td><td>&nbsp;&nbsp;</td>
				     <td><button class='btn btn-primary' onClick='GetCellValues5()'><b>그룹 수정</b></button></td>
				     </table>
                                </div>


                    </div>

                </div>

	";


?>


    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>
