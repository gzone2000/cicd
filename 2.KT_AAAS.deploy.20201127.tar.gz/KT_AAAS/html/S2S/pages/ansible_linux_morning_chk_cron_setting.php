<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>


</head>

<body>

    <div id="wrapper">

<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

if($_SESSION[auth_level] != '0') {
        echo "<center><font color=red size=5><b>접근권한이 없습니다. 확인해 보시기 바랍니다!!</b></font></center>";
        exit(0);
}


?>

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->


                        <div class="panel-body">

            		  <div class="row">
                            <div class="col-lg-4">
                              <div class="label_info" style="margin-bottom: 5px;padding: 4px 12px;">

                               <table>
                               <tr><td width=200 height=35><font size=3><b>1.&nbsp;조근점검 Cron 리스트&nbsp;&nbsp;</b></font></td></tr>
                               </table>

                              </div>

                            </div>
                            <div class="col-lg-8">
                            </div>
                          </div>


                          <div class="row">
                            <div class="col-lg-12">



<?php

                echo "<div id=wrapper>";
                echo "<div class='panel-body'>";

                echo "<div class='row'>";
                echo "<div class='col-lg-6'>";

		echo "
                                 <table width='100%' class='table table-striped table-bordered table-hover' id='dataTables-example'>
                                 <thead>
                                    <tr>
                                        <th>번호</th>
                                        <th>Minute</th>
                                        <th>Hour</th>
                                        <th>Day</th>
                                        <th>Month</th>
                                        <th>Week</th>
                                        <th>Command</th>
                                        <th>수정</th>
                                        <th>삭제</th>
                                        <th>메일 발송</th>
                                    </tr>
                                 </thead>
                                 <tbody>
		";



	$cmd_sql = "select * from Ansible_linux_morning_chk_cron" ;
        $res = mysqli_query($mysqli,$cmd_sql);

	$row = mysqli_fetch_array($res);
	$row_OK  = $row["c_num"];

	$cmd_sql = "select * from Ansible_linux_morning_chk_cron" ;
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($row_OK) {
		$ACT = "MOD";
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_num = $newArray['c_num'];
                        $c_min = $newArray['c_min'];
                        $c_min_chk = $newArray['c_min_chk'];
                        $c_hour = $newArray['c_hour'];
                        $c_hour_chk = $newArray['c_hour_chk'];
                        $c_day = $newArray['c_day'];
                        $c_month = $newArray['c_month'];
                        $c_week = $newArray['c_week'];
                        $c_cmd = $newArray['c_cmd'];
                        $c_mail = $newArray['c_mail'];

			if($c_min_chk == 'Y' and $c_min != '*') $c_min = '* / ' . $c_min;
			if($c_hour_chk == 'Y' and $c_hour != '*') $c_hour = '* / ' . $c_hour;

                	if($c_week == "*") $S_MSG="*";
                	else if($c_week == '0') $S_MSG="Sun";
                	else if($c_week == '1') $S_MSG="Mon";
                	else if($c_week == '2') $S_MSG="Tus";
                	else if($c_week == '3') $S_MSG="Wed";
                	else if($c_week == '4') $S_MSG="Thu";
                	else if($c_week == '5') $S_MSG="Fri";
                	else if($c_week == '6') $S_MSG="Sat";

                        echo "<tr>";
                        echo "<td>{$c_num}</td><td>{$c_min}</td><td>{$c_hour}</td><td>{$c_day}</td><td>{$c_month}</td><td>{$S_MSG}</td><td>{$c_cmd}</td>";

                        echo "<td width=50><form action=./ansible_linux_morning_chk_cron.php>";
			//echo "<input type=hidden name=FLOW value={$FLOW}></input>";
                        echo "<center><button class='btn btn-warning btn-xs' type=submit name=MOD_NUM value={$c_num}><b><font size=2>수정</font></b></button></center></form></td>";

                        echo "<td width=50><form action=./ansible_linux_morning_chk_cron.php>";
			//echo "<input type=hidden name=FLOW value={$FLOW}></input>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=DEL_NUM value={$c_num}><b><font size=2>삭제</font></b></button></center></form></td>";

			if($c_mail == 'Y') $MSG5 = "YES";
			else $MSG5 = "NO";
			echo"<td align=center>$MSG5</td>";

                        echo "</tr>";   
                }
        }
	else {
		$ACT = "ADD";
	}

	echo "</table>"	;



                echo "</div>"; //col-lg-6

                echo "<div class='col-lg-1'>";
                echo "</div>"; //col-lg-1

                echo "<div class='col-lg-5'>";



// Cron 등록 수정 삭제 루틴 Start //

$FLOW = "Morning_Cheking_Playbook.yaml";
$ITEM = $_GET['ITEM'];

if ($ITEM and preg_match("/[^a-z|\d]/i", $ITEM)) {
        $FAULT = 'Y';
}

if ($FLOW and preg_match("/[^a-z.\d_-]/i", $FLOW)) {
        $FAULT = 'Y';
}

if ($ACT and preg_match("/[^A-Z]/", $ACT)) {
        $FAULT = 'Y';
}


if($FAULT != 'Y') {


    if($ACT == "ADD"){

	// 조근점검 경우 crontab 등록시 900번 부터 등록

	$cmd_sql = "select count(c_num) AS max_num from Ansible_linux_morning_chk_cron";
	//echo "# SQL : {$cmd_sql}";
	//echo "<br>";
	$res5 = mysqli_query($mysqli,$cmd_sql);
        $data = mysqli_fetch_array($res5);
        $CNT = $data["max_num"];

	if ($CNT >= 0) {

		if($CNT == 0) {
			$INDEX = 900;
		}
		else {
        		$INDEX = $CNT + 900;
		}

        	echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 등록 화면 </b></font>";
        	echo "<br>";
        	echo "<br>";
		echo "<form action=./ansible_linux_morning_chk_cron_add.php method=POST>";

        	echo "<table border=1>";
        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 번호 : </label>";
        	echo "</td>";
        	echo "<td width=350 colspan=2>";
        	echo "<input type='text' class='form-control' name=NUM value={$INDEX} readonly>";
        	echo "</td><td><input type=hidden name=FLOW value={$FLOW}></input></td></tr>";
        	echo "</td><td><input type=hidden name=ITEM value={$ITEM}></input></td></tr>";

        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ Minute : </label>";
        	echo "</td>";
        	echo "<td width=200>";
                echo "<select class='form-control' name=MIN>";
                echo "<option value='*'>*</option>";
                for($i=0;$i < 60; $i++) {
                        echo "<option value=$i>$i</option>";
                }
                echo "</select>";
		echo "</td>";
        	echo "<td align=center>";
                echo "<div class=checkbox><label><input type=checkbox name=EVERY_MIN_CHK value=Y>Every Minutes</label></div>";
		echo "</td>";
        	echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Hour : </label>";
                echo "</td>";
                echo "<td>";
                echo "<select class='form-control' name=HOUR>";
                echo "<option value='*'>*</option>";
                for($i=0;$i < 24; $i++) {
                        echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td align=center>";
                echo "<div class=checkbox><label><input type=checkbox name=EVERY_HOUR_CHK value=Y>Every Hours</label></div>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Day : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=DAY>";
                echo "<option value='*'>*</option>";
                for($i=1;$i < 32; $i++) {
                        echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Month : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=MONTH>";
                echo "<option value='*'>*</option>";
                for($i=1;$i <= 12; $i++) {
                        echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Week : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=WEEK>";
                echo "<option value='*'>*</option>";
                        echo "<option value=0>Sun</option>";
                        echo "<option value=1>Mon</option>";
                        echo "<option value=2>Tus</option>";
                        echo "<option value=3>Wed</option>";
                        echo "<option value=4>Thu</option>";
                        echo "<option value=5>Fri</option>";
                        echo "<option value=6>Sat</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ 메일 발송: </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=MAIL_SEND>";
                echo "<option value=Y>YES</option>";
                echo "<option value=N>NO</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ 등록할 Flow : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<input type='text' class='form-control' name=COMMAND value='{$FLOW}' readonly>";
                echo "</td>";
                echo "<td></td></tr>";


        	echo "</table>";

        	echo "<br>";
		echo "추가 하시겠습니까? &nbsp;&nbsp;&nbsp;";
        	echo "<button type=submit class='btn btn-success'>추가</button>";
        	echo "</form>";

        	echo "</div>";

        }


   }

   echo "</div>"; //col-lg-4
   echo "</div>";  //row


}
else {
        echo "<b><font color=red>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</font></b>";

}



                echo "</div>";  //row 
                echo "</div>";  //col-lg-12


                echo "</div>";  //panel-body
                echo "</div>";  //wrapper


echo "<div>";
echo "<div>";

?>



                            </div>
                          </div>




                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




