<?php
//include "css.php" ;
//include "sidemenu.php" ;
include "ip.inc" ;
include "Acase.php";

////// dec_enc Function Start //////

    $output = false;

    $encrypt_method = "AES-256-CBC";
    $action = "decrypt";
    $string = $MYSQL_PWD;
    $secret_key = $S_KEY;
    $secret_iv = $S_IV;

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

////// dec_enc Function End //////

$mysqli = new mysqli($MYSQL_HST,$MYSQL_USR,$output,$MYSQL_DBI);
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}


function dec_enc($action, $string, $secret_key, $secret_iv) {
    $output = false;

    $encrypt_method = "AES-256-CBC";

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}

$mysqli = new mysqli($MYSQL_HST,$MYSQL_USR,$output,$MYSQL_DBI);
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

/*****************************************************************
실행 : ansible_linux_morning_chk_CronExec.php Morning_Cheking_Playbook.yaml Y LINUX_900_LINE
LINUX_900_LINE : 900 확인
Ansible_linux_morning_chk_cron 테이블에서 c_num == 900 찾아 c_itemlist 확보
ITEM_LIST : CPU , MEM, DISK 등등 

그후에 각 ITEM 별로 전체 Linux 서버에 대해 실행하여 결과를 받음.
-> 출력 결과: 서버명|CPU_IDLE값
*****************************************************************/


	date_default_timezone_set("Asia/Seoul");
	$UTIME_F = explode('.',microtime(true));
	$T_UTIME = $UTIME_F[0];

	$CMD_TIMEOUT_SEC = 2;

	$MEMBERS = 'all';

	$T_ITEM = explode('_',$argv[3]);  # LINUX_900_LINE
	$ITEM_NUM = $T_ITEM[1];


if ($ITEM_NUM)
{

	// 1. CPU, Memory, Swap, Disk 임계치 정의
        $cpu_sql = "select item_warn_thres, item_crit_thres from Ansible_linux_morning_chk_Item where item_name = 'CPU' ";
        $cpu_res = mysqli_query($mysqli,$cpu_sql);
       	$cpu_data = mysqli_fetch_array($cpu_res);
	$CPU_WARN = $cpu_data['item_warn_thres'];
	$CPU_CRIT = $cpu_data['item_crit_thres'];

        $mem_sql = "select item_warn_thres, item_crit_thres from Ansible_linux_morning_chk_Item where item_name = 'Memory' ";
        $mem_res = mysqli_query($mysqli,$mem_sql);
       	$mem_data = mysqli_fetch_array($mem_res);
	$MEM_WARN = $mem_data['item_warn_thres'];
	$MEM_CRIT = $mem_data['item_crit_thres'];

        $swap_sql = "select item_warn_thres, item_crit_thres from Ansible_linux_morning_chk_Item where item_name = 'Swap' ";
        $swap_res = mysqli_query($mysqli,$swap_sql);
       	$swap_data = mysqli_fetch_array($swap_res);
	$SWAP_WARN = $swap_data['item_warn_thres'];
	$SWAP_CRIT = $swap_data['item_crit_thres'];

        $disk_sql = "select item_warn_thres, item_crit_thres from Ansible_linux_morning_chk_Item where item_name = 'Disk' ";
        $disk_res = mysqli_query($mysqli,$disk_sql);
       	$disk_data = mysqli_fetch_array($disk_res);
	$DISK_WARN = $disk_data['item_warn_thres'];
	$DISK_CRIT = $disk_data['item_crit_thres'];
	
	$PORT_WARN = 0;
	$PORT_CRIT = 0;

	$DAEMON_WARN = 0;
	$DAEMON_CRIT = 0;

	echo "* ITEM 임계치 * \n";
	echo "- CPU Warn : $CPU_WARN, CPU Crit : $CPU_CRIT \n";
	echo "- MEM Warn : $MEM_WARN, MEM Crit : $MEM_CRIT \n";
	echo "- SWAP Warn : $SWAP_WARN, SWAP Crit : $SWAP_CRIT \n";
	echo "- DISK Warn : $DISK_WARN, DISK Crit : $DISK_CRIT \n";
	echo "- PORT Warn : $PORT_WARN, PORT Crit : $PORT_CRIT \n";
	echo "- DAEMON Warn : $DAEMON_WARN, DAEMON Crit : $DAEMON_CRIT \n\n";


        $cnt = 0;
	$HOST_STR = '';
	$HOST_STR_T = '';
	$T_SKIP_HOST = '';

	// 모든 Linux 호스트 검색
        $cmd_sql1 = "select * from Ansible_linux_host";
        $res = mysqli_query($mysqli,$cmd_sql1);

       	while ($data = mysqli_fetch_array($res)) {
                $hostname = $data['hostname'];
                $nodename = $data['nodename'];
                $ip = $data['ip'];
		$port = $data['port'];
		$PING_CMD = "ping -c 1 -w 1 $ip | grep '64 bytes' | awk -F'=' '{print \$NF}' | awk '{print $1}'";
		$PING_CMD_MS = shell_exec("$PING_CMD");
		//echo "Ping CMD : $PING_CMD , Ping MS : $PING_CMD_MS\n";

		if ($PING_CMD_MS > 1 or $PING_CMD_MS == "") {
			$T_SKIP_HOST = $hostname  . '|' . $T_SKIP_HOST;
			continue;
		}
				
		// Linux RSA , ID/PWD
		if ($data['username'] and $data['password']) {
			$ID_PWD = 'Y';
			$username = $data['username'];
			$password = dec_enc('decrypt',$data['password'],$S_KEY,$S_IV);
			$HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_user=$username ansible_ssh_pass='$password' ansible_port=$port\n";
			$HOST_STR_T = $HOST_STR_T . "$nodename ansible_host=$ip ansible_user=$username ansible_ssh_pass=********* ansible_port=$port\n";
		}
		else {
			$HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_ssh_port=$port \n";
			$HOST_STR_T = $HOST_STR_T . "$nodename ansible_host=$ip ansible_ssh_port=$port \n";
		}

		$cnt = $cnt + 1;
        }


	if ($cnt < 10 ) $T_CMD_TIMEOUT = 60;	
	else $T_CMD_TIMEOUT = ($CMD_TIMEOUT_SEC * $cnt) + 60 ;


	// ITEM 별로 Loop 실행 & ITEM별 playbook 실행하여 결과 도출 //

	// 2. ITEM 별 Count 변수 정의
	$CPU_WARN_CNT = 0;
	$CPU_CRIT_CNT = 0;
	$MEM_WARN_CNT = 0;
	$MEM_CRIT_CNT = 0;
	$SWAP_WARN_CNT = 0;
	$SWAP_CRIT_CNT = 0;
	$DISK_WARN_CNT = 0;
	$DISK_CRIT_CNT = 0;
	$PORT_WARN_CNT = 0;
	$PORT_CRIT_CNT = 0;
	$DAEMON_WARN_CNT = 0;
	$DAEMON_CRIT_CNT = 0;


	// Mail 
	$RESULT_FILE_S = "$ANSIBLE_LOG_DIR/Mail_Result_S.txt" . $T_UTIME ;
	$fp_S = fopen($RESULT_FILE_S,'w');	
	$ALARM_MSG1 = '';

        $cmd_sql1 = "select c_itemlist from Ansible_linux_morning_chk_cron";
        $res = mysqli_query($mysqli,$cmd_sql1);
       	$data = mysqli_fetch_array($res); 
	$ITEM_LIST = $data['c_itemlist'];

        $T_ITEM = explode('|',$ITEM_LIST);
        foreach($T_ITEM as $EXE_ITEM) {

        	$cmd_sql1 = "select * from Ansible_linux_morning_chk_Item where item_name = '$EXE_ITEM' ";
        	$res5 = mysqli_query($mysqli,$cmd_sql1);
        	$data5 = mysqli_fetch_array($res5);
		$PLAYBOOK_NAME = $data5['item_playook'];
		$WARN_THRES = $data5['item_warn_thres'];
		$CRIT_THRES = $data5['item_crit_thres'];

                $RANDOM_NUM = mt_rand(1,1000);
                $UTIME_F = explode('.',microtime(true));
                $UTIME = $UTIME_F[0] . $UTIME_F[1] . $RANDOM_NUM ;

                $ANSIBLE_HOST_FILE = "$ANSIBLE_HOST_DIR/host5" . $UTIME ;
                $ANSIBLE_HOST_NICK_FILE = "$ANSIBLE_HOST_DIR/host5" ;

		$HOST_CREATE = shell_exec("echo  '$HOST_STR' > $ANSIBLE_HOST_FILE");
		$HOST_DISPLAY = shell_exec("cat $ANSIBLE_HOST_FILE");

        	$cmd_sql = "select * from Ansible_linux_playbook where p_name = '{$PLAYBOOK_NAME}'";
        	$res = mysqli_query($mysqli,$cmd_sql);
                $data = mysqli_fetch_array($res);
                $p_seq = $data['p_seq'];
		$p_seq = sprintf('%09d',$p_seq);
		$p_seq = 'PLY' . $p_seq;
                $p_content = base64_decode($data['p_content']);
		$STRING = $MEMBERS;

                $ANSIBLE_PLAYBOOK_FILE = "${ANSIBLE_EXEC_DIR}/$PLAYBOOK_NAME" . $UTIME ;
                $ANSIBLE_PLAYBOOK_FILE_DIS = "${ANSIBLE_EXEC_DIR}/$PLAYBOOK_NAME" . $UTIME . "DIS" ;

		$p_content = str_replace("$","UUaU",$p_content);
		$p_content = str_replace("'","UUbU",$p_content);

                $PB_CREATE = shell_exec("echo  '$p_content' > $ANSIBLE_PLAYBOOK_FILE");
                $PB_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");

		#$EXEC1 = "sed -i '/- hosts:/c $STRING' $ANSIBLE_PLAYBOOK_FILE";
		$EXEC1 = "sed -i \"s/- hosts: .*/- hosts: $STRING/\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC1");

		$EXEC2 = "sed -i \"s|UUaU|$|g\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC2");

		$EXEC3 = "sed -i \"s|UUbU|'|g\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC3");

                $EXEC3 = "sed -i \"s|UUcU|>|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");

		// Linux
                $EXEC3 = "sed -i \"s|UUdU|~|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");


		// add 2019.6.17
                $EXEC3 = "sed \"s|UUeU|\&lt;|g\" $ANSIBLE_PLAYBOOK_FILE > $ANSIBLE_PLAYBOOK_FILE_DIS";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");
                $EXEC3 = "sed -i \"s|UUeU|<|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");

		//$PLAYBOOK_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");
		//$PLAYBOOK_DISPLAY_DIS = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE_DIS");


		$RESULT = '';
		$EXTRACT_HOST = '';
		if ( $EXE_ITEM == 'Port' ) {

			$p_starttime = date("Y-m-d H:i:s");
                	$ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log.txt" . $UTIME ;
                	$ANSIBLE_SAVE_FILE = "$ANSIBLE_LOG_DIR/save.txt" . $UTIME ;
                	$t_sql = "select * from Ansible_linux_morning_chk_Item_Port_List ";
                	$t_res = mysqli_query($mysqli,$t_sql);
			$SQL_CNT = mysqli_num_rows($t_res);

			if ($SQL_CNT > 0) {
				$T_CNT = 0;
				while ($t_data = mysqli_fetch_array($t_res)) {
                			$c_hostname = $t_data['c_hostname'];
                			$C_PORT = $t_data['c_port'];

					$LIST_PORT = explode('|',$C_PORT);
					$T_SIZE = sizeof($LIST_PORT);
					if ($T_SIZE == 1 ) $c_port = ":" . $t_data['c_port'] . " ";
					else {
						$c_port = '';
						foreach($LIST_PORT as $SUB_PORT) {
                					$tmp_port = ":" . $SUB_PORT . " ";
							$c_port = $tmp_port . '|' . $c_port;
						}
						$c_port = trim($c_port,'|');
					}

                			$EXEC1 = "sed -i \"s/- hosts: .*/- hosts: $c_hostname/\" $ANSIBLE_PLAYBOOK_FILE";
                			$PLAYBOOK_CREATE = shell_exec("$EXEC1");

					$FULLSTR = "timeout $T_CMD_TIMEOUT ansible-playbook -e 'PORT5=\"{$c_port}\"' -i $ANSIBLE_HOST_FILE $ANSIBLE_PLAYBOOK_FILE";
					$CMD_LINE = shell_exec("$FULLSTR > $ANSIBLE_SAVE_FILE 2>&1");
					$SAVE_FILE = shell_exec("cat $ANSIBLE_SAVE_FILE >> $ANSIBLE_LOG_FILE");
	
					$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_SAVE_FILE");
					$C_PORT = str_replace("|","-",$C_PORT);
					$T_EXE_ITEM = $EXE_ITEM . ':' . $C_PORT;
					$RES1 = shell_exec("$ANSIBLE_PLAYBOOK_DIR/moring_chk_parser.sh $ANSIBLE_SAVE_FILE $T_EXE_ITEM 2>&1");
					if ($T_CNT == 0) $RESULT = $RES1;	
					else $RESULT = $RESULT . $RES1;
					$T_CNT = $T_CNT + 1;

				}

				$p_endtime = date("Y-m-d H:i:s");
				$SAVE_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
				$EXTRACT_HOST = shell_exec("$ANSIBLE_PLAYBOOK_DIR/extract_host2.sh $ANSIBLE_LOG_FILE");
			}

		}

		else if ( $EXE_ITEM == 'Daemon' ) {

			$p_starttime = date("Y-m-d H:i:s");
                	$ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log.txt" . $UTIME ;
                	$ANSIBLE_SAVE_FILE = "$ANSIBLE_LOG_DIR/save.txt" . $UTIME ;
                	$t_sql = "select * from Ansible_linux_morning_chk_Item_Daemon_List ";
                	$t_res = mysqli_query($mysqli,$t_sql);
			$SQL_CNT = mysqli_num_rows($t_res);

			if ($SQL_CNT > 0) {
				$T_CNT = 0;
				while ($t_data = mysqli_fetch_array($t_res)) {
                			$c_hostname = $t_data['c_hostname'];
                			$C_DAEMON = $t_data['c_daemon'];

                			$EXEC1 = "sed -i \"s/- hosts: .*/- hosts: $c_hostname/\" $ANSIBLE_PLAYBOOK_FILE";
                			$PLAYBOOK_CREATE = shell_exec("$EXEC1");

					$FULLSTR = "timeout $T_CMD_TIMEOUT ansible-playbook -e 'DAEMON5=\"{$C_DAEMON}\"' -i $ANSIBLE_HOST_FILE $ANSIBLE_PLAYBOOK_FILE";
					$CMD_LINE = shell_exec("$FULLSTR > $ANSIBLE_SAVE_FILE 2>&1");
					$SAVE_FILE = shell_exec("cat $ANSIBLE_SAVE_FILE >> $ANSIBLE_LOG_FILE");
	
					$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_SAVE_FILE");
					$C_DAEMON = str_replace("|","^",$C_DAEMON);
					$T_EXE_ITEM = $EXE_ITEM . ':' . $C_DAEMON;
					$RES1 = shell_exec("$ANSIBLE_PLAYBOOK_DIR/moring_chk_parser.sh $ANSIBLE_SAVE_FILE $T_EXE_ITEM 2>&1");
					if ($T_CNT == 0) $RESULT = $RES1;	
					else $RESULT = $RESULT . $RES1;
					$T_CNT = $T_CNT + 1;

				}

				$p_endtime = date("Y-m-d H:i:s");
				$SAVE_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
				$EXTRACT_HOST = shell_exec("$ANSIBLE_PLAYBOOK_DIR/extract_host2.sh $ANSIBLE_LOG_FILE");
			}

		}

		else {
			$FULLSTR = "timeout $T_CMD_TIMEOUT ansible-playbook -i $ANSIBLE_HOST_FILE $ANSIBLE_PLAYBOOK_FILE";
                	$ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log.txt" . $UTIME ;

			$p_starttime = date("Y-m-d H:i:s");
			$CMD_LINE = shell_exec("$FULLSTR > $ANSIBLE_LOG_FILE 2>&1");
			$p_endtime = date("Y-m-d H:i:s");
			$EXTRACT_HOST = shell_exec("$ANSIBLE_PLAYBOOK_DIR/extract_host.sh $ANSIBLE_LOG_FILE");

			$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
			$RESULT = shell_exec("$ANSIBLE_PLAYBOOK_DIR/moring_chk_parser.sh $ANSIBLE_LOG_FILE $EXE_ITEM 2>&1");

		}


                $SUCC_HOST_CNT  = 0;
                $FAIL_HOST_CNT  = 0;
                $SUCC_HOST_LIST = "";
                $FAIL_HOST_LIST = "";
                if($EXTRACT_HOST != "") {
                        $TEMP_HOST_LIST = explode(':',$EXTRACT_HOST);
                        $SUCC_HOST_CNT = $TEMP_HOST_LIST[0];
                        $FAIL_HOST_CNT = $TEMP_HOST_LIST[1];
                        $SUCC_HOST_LIST = str_replace("\n","",$TEMP_HOST_LIST[2]);
                        $SUCC_HOST_LIST = str_replace(" ","",$SUCC_HOST_LIST);
                        $FAIL_HOST_LIST = str_replace("\n","",$TEMP_HOST_LIST[3]);
                        $FAIL_HOST_LIST = str_replace(" ","",$FAIL_HOST_LIST);
                }

		$total_cnt = $SUCC_HOST_CNT + $FAIL_HOST_CNT;	


                if ($SUCC_HOST_CNT == 0 and $FAIL_HOST_CNT != 0) {
                        $SUCC = 'N';
                }
                else if ($SUCC_HOST_CNT == 0 and $FAIL_HOST_CNT == 0) {
                        $SUCC = 'N';
                }
                else if ($SUCC_HOST_CNT != 0 and $FAIL_HOST_CNT == 0) {
                        $SUCC = 'Y';
                }
                else {
                        $SUCC = 'PY'; //partial success
                }
	
		/***********************************************************************
		echo "\n4. Succ Host List : $SUCC_HOST_LIST \n";
		echo "5. Fail Host List : $FAIL_HOST_LIST \n";
		echo "6. Succ Host Count : $SUCC_HOST_CNT \n";
		echo "7. Fail Host Count : $FAIL_HOST_CNT \n";
		echo "8. Skip Host List : $T_SKIP_HOST \n";
		echo "9. RESULT : $SUCC \n\n";
		***********************************************************************/


		/**************************************************************************************
		// DEBUG
		echo "\n\n\n\n";
		echo "###### DEBUG ####\n";
		echo "0. utime : $T_UTIME , Start Time: $p_starttime  , End Time: $p_endtime \n";
		echo "1. $EXE_ITEM \n";
		echo "2. Total CNT: $total_cnt , Succ CNT: $SUCC_HOST_CNT , Fail CNT : $FAIL_HOST_CNT \n";
		echo "3. Succ Y/N : $SUCC \n";
		echo "4. Playbook : $PLAYBOOK_NAME \n";
		echo "5. Inventory \n";
		echo "$HOST_DISPLAY \n";
		echo "6. Playbook Command : {$FULLSTR} \n";
		echo "7. Log : \n";
		echo "$RESULT_DISPLAY \n";
		echo "8. Item execute Result \n";
		echo "$RESULT \n\n\n\n";
		****************************************************************************************/

		$T_LINE = preg_split("/\r\n|\n|\r/",$RESULT);
		foreach($T_LINE as $LINE) {

			if ($LINE) {
				
				if ($EXE_ITEM == "CPU") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('#',$S_LINE[2]);

					if ($R_LINE[0] + $R_LINE[1] >= $CPU_CRIT) {
						$CPU_RESULT = 'C';
						$CPU_CRIT_CNT = $CPU_CRIT_CNT + 1;
						$ALARM_MSG1 = "# $S_LINE[1] \n - CPU Critical : CPU Usage ($R_LINE[0] + $R_LINE[1]) > Threshold ($CPU_CRIT) \n"; 
						fputs($fp_S,$ALARM_MSG1);
					}
					elseif ($R_LINE[0] + $R_LINE[1] >= $CPU_WARN) {
						$CPU_RESULT = 'W';
						$CPU_WARN_CNT = $CPU_WARN_CNT + 1;
						$ALARM_MSG1 = "# $S_LINE[1] \n - CPU Warning : CPU Usage ($R_LINE[0] + $R_LINE[1]) > Threshold ($CPU_WARN) \n"; 
						fputs($fp_S,$ALARM_MSG1);
					}
					else {
						$CPU_RESULT = 'N';
					}

                			$insert_sql = "insert into Ansible_linux_morning_chk_Item_Result_CPU values ('$T_UTIME', '$p_starttime', '$p_endtime', '$S_LINE[1]', '$PLAYBOOK_NAME', '$R_LINE[0]','$R_LINE[1]', '$R_LINE[2]', '$R_LINE[3]', '$CPU_WARN','$CPU_CRIT', '$CPU_RESULT');";
                			$result55 = mysqli_query($mysqli,$insert_sql);

					/*****************************************************************************************
					# CPU|centos7-edu18|0.63#1.50#0.00#97.87 
					echo "- Line : $LINE \n";
					echo "-- ITEM : $S_LINE[0], HOSTNAME : $S_LINE[1], USER : $R_LINE[0], SYSTEM : $R_LINE[1], IOWAIT : $R_LINE[2], IDLE : $R_LINE[3] , RESULT : $CPU_RESULT \n\n";
					echo "-- SQL : $insert_sql \n";
					*****************************************************************************************/

				}

				elseif ($EXE_ITEM == "Memory") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('#',$S_LINE[2]);

					$P_USED = ($R_LINE[2]/$R_LINE[0])*100;
					if ($P_USED >= $MEM_CRIT) {
						$MEM_RESULT = 'C';
						$MEM_CRIT_CNT = $MEM_CRIT_CNT + 1;
						$ALARM_MSG1 = "# $S_LINE[1] \n - MEM Critical : MEM Usage ({$P_USED}%) > Threshold ($MEM_CRIT) \n"; 
						fputs($fp_S,$ALARM_MSG1);
					}
					elseif ($P_USED >= $MEM_WARN) {
						$MEM_RESULT = 'W';
						$MEM_WARN_CNT = $MEM_WARN_CNT + 1;
						$ALARM_MSG1 = "# $S_LINE[1] \n - MEM Warning : MEM Usage ({$P_USED}%) > Threshold ($MEM_WARN) \n"; 
						fputs($fp_S,$ALARM_MSG1);
					}
					else {
						$MEM_RESULT = 'N';
					}

                			$insert_sql = "insert into Ansible_linux_morning_chk_Item_Result_Memory values ('$T_UTIME', '$p_starttime', '$p_endtime', '$S_LINE[1]', '$PLAYBOOK_NAME', '$R_LINE[0]','$R_LINE[1]', '$R_LINE[2]', '$R_LINE[3]', '$MEM_WARN','$MEM_CRIT', '$MEM_RESULT');";
                			$result55 = mysqli_query($mysqli,$insert_sql);

					/*****************************************************************************************
					# Memory|centos7-edu18|8010216#408612#1026552#6575052
					echo "- Line : $LINE \n";
					echo "-- ITEM : $S_LINE[0], HOSTNAME : $S_LINE[1], TOTAL : $R_LINE[0], FREE : $R_LINE[1], USED : $R_LINE[2], BUFFER/CACHE : $R_LINE[3] , RESULT : $MEM_RESULT \n\n";
					echo "-- SQL : $insert_sql \n";
					echo "USED%: $P_USED , Result: $MEM_RESULT , WARN CNT : $MEM_WARN_CNT, CRIT CNT : $MEM_CRIT_CNT \n";
					*****************************************************************************************/

				}

				elseif ($EXE_ITEM == "Swap") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('#',$S_LINE[2]);

					// total 0 으로 나누기 방지
					if ($R_LINE[0] == 0) {
						$SWAP_RESULT = 'N';
					}
					else {
						$P_USED = ($R_LINE[2]/$R_LINE[0])*100;
						if ($P_USED >= $SWAP_CRIT) {
							$SWAP_RESULT = 'C';
							$SWAP_CRIT_CNT = $SWAP_CRIT_CNT + 1;
							$ALARM_MSG1 = "# $S_LINE[1] \n - SWAP Critical : SWAP Usage ({$P_USED}%) > Threshold ($SWAP_CRIT) \n"; 
							fputs($fp_S,$ALARM_MSG1);
						}
						elseif ($P_USED >= $SWAP_WARN) {
							$SWAP_RESULT = 'W';
							$SWAP_WARN_CNT = $SWAP_WARN_CNT + 1;
							$ALARM_MSG1 = "# $S_LINE[1] \n - SWAP Warning : SWAP Usage ({$P_USED}%) > Threshold ($SWAP_WARN) \n"; 
							fputs($fp_S,$ALARM_MSG1);
						}
						else {
							$SWAP_RESULT = 'N';
						}
					}

                			$insert_sql = "insert into Ansible_linux_morning_chk_Item_Result_Swap values ('$T_UTIME', '$p_starttime', '$p_endtime', '$S_LINE[1]', '$PLAYBOOK_NAME', '$R_LINE[0]','$R_LINE[1]', '$R_LINE[2]', '$SWAP_WARN','$SWAP_CRIT', '$SWAP_RESULT');";
                			$result55 = mysqli_query($mysqli,$insert_sql);

					/*****************************************************************************************
					# Memory|centos7-edu18|8010216#408612#1026552#6575052
					echo "- Line : $LINE \n";
					echo "-- ITEM : $S_LINE[0], HOSTNAME : $S_LINE[1], TOTAL : $R_LINE[0], FREE : $R_LINE[1], USED : $R_LINE[2], BUFFER/CACHE : $R_LINE[3] , RESULT : $SWAP_RESULT \n\n";
					echo "-- SQL : $insert_sql \n";
					echo "USED%: $P_USED , Result: $SWAP_RESULT , WARN CNT : $SWAP_WARN_CNT, CRIT CNT : $SWAP_CRIT_CNT \n";
					*****************************************************************************************/

				}

				elseif ($EXE_ITEM == "Disk") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',$S_LINE[2]);
					
					$T_DISK_RESULT = 'N';
        				foreach($R_LINE as $DISK_ITEM) {

						if ($DISK_ITEM) {

							$S_DISK_ITEM = explode('#',$DISK_ITEM);
							$P_USED = preg_replace("/%/","",$S_DISK_ITEM[4]);

							if ($P_USED >= $DISK_CRIT) {
								$DISK_RESULT = 'C';
								$ALARM_MSG1 = "# $S_LINE[1] \n - DISK Critical : $S_DISK_ITEM[5] DISK Usage ({$P_USED}%) > Threshold ($DISK_CRIT) \n"; 
								fputs($fp_S,$ALARM_MSG1);
							}
							elseif ($P_USED >= $DISK_WARN) {
								$DISK_RESULT = 'W';
								$ALARM_MSG1 = "# $S_LINE[1] \n - DISK Warning : $S_DISK_ITEM[5] DISK Usage ({$P_USED}%) > Threshold ($DISK_WARN) \n"; 
								fputs($fp_S,$ALARM_MSG1);
							}
							else {
								$DISK_RESULT = 'N';
							}

							$DISK_MOUNT_ON = substr($S_DISK_ITEM[5],0,40);

                					$insert_sql = "insert into Ansible_linux_morning_chk_Item_Result_Disk values ('$T_UTIME', '$p_starttime', '$p_endtime', '$S_LINE[1]', '$PLAYBOOK_NAME', '$S_DISK_ITEM[0]','$S_DISK_ITEM[1]', '$S_DISK_ITEM[2]', '$S_DISK_ITEM[3]', '$P_USED', '$DISK_MOUNT_ON','$DISK_WARN', '$DISK_CRIT', '$DISK_RESULT');";
                					$result55 = mysqli_query($mysqli,$insert_sql);

							/**************************************************************************
							# Disk|cent7-edu18|/dev/cl-root#36G#26G#9.2G#74%#/AaA/dev/sda1#1014M#173M#842M#18%#/bootAaA
							echo "- Line : $LINE \n";
							echo "-- ITEM : $S_LINE[0], HOSTNAME : $S_LINE[1], DEVICE : $S_DISK_ITEM[0], SIZE : $S_DISK_ITEM[1], USED : $S_DISK_ITEM[2], AVAIL : $S_DISK_ITEM[3] , USED% : $P_USED , MOUNT : $S_DISK_ITEM[5] , RESULT : $DISK_RESULT \n\n";
							echo "-- SQL : $insert_sql \n";
							**************************************************************************/
						}

						// 여러개의 디스크에 Warn, Crit 발생해도 HOST 건수는 제일 높은 알람으로 1개로 처리
						if ($DISK_RESULT == 'C' or $DISK_RESULT == 'W') {
							if ($T_DISK_RESULT == 'N' and $DISK_RESULT == 'W') {
								$T_DISK_RESULT = 'W';
								$DISK_WARN_CNT = $DISK_WARN_CNT + 1;
							}
							elseif ($T_DISK_RESULT == 'N' and $DISK_RESULT == 'C') {
								$T_DISK_RESULT = 'C';
								$DISK_CRIT_CNT = $DISK_CRIT_CNT + 1;
							}
							elseif ($T_DISK_RESULT == 'W' and $DISK_RESULT == 'C') {
								$T_DISK_RESULT = 'C';
								$DISK_CRIT_CNT = $DISK_CRIT_CNT + 1;
							}

						}


					}  // foreach($R_LINE as $DISK_ITEM) 

                        	}

				elseif ($EXE_ITEM == "Port") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],'AaA:'));

					$HOST_PORT = explode(':',$S_LINE[0]);
					$EXE_PORT = explode('-',$HOST_PORT[1]);
					$SIZE_PORT_LIST = sizeof($EXE_PORT);
					$HOSTNAME = $S_LINE[1];

					
					// REQ_PORT_LIST_ARR : 사용자가 요청한 Port list
                                        // PORT_LIST_ARR : 실행 결과 분석후 나온 Port list
					$REQ_PORT_LIST_ARR = array();
        				foreach($EXE_PORT as $T_SUB_PORT) {
						array_push($REQ_PORT_LIST_ARR, $T_SUB_PORT);
					}

					$PORT_LIST_ARR = array();
        				foreach($R_LINE as $PORT_ITEM) {
						if ($PORT_ITEM) {
							$S_PORT_ITEM = explode('#',$PORT_ITEM);
							$TT_SPLIT = explode(':',$S_PORT_ITEM[3]);
							array_push($PORT_LIST_ARR, $TT_SPLIT[1]);
						}
					}

					$CNT_PORT_LIST = sizeof($PORT_LIST_ARR);
					$DIFF = array_diff($REQ_PORT_LIST_ARR, $PORT_LIST_ARR);
					$CNT_DIFF = sizeof($DIFF);

					if ($CNT_PORT_LIST > 0 and $R_LINE[0] != '') {

        					foreach($R_LINE as $PORT_ITEM) {
							$S_PORT_ITEM = explode('#',$PORT_ITEM);
							$TT_SPLIT = explode(':',$S_PORT_ITEM[3]);
							$T1_PORT = end($TT_SPLIT);
							$PORT_RESULT = 'N';

                					$insert_sql = "insert into Ansible_linux_morning_chk_Item_Result_Port values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$S_PORT_ITEM[0]','$S_PORT_ITEM[1]', '$S_PORT_ITEM[2]', '$S_PORT_ITEM[3]', '$S_PORT_ITEM[4]', '$S_PORT_ITEM[5]','$S_PORT_ITEM[6]','$T1_PORT','$PORT_WARN', '$PORT_CRIT', '$PORT_RESULT');";
               						$result55 = mysqli_query($mysqli,$insert_sql);
						}

						

					}

					if ($CNT_DIFF > 0) {
						// 여러개의 포트에 Crit 발생해도 HOST 건수는 제일 높은 알람으로 1개로 처리
						$PORT_RESULT = 'C';
						$PORT_CRIT_CNT = $PORT_CRIT_CNT + 1;

						for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
							$CRIT_PORT = array_pop($DIFF);
                					$insert_sql = "insert into Ansible_linux_morning_chk_Item_Result_Port values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '','', '', '', '', '','','$CRIT_PORT','$PORT_WARN', '$PORT_CRIT', '$PORT_RESULT');";
               						$result55 = mysqli_query($mysqli,$insert_sql);

							$ALARM_MSG1 = "# $HOSTNAME \n - PORT Critical : $CRIT_PORT NOT Found!! \n"; 
							fputs($fp_S,$ALARM_MSG1);
						}

					}



                        	} // elseif ($EXE_ITEM == "Port") 

				elseif ($EXE_ITEM == "Daemon") {

        				$S_LINE = explode('|',$LINE);
					$R_LINE = explode('AaA',trim($S_LINE[2],'AaA:'));

					$HOST_DAEMON = explode(':',$S_LINE[0]);
					$EXE_DAEMON = explode('^',$HOST_DAEMON[1]);
					$SIZE_DAEMON_LIST = sizeof($EXE_DAEMON);
					$HOSTNAME = $S_LINE[1];

					
					// REQ_DAEMON_LIST_ARR : 사용자가 요청한 Damon list
                                        // DAEMON_LIST_ARR : 실행 결과 분석후 나온 Daemon list
					$REQ_DAEMON_LIST_ARR = array();
        				foreach($EXE_DAEMON as $T_SUB_DAEMON) {
						array_push($REQ_DAEMON_LIST_ARR, $T_SUB_DAEMON);
					}

					$DAEMON_LIST_ARR = array();
        				foreach($R_LINE as $DAEMON_ITEM) {
						if ($DAEMON_ITEM) {
							$S_DAEMON_ITEM = explode('#',$DAEMON_ITEM);
							array_push($DAEMON_LIST_ARR, $S_DAEMON_ITEM[5]);
						}
					}

					$CNT_DAEMON_LIST = sizeof($DAEMON_LIST_ARR);
					$DIFF = array_diff($REQ_DAEMON_LIST_ARR, $DAEMON_LIST_ARR);
					$CNT_DIFF = sizeof($DIFF);

					if ($CNT_DAEMON_LIST > 0 and $R_LINE[0] != '') {

        					foreach($R_LINE as $DAEMON_ITEM) {
							$S_DAEMON_ITEM = explode('#',$DAEMON_ITEM);
							$DAEMON_RESULT = 'N';

                					$insert_sql = "insert into Ansible_linux_morning_chk_Item_Result_Daemon values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '$S_DAEMON_ITEM[0]','$S_DAEMON_ITEM[1]', '$S_DAEMON_ITEM[2]', '$S_DAEMON_ITEM[3]', '$S_DAEMON_ITEM[4]', '$S_DAEMON_ITEM[5]','$DAEMON_WARN', '$DAEMON_CRIT', '$DAEMON_RESULT');";
               						$result55 = mysqli_query($mysqli,$insert_sql);

						}

						

					}

					if ($CNT_DIFF > 0) {
						// 여러개의 데몬에 Crit 발생해도 HOST 건수는 제일 높은 알람으로 1개로 처리
						$DAEMON_RESULT = 'C';
						$DAEMON_CRIT_CNT = $DAEMON_CRIT_CNT + 1;

						for ($T3_CNT=0; $T3_CNT < $CNT_DIFF; $T3_CNT++) {
							$CRIT_DAEMON = array_pop($DIFF);
                					$insert_sql = "insert into Ansible_linux_morning_chk_Item_Result_Daemon values ('$T_UTIME', '$p_starttime', '$p_endtime', '$HOSTNAME', '$PLAYBOOK_NAME', '','', '', '', '', '$CRIT_DAEMON','$DAEMON_WARN', '$DAEMON_CRIT', '$DAEMON_RESULT');";
               						$result55 = mysqli_query($mysqli,$insert_sql);

							$ALARM_MSG1 = "# $HOSTNAME \n - DAEMON Critical : $CRIT_DAEMON NOT Found!! \n"; 
							fputs($fp_S,$ALARM_MSG1);
						}

					}



                        	} // elseif ($EXE_ITEM == "Daemon") 

				echo "* Processing : $EXE_ITEM , $S_LINE[1] \n";

			} // if ($LINE) {

		} // foreach($T_LINE as $LINE) {

		/*************************************************************************************************************
		  . 출력결과 : 
		    . 항목|서버명|결과값
		    . 항목 : CPU, Memory, Disk
		    . 결과값: 인자간에는 '#' 구분하고 , 다른 라인으로 넘어가면 'AaA'로 구분하여 1개 라인 출력
		    . ex) Disk|centos7-edu18|/dev/mapper/cl-root#36G#26G#9.3G#74%#/AaA/dev/sda1#1014M#173M#842M#18%#/bootAaA
		*************************************************************************************************************/


		if ($EXE_ITEM == "CPU") {
			$WARN_CNT = $CPU_WARN_CNT;
			$CRIT_CNT = $CPU_CRIT_CNT;
		}
		elseif ($EXE_ITEM == "Memory") {
			$WARN_CNT = $MEM_WARN_CNT;
			$CRIT_CNT = $MEM_CRIT_CNT;
		}
		elseif ($EXE_ITEM == "Swap") {
			$WARN_CNT = $SWAP_WARN_CNT;
			$CRIT_CNT = $SWAP_CRIT_CNT;
		}
		elseif ($EXE_ITEM == "Disk") {
			$WARN_CNT = $DISK_WARN_CNT;
			$CRIT_CNT = $DISK_CRIT_CNT;
		}
		elseif ($EXE_ITEM == "Port") {
			$WARN_CNT = 0;
			$CRIT_CNT = $PORT_CRIT_CNT;
		}

               	$insert_sql = "insert into Ansible_linux_morning_chk_Item_Result values ('$T_UTIME', '$p_starttime', '$p_endtime', '$EXE_ITEM', '$SUCC', '$total_cnt','$SUCC_HOST_CNT', '$FAIL_HOST_CNT', '$WARN_CNT', '$CRIT_CNT', '$FAIL_HOST_LIST');";

		//echo "99. RESULT SQL : $insert_sql \n\n";
               	$res55 = mysqli_query($mysqli,$insert_sql);


        } /* foreach($T_ITEM as $EXE_ITEM) */

        // mail sending
        if($ALARM_MSG1) {

                $MAIL_LIST = '';
                $cmd_sql5 = "select mail_id from Mail_list where mail_send = 'Y'";
                $res5 = mysqli_query($mysqli,$cmd_sql5);
                if ($res5) {
                        while ($newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                                $mail_id = $newArray5['mail_id'];
                                $MAIL_LIST = $MAIL_LIST . ' ' . $mail_id;
                        }
                }

		$MAIL_LIST = "oh.yunwoo1@gmail.com";

                $SUBJECT = "Ansible Moring Checking - Problem Happened!!";
                $MAIL_STR = "mail -s '$SUBJECT' $MAIL_LIST < $RESULT_FILE_S";
                #echo "$MAIL_STR \n";
                $MAIL_SENDING = shell_exec("$MAIL_STR");
        }

	fclose($fp_S);

        $DELETE1 = shell_exec("rm -f $ANSIBLE_EXEC_DIR/Linux_Morning_Check_*");
        $DELETE2 = shell_exec("rm -f $ANSIBLE_HOST_DIR/host51*");
        $DELETE2 = shell_exec("rm -f $ANSIBLE_LOG_DIR/log.txt1*");		



} /* if ($ITEM_NUM) */
else {

       	if ($PLAYBOOK_NAME == '') {
		echo "<br><font color=red>ㅇ Playbook 항목이 비어 있습니다. 확인 바랍니다!! </font><br>";
	}
       	else if ($MEMBERS == '') {
		echo "<br><font color=red>ㅇ Inventory 항목이 비어 있습니다. 확인 바랍니다!! </font><br>";
	}
       	else if ($FAULT == 'Y') {
		echo "<br><font color=red>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</font><br><br><br>";
	}

}



?> 
