<?php
include "session_chk.inc" ;
?> 

<!DOCTYPE html>
<html lang="en">

<head>

<?php
include "css.php" ;
?>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>


            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php

                        echo "<table>";
                        echo "<tr><td width=450><font size=6>Linux 조근 점검 상세보기</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>


		</div>
		<!-- /.panel-heading -->




<?php


$MC_NUM = $_GET['SEQ'];

if ($SEQ and preg_match("/[^\d]/", $SEQ)) {
        $FAULT = 'Y';
}



if ($FAULT != 'Y') {

        echo "

                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
	";

        echo "<tr><td width=220><font size=3><b>&nbsp;Linux 조근점검 Summary</b></font></td></tr>";

	echo "
                               </table>

                              </div>
                            </div>
                            <div class='col-lg-7'>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>

                                <div class='table-responsive'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>조근점검번호</th>
                                        <th>실행ITEM</th>
                                        <th>실행서버수</th>
                                        <th>실행실패서버수</th>
                                        <th>WARN 서버수</th>
                                        <th>CRIT 서버수</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>

	";


        $cmd_sql = "select * from Ansible_linux_morning_chk_Item_Result where mc_seq = $MC_NUM ";
        //echo "# SQL : {$cmd_sql}";

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $mc_seq = $newArray['mc_seq'];
                        $mc_item= $newArray['mc_item'];
                        $mc_total_cnt= $newArray['mc_total_cnt'];
                        $mc_warn_cnt = $newArray['mc_warn_cnt'];
                        $mc_crit_cnt = $newArray['mc_crit_cnt'];
                        $mc_fail_cnt = $newArray['mc_fail_cnt'];

			if ($mc_fail_cnt > 0 ) {
                        	$mc_fail_host = $newArray['mc_fail_host'];
				$FAIL_HOST_LIST = "($mc_fail_host)";
			}

                        if ($mc_warn_cnt > 0) $WARN_MSG = "<b><font size=3 color=blue>$mc_warn_cnt</font></b>";
                        else $WARN_MSG = "{$mc_warn_cnt}";

                        if ($mc_crit_cnt > 0) $CRIT_MSG = "<b><font size=3 color=red>$mc_crit_cnt</font></b>";
                        else $CRIT_MSG = "{$mc_crit_cnt}";

                        echo "<tr><td>{$mc_seq}</td><td>{$mc_item}</td>";
                        echo "<td>{$mc_total_cnt}</td><td>{$mc_fail_cnt}&nbsp;$FAIL_HOST_LIST</td>";
                        echo "<td>{$WARN_MSG}</td>";
                        echo "<td>{$CRIT_MSG}</td>";
                        echo "<td></td></tr>";

                }
        }


	echo "
                                </tbody>
                                </table>
			        </div>
			      </div>
			      </div>

			      </div>
			      </div>



                            </div>




                          <div class='row'>
        <div class='col-lg-3'>
        <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
        <table>
        <tr><td width=220><font size=3><b>&nbsp;Linux 조근점검 상세 내역</b></font></td></tr>
        </table>
	</div>
	</div>

                            <div class='col-lg-12'>



                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>

                                <div class='table-responsive'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>점검시작시간</th>
                                        <th>호스트명</th>
                                        <th>점검항목</th>
                                        <th>임계치</th>
                                        <th>점검결과</th>
                                        <th>점검상세</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>

	";



	// CPU

        $cmd_sql = "select * from Ansible_linux_morning_chk_Item_Result_CPU where c_seq = $MC_NUM ";
        //echo "# SQL : {$cmd_sql}";

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_user= $newArray['c_user'];
                        $c_system = $newArray['c_system'];
                        $c_iowait = $newArray['c_iowait'];
                        $c_idle = $newArray['c_idle'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'C') {
				$T_RESULT = "<font size=2 color=red><b>{$c_result}</b></font>";
				$CONTENT1 = "<font color=red>$c_idle</font>";
			}
			else {
				$T_RESULT = "<font size=2 color=black>{$c_result}</font>";
				$CONTENT1 = "<font color=black>$c_idle</font>";
			}

			$MSG1 = "
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>CPU User</th><th>CPU System</th><th>CPU IOwait</th><th>CPU Idle</th></tr>
			<tr><td>$c_user</td><td>$c_system</td><td>$c_iowait</td><td>$CONTENT1</td></tr>
			</table>";
		
                        echo "<tr><td>{$c_starttime}</td><td>{$c_hostname}</td><td>CPU</td>";
                        echo "<td>WARN:&nbsp;<font color=blue>$c_WARN</font>, CRIT:&nbsp;<font color=red>$c_CRIT</font></td><td>$T_RESULT</td>";
                        echo "<td>$MSG1</td>";
                        echo "<td></td></tr>";

                }
        }


	// Memory

        $cmd_sql = "select * from Ansible_linux_morning_chk_Item_Result_Memory where c_seq = $MC_NUM ";
        //echo "# SQL : {$cmd_sql}";

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_total= $newArray['c_total'];
                        $c_free = $newArray['c_free'];
                        $c_used = $newArray['c_used'];
                        $c_buffcache = $newArray['c_buffcache'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'C') {
				$T_RESULT = "<font size=2 color=red><b>{$c_result}</b></font>";
				$CONTENT1 = "<font color=red>$c_used</font>";
			}
			else {
				$T_RESULT = "<font size=2 color=black>{$c_result}</font>";
				$CONTENT1 = "<font color=black>$c_used</font>";
			}

			$MSG1 = "
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>MEM Total (K)</th><th>MEM Free (K)</th><th>MEM Used (K)</th><th>MEM Buffer/Cache (K)</th></tr>
			<tr><td>$c_total</td><td>$c_free</td><td>$CONTENT1</td><td>$c_buffcache</td></tr>
			</table>";
		
                        echo "<tr><td>{$c_starttime}</td><td>{$c_hostname}</td><td>Memory</td>";
                        echo "<td>WARN:&nbsp;<font color=blue>$c_WARN</font>, CRIT:&nbsp;<font color=red>$c_CRIT</font></td><td>$T_RESULT</td>";
                        echo "<td>$MSG1</td>";
                        echo "<td></td></tr>";

                }
        }


	// Swap

        $cmd_sql = "select * from Ansible_linux_morning_chk_Item_Result_Swap where c_seq = $MC_NUM ";
        //echo "# SQL : {$cmd_sql}";

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_total= $newArray['c_total'];
                        $c_free = $newArray['c_free'];
                        $c_used = $newArray['c_used'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'C') {
				$T_RESULT = "<font size=2 color=red><b>{$c_result}</b></font>";
				$CONTENT1 = "<font color=red>$c_used</font>";
			}
			else {
				$T_RESULT = "<font size=2 color=black>{$c_result}</font>";
				$CONTENT1 = "<font color=black>$c_used</font>";
			}

			$MSG1 = "
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>Swap Total (K)</th><th>Swap Free (K)</th><th>Swap Used (K)</th></tr>
			<tr><td>$c_total</td><td>$c_free</td><td>$CONTENT1</td></tr>
			</table>";
		
                        echo "<tr><td>{$c_starttime}</td><td>{$c_hostname}</td><td>Swap</td>";
                        echo "<td>WARN:&nbsp;<font color=blue>$c_WARN</font>, CRIT:&nbsp;<font color=red>$c_CRIT</font></td><td>$T_RESULT</td>";
                        echo "<td>$MSG1</td>";
                        echo "<td></td></tr>";

                }
        }

	// Disk

        $cmd_sql = "select * from Ansible_linux_morning_chk_Item_Result_Disk where c_seq = $MC_NUM ";
        //echo "# SQL : {$cmd_sql}";

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_device= $newArray['c_device'];
                        $c_size = $newArray['c_size'];
                        $c_used = $newArray['c_used'];
                        $c_avail = $newArray['c_avail'];
                        $c_p_used = $newArray['c_p_used'];
                        $c_mount = $newArray['c_mount'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'C') {
				$T_RESULT = "<font size=2 color=red><b>{$c_result}</b></font>";
				$CONTENT1 = "<font color=red>$c_p_used</font>";
			}
			else {
				$T_RESULT = "<font size=2 color=black>{$c_result}</font>";
				$CONTENT1 = "<font color=black>$c_p_used</font>";
			}

			$MSG1 = "
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>Filesystem</th><th>Size</th><th>Used</th><th>Avail</th><th>Use%</th><th>Mounted on</th></tr>
			<tr><td>$c_device</td><td>$c_size</td><td>$c_used</td><td>$c_avail</td><td>$CONTENT1</td><td><font color=black><b>$c_mount</b></font></td></tr>
			</table>";
		
                        echo "<tr><td>{$c_starttime}</td><td>{$c_hostname}</td><td>Disk</td>";
                        echo "<td>WARN:&nbsp;<font color=blue>$c_WARN</font>, CRIT:&nbsp;<font color=red>$c_CRIT</font></td><td>$T_RESULT</td>";
                        echo "<td>$MSG1</td>";
                        echo "<td></td></tr>";

                }
        }


	// Port

        $cmd_sql = "select * from Ansible_linux_morning_chk_Item_Result_Port where c_seq = $MC_NUM ";
        //echo "# SQL : {$cmd_sql}";

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_proto= $newArray['c_proto'];
                        $c_recv_q = $newArray['c_recv_q'];
                        $c_send_q = $newArray['c_send_q'];
                        $c_local_addr = $newArray['c_local_addr'];
                        $c_foreign_addr = $newArray['c_foreign_addr'];
                        $c_state = $newArray['c_state'];
                        $c_pid = $newArray['c_pid'];
                        $c_port = $newArray['c_port'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'C') {
				$T_RESULT = "<font size=2 color=red><b>{$c_result}</b></font>";
				$CONTENT1 = "<tr><td colspan=7><center><font color=red><b>$c_port port </b></font>not Found!!</center></td></tr>";
			}
			else {
				$T_RESULT = "<font size=2 color=black>{$c_result}</font>";
				$CONTENT1 = "<tr><td>$c_proto</td><td>$c_recv_q</td><td>$c_send_q</td><td>$c_local_addr</td><td>$c_foreign_addr</td><td>$c_state</td><td>$c_pid</td></tr>";
			}

			$MSG1 = "
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>Proto</th><th>Recv-Q</th><th>Send-Q</th><th>Local Address</th><th>Foreign Address</th><th>State</th><th>PID/Program name</th></tr>
			$CONTENT1
			</table>";
		
                        echo "<tr><td>{$c_starttime}</td><td>{$c_hostname}</td><td>Port</td>";
                        echo "<td>WARN:&nbsp;<font color=blue>$c_WARN</font>, CRIT:&nbsp;<font color=red>$c_CRIT</font></td><td>$T_RESULT</td>";
                        echo "<td>$MSG1</td>";
                        echo "<td></td></tr>";

                }
        }


	// Daemon

        $cmd_sql = "select * from Ansible_linux_morning_chk_Item_Result_Daemon where c_seq = $MC_NUM ";
        //echo "# SQL : {$cmd_sql}";

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_starttime = $newArray['c_starttime'];
                        $c_hostname= $newArray['c_hostname'];
                        $c_uid= $newArray['c_uid'];
                        $c_pid = $newArray['c_pid'];
                        $c_ppid = $newArray['c_ppid'];
                        $c_stime = $newArray['c_stime'];
                        $c_time = $newArray['c_time'];
                        $c_cmd = $newArray['c_cmd'];
                        $c_WARN = $newArray['c_WARN'];
                        $c_CRIT = $newArray['c_CRIT'];
                        $c_result = $newArray['c_result'];

			if ($c_result == 'C') {
				$T_RESULT = "<font size=2 color=red><b>{$c_result}</b></font>";
				$CONTENT1 = "<tr><td colspan=6><center><font color=red><b>$c_cmd Daemon </b></font>not Found!!</center></td></tr>";
			}
			else {
				$T_RESULT = "<font size=2 color=black>{$c_result}</font>";
				$CONTENT1 = "<tr><td>$c_uid</td><td>$c_pid</td><td>$c_ppid</td><td>$c_stime</td><td>$c_time</td><td>$c_cmd</td></tr>";
			}

			$MSG1 = "
			<table width='100%' class='table table-striped table-bordered table-hover'>
			<tr><th>UID</th><th>PID</th><th>PPID</th><th>STIME</th><th>TIME</th><th>CMD</th></tr>
			$CONTENT1
			</table>";
		
                        echo "<tr><td>{$c_starttime}</td><td>{$c_hostname}</td><td>Port</td>";
                        echo "<td>WARN:&nbsp;<font color=blue>$c_WARN</font>, CRIT:&nbsp;<font color=red>$c_CRIT</font></td><td>$T_RESULT</td>";
                        echo "<td>$MSG1</td>";
                        echo "<td></td></tr>";

                }
        }

        echo "
                                </tbody>
                                </table>
                                </div>
                              </div>
                              </div>

                                 </div>
                            </div>
                          </div>

                        </div>
                        </div>
                        <!-- /.panel-body -->


	";

}
else {
	echo "<font size=4 color=red>잘못된 값을 입력했습니다. 확인 바랍니다.!!<b></b></font>";
}



?>






                            </div>
                          </div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
