<?php
include "session_chk.inc" ;

$SYNC = $_GET['SYNC'];

if ($SYNC and preg_match("/[^\d]/", $SYNC)) {
        $FAULT = 'Y';
}

if (!$SYNC) {
	$FULLURL = "./ansible_window_playbookflow_cron.php";
	#echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {
        
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

        	if ($FAULT == 'Y') {
			$FULLURL = "./ansible_window_playbookflow_cron.php?modify=3";
                	#echo "# URL : {$FULLURL}";
                	header('Location: '.$FULLURL);
                	break;
        	}

		$FULLURL = "./ansible_window_playbookflow_cron.php";
                $EXEC_STR1 = "(crontab -l 2>/dev/null | sed '/WIN_/d') | crontab -";
                $RESULT = shell_exec("$EXEC_STR1");

        	$cmd_sql = "select * from Ansible_window_playbookflow_cron" ;
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        	$c_num = $newArray['c_num'];
                        	$c_min = $newArray['c_min'];
                        	$c_min_chk = $newArray['c_min_chk'];
                        	$c_hour = $newArray['c_hour'];
                        	$c_hour_chk = $newArray['c_hour_chk'];
                        	$c_day = $newArray['c_day'];
                        	$c_month = $newArray['c_month'];
                        	$c_week = $newArray['c_week'];
                        	$c_cmd = $newArray['c_cmd'];
                        	$c_mail = $newArray['c_mail'];

                        	if($c_min_chk == 'Y' and $c_min != '*') $c_min = '*/' . $c_min;
                        	if($c_hour_chk == 'Y' and $c_hour != '*') $c_hour = '*/' . $c_hour;

				$CRON_EXEC_STR1 = "/var/www/html/S2S/pages/ansible_window_playbookflow_CronExec.php $c_cmd $c_mail WIN_{$c_num}_LINE";
				$CRON_STR1 = $c_num . " " . $c_hour . " " . $c_day . " " . $c_month . " " . $c_week . " " . "php $CRON_EXEC_STR1 ";
				$EXEC_STR1 = "(crontab -l 2>/dev/null; echo \"$CRON_STR1\") | crontab -";
                		$RESULT = shell_exec("$EXEC_STR1");
			}
		}

		header('Location: '.$FULLURL);
		mysqli_free_result($res);
		mysqli_close($mysqli); 

	}
}

?> 
