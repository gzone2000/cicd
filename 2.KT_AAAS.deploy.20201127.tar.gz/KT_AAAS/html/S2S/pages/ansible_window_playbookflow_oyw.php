<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
$(function() {
$("[id^=button_playbook]").on('click', function(event){ 
    var id = $(this).attr("id"); 
    var Step = document.getElementById(id).value;
    var String = "./ansible_window_playbookflow_Plist.php?STEP=" + Step;
    $("#list1").load(String);
});
});
</script>

<script>
$(function() {
$("[id^=button_inventory]").on('click', function(event){
    var id = $(this).attr("id");
    var P_name = document.getElementById(id).value;
    var String = "./ansible_window_playbookflow_Ilist.php?PLAYBOOK=" + P_name;
    $("#list1").load(String);
});
});
</script>

<script>
function myFunctionCRUD() {
    var String = "./ansible_window_playbookflow_Create_oyw.php";
    location.replace(String);
    //$("#P_mod").load(String);
}
</script>

<script>
function FlowCOPY(f_name,action) {
    var url1 = './ansible_window_playbookflow_copy_oyw.php';
    var form = document.createElement("form");
    form.setAttribute("method","post");
    form.setAttribute("action",url1);
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type","hidden");
    hiddenField.setAttribute("name","F_NAME");
    hiddenField.setAttribute("value",f_name);
    form.appendChild(hiddenField);

    var hiddenField1 = document.createElement("input");
    hiddenField1.setAttribute("type","hidden");
    hiddenField1.setAttribute("name","ACT");
    hiddenField1.setAttribute("value",action);
    form.appendChild(hiddenField1);

    document.body.appendChild(form);
    form.submit();
}
</script>

<script>
function FlowMOD(f_name,action) {
    var url1 = './ansible_window_playbookflow_mod_oyw.php';
    var form = document.createElement("form");
    form.setAttribute("method","post");
    form.setAttribute("action",url1);
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type","hidden");
    hiddenField.setAttribute("name","F_NAME");
    hiddenField.setAttribute("value",f_name);
    form.appendChild(hiddenField);

    var hiddenField1 = document.createElement("input");
    hiddenField1.setAttribute("type","hidden");
    hiddenField1.setAttribute("name","ACT");
    hiddenField1.setAttribute("value",action);
    form.appendChild(hiddenField1);

    document.body.appendChild(form);
    form.submit();
}
</script>

<script>
function FlowEXEC(f_name,action) {
    var url1 = './ansible_window_playbookflow_exec_oyw.php';
    var form = document.createElement("form");
    form.setAttribute("method","post");
    form.setAttribute("action",url1);
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type","hidden");
    hiddenField.setAttribute("name","F_NAME");
    hiddenField.setAttribute("value",f_name);
    form.appendChild(hiddenField);

    var hiddenField1 = document.createElement("input");
    hiddenField1.setAttribute("type","hidden");
    hiddenField1.setAttribute("name","ACT");
    hiddenField1.setAttribute("value",action);
    form.appendChild(hiddenField1);

    document.body.appendChild(form);
    form.submit();
}
</script>

<script>
function FlowDEL(f_name,action) {
    var newWindow;
    var url = "./ansible_window_playbookflow_del_popup.php?F_NAME=" + f_name;
    newWindow = window.open(url, "Flow Delete", "width=1200,height=350,left=100,top=60");
}
</script>

<script>
function sendMeDataDel(data) {

    var res1 = data.split('|');
    var F_name = res1[0];
    var Del_Go = res1[1];

    if (Del_Go == 'YES') {
    	var url1 = './ansible_window_playbookflow_del_oyw.php';
    	var form = document.createElement("form");

    	form.setAttribute("method","post");
    	form.setAttribute("action",url1);

    	var hiddenField = document.createElement("input");
    	hiddenField.setAttribute("type","hidden");
    	hiddenField.setAttribute("name","F_NAME");
    	hiddenField.setAttribute("value",F_name);
    	form.appendChild(hiddenField);

    	document.body.appendChild(form);
    	form.submit();
    }

}
</script>

<script>
function flowchk_CR() {

    var msg;
    var p_arg = document.getElementById('button_flowchk_CR').value;
    if (p_arg == '0') {

<?php
	$T_MAX = $FLOW_MAX;
	for($x=1; $x <= $T_MAX ; $x++) {
		echo "document.getElementById('button_playbook{$x}').disabled = true;";
		echo "document.getElementById('button_inventory{$x}').disabled = true;";
	}

?>

    	var String = "./ansible_window_playbookflow_saveSUB.php";
    	$("#txt5").load(String);
    }
    else {
	if (p_arg == 'NO') msg = "먼저 Flow 항목을 채워 주시기 바랍니다!!";
        else msg = p_arg + "단계 Flow Inventory항목이 비어 있습니다. 확인 바랍니다!!";

	alert(msg);
    }

}
</script>

<script>
function popitup1(f_name) {
    var url = "./ansible_window_playbookflow_content_popup_oyw.php?F_NAME=" + f_name;
    window.open(url,"Flow Show","width=1200,height=700,left=100,top=60");
}
</script>



</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

if($_SESSION[auth_level] != '0') {
        echo "<center><font color=red size=5><b>접근권한이 없습니다. 확인해 보시기 바랍니다!!</b></font></center>";
        exit(0);
}

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Flow > Window > Flow 생성, 수정, 삭제</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
		echo "<table>";
		echo "<tr><td width=550><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Window Flow을 만들어 여러개의 Playbook을 순차대로 실행 및 자동화</font></td>";
		echo "</tr>";
		echo "</table>";
?>

		</div>
		<!-- /.panel-heading -->








<?php

if(!$_GET['add'] and !$_GET['del'] and !$_GET['mod']){

        echo "

                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
	";

	// 버튼 갯수 늘어 나면 T_MAX 수정 필요 
	$T_MAX = $FLOW_MAX;
	$FLOW = $_GET['FLOW'];
	if($FLOW) {
		echo "<tr><td style='height:33px'><font size=3>Flow 수정하기:&nbsp;'$FLOW'</font></td></tr>";
	}
	else {
               echo "<tr><td width=190><font size=3><b>&nbsp;Flow 만들기</b></font></td>";
	       echo "<td><button id=button1 name=btn1 class='btn btn-primary' onclick='myFunctionCRUD()'><b>만들기</b></button></td></tr>";

	}

	echo "
                               </table>

                              </div>
                            </div>
                            <div class='col-lg-7'>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>
				<div id='txt1'>



			      </div>

                            </div>
			  </div>


                        <div class='panel-body'>

                          <div class='row'>
                            <div class='col-lg-12'>

                                  <div id='txt5'>
	";



        echo "

<br>
<br>
<br>
<br>
<br>
                                 </div>
                            </div>
                          </div>



                        </div>
                        <!-- /.panel-body -->


                    </div>
                </div>
                </div>
                </div>
                </div>



<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Window Playbook Flow 리스트 현황</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i><b>&nbsp;Window Playbook Flow 수정, 삭제 가능</b></font></td></tr>
                                  </table>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                        <th colspan=4>비고</th>
                                    </tr>
                                </thead>
				<tbody id='myTable'>

        ";


                $cmd_sql = "select * from Ansible_window_playbookflow_Save2 order by f_name asc";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_playbook_list = $newArray['f_playbook_list'];
                                $f_member_list = $newArray['f_member_list'];
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                echo "<tr><td>$f_name</td><td>$f_explain</td><td>$gubun_name</td><td><button id=$p_name name=$f_name class='btn btn-success btn-xs' onclick='popitup1(\"$f_name\")'>$f_name 내용보기</button></td>";
				echo "<td align=center><button name=F_COPY value={$f_name} type=submit class='btn btn-danger btn-xs' onclick='FlowCOPY(\"$f_name\",\"COPY\")'><b>복사</b></button></td>";
				echo "<td align=center><button name=F_MOD value={$f_name} type=submit class='btn btn-primary btn-xs' onclick='FlowMOD(\"$f_name\",\"MOD\")'><b>수정</b></button></td>";
				echo "<td align=center><button name=F_DEL value={$f_name} type=submit class='btn btn-warning btn-xs' onclick='FlowDEL(\"$f_name\",\"DEL\")'><b>삭제</b></button></td>";
				echo "<td align=center><button name=F_EXEC value={$f_name} type=submit class='btn btn-info btn-xs' onclick='FlowEXEC(\"$f_name\",\"EXEC\")'><b>실행</b></button></td></tr>";
                        }
                }


                echo "</tbody>";
                echo "</table>";
                echo "</div>";


                echo "

                            </div>
                          </div>


                        </div>


                ";



}

else if($_GET['add']) {

	$F_NAME = $_GET['add'];
	if($F_NAME != 2 and $F_NAME != 3) {  
		
		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;$F_NAME 저장:</font><b></font><font size=3 color=blue>성공</font></b></td></tr>
                        	  </table>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>


                                <div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                        <th colspan=4>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";


                $cmd_sql = "select * from Ansible_window_playbookflow_Save2 where f_name = '{$F_NAME}'";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_playbook_list = $newArray['f_playbook_list'];
                                $f_member_list = $newArray['f_member_list'];
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                echo "<tr><td>$f_name</td><td>$f_explain</td><td>$gubun_name</td><td><button id=$p_name name=$f_name class='btn btn-success btn-xs' onclick='popitup1(\"$f_name\")'>$f_name 내용보기</button></td>";
				echo "<td align=center><button name=F_COPY value={$f_name} type=submit class='btn btn-danger btn-xs' onclick='FlowCOPY(\"$f_name\",\"COPY\")'><b>복사</b></button></td>";
				echo "<td align=center><button name=F_MOD value={$f_name} type=submit class='btn btn-primary btn-xs' onclick='FlowMOD(\"$f_name\",\"MOD\")'><b>수정</b></button></td>";
				echo "<td align=center><button name=F_DEL value={$f_name} type=submit class='btn btn-warning btn-xs' onclick='FlowDEL(\"$f_name\",\"DEL\")'><b>삭제</b></button></td>";
				echo "<td align=center><button name=F_EXEC value={$f_name} type=submit class='btn btn-info btn-xs' onclick='FlowEXEC(\"$f_name\",\"EXEC\")'><b>실행</b></button></td></tr>";
                	}
        	}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";


                echo "

                        <a href=./ansible_window_playbookflow_Create_oyw.php>
                        <button type='button' class='btn btn-primary'>
                        <b><font size=3>다른 Flow 만들기</font></b>
                        </button></a>


                ";



	}
	else {

		if ($_GET['add'] == "2") $MSG5 = "<font size=3 color=red>ㅇ Flow 저장 이름이 중복 됩니다!!</font>";
		else if ($_GET['add'] == "3") $MSG5 = "<font size=3 color=red>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</font>";

                echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Flow 저장:</font><b></font><font size=3 color=blue>실패</font></b></td></tr>
                                  </table>
                              </div>
		  	      $MSG5

                              <div id='txt' class='panel-body'>
                              </div>
			<br><br><br>

		";


	}


	echo "

                            </div>
			  </div>



                        </div>
                        <!-- /.panel-body -->


                    </div>
                </div>

<br>
<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Window Playbook Flow 리스트 현황</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i><b>&nbsp;Window Playbook Flow 수정, 삭제 가능</b></font></td></tr>
                        	  </table>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                        <th colspan=4>비고</th>
                                    </tr>
                                </thead>
				<tbody id='myTable'>

                ";

                $cmd_sql = "select * from Ansible_window_playbookflow_Save2 order by f_name";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_playbook_list = $newArray['f_playbook_list'];
                                $f_member_list = $newArray['f_member_list'];
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                echo "<tr><td>$f_name</td><td>$f_explain</td><td>$gubun_name</td><td><button id=$p_name name=$f_name class='btn btn-success btn-xs' onclick='popitup1(\"$f_name\")'>$f_name 내용보기</button></td>";
				echo "<td align=center><button name=F_COPY value={$f_name} type=submit class='btn btn-danger btn-xs' onclick='FlowCOPY(\"$f_name\",\"COPY\")'><b>복사</b></button></td>";
				echo "<td align=center><button name=F_MOD value={$f_name} type=submit class='btn btn-primary btn-xs' onclick='FlowMOD(\"$f_name\",\"MOD\")'><b>수정</b></button></td>";
				echo "<td align=center><button name=F_DEL value={$f_name} type=submit class='btn btn-warning btn-xs' onclick='FlowDEL(\"$f_name\",\"DEL\")'><b>삭제</b></button></td>";
				echo "<td align=center><button name=F_EXEC value={$f_name} type=submit class='btn btn-info btn-xs' onclick='FlowEXEC(\"$f_name\",\"EXEC\")'><b>실행</b></button></td></tr>";
                	}
        	}

        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";


                echo "

                            </div>
                          </div>


                        </div>
                ";

}

else if($_GET['del']) {

	$F_NAME = $_GET['del'];
	if($F_NAME != 2 and $F_NAME != 3) {  
		
		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;$F_NAME 삭제:</font><b></font><font size=3 color=blue>성공</font></b></td></tr>
                        	  </table>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>
		";


	}
	else {

		if ($_GET['del'] == "2") $MSG5 = "<font size=3 color=red>ㅇ 해당 Flow가 없습니다!!</font>";
		else if ($_GET['del'] == "3") $MSG5 = "<font size=3 color=red>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</font>";
                echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Flow 삭제:</font><b></font><font size=3 color=blue>실패</font></b></td></tr>
                                  </table>
                              </div>
		  	      $MSG5

                              <div id='txt' class='panel-body'>
                              </div>
			<br><br><br>

		";


	}


	echo "
			<br><br><br><br><br><br><br><br>
                        <a href=./ansible_window_playbookflow_Create_oyw.php>
                        <button type='button' class='btn btn-primary'>
                        <b><font size=3> Flow 만들기</font></b>
                        </button></a>



                            </div>
			  </div>



                        </div>
                        <!-- /.panel-body -->


                    </div>
                </div>

<br>
<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Window Playbook Flow 리스트 현황</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i><b>&nbsp;Window Playbook Flow 수정, 삭제 가능</b></font></td></tr>
                        	  </table>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                        <th colspan=4>비고</th>
                                    </tr>
                                </thead>
				<tbody id='myTable'>

                ";

                $cmd_sql = "select * from Ansible_window_playbookflow_Save2 order by f_name";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_playbook_list = $newArray['f_playbook_list'];
                                $f_member_list = $newArray['f_member_list'];
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                echo "<tr><td>$f_name</td><td>$f_explain</td><td>$gubun_name</td><td><button id=$p_name name=$f_name class='btn btn-success btn-xs' onclick='popitup1(\"$f_name\")'>$f_name 내용보기</button></td>";
				echo "<td align=center><button name=F_COPY value={$f_name} type=submit class='btn btn-danger btn-xs' onclick='FlowCOPY(\"$f_name\",\"COPY\")'><b>복사</b></button></td>";
				echo "<td align=center><button name=F_MOD value={$f_name} type=submit class='btn btn-primary btn-xs' onclick='FlowMOD(\"$f_name\",\"MOD\")'><b>수정</b></button></td>";
				echo "<td align=center><button name=F_DEL value={$f_name} type=submit class='btn btn-warning btn-xs' onclick='FlowDEL(\"$f_name\",\"DEL\")'><b>삭제</b></button></td>";
				echo "<td align=center><button name=F_EXEC value={$f_name} type=submit class='btn btn-info btn-xs' onclick='FlowEXEC(\"$f_name\",\"EXEC\")'><b>실행</b></button></td></tr>";
                        }
                }

                echo "</tbody>";
                echo "</table>";
                echo "</div>";


                echo "

                            </div>
                          </div>


                        </div>
                ";

}


else if($_GET['mod']) {

	$F_NAME = $_GET['mod'];
	if($F_NAME != 2 and $F_NAME != 3) {  
		
		echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                        	  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;$F_NAME 수정:</font><b></font><font size=3 color=blue>성공</font></b></td></tr>
                        	  </table>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>


                                <div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                        <th colspan=4>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";


                $cmd_sql = "select * from Ansible_window_playbookflow_Save2 where f_name = '$F_NAME'";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_playbook_list = $newArray['f_playbook_list'];
                                $f_member_list = $newArray['f_member_list'];
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                echo "<tr><td>$f_name</td><td>$f_explain</td><td>$gubun_name</td><td><button id=$p_name name=$f_name class='btn btn-success btn-xs' onclick='popitup1(\"$f_name\")'>$f_name 내용보기</button></td>";
				echo "<td align=center><button name=F_COPY value={$f_name} type=submit class='btn btn-danger btn-xs' onclick='FlowCOPY(\"$f_name\",\"COPY\")'><b>복사</b></button></td>";
				echo "<td align=center><button name=F_MOD value={$f_name} type=submit class='btn btn-primary btn-xs' onclick='FlowMOD(\"$f_name\",\"MOD\")'><b>수정</b></button></td>";
				echo "<td align=center><button name=F_DEL value={$f_name} type=submit class='btn btn-warning btn-xs' onclick='FlowDEL(\"$f_name\",\"DEL\")'><b>삭제</b></button></td>";
				echo "<td align=center><button name=F_EXEC value={$f_name} type=submit class='btn btn-info btn-xs' onclick='FlowEXEC(\"$f_name\",\"EXEC\")'><b>실행</b></button></td></tr>";
                        }
                }

                echo "</tbody>";
                echo "</table>";
                echo "</div>";


	}
	else {

		if ($_GET['mod'] == "2") $MSG5 = "<font size=3 color=red>ㅇ 해당 Flow가 없습니다!!</font>";
		else if ($_GET['mod'] == "3") $MSG5 = "<font size=3 color=red>ㅇ 잘못된 값이 입력되었습니다. 확인 바랍니다!!</font>";
                echo "
                        <div id='P_mod' class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Playbook 저장:</font><b></font><font size=3 color=blue>실패</font></b></td></tr>
                                  </table>
                              </div>
		  	      $MSG5

                              <div id='txt' class='panel-body'>
                              </div>
			<br><br><br>

		";


	}


	echo "
                        <a href=./ansible_window_playbookflow_Create_oyw.php>
                        <button type='button' class='btn btn-primary'>
                        <b><font size=3> Flow 만들기</font></b>
                        </button></a>

                            </div>
			  </div>



                        </div>
                        <!-- /.panel-body -->


                    </div>
                </div>

<br>
<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Window Playbook Flow 리스트 현황</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                        	  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i><b>&nbsp;Window Playbook Flow 수정, 삭제 가능</b></font></td></tr>
                        	  </table>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                        <th colspan=4>비고</th>
                                    </tr>
                                </thead>
				<tbody id='myTable'>

                ";

                $cmd_sql = "select * from Ansible_window_playbookflow_Save2 order by f_name";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_playbook_list = $newArray['f_playbook_list'];
                                $f_member_list = $newArray['f_member_list'];
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                echo "<tr><td>$f_name</td><td>$f_explain</td><td>$gubun_name</td><td><button id=$p_name name=$f_name class='btn btn-success btn-xs' onclick='popitup1(\"$f_name\")'>$f_name 내용보기</button></td>";
				echo "<td align=center><button name=F_COPY value={$f_name} type=submit class='btn btn-danger btn-xs' onclick='FlowCOPY(\"$f_name\",\"COPY\")'><b>복사</b></button></td>";
				echo "<td align=center><button name=F_MOD value={$f_name} type=submit class='btn btn-primary btn-xs' onclick='FlowMOD(\"$f_name\",\"MOD\")'><b>수정</b></button></td>";
				echo "<td align=center><button name=F_DEL value={$f_name} type=submit class='btn btn-warning btn-xs' onclick='FlowDEL(\"$f_name\",\"DEL\")'><b>삭제</b></button></td>";
				echo "<td align=center><button name=F_EXEC value={$f_name} type=submit class='btn btn-info btn-xs' onclick='FlowEXEC(\"$f_name\",\"EXEC\")'><b>실행</b></button></td></tr>";
                        }
                }

                echo "</tbody>";
                echo "</table>";
                echo "</div>";

                echo "

                            </div>
                          </div>


                        </div>
                ";


}


?>



                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>
