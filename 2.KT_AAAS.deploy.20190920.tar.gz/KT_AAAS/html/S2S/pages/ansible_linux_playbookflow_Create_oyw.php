<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
function Inventory_Select() {
    var String = "./ansible_linux_playbookflow_Ilist2.php";
    $("#Inventory_Select_Div").load(String);
}
</script>

<script>
function Playbook_Select() {

    var msg;
    var p_arg = document.getElementById('button1').value;

    if (p_arg) {
        var String = "./ansible_linux_playbookflow_Plist2.php?MEMBER=" + p_arg;
        document.getElementById('button1').disabled = true;
        $("#playbook_Select_Div").load(String);
    }
    else {
        msg = "Inventory 항목이 비어 있습니다. 확인바랍니다!!";
        alert(msg);
    }

}
</script>

<script>
function FlowMOD(f_name,action) {
    var String = "./ansible_linux_playbookflow_mod_oyw.php?F_MOD=" + f_name + "&ACT=" + action;
    $("#P_mod").load(String);
}
</script>

<script>
function popitup1(f_name) {
    var url = "./ansible_linux_playbookflow_content_popup.php?name=" + f_name;
    window.open(url,"Flow Show","width=1400,height=400,left=100,top=60");
}
</script>



</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Flow > Linux > Flow 생성, 수정, 삭제</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
		echo "<table>";
		echo "<tr><td width=550><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Flow을 만들어 여러개의 Playbook을 순차대로 실행 및 자동화</font></td>";
		echo "</tr>";
		echo "</table>";
?>

		</div>
		<!-- /.panel-heading -->








<?php

	$MEMBER = $_POST['MEMBER'];
	$PLAYBOOK = $_POST['PLAYBOOK'];
        echo "

            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>

                        <div id='P_mod' class='panel-body'>

                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
                               <tr><td width=190 style='height:33px'><font size=3><b>&nbsp;Flow 만들기</b></font></td>
                               </table>

                              </div>
                            </div>
                            <div class='col-lg-9'>
                            </div>
                          </div>


                          <div class='panel-body'>

                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
                               <tr><td width=190 height=25><font size=3><b>&nbsp;1. Inventory</b></font></td>
			       <td><button id=button1 value='{$MEMBER}' name=btn1 class='btn btn-primary' onclick='Inventory_Select()'><b>선택</b></button></td></tr>
                               </table>

                              </div>
                            </div>
                            <div class='col-lg-9'>
                            </div>
                          </div>
	";



	if($MEMBER) {
		echo "
                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>
                                <div id='Inventory_Select_Div'>
		";

                // Host, Group List display //
                $T_CNT = 0;
		$HOST_LIST = '';
		$G_LIST = '';
        	$T_MEMBER = explode('|',$MEMBER);
        	foreach($T_MEMBER as $SubMember) {

                	$NODENAME = $SubMember;

                	$cmd_sql = "select * from Ansible_linux_host where nodename = '{$NODENAME}'";
                	$res = mysqli_query($mysqli,$cmd_sql);

                       	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
                	$data = mysqli_fetch_array($res);
                        $hostname = $newArray['hostname'];

                	if (isset($hostname)) {

                                $hostname = $newArray['hostname'];
                                $nodename= $newArray['nodename'];
                                $ip = $newArray['ip'];
				if(!$HOST_LIST) $HOST_LIST = "<a title='Nodename: {$nodename}\nIP: {$ip}'>" . $hostname . "</a>";
                                else {
                                        $MOD = $T_CNT % 13;
                                        if($MOD == 0) $BR = "<br>";
                                        else $BR = "";

                                        $HOST_LIST = $HOST_LIST . "{$BR}&nbsp;<font color=red><b>,</b></font>&nbsp;" . "<a title='Nodename: {$nodename}\nIP: {$ip}'>" . $hostname . "</a>";
                                }

			}
			else {
				if(!$G_LIST) $G_LIST = $NODENAME;
				else $G_LIST = $G_LIST . '|' . $NODENAME;
			}

                        $T_CNT = $T_CNT + 1;
		}

                $T_CNT = 0;
		if($G_LIST) {

			$GROUP_LIST = '';
                	$G_MEMBER = explode('|',$G_LIST);
                	foreach($G_MEMBER as $SubGroup) {

                        	$GROUPNAME = $SubGroup;

                        	$cmd_sql = "select * from Ansible_linux_group where groupname = '{$GROUPNAME}'";
                        	$res = mysqli_query($mysqli,$cmd_sql);
                        	if ($res) {
                                	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);

                                	$groupname = $newArray['groupname'];
                                	$member= $newArray['member'];

					$SubGroup_Member_list = '';
					$G_member = explode('|',$member);
					foreach($G_member as $subgroup_member) {
						if(!$SubGroup_Member_list) $SubGroup_Member_list = $subgroup_member;
						else $SubGroup_Member_list = $SubGroup_Member_list . "\n" . $subgroup_member;
					}

					if(!$GROUP_LIST) $GROUP_LIST = "<a title='{$SubGroup_Member_list}'>" . $groupname . "</a>";
                                        else {
                                                $MOD = $T_CNT % 13;
                                                if($MOD == 0) $BR = "<br>";
                                                else $BR = "";

                                                $GROUP_LIST =  $GROUP_LIST . "{$BR}&nbsp;<font color=red><b>,</b></font>&nbsp;" . "<a title='{$SubGroup_Member_list}'>" . $groupname . "</a>";
                                        }

				}

                                $T_CNT = $T_CNT + 1;
			}

		}


		if($HOST_LIST or $GROUP_LIST) {

			echo "<table border=1 width='100%' class='table table-striped table-bordered table-hover'>";
			if($HOST_LIST) {
				echo "
				<tr><td>ㅇ 호스트 리스트: </td>
				<td>$HOST_LIST</td></tr>
				";
			}

			if($GROUP_LIST) {
				echo "
				<tr><td>ㅇ 그룹 리스트: </td>
				<td>$GROUP_LIST</td></tr>
				";
			}

			echo "</table>";

		}


		echo "

                                </div>
                              </div>
                              </div>
                              </div>

                            </div>
                          </div>
		";
	}
	else {
                echo "
                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>
                                <div id='Inventory_Select_Div'>

                                </div>
                              </div>
                              </div>
                              </div>

                            </div>
                          </div>
                ";

	}


        echo "
                          <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table>
                               <tr><td width=190 height=25><font size=3><b>&nbsp;2. Playbook</b></font></td>
                               <td><button id=button2 name=btn1 class='btn btn-primary' onclick='Playbook_Select()'><b>선택</b></button></td></tr>
                               </table>

                              </div>
                            </div>
                            <div class='col-lg-9'>
                            </div>
                          </div>
	";




	if($PLAYBOOK) {
        	echo "
                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>
				<div id='playbook_Select_Div'>
                                        <pre>$PLAYBOOK</pre>

                                </div>
                              </div>
                              </div>
                              </div>

                            </div>
                          </div>
		";
	}
	else {
                echo "
                          <div class='row'>
                            <div class='col-lg-12'>

                              <div class='panel-body'>
                              <div class='row'>
                              <div class='col-lg-12'>
                                <div id='playbook_Select_Div'>

                                </div>
                              </div>
                              </div>
                              </div>

                            </div>
                          </div>
                ";
	}


?>

            		  <div class="row">
                            <div class="col-lg-12">
			      <div id="list1">

			      </div>

                            </div>
			  </div>






<?php


        echo "


                    </div>
                </div>


			</div>
			</div>
			</div>
			</div>


<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Linux Playbook Flow 리스트 현황</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <table>
                                  <tr><td width=450 style='height:30px'><font size=3><i class='fa fa-calendar fa-fw'></i><b>&nbsp;Linux Playbook Flow 수정, 삭제 가능</b></font></td></tr>
                                  </table>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

                                <div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                        <th colspan=3>비고</th>
                                    </tr>
                                </thead>
				<tbody id='myTable'>

        ";


                $cmd_sql = "select * from Ansible_linux_playbookflow_Save2 order by f_name asc";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_playbook_list = $newArray['f_playbook_list'];
                                $f_member_list = $newArray['f_member_list'];
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                echo "<tr><td>$f_name</td><td>$f_explain</td><td>$gubun_name</td><td><button id=$p_name name=$f_name class='btn btn-success btn-sm' onclick='popitup1(\"$f_name\")'>$f_name 내용보기</button></td>";
                                echo "<td align=center><button name=F_MOD value={$f_name} type=submit class='btn btn-primary btn-sm' onclick='FlowMOD(\"$f_name\",\"MOD\")'><b>수정</b></button></td>";
				echo "<td align=center><form action=./ansible_linux_playbookflow_del_oyw.php>";
				echo "<button name=F_DEL value={$f_name} type=submit class='btn btn-warning btn-sm'><b>삭제</b></button></form></td>";
				echo "<td align=center><form action=./ansible_linux_playbookflow_exec_oyw.php>";
                                echo "<button name=FLOW value={$f_name} type=submit class='btn btn-info btn-sm'><b>실행</b></button></form></td></tr>";
                        }
                }


                echo "</tbody>";
                echo "</table>";
                echo "</div>";


                echo "

                            </div>
                          </div>


                        </div>


                ";




?>



                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>
