<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->


<script>
function popitup1(f_name) {
    var url = "./help_RSA_Key.php";
    window.open(url,"Ansible Public Key","width=760,height=400,left=100,top=60,location=no");
}
</script>

<style>
#NOTICE {margin: 0;color: #888;font: 13px/1.25 sans-serif;-webkit-text-size-adjust: 100%;}
h1 {font-size: 1.6em;}
h3 {font-size: 1em;}
h1, h2, h3, h4 {color: #000;}
#titleS {padding: 1.25em 1em 1em; margin: 0;background:#000;color:#5d5d5d; position: relative;}
#noticeS,#oss,#licensesS div {padding: 10px;}dt {font-size: 14px;font-weight: bold;color: #000;margin-top: 1em;}
dd {margin-left: 20px;}
pre, dd a {word-wrap: break-word;}
#ossS i {color: #333;}
#ossS,#licensesS div {border-top: 1px solid #ccc;padding-top: 1em;}
#licensesS div { display: block; white-space: pre; word-wrap: break-word;}
#licensesS p {fmargin: .75em 0;}.license a {text-decoration: none; color:#999;}
#createHtml { position: absolute; top: 50%; transform: translateY(-50%);-webkit-transform: translateY(-50%);-ms-transform: translateY(-50%); background-color:#44c767; border-radius:2em; border:1px solid #18ab29; display:inline-block; cursor:pointer; color:#fff; font-size:14px; padding:.5em .75em; text-decoration:none; text-shadow:0px 1px 0px #2f6627; margin-left: 1em;}
#createHtml:hover { background-color:#5cbf2a;}
</style>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 style='font-size:2.5em;' class="page-header">오픈소스 라이선스</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">

                        <div class="panel-body">




            <div id=NOTICE class="row">



<h1 id="titleS" style='font-size:2em;color:white;'>Open Source Software Notice</h1> <div id="noticeS"> <p>This product contains the following Open Source Software with licenses and notices below.<p> <p>For any questions, please contact to <a href=\"mailto:osscenter@kt.com\">osscenter@kt.com</a><p> </div> <div id="ossS"> <dl> <dt>animate.css-jquery</dt> <dd><a href="http://github.com/twbs/bootstrap/">http://github.com/twbs/bootstrap/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>BlackrockDigital/startbootstrap-sb-admin-2</dt> <dd><a href="https://github.com/BlackrockDigital/startbootstrap-sb-admin-2">https://github.com/BlackrockDigital/startbootstrap-sb-admin-2</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>Bootstrap</dt> <dd><a href="http://github.com/twbs/bootstrap/">http://github.com/twbs/bootstrap/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>bootstrap-social</dt> <dd><a href="http://github.com/lipis/bootstrap-social/">http://github.com/lipis/bootstrap-social/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>branch-sdk</dt> <dd><a href="https://www.npmjs.org/package/branch-sdk">https://www.npmjs.org/package/branch-sdk</a></dd> <dd>Copyright (c) </dd> <dd>ISC License</dd> <dt>chart.js-v2</dt> <dd><a href="http://github.com/nnnick/Chart.js/">http://github.com/nnnick/Chart.js/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>DataTables</dt> <dd><a href="http://github.com/DataTables/DataTables/">http://github.com/DataTables/DataTables/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>DataTables Plugins</dt> <dd><a href="http://webjars.org">http://webjars.org</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>fakeLoader.js</dt> <dd><a href="http://www.joaopereira.pt">http://www.joaopereira.pt</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>Flot</dt> <dd><a href="http://github.com/flot/flot/">http://github.com/flot/flot/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>flot.tooltip</dt> <dd><a href="http://github.com/krzysu/flot.tooltip/">http://github.com/krzysu/flot.tooltip/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>Font-Awesome</dt> <dd><a href="http://github.com/FortAwesome/Font-Awesome/">http://github.com/FortAwesome/Font-Awesome/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>Google fonts</dt> <dd><a href="http://github.com/google/fonts/">http://github.com/google/fonts/</a></dd> <dd>Copyright (c) </dd> <dd>SIL Open Font License 1.1</dd> <dt>GoogleAuthenticator</dt> <dd><a href="http://www.phpgangsta.de/">http://www.phpgangsta.de/</a></dd> <dd>Copyright (c) </dd> <dd>BSD 3-clause "New" or "Revised" License</dd> <dt>HTML5 Shiv - org.webjars:html5shiv</dt> <dd><a href="http://repo.maven.apache.org/maven2/org/webjars/html5shiv/">http://repo.maven.apache.org/maven2/org/webjars/html5shiv/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>jbarba_select2</dt> <dd><a href="http://github.com/ivaynberg/select2/">http://github.com/ivaynberg/select2/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>jquery - jquery/jquery</dt> <dd><a href="http://github.com/jquery/jquery/">http://github.com/jquery/jquery/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>metismenu</dt> <dd><a href="http://github.com/onokumus/metismenu/">http://github.com/onokumus/metismenu/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>montserrat-ionic</dt> <dd><a href="https://www.npmjs.org/package/montserrat-ionic">https://www.npmjs.org/package/montserrat-ionic</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>morris.js06</dt> <dd><a href="http://github.com/morrisjs/morris.js/">http://github.com/morrisjs/morris.js/</a></dd> <dd>Copyright (c) </dd> <dd>BSD 2-clause "Simplified" License</dd> <dt>popper.js</dt> <dd><a href="https://www.npmjs.org/package/popper.js">https://www.npmjs.org/package/popper.js</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>Raphael JavaScript Library</dt> <dd><a href="http://github.com/DmitryBaranovskiy/raphael/">http://github.com/DmitryBaranovskiy/raphael/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>Respond</dt> <dd><a href="http://github.com/scottjehl/Respond/">http://github.com/scottjehl/Respond/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>Responsive - DataTables/Responsive</dt> <dd><a href="http://github.com/DataTables/Responsive/">http://github.com/DataTables/Responsive/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> <dt>tablednd</dt> <dd><a href="http://github.com/isocra/TableDnD/">http://github.com/isocra/TableDnD/</a></dd> <dd>Copyright (c) </dd> <dd>MIT License</dd> </dl> </div> <div id="licensesS"> <hr size="1" color="d9d9d9"><dl><dd><H1>BSD Two Clause License</H1> <!-- Title added by Steve Snow of Black Duck Software for identification purposes only --> <p>Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:</p> <ol> <li> <a name="includeLicenseRestrictionLicense">Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.</a></li> <li> <a name="includeLicenseRestrictionLicense2">Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.</a></li> </ol><p> THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. </p></dd></dl> <hr size="1" color="d9d9d9"><dl><dd><br> Copyright (c) &lt;YEAR&gt;, &lt;OWNER&gt;<br> All rights reserved.<br><br> Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met: <ul> <li>Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. <li>Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. <li>Neither the name of the &lt;ORGANIZATION&gt; nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. </ul><br> THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS &quot;AS IS&quot; AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.<br><br></dd></dl> <hr size="1" color="d9d9d9"><dl><dd><h1> SIL OPEN FONT LICENSE </h1> <p>Version 1.1 - 26 February 2007</p> <h3> PREAMBLE</h3> <p>The goals of the Open Font License (OFL) are to stimulate worldwide development of collaborative font projects, to support the font creation efforts of academic and linguistic communities, and to provide a free and open framework in which fonts may be shared and improved in partnership with others.</p> <p>The OFL allows the licensed fonts to be used, studied, modified and redistributed freely as long as they are not sold by themselves. The fonts, including any derivative works, can be bundled, embedded, redistributed and/or sold with any software provided that any reserved names are not used by derivative works. The fonts and derivatives, however, cannot be released under any other type of license. The requirement for fonts to remain under this license does not apply to any document created using the fonts or their derivatives.</p> <h3> DEFINITIONS</h3> <p>"Font Software" refers to the set of files released by the Copyright Holder(s) under this license and clearly marked as such. This may include source files, build scripts and documentation.</p> <p>"Reserved Font Name" refers to any names specified as such after the copyright statement(s).</p> <p>"Original Version" refers to the collection of Font Software components as distributed by the Copyright Holder(s).</p> <p>"Modified Version" refers to any derivative made by adding to, deleting, or substituting &mdash; in part or in whole &mdash; any of the components of the Original Version, by changing formats or by porting the Font Software to a new environment.</p> <p>"Author" refers to any designer, engineer, programmer, technical writer or other person who contributed to the Font Software.</p> <h3>PERMISSION &amp; CONDITIONS</h3> <p><a name="maximumUsageLevelLicense">Permission is hereby granted, free of charge, to any person obtaining a copy of the Font Software, to use, study, copy, merge, embed, modify, redistribute, and sell modified and unmodified copies of the Font Software</a>, subject to the following conditions:</p> <p>1) <a name="feeForSoftwareRestrictionLicense">Neither the Font Software nor any of its individual components, in Original or Modified Versions, may be sold by itself.</p> <p>2) Original or Modified Versions of the Font Software may be bundled, redistributed and/or sold with any software</a>, provided that <a name="includeLicenseRestrictionLicense">each copy contains the above copyright notice and this license. These can be included either as stand-alone text files, human-readable headers or in the appropriate machine-readable metadata fields within text or binary files as long as those fields can be easily viewed by the user.</a></p> <p>3) <a name="discriminationRestrictionLicense">No Modified Version of the Font Software may use the Reserved Font Name(s) unless explicit written permission is granted by the corresponding Copyright Holder. This restriction only applies to the primary font name as presented to the users.</a></p> <p>4) <a name="promotionRestrictionLicense">The name(s) of the Copyright Holder(s) or the Author(s) of the Font Software shall not be used to promote, endorse or advertise any Modified Version, except to acknowledge the contribution(s) of the Copyright Holder(s) and the Author(s) or with their explicit written permission.</a></p> <p>5) <a name="usageLevelLicense">The Font Software, modified or unmodified, in part or in whole, must be distributed entirely under this license, and must not be distributed under any other license. The requirement for fonts to remain under this license does not apply to any document created using the Font Software.</a></p> <h3>TERMINATION</h3> <p>This license becomes null and void if any of the above conditions are not met.</p> <h3>DISCLAIMER</h3> <p>THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM OTHER DEALINGS IN THE FONT SOFTWARE.</p></dd></dl> <hr size="1" color="d9d9d9"><dl><dd><h1>ISC License (ISCL)</h1> <TT>Copyright (c) 4-digit year, Company or Person's Name </TT> <p> <p><a name="maximumUsageLevelLicense">Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted</a>, provided that <a name="includeLicenseRestrictionLicense">the above copyright notice and this permission notice appear in all copies.</a></p> <p>THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.</p></dd></dl> <hr size="1" color="d9d9d9"><dl><dd><h1>The MIT License</h1> <tt>Copyright (c) &lt;year&gt; &lt;copyright holders&gt;</tt><br><br> <a name="feeForSoftwareLicense"><a name="feeForDistributionLicense">Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the &quot;Software&quot;), to deal in the Software without restriction,</a> <a name="copyRestrictionLicense"><a name="modificationRestrictionLicense">including without limitation the rights to use, copy,</a> modify, merge,</a> publish, distribute, sublicense, and/or sell copies of the Software,</a> and to permit persons to whom the Software is furnished to do so, subject to the following conditions:<br><br> The above copyright notice and <a name="includeLicenseRestrictionLicense"><a name="includeAddedCodeRestrictionLicense"><a name="includeLicenseRestrictionLicense">this permission notice shall be included in all copies or substantial portions of the Software.</a></a></a><br><br> <a name="disclaimerRestrictionLicense">THE SOFTWARE IS PROVIDED &quot;AS IS&quot;, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.</a> <a name="excludeDamagesRestrictionLicense">IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.</a><br></dd></dl> </div> 






            </div>





                        </div>
                        <!-- /.panel-body -->


                        <div class="panel-footer">
                            <img src="../vendor/login/a-ops_logo.png" width=150>
                        </div>



                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
