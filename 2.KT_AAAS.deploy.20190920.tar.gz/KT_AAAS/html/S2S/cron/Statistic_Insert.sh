#!/bin/bash

TIME_T="01:01"
BASE_T=$(date +%H:%M)


while true 
do

if [ "$BASE_T" = "$TIME_T" ] ; then
   php /var/www/html/S2S/cron/Statistic_Insert2.php
fi

sleep 60
BASE_T=$(date +%H:%M)
echo "BASE : $BASE_T , Meet_TIME : $TIME_T"

done >> /var/www/html/S2S/cron/cronResult.txt
