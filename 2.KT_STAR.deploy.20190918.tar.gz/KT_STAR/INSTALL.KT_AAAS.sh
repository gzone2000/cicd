sysctl -w net.ipv4.conf.all.forwarding=1
docker rm -f KT_STAR
docker run --privileged --name KT_STAR --restart=always -d -p 8080:80 -p 9443:443 \
-v /Project1/KT_STAR/html:/var/www/html \
-v /Project1/KT_STAR/mysql:/var/lib/mysql \
gzone2000/my_test:CentOS7_BASE_LAMP_KTSTAR
