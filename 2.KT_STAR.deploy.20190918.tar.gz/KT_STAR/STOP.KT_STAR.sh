docker stop KT_STAR
