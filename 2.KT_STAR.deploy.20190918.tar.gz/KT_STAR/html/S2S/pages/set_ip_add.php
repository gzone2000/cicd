<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$HOST = trim($_POST['HOST']);
$IP = trim($_POST['IP']);
$SUBNET = trim($_POST['SUBNET']);
$BLOCK_CONECT = trim($_POST['BLOCK_CONECT']);
#echo "# Argument: NUM > {$NUM}\n";
#echo "# Argument: IP > {$IP}\n";
#echo "# Argument: SUBNET > {$SUBNET}\n";
#echo "# Argument: BLOCK_CONECT > {$BLOCK_CONECT}\n";


if (!$HOST or !$IP or !$SUBNET) {
	$FULLURL = "./set_ip.php?add=1";
	#echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {
        
        function mask2cidr($mask){
                $long = ip2long($mask);
                $base = ip2long('255.255.255.255');
                return 32-log(($long ^ $base)+1,2);
        } 

	$SUBNET = mask2cidr($SUBNET);

	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		$FULLURL = "./set_ip.php?add=9999";

		$select_sql = "select num from Connect_IP_chk where host = '{$HOST}' and ip = '{$IP}' and subnet = '{$SUBNET}' " ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['num'];

		if (!isset($isset_num)) {

			# 설정 추가 화면
			# Insert Connect_IP_chk table
			$insert_sql = "INSERT into Connect_IP_chk values ('{$NUM}', '{$HOST}', '{$IP}', '{$SUBNET}', '{$BLOCK_CONECT}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			#echo "# SQL : {$insert_sql} , Result : $res";
			#echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			$FULLURL = "./set_ip.php?add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}
}

?> 
