<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$HOST = trim($_POST['HOST']);
$USER = trim($_POST['USER']);
$COMMAND = trim($_POST['COMMAND']);
$COMMAND = str_replace("\\b","\\\\b",$COMMAND);
$APPLY = trim($_POST['APPLY']);
#echo "# Argument: NUM > {$NUM}\n";
#echo "# Argument: USER > {$USER}\n";
#echo "# Argument: COMMAND > {$COMMAND}\n";
#echo "# Argument: APPLY > {$APPLY}\n";


if (!$HOST or !$USER or !$COMMAND) {
	$FULLURL = "./set_command.php?add=1";
	echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {

	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		$FULLURL = "./set_command.php?add=9999";

		$select_sql = "select num from crit_cmd_list_v1 where host = '{$HOST}' and user = '{$USER}' and crit_command = '{$COMMAND}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} <br>" ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['num'];

		#echo "# NUM : $isset_num <br>";

		if (!isset($isset_num)) {

			# 설정 추가 화면
			# Insert crit_cmd_list_v1 table
			$insert_sql = "INSERT into crit_cmd_list_v1 values ('{$NUM}', '{$HOST}', '{$USER}', '{$COMMAND}', '{$APPLY}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			#echo "# SQL : {$insert_sql} , Result : $res";
			#echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			$FULLURL = "./set_command.php?add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}
}

?> 
