<?php

$UTIME = trim($_POST['utime']);
###echo "# Argument: utime > {$UTIME}\n";

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

	$cmd_sql = "select * from input_cmd_list where utime = '{$UTIME}' ;" ;
	###echo "# SQL : {$cmd_sql}\n";

	$res = mysqli_query($mysqli,$cmd_sql);


	if ($res) {
        	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                	$date = $newArray['date'];
                	$time= $newArray['time'];
                	$utime= $newArray['utime'];
                	$host = $newArray['host'];
                	$user= $newArray['user'];
                	$sip = $newArray['sip'];
                	$pid = $newArray['pid'];
                	$pwd = $newArray['pwd'];
                	$cmd = $newArray['cmd'];
                	###echo "Values: {$date}, {$time}, {u$time}, {$host} , {$user} , {$sip} , {$pid} , {$pwd} , {$cmd}\n";

        	}

/*
		# Command execution Time Check
		$connect_time_sql = "select * from Cmd_exe_time_chk where block_conect = 'N' and host = '{$host}' and '{$time}' >= start_time and '{$time}' <= end_time" ;

                $res5 = mysqli_query($mysqli,$connect_time_sql);
                $data = mysqli_fetch_array($res5);
                $isset_check1 = $data['num'];
                if (!isset($isset_check1)) {

			$connect_time_sql1 = "select * from Cmd_exe_time_chk where block_conect = 'N' and host = 'DEFAULT' and '{$time}' >= start_time and '{$time}' <= end_time" ;

                	$res6 = mysqli_query($mysqli,$connect_time_sql1);
                	$data = mysqli_fetch_array($res6);
                	$isset_check2 = $data['num'];

			if (!isset($isset_check1)) {
				# 접속 가능 시간외의 접속으로 차단 
				#echo "BLOCK";

				mysqli_free_result($res);
				mysqli_close($mysqli); 
				exit("BLOCK");
			}

		}
*/

		# 승인 될때까지 계속해서 기다림. 만약 클라이어단에서 끊는지도 체크함 

                $PID = getmypid();
                ###echo "PID : {$PID}\n";
                $update_sql = "UPDATE input_cmd_list SET remark = '{$PID}' where utime = '{$UTIME}' ;" ;
                $res = mysqli_query($mysqli,$update_sql);

		/*
		### apache User : netstat -nap >>> NOT Display PID
		### execute "chmod 4755 /bin/netstat" 

		###echo system("whoami");
                ###$NET_LINE = exec("netstat -nap | grep $PID | grep EST",$output) ;
		###print_r($output);
                ###$NET_LINE = exec("netstat -nap | grep $PID | grep EST | wc -l") ;
                ###echo "Network Connection Count: {$NET_LINE} \n" ;
		*/

                # loop until ack='Y'
                $approve_sql = "select * from input_cmd_list where utime = '{$UTIME}' and ack = 'Y';" ;
                ###echo "# SQL : {$approve_sql}\n";

                $res1 = mysqli_query($mysqli,$approve_sql);
                $data = mysqli_fetch_array($res1);
                $isset_check = $data['utime'];
                while (!isset($isset_check)) {
			sleep(1);


                        $CLOSE_WAIT = exec("netstat -nap | grep $PID | grep CLOSE_WAIT | wc -l") ;
                	###echo "CLOSE_WAIT Network Connection Count: {$CLOSE_WAIT} \n" ;
                        $ESTABLISHED = exec("netstat -nap | grep $PID | grep ESTAB | wc -l") ;
                	###echo "ESTABLISHED Network Connection Count: {$ESTABLISHED} \n" ;

                        if ($CLOSE_WAIT == 1 && $ESTABLISHED == 0) {
                                ###echo "# Client disconnect Server http connection by Crtl+C \n" ;
				$update_sql = "UPDATE input_cmd_list SET cmd_status = 'C' where utime = '{$UTIME}' " ;
                        	$res = mysqli_query($mysqli,$update_sql);
				break;
                        }

			elseif ($CLOSE_WAIT == 0 && $ESTABLISHED == 1) {
				###echo "# Client <---> Server Connect continuously \n" ;

                        	# select query
                        	$res1 = mysqli_query($mysqli,$approve_sql);
                        	$data = mysqli_fetch_array($res1);
                        	$isset_check = $data['utime'];

			}

		} # while

                $CANCEL_UTIME = microtime(true);
                $update_sql = "UPDATE input_cmd_list SET cancel_utime = '{$CANCEL_UTIME}' where utime = '{$UTIME}'" ;
               	$res = mysqli_query($mysqli,$update_sql);

                $approve_sql = "select * from input_cmd_list where utime = '{$UTIME}' and ack = 'Y';" ;
                $res1 = mysqli_query($mysqli,$approve_sql);
                $data = mysqli_fetch_array($res1);
                $isset_cmd_status = $data['cmd_status'];

		if ($isset_cmd_status == 'E') echo "SUCC";
		else echo "REJ";

	}

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
