<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=$LOGO_SIZE></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">도움말</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
                        echo "<table colnum=3>";
                        echo "<tr><td width=250><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;&nbsp;KT Star 도움말</font>";
                        echo "</td></tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->

<?php

        $CMD_COND = " where date >= '{$INPUT_DATE}' and date <= '{$INPUT_DATE1}' " ;
        $ORDER = "order by date asc, time asc" ;
        $cmd_sql = "select * from input_cmd_list " . $CMD_COND . $ORDER;
        ###echo "# SQL : {$cmd_sql}";
?>

                        <div class="panel-body">




            <div class="row">
                <div class="col-lg-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <?php echo "$MENU0"; ?>
                        </div>
                        <div class="panel-body">
                            <p>전체적으로 시스템에서 발생하는 명령 내용을 한눈에 보여주며 그래프와 통계 테이블을 통한 흐름을 파악할수 있다.</p>
			  <ul>
			    <li>주요 이벤트 발생건수: 명령 건수 , 비정상 명령건수, 승인 명령건수</li>
			    <li>한달간의 명령에 대한 그래프와 테이블 리스트</li>
			  </ul>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <?php echo "$MENU1"; ?>
                        </div>
                        <div class="panel-body">
                            <p>시스템에서 발생하는 명령을 검색할수 있는 화면</p>
			  <ul>
			    <li>기본적으로 당일에 발생한 명령 리스트을 시간 기준으로 오름차순으로 보여준다.</li>
			    <li>원하는 날짜를 선택하여 검색 가능하다.</li>
			  </ul>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <?php echo "$MENU2"; ?>
                        </div>
                        <div class="panel-body">
                            <p>시스템에서 발생되는 명령어를 실시간으로 내림차순으로 보여주며 필요시 실시간 해체 가능하다. </p>
			  <ul>
			    <li>5초간격으로 실시간으로 발생되는 명령을 보여줌</li>
			    <li>필요시 실시간 조회 버튼을 눌러 실시간 조회 해체 가능</li>
			  </ul>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->



            <div class="row">
                <div class="col-lg-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <?php echo "$MENU3"; ?>
                        </div>
                        <div class="panel-body">
                            <p>비정상 명령어는 3가지 형태의 명령 실행시 탐지되며 기본적으로 차단된다.</p>
			  <ul>
			    <li>접속시간 위반 : 설정된 시간외에 접속시 차단된다.</li>
			    <li>접속IP 위반 : 설정된 IP외에 접속시에 차단된다.</li>
			    <li>설정명령 위반 : 설정 명령을 실행시 탐지되며 동작은 차단/허용/승인에 따른다. </li>
			  </ul>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            <?php echo "$MENU4"; ?>
                        </div>
                        <div class="panel-body">
                            <p>Critical 명령에 대해서 중앙의 관리자가 승인해야 명령어가 실행된다.</p>
			  <ul>
			    <li>어드민 권한을 가진 유저에게만 화면이 보인다.</li>
			    <li>5초마다 갱신되며 날짜를 선택하여 명령어 승인 리스트 볼수있다.</li>
			    <li>Critical 명령 입력시 Accept나 Reject 버늩을 눌러 선택할수 있으며 Accept시 명령어가 실행되고 Reject시 명령어 실행안됨.</li>
			  </ul>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <?php echo "$MENU5"; ?>
                        </div>
                        <div class="panel-body">
                            <p>설정화면으로 접속시간 / 접속IP / 명령제어 / 통제기능 설정할수 있다. </p>
			  <ul>
			    <li>어드민 권한을 가진 유저에게만 화면이 보인다.</li>
			    <li>각 설정화면에서 항목을 추가/삭제/수정 할수 있다.</li>
			    <li>통제기능 설정은 발생되는 명령에 대해 접속시간/접속IP/설정명령 체크 기능 전체를 Enable/Disable 할수 있어 주의 바랍니다. </li>
			  </ul>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->



            <div class="row">
                <div class="col-lg-4">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <?php echo "$MENU6"; ?>
                        </div>
                        <div class="panel-body">
                            <p>시스템에서 발생되는 명령어를 날짜별로 통계를 만들어 보여준다.</p>
			  <ul>
			    <li>기본적으로 1달간의 통계를 보여준다.</li>
			    <li>원하는 날자를 선택하여 통계를 볼수 있다.</li>
			    <li>일반명령, 승인명령, Block명령등의 상세한 내용을 파악할수 있다.</li>
			  </ul>
                        </div>
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
                <div class="col-lg-4">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <?php echo "$MENU7"; ?>
                        </div>
                        <div class="panel-body">
                            <p>계정관리 화면으로 계정을 추가/삭제/수정할수 있다.</p>
			  <ul>
			    <li>어드민 권한을 가진 유저에게만 화면이 보인다.</li>
			    <li>계정을 추가, 삭제, 수정할수 있다.</li>
			    <li>패스워드는 암호화되어 DB에 저장된다.</li>
			  </ul>
                        </div>
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
                <div class="col-lg-4">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <?php echo "$MENU8"; ?>
                        </div>
                        <div class="panel-body">
                            <p>해당 시스템의 매뉴에 대한 설명을 보여준다.</p>
			  <ul>
			    <li>9개의 패널로 각 매뉴을 표시한다.</li>
			    <li>각 패널에는  매뉴에 대한 보다 상세한 설명이 있다.</li>
			    <li>각 패널의 색상을 달리하여 보기 좋게 구현함.</li>
			  </ul>
                        </div>
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
            </div>
            <!-- /.row -->





                        </div>
                        <!-- /.panel-body -->


                        <div class="panel-footer">
                            <?php echo "<img src='../vendor/login/$LOGO' width=100>"; ?>
                        </div>



                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
