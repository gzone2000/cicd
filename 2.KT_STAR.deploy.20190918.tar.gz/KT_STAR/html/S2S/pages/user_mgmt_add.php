<?php
include "session_chk.inc" ;

$ID = trim($_POST['ID']);
$PWD = trim($_POST['PWD']);
$OPER_NAME = trim($_POST['OPER_NAME']);
$LEVEL = trim($_POST['LEVEL']);
$STATUS = trim($_POST['STATUS']);
#echo "# Argument: ID > {$ID}\n";


if (!$ID or !$PWD) {
	$FULLURL = "./user_mgmt.php?add=1";
	#echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {

function dec_enc($action, $string) {
    $output = false;

    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my SECRET key';
    $secret_iv = 'This is my SECRET iv';

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}


	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		$FULLURL = "./user_mgmt.php?add=9999";

		$select_sql = "select id from User where id = '{$ID}' " ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['id'];

		if (!isset($isset_num)) {

			if (!$OPER_NAME) $OPER_NAME = $ID ;
			$encrypted_string = dec_enc('encrypt',$PWD);

			# 설정 추가 화면
			# Insert User table
			$insert_sql = "INSERT into User values ('{$ID}', '{$encrypted_string}', '{$OPER_NAME}', '{$LEVEL}', '{$STATUS}' ,'')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			#echo "# SQL : {$insert_sql} , Result : $res";
			#echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			$FULLURL = "./user_mgmt.php?add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}
}

?> 
