<?php
include "session_chk.inc" ;

$STR_VALUE = trim($_POST['STR_VALUE']);
#echo "# Argument: STR_VALUE > {$STR_VALUE} <br>";

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

	$FULLURL = "./set_controll.php?modify=1";

	# 설정 수정 화면
	# Update System_parm_chk table

	$update_sql = "UPDATE System_parm_chk set str_value = '{$STR_VALUE}' where num = 4" ;
	#echo "# SQL : {$update_sql}";
	#echo "<br>";
	$res = mysqli_query($mysqli,$update_sql);

	header('Location: '.$FULLURL);

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
