<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title>STAR(System Total Access Restriction)</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php"><img src="../vendor/login/kt_star_top2.PNG" width=130></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

if($_GET['input_date']){
        $INPUT_DATE = $_GET['input_date'];
}
else {
        $INPUT_DATE = date("Y-m-d");
}

if($_GET['input_date1']){
        $INPUT_DATE1 = $_GET['input_date1'];
}
else {
        $INPUT_DATE1 = date("Y-m-d");
}

if($_GET['input_chkbox'] == 'on') {

        // S2S_ABNORMAL_REALTIME : num = 3

        $chkbox = 'checked';
        $update_sql = "UPDATE System_parm_chk SET str_value = 'Y' where num = 3" ;
        $res = mysqli_query($mysqli,$update_sql);
        ###echo "chkbox ON: Stated!! <br>";
}
else if ($_GET['input_chkbox'] == 'off') {

        $update_sql = "UPDATE System_parm_chk SET str_value = 'N' where num = 3" ;
        $res = mysqli_query($mysqli,$update_sql);
        ###echo "chkbox OFF : Pressed!! <br>";
}
else
{
        $chk_sql = "select * from System_parm_chk where num = 3 and str_value = 'Y' ";
        $res5 = mysqli_query($mysqli,$chk_sql);
        ###echo "# SQL: {$chk_sql} , Result : $res5\n" ;

        $data = mysqli_fetch_array($res5);
        $isset_num = $data['num'];
        if (isset($isset_num)) $chkbox = 'checked';
        else $chkbox = '';
}

?>



<script>
        function checkBox(chkbox1)
        {
                if (chkbox1.checked == true) {
<?php
                        echo "window.open('./abnormal_cmd.php?input_chkbox=on','_self')";
?>
                }
                else {
<?php
                        echo "window.open('./abnormal_cmd.php?input_chkbox=off','_self')";
?>
                }
        }
</script>


<script type="text/javascript" src="../vendor/jquery/jquery.min.js"></script>
<script type="text/javascript">
    var auto_refresh = setInterval(
    function ()
    {

<?php

        if ($chkbox == 'checked')
        {
                $INPUT_DATE = date("Y-m-d");
                echo "$('#content_sub_all').load('./abnormal_cmd1.php?input_date={$INPUT_DATE}');" ;
        }

?>

    }, 5000); // refresh every 5000 milliseconds
</script>




        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">비정상 명령어</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">


<?php
                        echo "<table>";
                        echo "<tr><td width=800><font size=3><i class='fa fa-info-circle fa-fw'></i>&nbsp;비정상 명령어(접속시간 위반/접속IP 위반/설정명령 위반)는 명령 실행시 탐지되며 기본적으로 차단된다.</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->




                        <div class="panel-body">

                          <div class="row">
                            <div class="col-lg-6">
                              <div class="label_info" style="margin-bottom: 5px;padding: 4px 12px;">




<?php

        if($_GET['input_chkbox'] == 'on' or $chkbox == 'checked') {
                $DISABLED = "disabled";
        }
                	echo "<form action='abnormal_cmd.php'>";
                        echo "<table>";
                        echo "<tr><td width=240><i class='fa fa-calendar fa-fw'></i>&nbsp;&nbsp;<font size=3>From:&nbsp;&nbsp;</font>";
                        echo "<input type=date name=input_date value='{$INPUT_DATE}' {$DISABLED}></td>";
                        echo "<td><font size=3>&nbsp;&nbsp;&nbsp;~&nbsp;&nbsp;&nbsp;To:&nbsp;&nbsp;</font>";
                        echo "<input type=date name=input_date1 value='{$INPUT_DATE1}' {$DISABLED}></td>";
			echo "<td width=30><td>";
                        echo "<td><button class='btn btn-primary btn-block' type=submit {$DISABLED}><b>입력</b></button></td>";
                        echo "<td width=230 align=right>";
                        echo "<form action='abnormal_cmp.php'>";
                        echo "<font size=3 color=green>실시간체크(5초)</font></td>";
                        echo "<td width=70 align=right><label class=switch>";
                        echo "<input type=checkbox name=input_chkbox value=1 onClick='checkBox(this)' {$chkbox}>";
                        echo "<span class='slider round'></span>";
                        echo "</label>";
                        echo "</form>";
                        echo "</td></tr>";
                        echo "</table>";
                        echo "</form>";
?>



                              </div>
                            </div>
                            <div class="col-lg-6">
                            </div>
                          </div>  <!-- row -->

                          <div class="row">
                            <div class="col-lg-12">
                            </div>
                          </div>


                          <div class="row">
                            <div class="col-lg-12">




                        <div id="content_sub_all" class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Time</th>
					<th>Blocking</th>
					<th>Rule</th>
                                        <th>Host</th>
                                        <th>User</th>
                                        <th>Source IP</th>
                                        <th>PID</th>
                                        <th>Pwd</th>
                                        <th>Command</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>

<?php

        $mydate=date("Y-m-d",time());
        $cmd_sql = "select * from input_cmd_list where cmd_status = 'B' and (block_gubun = 'I' or  block_gubun = 'C' or block_gubun = 'T') and date >= '{$INPUT_DATE}' and date <= '{$INPUT_DATE1}' order by date, time desc";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $date = $newArray['date'];
                        $time= $newArray['time'];
                        $host = $newArray['host'];
                        $user= $newArray['user'];
                        $sip = $newArray['sip'];
                        $pid = $newArray['pid'];
                        $pwd = $newArray['pwd'];
                        $cmd = $newArray['cmd'];
                        $cmd_gubun = $newArray['cmd_gubun'];
                        $cmd_status = $newArray['cmd_status'];
                        $block_gubun = $newArray['block_gubun'];
                        $block_gubun_rule = $newArray['block_gubun_rule'];
                        echo "<tr>";

                        if ($cmd_gubun == "N") {
                                $MSG1 = "N" ;
                                $BUTTON1 = "button button2" ;
                                $BALLON_MSG1 = "Normal Command" ;
                        }
                        else if ($cmd_gubun == "C") {
                                $MSG1 = "Cr" ;
                                $BUTTON1 = "button button3" ;
                                $BALLON_MSG1 = "Critical Command" ;
                        }
                        else {
                                $MSG1 = "Null" ;
                                $BUTTON1 = "button button4" ;
                                $BALLON_MSG1 = "Null" ;
                        }

                        if ($cmd_status == "E") {
                                $MSG2 = "E" ;
                                $BUTTON2 = "button button6" ;
                                $BALLON_MSG2 = "Command Executed" ;
                        }
                        else if ($cmd_status == "B"){
                                $MSG2 = "B" ;
                                $BUTTON2 = "button button5" ;
                                $BALLON_MSG2 = "Command Blocked" ;
                        }
                        else if ($cmd_status == "C"){
                                $MSG2 = "C" ;
                                $BUTTON2 = "button button7" ;
                                $BALLON_MSG2 = "Command Canceled" ;
                        }
                        else if ($cmd_status == "R"){
                                $MSG2 = "R" ;
                                $BUTTON2 = "button button8" ;
                                $BALLON_MSG2 = "Command Rejected" ;
                        }
                        else {
                                $MSG2 = "Null" ;
                                $BUTTON2 = "button button4" ;
                                $BALLON_MSG2 = "Null" ;
                        }

                        if ($MSG1 == "Null" and $cmd_status == "B"){
                                $BUTTON1 = "button button7" ;
                                if ($block_gubun == 'C') {
                                        $BALLON_MSG1 = "Command Block";
                                        $color = "red";
                                        $MSG1 = "cmd";
                                        $MSG5 = "set_command.php";
                                }
                                else if ($block_gubun == 'T') {
                                        $BALLON_MSG1 = "Time Block";
                                        $color = "blue";
                                        $MSG1 = "time";
                                        $MSG5 = "set_time.php";
                                }
                                else if ($block_gubun == 'I') {
                                        $BALLON_MSG1 = "IP Block";
                                        $color = "green";
                                        $MSG1 = "IP";
                                        $MSG5 = "set_ip.php";
                                }

				echo "<td width=100>{$date}</td><td>{$time}</td><td width=120><font color={$color}>{$BALLON_MSG1}</font></td><td width=70><a href='{$MSG5}'>{$block_gubun_rule}</a></td><td>{$host}</td><td>{$user}</td><td>{$sip}</td><td>{$pid}</td><td>{$pwd}</td><td>{$cmd}</td>";
                                echo "<td width=95><center><a title='{$BALLON_MSG2}'><button class='{$BUTTON2}' type=button disabled><b>{$MSG2}</b></button></a>";
                                echo "&nbsp;&nbsp;<a title='{$BALLON_MSG1}'><button class='{$BUTTON1}' type=button disabled><b>{$MSG1}</b></button></a></td>";

                        }
                        else {

				echo "<td width=100>{$date}</td><td>{$time}</td><td width=120><font color={$color}>{$BALLON_MSG1}</font></td><td width=70><a href='{$MSG5}'>{$block_gubun_rule}</a></td><td>{$host}</td><td>{$user}</td><td>{$sip}</td><td>{$pid}</td><td>{$pwd}</td><td>{$cmd}</td>";
                                echo "<td width=95><center><a title='{$BALLON_MSG1}'><button class='{$BUTTON1}' type=button disabled><b>{$MSG1}</b></button></a>";
                                if ($cmd_gubun == "C" and $cmd_status == "E") {
                                        $BALLON_MSG2 = "Command Approved" ;
                                        echo "&nbsp;&nbsp;<a title='{$BALLON_MSG2}'><button class='button button2' type=button disabled><b>A</b></button></a>";
                                }
                                echo "&nbsp;&nbsp;<a title='{$BALLON_MSG2}'><button class='{$BUTTON2}' type=button disabled><b>{$MSG2}</b></button></a></td>";

                        }

                        echo "</tr>";
                }
        }

        mysqli_free_result($res);
        mysqli_close($mysqli);


?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->



                                </div>
                            </div>
                          </div>



                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
