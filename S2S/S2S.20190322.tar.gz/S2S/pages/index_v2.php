<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="refresh" content="3600">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title>STAR (System Total Access Restriction)</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->


    <!-- Charts.js -->
    <script src="../vendor/chart/Chart.bundle.js"></script>
    <script src="../vendor/chart/utils.js"></script>
    <style>
    canvas{
             -moz-user-select: none;
             -webkit-user-select: none;
             -ms-user-select: none;
    }
    </style>


<script type="text/javascript" src="../vendor/jquery/jquery.min.js"></script>
<script type="text/javascript">
    var auto_refresh = setInterval(
    function ()
    {

<?php
                echo "$('#content_sub_all').load('./index_panel.php');" ;
?>

    }, 10000); // refresh every 10000 milliseconds
</script>


</head>

<body>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

?>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php"><img src="../vendor/login/kt_star_top2.PNG" width=130></a>
            </div>
            <!-- /.navbar-header -->





            <ul class="nav navbar-top-links navbar-right">

		<li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
		</li>




                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Dashboard</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>





            <!-- /.row -->
            <div id="content_sub_all" class="row">

                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tasks fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">

<?php

$INPUT_DATE = date("Y-m-d");
$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' ";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$totalcount  = $row["count"];

                                    echo "<div class=huge>$totalcount</div>";

?>

                                    <div>Commands Count</div>
                                </div>
                            </div>
                        </div>
                        <a href="./search.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-warning fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">

<?php

$INPUT_DATE = date("Y-m-d");
$sql = "select count(*) as count from input_cmd_list where cmd_status = 'B' and (block_gubun = 'I' or  block_gubun = 'C' or block_gubun = 'T') and date = '{$INPUT_DATE}'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$abnormalcount  = $row["count"];

                                    echo "<div class=huge>$abnormalcount</div>";

?>

                                    <div>Abnormal Commands Count</div>
                                </div>
                            </div>
                        </div>
                        <a href="./abnormal_cmd.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>



                <div class="col-lg-1 col-md-3">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
<!--
                                <div class="col-xs-3">
                                    <i class="fa fa-warning fa-2x"></i>
                                </div>
-->
                                <div class="col-xs-9 text-right">

<?php

$INPUT_DATE = date("Y-m-d");
$sql = "select count(*) as count from input_cmd_list where cmd_status = 'B' and block_gubun ='T' and date = '{$INPUT_DATE}'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$totalcount  = $row["count"];

                                    echo "<h3>$totalcount </h3>";

?>

                                    <div>Time</div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <span class="pull-left"></span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>


                <div class="col-lg-1 col-md-3">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
<!--
                                <div class="col-xs-3">
                                    <i class="fa fa-warning fa-2x"></i>
                                </div>
-->
                                <div class="col-xs-9 text-right">

<?php

$INPUT_DATE = date("Y-m-d");
$sql = "select count(*) as count from input_cmd_list where cmd_status = 'B' and block_gubun ='I' and date = '{$INPUT_DATE}'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$totalcount  = $row["count"];

                                    echo "<h3>$totalcount</h3>";

?>

                                    <div>IP</div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <span class="pull-left"></span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>


                <div class="col-lg-1 col-md-3">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
<!--
                                <div class="col-xs-3">
                                    <i class="fa fa-warning fa-2x"></i>
                                </div>
-->
                                <div class="col-xs-9 text-right">

<?php

$INPUT_DATE = date("Y-m-d");
$sql = "select count(*) as count from input_cmd_list where cmd_status = 'B' and block_gubun ='C' and date = '{$INPUT_DATE}'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$totalcount  = $row["count"];

                                    //echo "<div class=huge>$totalcount</div>";
                                    echo "<h3>$totalcount</h3>";

?>

                                    <div>Command</div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <span class="pull-left"></span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>








                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-rocket fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">

<?php

$INPUT_DATE = date("Y-m-d");
$sql = "select count(*) as count from input_cmd_list where date = '{$INPUT_DATE}' and cmd_gubun = 'C'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$approvecount  = $row["count"];

                                    echo "<div class=huge>$approvecount</div>";

?>


                                    <div>Command Approve Count</div>
                                </div>
                            </div>
                        </div>
                        <a href="./command_approve.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>



            </div>
            <!-- /.row -->










            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> 시스템에서 발생된 명령에 대한 흐름 Line Chart (30일간)
                            <div class="pull-right">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                                        Actions
                                        <span class="caret"></span>
                                    </button>
                                </div>
                            </div>

                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">




	<div id='charts.js'>
		<canvas id="canvas"></canvas>
	</div>

<?php

$DAYS = -30;
$INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));

$sql = "select date,cmd_total from Statistic where date >= '{$INPUT_DATE}' order by date asc";
$res = mysqli_query($mysqli,$sql);

if ($res) {

	$CNT = 0;
	$Date_Str = '';
	$Count_Str = '';
	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
		$date = $newArray['date'];
		$count= $newArray['cmd_total'];

        	if ($CNT == 0) {
                	$Date_Str = '\'' . $date . '\'';
                	$Count_Str = $count;
        	}
        	else {
                	$Date_Str = $Date_Str . ',' . '\'' . $date . '\'';
                	$Count_Str = $Count_Str . ',' . $count;
        	}

        	$CNT = $CNT + 1;

	}

}



$sql = "select date,cmd_block from Statistic where date >= '{$INPUT_DATE}' order by date asc";
$res = mysqli_query($mysqli,$sql);

if ($res) {

        $CNT = 0;
        $Date_Str1 = '';
        $Count_Str1 = '';
        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                $date = $newArray['date'];
                $count= $newArray['cmd_block'];

                if ($CNT == 0) {
                        $Date_Str1 = '\'' . $date . '\'';
                        $Count_Str1 = $count;
                }
                else {
                        $Date_Str1 = $Date_Str1 . ',' . '\'' . $date . '\'';
                        $Count_Str1 = $Count_Str1 . ',' . $count;
                }

                $CNT = $CNT + 1;

        }

}



$sql = "select date,cmd_crit from Statistic where date >= '{$INPUT_DATE}' order by date asc";
$res = mysqli_query($mysqli,$sql);

if ($res) {

        $CNT = 0;
        $Date_Str2 = '';
        $Count_Str2 = '';
        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                $date = $newArray['date'];
                $count= $newArray['cmd_crit'];

                if ($CNT == 0) {
                        $Date_Str2 = '\'' . $date . '\'';
                        $Count_Str2 = $count;
                }
                else {
                        $Date_Str2 = $Date_Str2 . ',' . '\'' . $date . '\'';
                        $Count_Str2 = $Count_Str2 . ',' . $count;
                }

                $CNT = $CNT + 1;

        }

}



?>

	<script>
		var config = {
			type: 'line',
			data: {
<?php
				echo "labels: [{$Date_Str}],";
?>
				datasets: [{
					label: '총 명령건수',
					backgroundColor: window.chartColors.red,
					borderColor: window.chartColors.red,
					data: [
<?php
						echo "$Count_Str";
?>
					],
					fill: false,
				}, {
					label: '비정상 명령건수',
					fill: false,
					backgroundColor: window.chartColors.blue,
					borderColor: window.chartColors.blue,
					data: [
<?php
						echo "$Count_Str1";
?>
					],
                                }, {
                                        label: '승인 명령건수',
                                        fill: false,
                                        backgroundColor: window.chartColors.yellow,
                                        borderColor: window.chartColors.yellow,
                                        data: [
<?php
						echo "$Count_Str2";
?>
					],

				}]
			},
			options: {
				responsive: true,
				title: {
					display: true,
					text: ''
				},
				tooltips: {
					mode: 'index',
					intersect: false,
				},
				hover: {
					mode: 'nearest',
					intersect: true
				},
				scales: {
					xAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Month'
						}
					}],
					yAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Value'
						}
					}]
				}
			}
		};

		window.onload = function() {
			var ctx = document.getElementById('canvas').getContext('2d');
			window.myLine = new Chart(ctx, config);
		};

	</script>


                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->





<?php

$INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));

$sql = "select sum(cmd_crit_execute) as cmd_c_e ,sum(cmd_crit_reject) as cmd_c_r ,sum(cmd_crit_cancel) as cmd_c_c ,sum(cmd_block_time) as cmd_b_t ,sum(cmd_block_ip) as cmd_b_i ,sum(cmd_block_cmd) as cmd_b_c from Statistic where date >= '{$INPUT_DATE}'";
$res = mysqli_query($mysqli,$sql);

if ($res) {

        $newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
        $cmd_c_e = $newArray['cmd_c_e'];
        $cmd_c_r = $newArray['cmd_c_r'];
        $cmd_c_c = $newArray['cmd_c_c'];
        $cmd_b_t = $newArray['cmd_b_t'];
        $cmd_b_i = $newArray['cmd_b_i'];
        $cmd_b_c = $newArray['cmd_b_c'];
	
	$PIE_STR = $cmd_c_e . ',' . $cmd_c_r . ',' . $cmd_c_c . ',' . $cmd_b_t . ',' . $cmd_b_i . ',' . $cmd_b_c . ',' ;
	
	$T_SUM = $cmd_c_e + $cmd_c_r + $cmd_c_c + $cmd_b_t + $cmd_b_i + $cmd_b_c ;
	$Ratio_cmd_c_e = round(($cmd_c_e/$T_SUM) * 100) ;
	$Ratio_cmd_c_r = round(($cmd_c_r/$T_SUM) * 100) ;
	$Ratio_cmd_c_c = round(($cmd_c_c/$T_SUM) * 100) ;
	$Ratio_cmd_b_t = round(($cmd_b_t/$T_SUM) * 100) ;
	$Ratio_cmd_b_i = round(($cmd_b_i/$T_SUM) * 100) ;
	$Ratio_cmd_b_c = round(($cmd_b_c/$T_SUM) * 100) ;
}

mysqli_free_result($res);
mysqli_close($mysqli);


?>


                <div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Critical / Block 명령에 대한 Pie Chart (30일간)
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">


	<div id="canvas-holder">
		<canvas id="chart-area"></canvas>
	</div>


        <script>

                var config1 = {
                        type: 'pie',
                        data: {
                                datasets: [{
                                        data: [
<?php
	echo "$PIE_STR" ; 
?>
                                        ],
                                        backgroundColor: [
                                                window.chartColors.red,
                                                window.chartColors.orange,
                                                window.chartColors.yellow,
                                                window.chartColors.green,
                                                window.chartColors.blue,
                                                window.chartColors.purple,
                                        ],
                                        label: 'Dataset 1'
                                }],
                                labels: [
                                        'Crit 명령실행',
                                        'Crit 명령거부',
                                        'Crit 명령취소',
                                        'Time 명령블록',
                                        'IP 명령볼록',
                                        '설정명령볼록'
                                ]
                        },
                        options: {
                                responsive: true
                        }
                };

                        var ctx1 = document.getElementById('chart-area').getContext('2d');
                        window.myPie = new Chart(ctx1, config1);

        </script>




                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->



                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-comment fa-fw"></i> Critical / Block 명령에 대한 비율 테이블
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                            <table width="100%" class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
                                <tbody>
                                    <tr>
                                        <td>Crit 명령실행</td>
					<?php
                                        	echo "<td><progress value=$Ratio_cmd_c_e max=100></progress>&nbsp;&nbsp;{$Ratio_cmd_c_e}%</td>";
						echo "<td>$Ratio_cmd_c_e/$T_SUM</td>";
					?>
                                    </tr>
                                    <tr>
                                        <td>Crit 명령거부</td>
					<?php
                                        	echo "<td><progress value=$Ratio_cmd_c_r max=100></progress>&nbsp;&nbsp;{$Ratio_cmd_c_r}%</td>";
						echo "<td>$Ratio_cmd_c_r/$T_SUM</td>";
					?>
                                    </tr>
                                    <tr>
                                        <td>Crit 명령취소</td>
					<?php
                                        	echo "<td><progress value=$Ratio_cmd_c_c max=100></progress>&nbsp;&nbsp;{$Ratio_cmd_c_c}%</td>";
						echo "<td>$Ratio_cmd_c_c/$T_SUM</td>";
					?>
                                    </tr>
                                    <tr>
                                        <td>Time 명령블록</td>
					<?php
                                        	echo "<td><progress value=$Ratio_cmd_b_t max=100></progress>&nbsp;&nbsp;{$Ratio_cmd_b_t}%</td>";
						echo "<td>$Ratio_cmd_b_t/$T_SUM</td>";
					?>
                                    </tr>
                                    <tr>
                                        <td>IP 명령블록</td>
					<?php
                                        	echo "<td><progress value=$Ratio_cmd_b_i max=100></progress>&nbsp;&nbsp;{$Ratio_cmd_b_i}%</td>";
						echo "<td>$Ratio_cmd_b_i/$T_SUM</td>";
					?>
                                    </tr>
                                    <tr>
                                        <td>설정 명령볼록</td>
					<?php
                                        	echo "<td><progress value=$Ratio_cmd_b_c max=100></progress>&nbsp;&nbsp;{$Ratio_cmd_b_c}%</td>";
						echo "<td>$Ratio_cmd_b_c/$T_SUM</td>";
					?>
                                    </tr>
                                </tbody>
                            </table>




                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->

                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
