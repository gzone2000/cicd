<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$HOST = trim($_POST['HOST']);
$START_TIME = trim($_POST['START_TIME']);
$END_TIME = trim($_POST['END_TIME']);
$BLOCK_CONECT = trim($_POST['BLOCK_CONECT']);
#echo "# Argument: NUM > {$NUM}\n";
#echo "# Argument: START_TIME > {$START_TIME}\n";
#echo "# Argument: END_TIME > {$END_TIME}\n";
#echo "# Argument: BLOCK_CONECT > {$BLOCK_CONECT}\n";


if (!$HOST or !$START_TIME or !$END_TIME) {
	$FULLURL = "./set_time.php?add=1";
	#echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {


	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		$FULLURL = "./set_time.php?add=9999";

		$select_sql = "select num from Cmd_exe_time_chk where host = '{$HOST}' " ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['num'];

		if (!isset($isset_num)) {

			# 설정 추가 화면
			# Insert Cmd_exe_time_chk table
			$insert_sql = "INSERT into Cmd_exe_time_chk values ('{$NUM}', '{$HOST}', '{$START_TIME}', '{$END_TIME}', '{$BLOCK_CONECT}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			#echo "# SQL : {$insert_sql} , Result : $res";
			#echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			$FULLURL = "./set_time.php?add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}
}

?> 
