<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
echo "<meta http-equiv=refresh content='5;URL=./command_approve.php'>";
?>

    <title>S2S All-In-One</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php"><img src="../vendor/login/kt_star_top2.PNG" width=130></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>


                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

if($_GET['input_date']){
        $INPUT_DATE = $_GET['input_date'];
}

if($_GET['hostname']){
        $HOSTNAME = $_GET['hostname'];
}

if($_POST['a_utime']){
        $UTIME = $_POST['a_utime'];
        $ACCEPT = 'Y';
        ###echo "# a_utime : {$UTIME} , ACCEPT : {$ACCEPT}";
        ###echo "<br>";
}
else if($_POST['c_utime']){
        $UTIME = $_POST['c_utime'];
        $ACCEPT = 'N';
        ###echo "# c_utime : {$UTIME} , ACCEPT : {$ACCEPT}";
        ###echo "<br>";
}


?>


        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">명령어 승인 결과</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">



<?php

        if ($ACCEPT == "Y") {
                # E: Execute , ack = Y : Accept
                $update_sql = "UPDATE input_cmd_list SET ack = 'Y', cmd_status = 'E' where utime = '{$UTIME}' " ;
                $res = mysqli_query($mysqli,$update_sql);
		$Result1 = "승인";
        }
        else {
                # R : Reject , ack = Y : Reject
                $update_sql = "UPDATE input_cmd_list SET ack = 'Y', cmd_status = 'R' where utime = '{$UTIME}' " ;
                $res = mysqli_query($mysqli,$update_sql);
		$Result1 = "반려";
        }

                        echo "<table>";
			echo "<td width=350><i class='fa fa-table fa-fw'></i>&nbsp;&nbsp;명령어 승인 결과 : <font color=blue><b>$Result1 </b></font></td>";
                        echo "</td></tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->

                        <div id="content_sub_all" class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Host</th>
                                        <th>User</th>
                                        <th>Source IP</th>
                                        <th>PID</th>
                                        <th>Pwd</th>
                                        <th>Command</th>
					<th>Server PID</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>

<?php

	$cmd_sql = "select * from input_cmd_list where utime = '{$UTIME}' ;" ;

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $date = $newArray['date'];
                        $time= $newArray['time'];
                        $utime= $newArray['utime'];
                        #$cancel_utime= $newArray['cancel_utime'];
                        $host = $newArray['host'];
                        $user= $newArray['user'];
                        $sip = $newArray['sip'];
                        $pid = $newArray['pid'];
                        $pwd = $newArray['pwd'];
                        $cmd = $newArray['cmd'];
                        $ack = $newArray['ack'];
                        $remark = $newArray['remark'];
                        $cmd_status = $newArray['cmd_status'];
                        $REAL_UTIME = microtime(true);

                        if($cmd_status) {

                                if ($cmd_status == "E" ) {
                                        $MSG = "Accepted" ;
                                        $BUTTON = "button button2" ;
                                }
                                else if ($cmd_status == "R" ) {
                                        $MSG = "Rejected" ;
                                        $BUTTON = "button button_p4" ;
                                }
                                else if ($cmd_status == "C" ) {
                                        $MSG = "Canceled" ;
                                        $BUTTON = "button button7" ;
                                }

                                $COLOR="black";
                                echo "<tr><td width=105><font color={$COLOR}>{$date}</font></td><td width=80><font color={$COLOR}>{$time}</font></td><td width=200>{$host}</td><td width=55>{$user}</td><td width=110>{$sip}</td><td width=65>{$pid}</td><td width=180>{$pwd}</td><td width=340>{$cmd}</td width=75><td>{$remark}</td>";
                                echo "<td width=115><center><button class='{$BUTTON}' type=button disabled><b>{$MSG}</b></button></td>";
                                echo "</tr>";

                        }
                        else {
                                $COLOR="red";
                                $SIZE=4;
                                echo "<tr><td width=105>{$date}</td><td width=80>{$time}</td><td width=200>{$host}</td><td width=55>{$user}</td><td width=110>{$sip}</td><td width=65>{$pid}</td><td width=180>{$pwd}</td><td width=340><font size={$SIZE} color={$COLOR}><b>{$cmd}</b></font></td><td width=75>{$remark}</td>";

                                if (!$INPUT_DATE and !$HOSTNAME )
                                        echo "<td width=115><form action=./cmd_approve_result.php method=post>";
                                else {
                                        if ($INPUT_DATE and !$HOSTNAME )
                                                echo "<td width=115><form action=./cmd_approve_result.php?input_date={$INPUT_DATE} method=post>";
                                        else if (!$INPUT_DATE and $HOSTNAME )
                                                echo "<td width=115><form action=./cmd_approve_result.php?hostname={HOSTNAME} method=post>";
                                        else
                                                echo "<td width=115><form action=./cmd_approve_result.php?input_date={$INPUT_DATE}&hostname={HOSTNAME} method=post>";
                                }




                                echo "<center><button class='button button_p6' type=submit name=a_utime value={$utime} ><b>Accept</b></button>";
                                echo "<button class='button button_p3' type=submit name=c_utime value={$utime} ><b>Reject</b></button>";
                                echo "</form></td></tr>";
                        }

                }
        }


        mysqli_free_result($res);
        mysqli_close($mysqli);


?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
