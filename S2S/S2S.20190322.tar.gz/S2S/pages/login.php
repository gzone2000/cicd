<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../vendor/login/util.css">
        <link rel="stylesheet" type="text/css" href="../vendor/login/main.css">

</head>
<body>

	<div class="limiter">
		<div class="container-login100">
                        <div class="wrap-input100" align=center>
			        <center><img src="../vendor/login/kt_star_login1.PNG"></center>
			<div class="wrap-login100" style='background-image:url("../vendor/login/star.jpg")'>
				<div class="login100-pic js-tilt" data-tilt>
                                        <img width=200 src="../vendor/login/img-01.png" alt="IMG">
				</div>

				<form class="login100-form validate-form" method="POST" action="login_check.php">
					<font size=5 color=white><b>Member Login<b><br><br></font>

					<div class="wrap-input100 validate-input" data-validate = "id is required">
						<input class="input100" type="text" name="id" placeholder="아이디">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="pwd" placeholder="패스워드">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Login
						</button>
					</div>

					<div class="text-center p-t-12">
					        <!--
						<span class="txt1">
							Forgot
						</span>
						<a class="txt2" href="#">
							Username / Password?
						</a>
					        -->
					</div>

					<div class="text-center p-t-136">
					        <!--
						<a class="txt2" href="#">
							Create your Account
							<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
						</a>
					        -->
					</div>
				</form>
			</div>
			</div>
		</div>
	</div>


        <script src="../vendor/login/jquery-3.2.1.min.js"></script>
        <script src="../vendor/login/popper.js"></script>
        <script src="../vendor/login/bootstrap.min.js"></script>
        <script src="../vendor/login/select2.min.js"></script>
        <script src="../vendor/login/tilt.jquery.min.js"></script>
        <script >
                $('.js-tilt').tilt({
                        scale: 1.1
                })
        </script>

        <script src="../vendor/login/main.js"></script>


</body>
</html>

