<?php

# Menu Name
$MENU0 = " Dashboard";
$MENU1 = " 검색";
$MENU2 = " 실시간 명령어";
$MENU3 = " 비정상 명령어";
$MENU4 = " 명령어 승인";
$MENU5 = " 설정";
$MENU5_1 = " 접속시간 설정";
$MENU5_2 = " 접속IP 설정";
$MENU5_3 = " 명령제어 설정";
$MENU5_4 = " 통제기능 설정";
$MENU5_5 = " MGMT IP 설정";
$MENU6 = " 통계";
$MENU6_1 = " 명령 현황 통계";
$MENU6_2 = " 접속 IP 통계";
$MENU7 = " 계정관리";
$MENU8 = " 도움말";
$MENU9 = " 로그인";
$MENU9_1 = " 활성 로그인 현황";
$MENU9_2 = " 로그인 접속 히스토리";

?>

