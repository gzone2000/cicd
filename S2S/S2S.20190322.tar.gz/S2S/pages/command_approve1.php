<?php

session_start();
if (!$_SESSION[ss_id]) {
        header('Location: ./logout.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<body>


<?php

include "css.php" ;

$TODAY = date("Y-m-d",time());

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

if($_GET['input_date']){
        $INPUT_DATE = $_GET['input_date'];
}
else {
        $INPUT_DATE = date("Y-m-d");
}

?>

                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Host</th>
                                        <th>User</th>
                                        <th>Source IP</th>
                                        <th>PID</th>
                                        <th>Pwd</th>
                                        <th>Command</th>
					<th>Server PID</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>

<?php

        $mydate=date("Y-m-d",time());
	$cmd_sql = "select * from input_cmd_list where date >= '{$INPUT_DATE}' and cmd_gubun = 'C' order by date desc, time desc ;" ;
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $date = $newArray['date'];
                        $time= $newArray['time'];
                        $utime= $newArray['utime'];
                        #$cancel_utime= $newArray['cancel_utime'];
                        $host = $newArray['host'];
                        $user= $newArray['user'];
                        $sip = $newArray['sip'];
                        $pid = $newArray['pid'];
                        $pwd = $newArray['pwd'];
                        $cmd = $newArray['cmd'];
                        $ack = $newArray['ack'];
                        $remark = $newArray['remark'];
                        $cmd_status = $newArray['cmd_status'];
                        $REAL_UTIME = microtime(true);

                        if($cmd_status) {

                                if ($cmd_status == "E" ) {
                                        $MSG = "Accepted" ;
                                        $BUTTON = "button button2" ;
                                }
                                else if ($cmd_status == "R" ) {
                                        $MSG = "Rejected" ;
                                        $BUTTON = "button button_p4" ;
                                }
                                else if ($cmd_status == "C" ) {
                                        $MSG = "Canceled" ;
                                        $BUTTON = "button button7" ;
                                }

                                $COLOR="black";
                                echo "<tr><td width=105><font color={$COLOR}>{$date}</font></td><td width=80><font color={$COLOR}>{$time}</font></td><td width=200>{$host}</td><td width=55>{$user}</td><td width=110>{$sip}</td><td width=65>{$pid}</td><td width=180>{$pwd}</td><td width=340>{$cmd}</td width=75><td>{$remark}</td>";
                                echo "<td width=115><center><button class='{$BUTTON}' type=button disabled><b>{$MSG}</b></button></td>";
                                echo "</tr>";

                        }
                        else {
                                $COLOR="red";
                                $SIZE=4;
                                echo "<tr><td width=105>{$date}</td><td width=80>{$time}</td><td width=200>{$host}</td><td width=55>{$user}</td><td width=110>{$sip}</td><td width=65>{$pid}</td><td width=180>{$pwd}</td><td width=340><font size={$SIZE} color={$COLOR}><b>{$cmd}</b></font></td><td width=75>{$remark}</td>";

                                if (!$INPUT_DATE and !$HOSTNAME )
                                        echo "<td width=115><form action=./cmd_approve_result.php method=post>";
                                else {
                                        if ($INPUT_DATE and !$HOSTNAME )
                                                echo "<td width=115><form action=./cmd_approve_result.php?input_date={$INPUT_DATE} method=post>";
                                        else if (!$INPUT_DATE and $HOSTNAME )
                                                echo "<td width=115><form action=./cmd_approve_result.php?hostname={HOSTNAME} method=post>";
                                        else
                                                echo "<td width=115><form action=./cmd_approve_result.php?input_date={$INPUT_DATE}&hostname={HOSTNAME} method=post>";
                                }




                                echo "<center><button class='button button_p6' type=submit name=a_utime value={$utime} ><b>Accept</b></button>";
                                echo "<button class='button button_p3' type=submit name=c_utime value={$utime} ><b>Reject</b></button>";
                                echo "</form></td></tr>";
                        }

                }
        }


        mysqli_free_result($res);
        mysqli_close($mysqli);


?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->


    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
