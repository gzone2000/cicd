<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$ORG_NUM = trim($_POST['ORG_NUM']);
$IP = trim($_POST['IP']);
$SUBNET = trim($_POST['SUBNET']);
$BLOCK_CONECT = trim($_POST['BLOCK_CONECT']);
#echo "# Argument: NUM > {$NUM}\n";
#echo "# Argument: IP > {$IP}\n";
#echo "# Argument: SUBNET > {$SUBNET}\n";
#echo "# Argument: BLOCK_CONECT > {$BLOCK_CONECT}\n";

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

        function mask2cidr($mask){
                $long = ip2long($mask);
                $base = ip2long('255.255.255.255');
                return 32-log(($long ^ $base)+1,2);
        }

	$SUBNET = mask2cidr($SUBNET);

	$FULLURL = "./set_ip.php?modify=1";

	# 설정 수정 화면
	# Update Cmd_exe_time_chk table

	if( $NUM == 9999) {
		$update_sql = "UPDATE Connect_IP_chk set block_conect = '{$BLOCK_CONECT}' where num = {$NUM}" ;
	}
	else {
		if($NUM == $ORG_NUM) $update_sql = "UPDATE Connect_IP_chk set ip = '{$IP}' , subnet = '{$SUBNET}' , block_conect = '{$BLOCK_CONECT}' where num = {$NUM}" ;
		else {

                	$select_sql = "select num from Connect_IP_chk where num = {$NUM}" ;
                	$res5 = mysqli_query($mysqli,$select_sql);
                	#echo "# SQL: {$select_sql} " ;

                	$data = mysqli_fetch_array($res5);
                	$isset_num = $data['num'];

                	if (!isset($isset_num)) {
				$update_sql = "UPDATE Connect_IP_chk set num = {$NUM} , ip = '{$IP}' , subnet = '{$SUBNET}' , block_conect = '{$BLOCK_CONECT}' where num = {$ORG_NUM}" ;
			}
			else {
                        	$FULLURL = "./set_ip.php?modify=2";
                        	#echo "# URL : {$FULLURL}";
                        	header('Location: '.$FULLURL);
			}

		}
	}

	#echo "# SQL : {$update_sql}";
	#echo "<br>";
	$res = mysqli_query($mysqli,$update_sql);

	header('Location: '.$FULLURL);

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
