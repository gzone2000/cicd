<?php

session_start();
if (!$_SESSION[ss_id]) {
        header('Location: ./logout.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
include "ip.inc" ;
?>

    <title>STAR(System Total Access Restriction)</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];


	if (isset($_GET['command']))
	{


/*

# Ansible Directory
$ANSIBLE_DIR = "/home/ansible";
$ANSIBLE_PLAYBOOK_DIR = "$ANSIBLE_DIR/playbook";
$ANSIBLE_HOST_DIR = "$ANSIBLE_DIR/host";
$ANSIBLE_LOG_DIR = "$ANSIBLE_DIR/log";

*/


		//$CMD_LINE = shell_exec("cp $ANSIBLE_PLAYBOOK_DIR/cmd.yml.copy $ANSIBLE_PLAYBOOK_DIR/");
		//$CMD_LINE = shell_exec("cp $ANSIBLE_PLAYBOOK_DIR/cmd.yml $ANSIBLE_PLAYBOOK_DIR/");

		$ANSIBLE_PLAYBOOK_ORG = "${ANSIBLE_PLAYBOOK_DIR}/cmd.yml.copy" ;
		$ANSIBLE_PLAYBOOK_FILE = "${ANSIBLE_PLAYBOOK_DIR}/cmd.yml" ;
	
        	$COMMAND = trim(base64_decode($_GET['command']));
		$COMMAND = str_replace("|","\|",$COMMAND);
		$COMMAND = str_replace("\"","'",$COMMAND);
		$COMMAND = str_replace("(","\(",$COMMAND);
		$COMMAND = str_replace(")","\)",$COMMAND);
		$FULLSTR = "sed \"s|#CMD#|{$COMMAND}|\" $ANSIBLE_PLAYBOOK_ORG > $ANSIBLE_PLAYBOOK_FILE";
		echo "# Full Str : {$FULLSTR} <br>";
		echo "# COMMAND : {$COMMAND} <br>";
	
		$WHO = exec("whoami");
		echo "# USER : {$WHO} <br>";

		$PID = getmypid();
		echo "# PID : {$PID} <br>";

        	$REPLACE_STR = exec($FULLSTR,$output,$return) ;
		$CHECK_FILE = exec("cat $ANSIBLE_PLAYBOOK_FILE | grep '#CMD#' | wc -l");
		if ($return == 0 and $CHECK_FILE == 0) {
			###echo "Success!! <br>";
			###echo "Commmand Executing : $COMMAND <br><br><br>";
			echo "<br>";
			$CMD_LINE = shell_exec("ansible-playbook -i $ANSIBLE_HOST_DIR/hosts $ANSIBLE_PLAYBOOK_FILE >$ANSIBLE_LOG_DIR/log.txt 2>&1");
			$RESULT = shell_exec("$ANSIBLE_PLAYBOOK_DIR/parser.sh $ANSIBLE_LOG_DIR/log.txt 2>&1");
			echo "<pre>$RESULT</pre>";
		}
		else {
			echo "NOT Success!! <br>";
			foreach($output as $line) {
				echo "$line <br>";
			}
		}

	}



?> 

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>




</body>

</html>




