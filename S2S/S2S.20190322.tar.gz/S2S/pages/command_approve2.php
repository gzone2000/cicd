<?php

session_start();
if (!$_SESSION[ss_id]) {
        header('Location: ./logout.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<body>


<?php

include "css.php" ;

$TODAY = date("Y-m-d",time());

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$INPUT_DATE1 = date("Y-m-d");

$chk_sql = "select * from System_parm_chk where num = 2 and str_value = 'Y' ";
$res5 = mysqli_query($mysqli,$chk_sql);
###echo "# SQL: {$chk_sql} , Result : $res5\n" ;

$data = mysqli_fetch_array($res5);
$isset_num = $data['num'];
if (isset($isset_num)) {
        $chkbox = 'checked';
        $update_sql = "update input_cmd_list set cmd_status = 'E' , ack = 'Y' where cmd_gubun = 'C' and cmd_status is NULL";
        $res5 = mysqli_query($mysqli,$update_sql);
        ###echo "# SQL: {$update_sql} , Result : $res5\n" ;
}
else $chkbox = '';

?>


<script>
        function checkBox(chkbox1)
        {
                if (chkbox1.checked == true) {
<?php
                        echo "window.open('./command_approve.php?input_chkbox=on','_self')";
?>
                }
                else {
<?php
                        echo "window.open('./command_approve.php?input_chkbox=off','_self')";
?>
                }
        }
</script>

<?php

                           echo "<table id=content_sub_all_approve_switch>";

                           echo "<tr><td width=100 align=right>";
                           echo "<form action='command_approve.php'>";
                           echo "<td width=80 align=right>";
                           echo "<font size=3 color=green>일괄 승인</font>";
                           echo "<td width=70 align=right><label class=switch>";
                           echo "<input type=checkbox name=input_chkbox value=1 onClick='checkBox(this)' {$chkbox}>";
                           echo "<span class='slider round'></span>";
                           echo "</label>";
                           echo "</td>";
                           echo "</form>";
                           echo "</tr>";
                           echo "</table>";



?>


</body>
</html>
