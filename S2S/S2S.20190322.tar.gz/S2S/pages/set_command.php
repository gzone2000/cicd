<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title>STAR(System Total Access Restriction)</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php"><img src="../vendor/login/kt_star_top2.PNG" width=130></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];


?>



        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">명령제어 설정</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">


<?php

$cmd_sql = "select * from crit_cmd_list_v1 order by num" ;

                        echo "<table>";
                        echo "<tr><td width=500><font size=3><i class='fa fa-table fa-fw'></i>&nbsp;시스템에서 사용하는 명령어에 대한 허용/거부 설정:&nbsp;&nbsp;</font>";

			echo "<form action=./set_command.php>";
                        echo "<td><button class='btn btn-info btn-xs' type=submit name='ADD_NUM' value=9999><b>추가</b></button></td>";
                        echo "</tr>";
                        echo "</table>";
?>



                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-7">


                                 <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                 <thead>
                                    <tr>
                                        <th>번호</th>
                                        <th>호스트</th>
                                        <th>유저명</th>
                                        <th>명령어</th>
                                        <th>승인/허용/거부 여부</th>
                                        <th>수정</th>
                                        <th>삭제</th>
                                    </tr>
                                 </thead>
                                 <tbody>


<?php

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $num = $newArray['num'];
                        $host = $newArray['host'];
                        $user = $newArray['user'];
                        $crit_command = $newArray['crit_command'];
                        $apply = $newArray['apply'];

                        $crit_command = str_replace("\b","",$crit_command);

                        if ($apply == 'Y') $MSG1 = 'Approve';
                        else if ($apply == 'B') $MSG1 = 'Block';
                        else $MSG1 = 'Allow';

                        echo "<tr>";
			echo "<td width=70>{$num}</td><td width=90>{$host}</td><td width=90>{$user}</td><td width=120>{$crit_command}</td><td width=80>{$MSG1}</td>";

                        echo "<td width=50><form action=./set_command.php>";
                        echo "<center><button class='btn btn-warning btn-xs' type=submit name=MOD_NUM value={$num}><b><font size=2>수정</font></b></button></center></form></td>";

                        if ($num >= 9990) {
                                $DISABLED = "disabled";
                                $BUTTON = "btn btn-default btn-xs";
                        }
                        else $BUTTON = "btn btn-danger btn-xs";

                        echo "<td width=50><form action=./set_command.php>";
                        echo "<center><button class='{$BUTTON}' type=submit name=DEL_NUM value={$num} {$DISABLED}><b><font size=2>삭제</font></b></button></center></form></td>";

                        echo "</tr>";   
                }
        }

	echo "</table>"	;

?>




                                </div>
                                <!-- /.col-lg-6 (nested) -->




                                <div class="col-lg-5" >

<?php


if($_GET['MOD_NUM']){

	$num1 = trim($_GET['MOD_NUM']);
	$cmd_sql = "select * from crit_cmd_list_v1 where num = {$num1} " ;
	###echo "# SQL : {$cmd_sql}";
	###echo "<br>";
	$res5 = mysqli_query($mysqli,$cmd_sql);

        if ($res5) {
                while ($newArray = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                        $num = $newArray['num'];
                        $host = $newArray['host'];
                        $user = $newArray['user'];
                        $crit_command = $newArray['crit_command'];
                        $apply = $newArray['apply'];

                        $crit_command = str_replace("\\","&#92;",$crit_command);
                }
        }

	$DISABLED ='';
	if ($num >= 9990) {
		$DISABLED = 'disabled' ;
		$READONLY = 'readonly' ;
	}


	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 수정 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<form action=./set_command_mod.php method=POST>";

	echo "<table border=1>";
	echo "<tr><td width=160>";
	echo "<label class='control-label' for='inputSuccess'>ㅇ 번호 : </label>";
	echo "</td>";
	echo "<td>";
	echo "<input type='text' class='form-control' name=NUM value={$num} $READONLY>";
	echo "</td>";
	echo "<td>";
	echo "<input type='hidden' class='form-control' name=ORG_NUM value={$num1} $READONLY>";
	echo "</td><td></td></tr>";

        echo "<tr><td width=160>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 호스트 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=HOST value={$host} disabled>";
        echo "</td><td></td><td></td></tr>";

        echo "<tr><td width=160>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 유저명 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=USER value={$user} $DISABLED>";
	echo "</td>";
        echo "</td><td></td><td></td></tr>";

        echo "<tr><td width=160>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 명령어 : </label>";
        echo "</td>";
        echo "<td width=400>";
        echo "<input type='text' class='form-control' name=COMMAND value='{$crit_command}' $DISABLED>";
        echo "</td>";
        echo "</td><td></td><td></td></tr>";

        echo "<tr><td width=160>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 승인/허용/거부 여부 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<select class=form-control name=APPLY>";
        if($apply == 'Y') {
                echo "<option value=Y selected=selected>Approve</option>";
                echo "<option value=N>Allow</option>";
                echo "<option value=B>Block</option>";
        }
        else if($apply == 'B'){
                echo "<option value=Y>Approve</option>";
                echo "<option value=N>Allow</option>";
                echo "<option value=B selected=selected>Block</option>";
        }
        else {
                echo "<option value=Y>Approve</option>";
                echo "<option value=N selected=selected>Allow</option>";
                echo "<option value=B>Block</option>";
        }
        echo "</select>";
        echo "</td><td></td><td></td></tr>";
        echo "</table>";

	echo "<br>";
	echo "수정 하시겠습니까? &nbsp;&nbsp;&nbsp;";
	echo "<button type=submit class='btn btn-success'>수정</button>";
	echo "</form>";

	echo "</div>";

	echo "<br><br><br>";
	echo "<i class='fa fa-star fa-fw'></i><font>필요시 명령어 정확한 매칭을 위해 명령어 앞뒤에 '\b'를 추가하여 주시기 바랍니다.</font><br>";
	echo "예시) reboot 명령 정확한 매칭 -> \b<font color=blue>reboot</font>\b 입력</font>";

}

elseif($_GET['modify']){
	if($_GET['modify'] == 1) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 수정 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 수정 완료되었습니다.!! </b></font>";
		echo "</div>";
	}
	elseif($_GET['modify'] == 2) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 수정 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>번호가 중복됩니다. 확인 바랍니다.!! </b></font>";
		echo "</div>";
	}

}

elseif($_GET['ADD_NUM']){

	$cmd_sql = "select max(num) AS max_num from crit_cmd_list_v1 where num < 9990 ";
	###echo "# SQL : {$cmd_sql}";
	###echo "<br>";
	$res5 = mysqli_query($mysqli,$cmd_sql);
        $data = mysqli_fetch_array($res5);
        $isset_check2 = $data["max_num"];

	if (isset($isset_check2)) {


        	$isset_check2 = $isset_check2 + 1;

        	echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
        	echo "<br>";
        	echo "<br>";
		echo "<form action=./set_command_add.php method=POST>";

        	echo "<table border=1>";
        	echo "<tr><td width=160>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 번호 : </label>";
        	echo "</td>";
        	echo "<td>";
        	echo "<input type='text' class='form-control' name=NUM value={$isset_check2} readonly>";
        	echo "</td><td></td><td></td></tr>";

        	echo "<tr><td width=160>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 호스트 : </label>";
        	echo "</td>";
        	echo "<td>";
        	echo "<input type='text' class='form-control' name=HOST value='test01'>";
        	echo "</td><td></td><td></td></tr>";

        	echo "<tr><td width=160>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 유저명 : </label>";
        	echo "</td>";
        	echo "<td>";
        	echo "<input type='text' class='form-control' name=USER value='root'>";
		echo "</td>";
        	echo "</td><td></td><td></td></tr>";

        	echo "<tr><td width=160>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 명령어 : </label>";
        	echo "</td>";
        	echo "<td width=400>";
        	echo "<input type='text' class='form-control' name=COMMAND value='reboot'>";
        	echo "</td>";
        	echo "</td><td></td><td></td></tr>";

        	echo "<tr><td width=160>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 승인/허용/거부 여부 : </label>";
        	echo "</td>";
        	echo "<td>";
        	echo "<select class=form-control name=APPLY>";
               	echo "<option value=Y selected=selected>Approve</option>";
               	echo "<option value=N>Allow</option>";
               	echo "<option value=B>Block</option>";
        	echo "</select>";
        	echo "</td><td></td><td></td></tr>";
        	echo "</table>";

        	echo "<br>";
		echo "추가 하시겠습니까? &nbsp;&nbsp;&nbsp;";
        	echo "<button type=submit class='btn btn-success'>추가</button>";
        	echo "</form>";

        	echo "</div>";
	
		echo "<br><br><br>";
		echo "<i class='fa fa-star fa-fw'></i><font>필요시 명령어 정확한 매칭을 위해 명령어 앞뒤에 '\b'를 추가하여 주시기 바랍니다.</font><br>";
		echo "예시) reboot 명령 정확한 매칭 -> \b<font color=blue>reboot</font>\b 입력</font>";

        }


}

elseif($_GET['add']){
	if ($_GET['add'] == 9999){
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 추가 완료되었습니다.!! </b></font>";
		echo "</div>";
	}
	elseif($_GET['add'] == 1) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>호스트나 시간항목에 빈 항목이 있습니다. 채워주시기 바랍니다.!! </b></font>";
		echo "</div>";
	}
	elseif($_GET['add'] == 2) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>호스트/유저/명령어가 중복됩니다. 확인 바랍니다.!! </b></font>";
		echo "</div>";
	}

}

elseif($_GET['DEL_NUM']){

	$num1 = trim($_GET['DEL_NUM']);
	$cmd_sql = "select * from crit_cmd_list_v1 where num = {$num1} " ;
	###echo "# SQL : {$cmd_sql}";
	###echo "<br>";
	$res5 = mysqli_query($mysqli,$cmd_sql);

        if ($res5) {
                while ($newArray = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                        $num = $newArray['num'];
                        $host = $newArray['host'];
                        $user = $newArray['user'];
                        $crit_command = $newArray['crit_command'];
                        $apply = $newArray['apply'];
                }
        }


	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='fa fa-trash-o'></i> 삭제 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<form action=./set_command_del.php method=POST>";

	echo "<table border=1>";
	echo "<tr><td width=160>";
	echo "<label class='control-label' for='inputSuccess'>ㅇ 번호 : </label>";
	echo "</td>";
	echo "<td>";
	echo "<input type='text' class='form-control' name=NUM value={$num} readonly>";
	echo "</td><td></td><td></td></tr>";

        echo "<tr><td width=160>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 호스트 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=HOST value={$host} disabled>";
        echo "</td><td></td><td></td></tr>";

        echo "<tr><td width=160>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 유저명 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<input type='text' class='form-control' name=USER value={$user} disabled>";
	echo "</td>";
        echo "</td><td></td><td></td></tr>";

        echo "<tr><td width=160>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 명령어: </label>";
        echo "</td>";
        echo "<td width=400>";
        echo "<input type='text' class='form-control' name=COMMAND value='{$crit_command}' disabled>";
        echo "</td>";
        echo "</td><td></td><td></td></tr>";

        echo "<tr><td width=160>";
        echo "<label class='control-label' for='inputSuccess'>ㅇ 승인/허용/거부 여부 : </label>";
        echo "</td>";
        echo "<td>";
        echo "<select class=form-control name=APPLY disabled>";
        if($apply == 'Y') {
                echo "<option value=Y selected=selected>Approve</option>";
                echo "<option value=N>Allow</option>";
                echo "<option value=B>Block</option>";
        }
        else if($apply == 'B'){
                echo "<option value=Y>Approve</option>";
                echo "<option value=N>Allow</option>";
                echo "<option value=B selected=selected>Block</option>";
        }
        else {
                echo "<option value=Y>¨öAAI</option>";
                echo "<option value=N selected=selected>Allow</option>";
                echo "<option value=B>Allow</option>";
        }

        echo "</select>";
        echo "</td><td></td><td></td></tr>";
        echo "</table>";

	echo "<br>";
	echo "정말로 삭제하시겠습니다까? &nbsp;&nbsp;&nbsp;";
	echo "<button type=submit class='btn btn-success'>삭제</button>";
	echo "</form>";

	echo "</div>";

}

elseif($_GET['delete']){
	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='fa fa-trash-o'></i> 삭제 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 삭제 완료되었습니다.!! </b></font>";
	echo "</div>";

}

mysqli_free_result($res);
mysqli_close($mysqli); 

?>


                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
