<?php

date_default_timezone_set("Asia/Seoul");
$DATE = date('Y-m-d');
$TIME = date('H:i:s');
$UTIME = microtime(true);
$HOST = trim($_POST['host']);
$USER = trim($_POST['user']);
$IP = trim($_POST['ip']);
$PID = trim($_POST['pid']);
$PWD = trim($_POST['pwd']);
$COMMAND = trim($_POST['command']);
$COMMAND = addslashes($COMMAND);
###echo "# Argument: date > {$DATE}\n";
###echo "# Argument: time > {$TIME}\n";
###echo "# Argument: utime > {$UTIME}\n";
###echo "# Argument: host > {$HOST}\n";
###echo "# Argument: user > {$USER}\n";
###echo "# Argument: ip > {$IP}\n";
###echo "# Argument: pid > {$PID}\n";
###echo "# Argument: pwd > {$PWD}\n";
###echo "# Argument: command > {$COMMAND}\n";

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        //printf("Connect failed: %s\n", mysqli_connect_error());
	exit("N ");
} 
else {

	# Insert input command
	$COMMAND=str_replace("#Y#","&",$COMMAND);
	$insert_sql = "INSERT INTO input_cmd_list (date, time, utime, host, user, sip, pid, pwd, cmd) VALUES ( '{$DATE}', '{$TIME}', '{$UTIME}', '{$HOST}','{$USER}', '{$IP}', '{$PID}', '{$PWD}', '{$COMMAND}' )" ;
	$res = mysqli_query($mysqli,$insert_sql);
	###echo "# SQL: {$insert_sql} , Result : $res\n" ;


	# S2S_CONTROLL_FUNCTION : Y -> S2S 통제 기능 활성화 , N --> S2S 통제 기능 비활성화
        $chk_sql = "select * from System_parm_chk where num = 4 ";
        $res5 = mysqli_query($mysqli,$chk_sql);
        ###echo "# SQL: {$chk_sql} , Result : $res5\n" ;

        $data = mysqli_fetch_array($res5);
        $isset_str_value = $data['str_value'];
        if ($isset_str_value == 'N') {

		# cmd_gubun : C : Critical cmd , N : Normal cmd , P : Passing cmd
		$update_sql1 = "UPDATE input_cmd_list SET cmd_gubun = 'P', cmd_status = 'E' where utime = '{$UTIME}' " ;
		###echo "# SQL: {$update_sql1}\n" ;
		$res8 = mysqli_query($mysqli,$update_sql1);

		mysqli_free_result($res);
		mysqli_close($mysqli); 
		exit("N ");

	}


	# Time Range Check Function
	function isWithinTimeRange($inputTime, $start, $end){
		if($start > $end) {
			if($inputTime >= $start || $inputTime < $end) return 1;
		}
		else if ($inputTime >= $start && $inputTime <= $end) return 1;

        	return 0;
	}

        # Checking Command execution Time 
	# block_conect = 'N' 이면 무조건 block 됨.
	# block_conect = 'Y' 이고 허용 시간 안에 들어 있으면 접속해서 명령 가능
	$select_sql = "select * from Cmd_exe_time_chk where host = '{$HOST}' or host = 'ALL' order by num";
	###echo "# SQL: {$select_sql}\n" ;
        $res = mysqli_query($mysqli,$select_sql);
        $num_rows = mysqli_num_rows($res);

        if ($num_rows > 0) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $t_num = $newArray['num'];
                        $t_host = $newArray['host'];
                        $t_start_time = $newArray['start_time'];
                        $t_end_time = $newArray['end_time'];
                        $t_block_conect = $newArray['block_conect'];

			$t_result = isWithinTimeRange("{$TIME}","{$t_start_time}","{$t_end_time}");
                        ###echo "host : $t_host ,start_time : $t_start_time ,end_time : $t_end_time ,block_connect : $t_block_conect ,TIME : $TIME , Result : $t_result \n" ;

			if ($t_result == 1 and $t_block_conect == 'N') {
				# time range : OK and Block : No --> 허용된 TIME 접속 
				###echo "Time range : OK and Block : No --> 허용된 TIME 접속 \n";
				break;
			}
			else if ($t_result == 1 and $t_block_conect == 'Y') {
				# ip range : OK and Block : Yes --> Block 접속 by Time
				# block_gubun : T = Time Block , C = Command Block , I = IP Block
				$update_sql = "UPDATE input_cmd_list SET cmd_status = 'B', block_gubun = 'T', block_gubun_rule = '{$t_num}' where utime = '{$UTIME}' ;" ;
				$res = mysqli_query($mysqli,$update_sql);

				###echo "Block Connection by Time!! \n";
				mysqli_free_result($res);
				mysqli_close($mysqli);
				$BLK_MSG = "BLK" . ".TIME" ;
				exit($BLK_MSG);
			}

		}

	}



	# IP Range Check Function
	function ip_in_range( $ip, $range, $netmask ) {
		$range_decimal = ip2long( $range );
		$ip_decimal = ip2long( $ip );
		$wildcard_decimal = pow( 2, ( 32 - $netmask ) ) - 1;
		$netmask_decimal = ~ $wildcard_decimal;
		return ( ( $ip_decimal & $netmask_decimal ) == ( $range_decimal & $netmask_decimal ) );
	}

        # Checking IP address 
	# block_conect = 'N' 이면 IP 접속 허용
	# block_conect = 'Y' 이면 IP 접속 차단
	date_default_timezone_set("Asia/Seoul");
	$select_sql = "select * from Connect_IP_chk where host = '{$HOST}' or host = 'ALL' order by num";
	###echo "# SQL: {$select_sql}\n" ;
        $res = mysqli_query($mysqli,$select_sql);
        $num_rows = mysqli_num_rows($res);

        if ($num_rows > 0) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $t_num = $newArray['num'];
                        $v_host = $newArray['host'];
                        $v_ip = $newArray['ip'];
                        $v_subnet = $newArray['subnet'];
                        $v_block_conect = $newArray['block_conect'];
                        ###echo "host : $v_host ,ip : $v_ip ,subnet : $v_subnet ,block_connect : $v_block_conect ,SIP : $IP \n" ;

			if ($v_ip != 'ALL') {
				$v_result = ip_in_range("{$IP}","{$v_ip}","{$v_subnet}");

				if ($v_result == 1 and $v_block_conect == 'N') {
					# ip range : OK and Block : No --> 허용된 IP 접속 
					###echo "ip range : OK and Block : No --> 허용된 IP 접속 \n";
					break;
				}
				else if ($v_result == 1 and $v_block_conect == 'Y') {
					# ip range : OK and Block : Yes --> Block IP 접속 
					# block_gubun : T = Time Block , C = Command Block , I = IP Block
					$update_sql = "UPDATE input_cmd_list SET cmd_status = 'B', block_gubun = 'I', block_gubun_rule = '{$t_num}' where utime = '{$UTIME}' ;" ;
					$res = mysqli_query($mysqli,$update_sql);

					###echo "Block Special IP Connection!! \n";
					mysqli_free_result($res);
					mysqli_close($mysqli);
					$BLK_MSG = "BLK" . ".IP" ;
					exit($BLK_MSG);
				}
			}
			else {
				if ($v_block_conect == 'N') {
					# DEFAULT Block : No --> 모든 IP 접속 허용 
					###echo "Allow ALL IP Connection!! \n";
					break;
				}
				else {
					# Block : Yes --> Block ALL IP 접속 
					# block_gubun : T = Time Block , C = Command Block , I = IP Block
					$update_sql = "UPDATE input_cmd_list SET cmd_status = 'B', block_gubun = 'I', block_gubun_rule = '{$t_num}' where utime = '{$UTIME}' ;" ;
					$res = mysqli_query($mysqli,$update_sql);

					###echo "Block ALL IP Connection!! \n";
					mysqli_free_result($res);
					mysqli_close($mysqli);
					$BLK_MSG = "BLK" . ".IP" ;
					exit($BLK_MSG);
				}
			}

		}

	}



	# Checking whether Critical Command is or not....
	###$PATTERN = " " ;
	###$ARR_COMMAND = split($PATTERN, $COMMAND);
        ###echo "# Real Command: {$ARR_COMMAND[0]}\n" ;

	$CRIT_CMD = 'N';
        $cmd_sql = "select * from crit_cmd_list_v1 where host = '{$HOST}' or host = 'ALL' order by num";
	###echo "# SQL: {$cmd_sql} \n" ;
        $res = mysqli_query($mysqli,$cmd_sql);
	$num_rows = mysqli_num_rows($res);

	if ($num_rows > 0) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $t_num = $newArray['num'];
                        $DB_USER = $newArray['user'];
                        $CRIT_COMMAND = $newArray['crit_command'];
			$APPLY = $newArray['apply'];
			if ($USER == $DB_USER or $DB_USER == 'ALL') {
				###echo "1. USER : $DB_USER , Critical CMD : $CRIT_COMMAND , Apply : $APPLY \n" ;
				if (preg_match("/{$CRIT_COMMAND}/", $COMMAND)) {
					if ($APPLY == 'Y') {
						$CRIT_CMD = 'Y';
						###echo "Break OK. Critcal cmd!! \n";
						break;
					}
					else if ($APPLY == 'B') {
						# block_gubun : T = Time Block , C = Command Block , I = IP Block
						$update_sql = "UPDATE input_cmd_list SET cmd_status = 'B', block_gubun = 'C', block_gubun_rule = '{$t_num}' where utime = '{$UTIME}' ;" ;
						$res7 = mysqli_query($mysqli,$update_sql);

						###echo "Block Command!! \n";
						mysqli_free_result($res);
						mysqli_close($mysqli);
						$BLK_MSG = "BLK" . ".CMD" ;
						exit($BLK_MSG);
					}
					else {
						# APPLY = N : normal 명령어로 허용
						break;
					}
				}
			}
		}
	}


	if ($CRIT_CMD == 'Y') {
		# cmd_gubun : C : Critical cmd , N : Normal cmd
		$update_sql1 = "UPDATE input_cmd_list SET cmd_gubun = 'C' where utime = '{$UTIME}' " ;
		###echo "# SQL: {$update_sql1}\n" ;
		$res8 = mysqli_query($mysqli,$update_sql1);
		echo "{$UTIME}";
	}
	else {
		# cmd_gubun : C : Critical cmd , N : Normal cmd
		$update_sql1 = "UPDATE input_cmd_list SET cmd_gubun = 'N', cmd_status = 'E' where utime = '{$UTIME}' " ;
		###echo "# SQL: {$update_sql1}\n" ;
		$res8 = mysqli_query($mysqli,$update_sql1);
		echo "N";
	}

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
