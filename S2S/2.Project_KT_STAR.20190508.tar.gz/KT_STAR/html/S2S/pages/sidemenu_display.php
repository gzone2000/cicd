                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="search.php"><i class="fa fa-search fa-fw"></i><?php echo " $MENU1"; ?></a>
                        </li>
                        <li>
                            <a href="realtime_cmd.php"><i class="fa fa-tasks fa-fw"></i><?php echo " $MENU2"; ?></a>
                        </li>
                        <li>
                            <a href="abnormal_cmd.php"><i class="fa fa-warning fa-fw"></i><?php echo " $MENU3"; ?></a>
                        </li>


<?php
if($_SESSION[auth_level] == '0') {
	echo "
                        <li>
                            <a href='command_approve.php'><i class='fa fa-rocket fa-fw'></i> $MENU4</a>
                        </li>
                        <li>
                            <a href='#'><i class='fa fa-gear fa-fw'></i> $MENU5<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='set_time.php'> $MENU5_1</a>
                                </li>
                                <li>
                                    <a href='set_ip.php'> $MENU5_2</a>
                                </li>
                                <li>
                                    <a href='set_command.php'> $MENU5_3</a>
                                </li>
                                <li>
                                    <a href='set_mgmt_ip.php'> $MENU5_5</a>
                                </li>
                                <li>
                                    <a href='set_controll.php'> $MENU5_4</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

	";

/* Ansible automation 
                        <li>
                            <a href='#'><i class='fa fa-automobile fa-fw'></i> $MENU9<span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='ansible_command.php'> $MENU9_1</a>
                                </li>
                                <li>
                                    <a href='ansible_inventory.php'> $MENU9_2</a>
                                </li>
                                <li>
                                    <a href='ansible_playbook.php'> $MENU9_3</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

*/

}
?>

                        <li>
                            <a href='#'><i class='fa fa-automobile fa-fw'></i> <?php echo " $MENU6"; ?><span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='command_stats.php'> <?php echo " $MENU6_1"; ?></a>
                                </li>
                                <li>
                                    <a href='connect_ip_stats.php'> <?php echo " $MENU6_2"; ?></a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>


<?php
if($_SESSION[auth_level] == '0') {
        echo "

                        <li>
                            <a href='user_mgmt.php'><i class='glyphicon glyphicon-user'></i> $MENU7</a>
                        </li>
        ";
}
?>

                        <li>
                            <a href='#'><i class='fa fa-desktop fa-fw'></i> <?php echo " $MENU9"; ?><span class='fa arrow'></span></a>
                            <ul class='nav nav-second-level'>
                                <li>
                                    <a href='login_active_list.php'> <?php echo " $MENU9_1"; ?></a>
                                </li>
                                <li>
                                    <a href='login_history.php'> <?php echo " $MENU9_2"; ?></a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>


                        <li>
                            <a href="help.php"><i class="glyphicon glyphicon-stats"></i><?php echo " $MENU8"; ?></a>
                        </li>

                    </ul>
