<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=$LOGO_SIZE></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


<?php

$TODAY = date("Y-m-d",time());

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

if($_GET['input_date']){
        $INPUT_DATE = $_GET['input_date'];
}
else {
        $INPUT_DATE = date("Y-m-d");
}

$INPUT_DATE1 = date("Y-m-d");

if($_GET['input_chkbox'] == 'on')
{
        $chkbox = 'checked';
        $update_sql = "UPDATE System_parm_chk SET str_value = 'Y' where num = 2" ;  # str_key : APPROVE_REALTIME
        $res = mysqli_query($mysqli,$update_sql);
        ###echo "chkbox ON: Stated!! <br>";
}
else if ($_GET['input_chkbox'] == 'off')
{
        $update_sql = "UPDATE System_parm_chk SET str_value = 'N' where num = 2" ;  # str_key : APPROVE_REALTIME
        $res = mysqli_query($mysqli,$update_sql);
        ###echo "chkbox OFF : Pressed!! <br>";
}
else
{
        $chk_sql = "select * from System_parm_chk where num = 2 and str_value = 'Y' ";
        $res5 = mysqli_query($mysqli,$chk_sql);
        ###echo "# SQL: {$chk_sql} , Result : $res5\n" ;

        $data = mysqli_fetch_array($res5);
        $isset_num = $data['num'];
        if (isset($isset_num)) $chkbox = 'checked';
        else $chkbox = '';
}

?>



<script>
        function checkBox(chkbox1)
        {
                if (chkbox1.checked == true) {
<?php
                        echo "window.open('./command_approve.php?input_chkbox=on','_self')";
?>
                }
                else {
<?php
                        echo "window.open('./command_approve.php?input_chkbox=off','_self')";
?>
                }
        }
</script>


<script type="text/javascript" src="../vendor/jquery/jquery.min.js"></script>
<script type="text/javascript">
    var auto_refresh = setInterval(
    function ()
    {

<?php

if (!$INPUT_DATE)
        echo "$('#content_sub_all').load('./command_approve1.php');" ;
else {
        echo "$('#content_sub_all').load('./command_approve1.php?input_date={$INPUT_DATE}');" ;
}
echo "$('#content_sub_all_approve_switch').load('./command_approve2.php');" ;

?>
    }, 5000); // refresh every 5000 milliseconds
</script>



        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">명령어 승인</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">


<?php
                        echo "<table>";
                        echo "<tr><td width=800><font size=3><i class='fa fa-info-circle fa-fw'></i>&nbsp;Critical 명령에 대해서 중앙의 관리자가 Accept해야 명령어가 실행되며 Reject시 명령은 취소된다..</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->




                        <div class="panel-body">

                          <div class="row">
                            <div class="col-lg-6">
                              <div class="label_info" style="margin-bottom: 5px;padding: 4px 12px;">





<?php

        if($_GET['input_chkbox'] == 'on' or $chkbox == 'checked') {
                $DISABLED = "disabled";
                $INPUT_DATE = date("Y-m-d");
        }

                        echo "<table>";
			echo "<tr><td>";
                           echo "<table>";
                           echo "<form action='command_approve.php'>";

                           echo "<tr><td width=250><i class='fa fa-calendar fa-fw'></i>&nbsp;&nbsp;<font size=3>From:&nbsp;&nbsp;</font>";
                           echo "<input type=date name=input_date value='{$INPUT_DATE}' {$DISABLED}></td>";
                           echo "<td><font size=3>&nbsp;&nbsp;&nbsp;~&nbsp;&nbsp;&nbsp;To:&nbsp;&nbsp;</font>";
                           echo "<input type=date name=input_date1 value='{$INPUT_DATE1}' disabled><td width=30><td>";
                           echo "<td><button class='btn btn-primary btn-block' type=submit><b>입력</b></button></td>";
			   echo "</tr>";
                           echo "</form>";
                           echo "</table>";
			echo "</td>";

			echo "<td>";
                           echo "<table id=content_sub_all_approve_switch>";
                           echo "<tr><td width=100 align=right>";
                           echo "<form action='command_approve.php'>";
                           echo "<td width=80 align=right>";
                           echo "<font size=3 color=green>일괄 승인</font></td>";
                           echo "<td width=70 align=right><label class=switch>";
                           echo "<input type=checkbox name=input_chkbox value=1 onClick='checkBox(this)' {$chkbox}>";
                           echo "<span class='slider round'></span>";
                           echo "</label>";
                           echo "</td>";
                           echo "</form>";
                           echo "</tr>";
                           echo "</table>";
			echo "</td></tr>";
                        echo "</table>";

?>



                              </div>
                            </div>
                            <div class="col-lg-6">
                            </div>
                          </div>  <!-- row -->

                          <div class="row">
                            <div class="col-lg-12">
                            </div>
                          </div>


                          <div class="row">
                            <div class="col-lg-12">






                        <div id="content_sub_all" class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Host</th>
                                        <th>User</th>
                                        <th>Source IP</th>
                                        <th>PID</th>
                                        <th>Pwd</th>
                                        <th>Command</th>
					<th>Server PID</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>

<?php

        $mydate=date("Y-m-d",time());
	$cmd_sql = "select * from input_cmd_list where date >= '{$INPUT_DATE}' and cmd_gubun = 'C' order by date desc, time desc ;" ;
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $date = $newArray['date'];
                        $time= $newArray['time'];
                        $utime= $newArray['utime'];
                        #$cancel_utime= $newArray['cancel_utime'];
                        $host = $newArray['host'];
                        $user= $newArray['user'];
                        $sip = $newArray['sip'];
                        $pid = $newArray['pid'];
                        $pwd = $newArray['pwd'];
                        $cmd = $newArray['cmd'];
                        $ack = $newArray['ack'];
                        $remark = $newArray['remark'];
                        $cmd_status = $newArray['cmd_status'];
                        $REAL_UTIME = microtime(true);

                        if($cmd_status) {

                                if ($cmd_status == "E" ) {
                                        $MSG = "Accepted" ;
                                        $BUTTON = "button button2" ;
                                }
                                else if ($cmd_status == "R" ) {
                                        $MSG = "Rejected" ;
                                        $BUTTON = "button button_p4" ;
                                }
                                else if ($cmd_status == "C" ) {
                                        $MSG = "Canceled" ;
                                        $BUTTON = "button button7" ;
                                }

                                $COLOR="black";
                                echo "<tr><td width=105><font color={$COLOR}>{$date}</font></td><td width=80><font color={$COLOR}>{$time}</font></td><td width=200>{$host}</td><td width=55>{$user}</td><td width=110>{$sip}</td><td width=65>{$pid}</td><td width=180>{$pwd}</td><td width=340>{$cmd}</td width=75><td>{$remark}</td>";
                                echo "<td width=115><center><button class='{$BUTTON}' type=button disabled><b>{$MSG}</b></button></td>";
                                echo "</tr>";

                        }
                        else {
                                $COLOR="red";
                                $SIZE=4;
                                echo "<tr><td width=105>{$date}</td><td width=80>{$time}</td><td width=200>{$host}</td><td width=55>{$user}</td><td width=110>{$sip}</td><td width=65>{$pid}</td><td width=180>{$pwd}</td><td width=340><font size={$SIZE} color={$COLOR}><b>{$cmd}</b></font></td><td width=75>{$remark}</td>";

                                if (!$INPUT_DATE and !$HOSTNAME )
                                        echo "<td width=115><form action=./cmd_approve_result.php method=post>";
                                else {
                                        if ($INPUT_DATE and !$HOSTNAME )
                                                echo "<td width=115><form action=./cmd_approve_result.php?input_date={$INPUT_DATE} method=post>";
                                        else if (!$INPUT_DATE and $HOSTNAME )
                                                echo "<td width=115><form action=./cmd_approve_result.php?hostname={HOSTNAME} method=post>";
                                        else
                                                echo "<td width=115><form action=./cmd_approve_result.php?input_date={$INPUT_DATE}&hostname={HOSTNAME} method=post>";
                                }




                                echo "<center><button class='button button_p6' type=submit name=a_utime value={$utime} ><b>Accept</b></button>";
                                echo "<button class='button button_p3' type=submit name=c_utime value={$utime} ><b>Reject</b></button>";
                                echo "</form></td></tr>";
                        }

                }
        }


        mysqli_free_result($res);
        mysqli_close($mysqli);


?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
