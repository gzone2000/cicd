<?php

session_start();
if (!$_SESSION[ss_id]) {
        header('Location: ./logout.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<body>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

include "css.php" ;

?>


                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Host</th>
                                        <th>User</th>
                                        <th>Source IP</th>
                                        <th>PID</th>
                                        <th>Pwd</th>
                                        <th>Command</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>

<?php

	$mydate=date("Y-m-d",time());
        $cmd_sql = "select * from input_cmd_list where date >= '{$mydate}' order by date desc, time desc";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $date = $newArray['date'];
                        $time= $newArray['time'];
                        $host = $newArray['host'];
                        $user= $newArray['user'];
                        $sip = $newArray['sip'];
                        $pid = $newArray['pid'];
                        $pwd = $newArray['pwd'];
                        $cmd = $newArray['cmd'];
                        $cmd_gubun = $newArray['cmd_gubun'];
                        $cmd_status = $newArray['cmd_status'];
                        $block_gubun = $newArray['block_gubun'];
                        echo "<tr>";
                        echo "<td width=100>{$date}</td><td>{$time}</td><td>{$host}</td><td>{$user}</td><td>{$sip}</td><td>{$pid}</td><td>{$pwd}</td><td>{$cmd}</td>";

                        if ($cmd_gubun == "N") {
                                $MSG1 = "N" ;
                                $BUTTON1 = "button button2" ;
                                $BALLON_MSG1 = "Normal Command" ;
                        }
                        else if ($cmd_gubun == "P") {
                                $MSG1 = "P" ;
                                $BUTTON1 = "button button3" ;
                                $BALLON_MSG1 = "Passing Command" ;
                        }
                        else if ($cmd_gubun == "C") {
                                $MSG1 = "Cr" ;
                                $BUTTON1 = "button button3" ;
                                $BALLON_MSG1 = "Critical Command" ;
                        }
                        else {
                                $MSG1 = "Null" ;
                                $BUTTON1 = "button button4" ;
                                $BALLON_MSG1 = "Null" ;
                        }

                        if ($cmd_status == "E") {
                                $MSG2 = "E" ;
                                $BUTTON2 = "button button6" ;
                                $BALLON_MSG2 = "Command Executed" ;
                        }
                        else if ($cmd_status == "B"){
                                $MSG2 = "B" ;
                                $BUTTON2 = "button button5" ;
                                $BALLON_MSG2 = "Command Blocked" ;
                        }
                        else if ($cmd_status == "C"){
                                $MSG2 = "C" ;
                                $BUTTON2 = "button button7" ;
                                $BALLON_MSG2 = "Command Canceled" ;
                        }
                        else if ($cmd_status == "R"){
                                $MSG2 = "R" ;
                                $BUTTON2 = "button button8" ;
                                $BALLON_MSG2 = "Command Rejected" ;
                        }
                        else {
                                $MSG2 = "Null" ;
                                $BUTTON2 = "button button4" ;
                                $BALLON_MSG2 = "Null" ;
                        }

                        if ($MSG1 == "Null" and $cmd_status == "B"){
                                $BUTTON1 = "button button7" ;
                                if ($block_gubun == 'C') {
                                        $BALLON_MSG1 = "Command Block";
                                        $MSG1 = "cmd";
                                }
                                else if ($block_gubun == 'T') {
                                        $BALLON_MSG1 = "Time Block";
                                        $MSG1 = "time";
                                }
                                else if ($block_gubun == 'I') {
                                        $BALLON_MSG1 = "IP Block";
                                        $MSG1 = "IP";
                                }
                                echo "<td width=95><center><a title='{$BALLON_MSG2}'><button class='{$BUTTON2}' type=button disabled><b>{$MSG2}</b></button></a>";
                                echo "&nbsp;&nbsp;<a title='{$BALLON_MSG1}'><button class='{$BUTTON1}' type=button disabled><b>{$MSG1}</b></button></a></td>";

                        }
                        else {

                                echo "<td width=95><center><a title='{$BALLON_MSG1}'><button class='{$BUTTON1}' type=button disabled><b>{$MSG1}</b></button></a>";
                                if ($cmd_gubun == "C" and $cmd_status == "E") {
                                        $BALLON_MSG2 = "Command Approved" ;
                                        echo "&nbsp;&nbsp;<a title='{$BALLON_MSG2}'><button class='button button2' type=button disabled><b>A</b></button></a>";
                                }
                                echo "&nbsp;&nbsp;<a title='{$BALLON_MSG2}'><button class='{$BUTTON2}' type=button disabled><b>{$MSG2}</b></button></a></td>";

                        }

                        echo "</tr>";
                }
        }

        mysqli_free_result($res);
        mysqli_close($mysqli);


?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->



    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
