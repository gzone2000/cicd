<?php

session_start();
$id=strip_tags(trim($_POST['id']));
$pwd=strip_tags(trim($_POST['pwd']));
$mysqli = new mysqli("localhost","root","mysql_123","syslog");

if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

function dec_enc($action, $string) {
    $output = false;

    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my SECRET key';
    $secret_iv = 'This is my SECRET iv';

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}

	date_default_timezone_set("Asia/Seoul");

	//echo "ID : $id <br>";
	//echo "PWD : $pwd <br>";
	//echo "SELECT * FROM User WHERE id='$id' and pwd=password('$pwd')";
	$login_check="SELECT * FROM User WHERE id='$id'";
	$res = mysqli_query($mysqli,$login_check);

	$row = mysqli_fetch_array($res);
	$db_id = $row["id"];
	$db_name  = $row["oper_name"];
	$db_pwd = $row["pwd"];
	$input_pwd = dec_enc('encrypt',$pwd);
	$db_level = $row["level"];
	$db_status = $row["status"];
	$REMOTE_IP = $_SERVER['REMOTE_ADDR'] ;
	$logintime = date("Y-m-d H:i:s");

	if( $input_pwd == $db_pwd ) {

		if( $db_status != '0' ) {

			$login_result = 'L';
			$insert_sql="insert into User_login_history values('$logintime','$db_id','$db_name','$db_level','$REMOTE_IP','$login_result')";
			$res = mysqli_query($mysqli,$insert_sql);

			// db_status : 0 --> 정상 , 1 --> 잠김
			echo "
     			<SCRIPT LANGUAGE='JavaScript'>
			alert('id가 잠겨 있습니다. 관리자에게 문의 바랍니다!!');
			</SCRIPT>
			";
			session_destroy();
     			echo "<meta http-equiv='Refresh' content='0; URL=./login.php' >";
			exit;

		}

		$select_sql = "select * from MGMT_IP_chk where client_ip = '{$REMOTE_IP}' or client_ip = 'ALL' order by num";
		//echo "# Remote IP: {$REMOTE_IP}<br>" ;
		//echo "# SQL: {$select_sql}<br>" ;
		$res = mysqli_query($mysqli,$select_sql);
		$num_rows = mysqli_num_rows($res);

		if ($num_rows > 0) {
        		while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                		$num = $newArray['num'];
                		$client_ip = $newArray['client_ip'];
                		$block_conect = $newArray['block_conect'];
                		$session_time = $newArray['session_time'];

                		//echo "VAR : $num , $client_ip , $block_conect , $session_time <br>";

                		if ($block_conect == 'N') {
                        		// Permit Website Connection
					$login_result = 'S';
					$insert_sql="insert into User_login_history values('$logintime','$db_id','$db_name','$db_level','$REMOTE_IP','$login_result')";
					$res = mysqli_query($mysqli,$insert_sql);

                        		break;

                		}
                		else {
                        		// Deny Website Connection
					$login_result = 'D';
					$insert_sql="insert into User_login_history values('$logintime','$db_id','$db_name','$db_level','$REMOTE_IP','$login_result')";
					$res = mysqli_query($mysqli,$insert_sql);

                        		echo "
                        		<SCRIPT LANGUAGE='JavaScript'>
                        		alert('허용된 접속IP가 아닙니다.!!');
                        		</SCRIPT>
                        		";
                        		session_destroy();
                        		echo "<meta http-equiv='Refresh' content='0; URL=./login.php' >";
					exit;

                		}

        		}
		}

		$UTIME = microtime(true);
		$Tmp_id = $db_id . $UTIME;
  		$_SESSION[id] = $db_id;
  		$_SESSION[ss_id] = $Tmp_id;
  		$_SESSION[auth_level] = $db_level;
		$_SESSION[login_time] = $logintime;

		$insert_sql="insert into User_history(id,session_id,oper_name,remote_ip,level,logintime) values('$db_id','$Tmp_id','$db_name','$REMOTE_IP','$db_level','$logintime')";
		$res = mysqli_query($mysqli,$insert_sql);

		//echo "SQL : $insert_sql <br>";
		//echo "ID : $_SESSION[id] , SS_ID : $_SESSION[ss_id] , LOGIN_TIME : $$_SESSION[login_time] <br>";

  		// write last login time
  		$query = "UPDATE User SET lastlogin='$logintime' WHERE id = '$id'";
		$res = mysqli_query($mysqli,$query);

  		echo "<meta http-equiv='Refresh' content='0; URL=./index.php'>";
  		exit;
	}
	else
 	{    
		$login_result = 'P';
		$insert_sql="insert into User_login_history values('$logintime','$db_id','$db_name','$db_level','$REMOTE_IP','$login_result')";
		$res = mysqli_query($mysqli,$insert_sql);

		echo "
     		<SCRIPT LANGUAGE='JavaScript'>
		alert('id 또는 password가 일치하지 않습입니다');
		</SCRIPT>
		";
		session_destroy();
     		echo "<meta http-equiv='Refresh' content='0; URL=./login.php' >";
  	}

}

?>

