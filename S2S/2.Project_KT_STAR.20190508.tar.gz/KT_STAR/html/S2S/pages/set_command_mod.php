<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$ORG_NUM = trim($_POST['ORG_NUM']);
$USER = trim($_POST['USER']);
$COMMAND = trim($_POST['COMMAND']);
$COMMAND = str_replace("\\b","\\\\b",$COMMAND);
$APPLY = trim($_POST['APPLY']);
#echo "# Argument: NUM > {$NUM}\n";
#echo "# Argument: ORG_NUM > {$ORG_NUM}\n";
#echo "# Argument: USER > {$USER}\n";
#echo "# Argument: COMMAND > {$COMMAND}\n";
#echo "# Argument: APPLY > {$APPLY}\n";

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

	$FULLURL = "./set_command.php?modify=1";

	# 설정 수정 화면
	# Update Cmd_exe_time_chk table

	if( $NUM > 9995) {
		$update_sql = "UPDATE crit_cmd_list_v1 set apply = '{$APPLY}' where num = {$NUM}" ;
	}
	else {
		if($NUM == $ORG_NUM) $update_sql = "UPDATE crit_cmd_list_v1 set user = '{$USER}' , crit_command = '{$COMMAND}' , apply = '{$APPLY}' where num = {$NUM}" ;
		else {

                	$select_sql = "select num from crit_cmd_list_v1 where num = {$NUM}" ;
                	$res5 = mysqli_query($mysqli,$select_sql);
                	#echo "# SQL: {$select_sql} " ;

                	$data = mysqli_fetch_array($res5);
                	$isset_num = $data['num'];

                	if (!isset($isset_num)) {
				$update_sql = "UPDATE crit_cmd_list_v1 set num = {$NUM} , user = '{$USER}' , crit_command = '{$COMMAND}' , apply = '{$APPLY}' where num = {$ORG_NUM}" ;
			}
			else {
                        	$FULLURL = "./set_command.php?modify=2";
                        	#echo "# URL : {$FULLURL}";
                        	header('Location: '.$FULLURL);
			}

		}
	}

	echo "# SQL : {$update_sql}";
	echo "<br>";
	$res = mysqli_query($mysqli,$update_sql);

	header('Location: '.$FULLURL);

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
