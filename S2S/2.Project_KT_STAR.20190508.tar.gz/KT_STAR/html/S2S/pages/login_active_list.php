<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=$LOGO_SIZE></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];


?>



        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">활성 로그인 현황</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">


<?php


                        echo "<table>";
                        echo "<tr><td width=400><font size=3><i class='glyphicon glyphicon-user'></i>&nbsp;현재 로그인하여 세션이 활성화된 계정 보여줌.</font></td>";

                        echo "</tr>";
                        echo "</table>";
?>



                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                 <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                 <thead>
                                    <tr>
                                        <th>아이디</th>
                                        <th>세션</th>
                                        <th>이름</th>
                                        <th>접속IP</th>
                                        <th>레벨</th>
                                        <th>로그인 접속 시간</th>
                                    </tr>
                                 </thead>
                                 <tbody>


<?php
	date_default_timezone_set("Asia/Seoul");
	$cmd_sql = "select * from User_history where logouttime is NULL" ;
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $id = $newArray['id'];
                        $session_id = $newArray['session_id'];
                        $oper_name = $newArray['oper_name'];
                        $remote_ip = $newArray['remote_ip'];
                        $level = $newArray['level'];
                        $logintime = $newArray['logintime'];

			$SESSION_STATE = "OK";
			//echo "SESS : $session_id <br>";


			$select_sql = "select * from MGMT_IP_chk where client_ip = '{$remote_ip}' or client_ip = 'ALL' order by num";
			$res5 = mysqli_query($mysqli,$select_sql);
			$num_rows = mysqli_num_rows($res5);

			if ($num_rows > 0) {
        			$newArray = mysqli_fetch_array($res5,MYSQLI_ASSOC);
                		$num = $newArray['num'];
                		$client_ip = $newArray['client_ip'];
                		$block_conect = $newArray['block_conect'];
                		$session_time = $newArray['session_time'];

                		$currenttime = date("Y-m-d H:i:s");
                		//echo "VAR : $num , $client_ip , $block_conect , $session_time <br>";

                		$Diff_Time = strtotime($currenttime) - strtotime($logintime);
                		//echo "Session : $session_id , DATE : $currenttime , LoginTime: $logintime , SessionTime: $session_time, Diff time: $Diff_Time <br>";
                		if($Diff_Time >= $session_time){
                        		//Old session delete;
					$SESSION_STATE = "OLD";

                			$delete_sql = "Delete from User_history where session_id = '{$session_id}'" ;
                			$res8 = mysqli_query($mysqli,$delete_sql);
                		}
				else $SESSION_STATE = "OK";

			}



			if($level == '0') { 
				$MSG1="어드민 권한";
				$DISABLED = "disabled";
			}
			else {
				$MSG1="일반 권한";
				$DISABLED = "";
			}


			if($SESSION_STATE == "OK") {
                        	echo "<tr>";
                        	echo "<td width=80>{$id}</td><td width=100>{$session_id}</td><td width=120>{$oper_name}</td><td width=120>{$remote_ip}</td><td width=120>{$MSG1}</td><td width=120>{$logintime}</td>";
                        	echo "</tr>";   
			}
                }
        }

	echo "</table>"	;



	if($_GET['del'] == 2) {

		echo "<br><font color=red><b>본인 세션은 삭제 안됩니다!!</b></font>";
		echo "<br>";

	}
?>



                                </div>
                                <!-- /.col-lg-12 (nested) -->




                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
