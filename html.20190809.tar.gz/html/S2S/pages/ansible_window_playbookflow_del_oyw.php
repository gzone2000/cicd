<?php
include "session_chk.inc" ;

$F_NAME = trim($_POST['F_NAME']);
//echo "# Argument: Flow Name > {$F_NAME}<br>";


        $mysqli = new mysqli("localhost","root","mysql_123","syslog");
        if (mysqli_connect_errno()) {
                printf("Connect failed: %s\n", mysqli_connect_error());
                exit();
        }
        else {

                # delete Flow
                $FULLURL = "./ansible_window_playbookflow_oyw.php?del=$F_NAME";

                $select_sql = "select f_name from Ansible_window_playbookflow_Save2 where f_name = '{$F_NAME}'" ;
                $res5 = mysqli_query($mysqli,$select_sql);
                //echo "# SQL: {$select_sql} " ;

                $data = mysqli_fetch_array($res5);
                $isset_num = $data['f_name'];

                if (isset($isset_num)) {

                        # delete Ansible_window_playbookflow_Save2 table
                        $delete_sql = "delete from Ansible_window_playbookflow_Save2 where f_name = '{$F_NAME}'" ;
                        $res = mysqli_query($mysqli,$delete_sql);
                        //echo "# SQL : {$delete_sql} , Result : $res";
                        //echo "<br>";

                        header('Location: '.$FULLURL);

                        mysqli_free_result($res);
                        mysqli_close($mysqli);
                }
                else {
                        # del=2 : playbook not found
                        $FULLURL = "./ansible_window_playbookflow_oyw.php?del=2";
                        #echo "# URL : {$FULLURL}";
                        header('Location: '.$FULLURL);
                }
        }

?>
