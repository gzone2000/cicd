<?php
include "session_chk.inc" ;

$MAIL_ID = trim($_POST['MAIL_ID']);
$NAME = trim($_POST['NAME']);
$DEPARTMENT = trim($_POST['DEPARTMENT']);
$MAIL_SEND = trim($_POST['MAIL_SEND']);
#echo "# Argument: MAIL_ID > {$MAIL_ID}\n";


if (!$MAIL_ID or !$NAME or !DEPARTMENT) {
	$FULLURL = "./set_mgmt_mail.php?add=1";
	#echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {

	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		$FULLURL = "./set_mgmt_mail.php?add=9999";

		$select_sql = "select mail_id from Mail_list where mail_id = '{$MAIL_ID}' " ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['mail_id'];

		if (!isset($isset_num)) {

			# 설정 추가 화면
			# Insert User table
			$insert_sql = "INSERT into Mail_list values ('{$MAIL_ID}', '{$NAME}', '{$DEPARTMENT}', '{$MAIL_SEND}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			#echo "# SQL : {$insert_sql} , Result : $res";
			#echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			$FULLURL = "./set_mgmt_mail.php?add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}
}

?> 
