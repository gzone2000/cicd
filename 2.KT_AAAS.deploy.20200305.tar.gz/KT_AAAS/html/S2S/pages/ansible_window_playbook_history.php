<?php
date_default_timezone_set("Asia/Seoul");
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->


<script>
function popitup1(p_id) {
    var url = "./ansible_window_playbook_content_his_popup.php?P_NAME=" + p_id;
    window.open(url,"Playbook 내용","width=900,height=600,left=100,top=60");
}
</script>

<script>
function popitup2(p_id) {
    var url2 = "./ansible_window_playbook_content_his_popup.php?P_NAME1=" + p_id;
    window.open(url2,"Playbook 결과 내용","width=1600,height=600,left=100,top=60");
}
</script>


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php


$DAYS=$INPUT_DAYS ;

if($_GET['input_date']){
        if (preg_match("/[^-\d]/", $_GET['input_date'])) $INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));
        else $INPUT_DATE = $_GET['input_date'];
}
else {
        $INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));
}

if($_GET['input_date1']){
        if (preg_match("/[^-\d]/", $_GET['input_date1'])) $INPUT_DATE1 = date("Y-m-d",strtotime("0 days"));
        else $INPUT_DATE1 = $_GET['input_date1'];
}
else {
        $INPUT_DATE1 = date("Y-m-d",strtotime("0 days"));
}


$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">History > Window > Playbook 실행 이력</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">


<?php
                        echo "<table>";
                        echo "<tr><td width=800><font size=3><i class='fa fa-info-circle fa-fw'></i>&nbsp;Window Ansible Playbook 실행 히스토리 확인할수 있다.</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->




                        <div class="panel-body">

                          <div class="row">
                            <div class="col-lg-5">
                              <div class="label_info" style="margin-bottom: 5px;padding: 4px 12px;">




                           <form action="./ansible_window_playbook_history.php">
<?php
                        echo "<table>";
                        echo "<tr><td width=230><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;&nbsp;From:&nbsp;&nbsp;</font>";
                        echo "<input type=date name=input_date value='{$INPUT_DATE}'></td>";
                        echo "<td><font size=3>&nbsp;&nbsp;&nbsp;~&nbsp;&nbsp;&nbsp;To:&nbsp;&nbsp;</font>";
                        echo "<input type=date name=input_date1 value='{$INPUT_DATE1}'><td width=30><td>";
                        echo "<td><button class='btn btn-primary' type=submit><b>검색</b></button></td>";
                        echo "</tr>";
                        echo "</table>";
?>
                           </form>


<?php

        if($_SESSION[auth_level] == 0 ) {
                //admin
                $CMD_COND = " where date_format(p_starttime,'%Y-%m-%d') >= '{$INPUT_DATE}' and date_format(p_starttime,'%Y-%m-%d') <= '{$INPUT_DATE1}' " ;
        }
        else {
                //NOT admin
                $CMD_COND = " where date_format(p_starttime,'%Y-%m-%d') >= '{$INPUT_DATE}' and date_format(p_starttime,'%Y-%m-%d') <= '{$INPUT_DATE1}' and user = '$_SESSION[id]'" ;
        }

        $ORDER = " order by p_starttime desc" ;
        $cmd_sql = "select * from Ansible_window_playbook_history " . $CMD_COND . $ORDER;
        #echo "# SQL : {$cmd_sql} <br>";
?>




                              </div>
                            </div>
                            <div class="col-lg-7">
                            </div>
                          </div>  <!-- row -->

                          <div class="row">
                            <div class="col-lg-12">
                            </div>
                          </div>


                          <div class="row">
                            <div class="col-lg-12">


                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>시작 시간</th>
                                        <th>종료 시간</th>
                                        <th>Playbook ID</th>
                                        <th>사용자</th>
                                        <th>실행 Playbook</th>
                                        <th>Playbook 내용</th>
                                        <th width=70>Playbook 실행 결과</th>
                                        <th width=70>Playbook 결과 내용</th>
                                    </tr>
                                </thead>
                                <tbody>

<?php

        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $p_id = $newArray['p_id'];
                        $p_seq = $newArray['p_seq'];
                        $p_starttime = $newArray['p_starttime'];
                        $p_endtime = $newArray['p_endtime'];
                        $user = $newArray['user'];
                        $p_name = $newArray['p_name'];
                        $p_content = $newArray['p_content'];
                        $p_exec_result = $newArray['p_exec_result'];
                        $p_result_content = $newArray['p_result_content'];

			//$p_content_dec = base64_decode($p_content);
			//$p_result_content_dec = base64_decode($p_result_content);

			if($p_exec_result == 'Y') $MSG1 = "<b><font color=blue>성공</font></b>";
			else if($p_exec_result == 'N') $MSG1 = "<b><font color=red>실패</font></b>";
			else $MSG1 = "<b><font color=green>일부 성공</font></b>";

                        echo "<tr>";
                        echo "<td>{$p_starttime}</td><td>{$p_endtime}</td><td>{$p_seq}</td><td>{$user}</td><td>{$p_name}</td>";
			echo "<td><button id=$p_name name=$p_name  class='btn btn-success btn-sm' onclick='popitup1(\"$p_id\")'>$p_name</button></td>";
			echo "<td>{$MSG1}</td>";
			echo "<td><button id='{$p_name}_2' name='{$p_name}_2' class='btn btn-info btn-sm' onclick='popitup2(\"{$p_id}\")'>실행결과</button></td>";
                        echo "</tr>";
                }
        }

        mysqli_free_result($res);
        mysqli_close($mysqli);


?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
