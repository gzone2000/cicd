<?php
include "session_chk.inc" ;

$DEL_ALL = $_POST['DEL_ALL'];

if ($DEL_ALL and preg_match("/[^\d]/", $DEL_ALL)) {
        $FAULT = 'Y';
}

if (!$DEL_ALL) {
	$FULLURL = "./ansible_linux_playbookflow_cron.php";
	#echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {
        
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

                if ($FAULT == 'Y') {
                        $FULLURL = "./ansible_linux_playbookflow_cron.php?delete=3";
                        #echo "# URL : {$FULLURL}";
                        header('Location: '.$FULLURL);
                        break;
                }

		// Crontab and DB Table Delete All
		$FULLURL = "./ansible_linux_playbookflow_cron.php";
                $EXEC_STR1 = "(crontab -l 2>/dev/null | sed '/ /d') | crontab -";
                $RESULT = shell_exec("$EXEC_STR1");

        	$cmd_sql = "delete from Ansible_linux_playbookflow_cron" ;
        	$res = mysqli_query($mysqli,$cmd_sql);

        	$cmd_sql = "delete from Ansible_window_playbookflow_cron" ;
        	$res = mysqli_query($mysqli,$cmd_sql);

		header('Location: '.$FULLURL);
		mysqli_free_result($res);
		mysqli_close($mysqli); 

	}
}

?> 
