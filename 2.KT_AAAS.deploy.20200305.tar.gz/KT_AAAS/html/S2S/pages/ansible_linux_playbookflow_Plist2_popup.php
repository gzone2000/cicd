<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->


<script type="text/javascript" src="../vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>

function PlaybookSelect(F_name,Playbook_List,Member_List,Bef_Playbook,Row_Num) {

        var radio = '' ;
        var Select_Playbook ;
        var table = document.getElementById('table_source');
        for (var r = 1, n = table.rows.length; r < n; r++) {
            radio = table.rows[r].cells[0].getElementsByTagName("input");
	    if (radio[0].checked) {
		Select_Playbook = radio[0].value;	
	    }
        }


	var total_str = F_name + '||' + Playbook_List + '||' + Member_List +  '||' + Bef_Playbook + '||' + Select_Playbook + '||' + Row_Num;

	//alert(total_str);

        window.opener.sendMeData(total_str)
        window.close();

}

</script>

</head>

<body>

    <div id="wrapper">


<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>


<?php

        if (preg_match("/[^a-z.\d_-]/i", $_GET['F_NAME'])) {
                $FAULT = 'Y';
        }

        if (preg_match("/[^a-z+-\/=\d_]/i", $_GET['PLAYBOOKLIST'])) {
                $FAULT = 'Y';
        }

        if (preg_match("/[^a-z+-\/=\d_]/i", $_GET['MEMBERLIST'])) {
                $FAULT = 'Y';
        }

        if (preg_match("/[^a-z.\d_-]/i", $_GET['BEF_PLY'])) {
                $FAULT = 'Y';
        }

        if (preg_match("/[^\d]/", $_GET['ROW_NUM'])) {
                $FAULT = 'Y';
        }


		$F_NAME = $_GET['F_NAME'];
		$PLAYBOOKLIST = base64_decode($_GET['PLAYBOOKLIST']);
		$MEMBERLIST = base64_decode($_GET['MEMBERLIST']);
		$BEF_PLY = $_GET['BEF_PLY'];
		$ROW_NUM = $_GET['ROW_NUM'];
		echo "

                        <div id='P_mod' class='panel-body'>
            		  <div class='row'>
                	    <div class='col-lg-3'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
				  <table><tr>
                                  <td width=300><b><font size=3>Ansible Playbook 리스트 </font></b></td>
				  <td><button id=PLYSELECT class='btn btn-success btn-sm' onclick='PlaybookSelect(\"$F_NAME\",\"$PLAYBOOKLIST\",\"$MEMBERLIST\",\"$BEF_PLY\",\"$ROW_NUM\")'><b>Playbook Select</b></button></td>
				  </tr></table>
                              </div>
                            </div>
                            <div class='col-lg-3'>
                                  <input id='myInput' type='text' placeholder='Search..'>
                            </div>

                            <div class='col-lg-2'>
                            </div>
                          </div>

			  <br>
                          <div class='row'>
                            <div class='col-lg-12'>


				<div class='scrollClass'>
                                <table id='table_source' class='table table-sm table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>체크</th>
                                        <th>playbook 구분</th>
                                        <th>playbook 분류</th>
                                        <th>Playbook 이름</th>
                                    </tr>
                                </thead>
				<tbody id='myTable1'>
                ";

	if ($FAULT != 'Y') {

                $cmd_sql = "select * from Ansible_linux_playbook order by p_name";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $p_name = $newArray['p_name'];
                                $p_gubun = $newArray['p_gubun'];
                                $p_gubun1 = $newArray['p_gubun1'];
                                //$p_explain= $newArray['p_explain'];
                                //$p_explain= base64_decode($p_explain);
                                //$p_content = $newArray['p_content'];
                                //$p_content_dec = base64_decode($p_content);

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                        	echo "<tr><td><input type='radio' name=NODE value=$p_name></td><td>$gubun_name</td><td>$gubun_name1</td><td>$p_name</td></tr>";
			}
		}
        }
        else {
                        echo "<tr><td colspan=4><b><font color=red>잘못된 값이 입력되었습니다. 확인 바랍니다!!</font></b></td></tr>";
        }

        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";



        echo "
			    </div>

                    </div>
                </div>
            </div>
	";


?>


                    </div>


    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




