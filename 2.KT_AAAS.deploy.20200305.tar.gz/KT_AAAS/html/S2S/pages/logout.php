<?php

session_start();

include "Acase.php";

////// dec_enc Function Start //////

    $output = false;

    $encrypt_method = "AES-256-CBC";
    $action = "decrypt";
    $string = $MYSQL_PWD;
    $secret_key = $S_KEY;
    $secret_iv = $S_IV;

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

////// dec_enc Function End //////

$mysqli = new mysqli($MYSQL_HST,$MYSQL_USR,$output,$MYSQL_DBI);
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}
else {
        $logouttime = date("Y-m-d H:i:s");
        $query = "UPDATE User_history SET logouttime='$logouttime' WHERE session_id='$_SESSION[ss_id]'";
        $res = mysqli_query($mysqli,$query);
	//echo "$query" ;
}

$res=session_destroy(); //모든 세션 변수 지우기
if($res){
    header('Location: ./login.php'); // 로그아웃 성공 시 로그인 페이지로 이동
    exit();
}


?>
