<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$FLOW = trim($_POST['FLOW']);
$MIN = trim($_POST['MIN']);
$EVERY_MIN_CHK = trim($_POST['EVERY_MIN_CHK']);
$HOUR = trim($_POST['HOUR']);
$EVERY_HOUR_CHK = trim($_POST['EVERY_HOUR_CHK']);
$DAY = trim($_POST['DAY']);
$MONTH = trim($_POST['MONTH']);
$WEEK = trim($_POST['WEEK']);
$MAIL_SEND = trim($_POST['MAIL_SEND']);
$COMMAND = trim($_POST['COMMAND']);

if ($NUM and preg_match("/[^\d]/", $NUM)) {
        $FAULT = 'Y';
}

if ($FLOW and preg_match("/[^a-z.\d_-]/i", $FLOW)) {
        $FAULT = 'Y';
}

if ($MIN and preg_match("/[^\d*]/", $MIN)) {
        $FAULT = 'Y';
}

if ($HOUR and preg_match("/[^\d*]/", $HOUR)) {
        $FAULT = 'Y';
}

if ($DAY and preg_match("/[^\d*]/", $DAY)) {
        $FAULT = 'Y';
}

if ($MONTH and preg_match("/[^\d*]/", $MONTH)) {
        $FAULT = 'Y';
}

if ($WEEK and preg_match("/[^\d*]/", $WEEK)) {
        $FAULT = 'Y';
}

if ($MAIL_SEND and preg_match("/[^YN]/", $MAIL_SEND)) {
        $FAULT = 'Y';
}

if ($EVERY_MIN_CHK and preg_match("/[^Y]/", $EVERY_MIN_CHK)) {
        $FAULT = 'Y';
}

if ($EVERY_HOUR_CHK and preg_match("/[^Y]/", $EVERY_HOUR_CHK)) {
        $FAULT = 'Y';
}

if ($COMMAND and preg_match("/[^a-z.\d_-]/i", $COMMAND)) {
        $FAULT = 'Y';
}


if (!$COMMAND) {
	$FULLURL = "./ansible_linux_playbookflow_cron.php?FLOW={$FLOW}&add=1";
	#echo "# URL : {$FULLURL}";
	header('Location: '.$FULLURL);
}
else {
        
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		if ($FAULT == 'Y') {
			$FULLURL = "./ansible_linux_playbookflow_cron.php?FLOW={$FLOW}&add=3";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
			break;
		}

		$FULLURL = "./ansible_linux_playbookflow_cron.php?FLOW={$FLOW}&add=9999";

		$select_sql = "select c_num from Ansible_linux_playbookflow_cron where c_num = '{$NUM}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['c_num'];

		if (!isset($isset_num)) {

			if(!$EVERY_MIN_CHK) $EVERY_MIN_CHK = 'N';
			if(!$EVERY_HOUR_CHK) $EVERY_HOUR_CHK = 'N';

			# 설정 추가 화면
			# Insert Ansible_linux_playbookflow_cron table
			$insert_sql = "INSERT into Ansible_linux_playbookflow_cron values ('{$NUM}', '{$MIN}', '{$EVERY_MIN_CHK}', '{$HOUR}', '{$EVERY_HOUR_CHK}','{$DAY}','{$MONTH}','{$WEEK}','{$COMMAND}','{$MAIL_SEND}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			#echo "# SQL : {$insert_sql} , Result : $res";
			#echo "<br>";

			// Cron Add //

                	$LINE_CNT = shell_exec("crontab -l | grep 'LINUX_{$NUM}_LINE' | wc -l");
                	if($LINE_CNT == 0) {
                        	if($EVERY_MIN_CHK == 'Y' and $MIN != '*') $MIN = '*/' . $MIN;
                        	if($EVERY_HOUR_CHK == 'Y' and $HOUR != '*') $HOUR = '*/' . $HOUR;

				$CRON_EXEC_STR1 = "/var/www/html/S2S/pages/ansible_linux_playbookflow_CronExec.php $COMMAND $MAIL_SEND LINUX_{$NUM}_LINE";
				$CRON_STR1 = $MIN . " " . $HOUR . " " . $DAY . " " . $MONTH . " " . $WEEK . " " . "php $CRON_EXEC_STR1 ";

				$EXEC_STR1 = "(crontab -l 2>/dev/null; echo \"$CRON_STR1\") | crontab -";
                		$RESULT = shell_exec("$EXEC_STR1");
			}

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			$FULLURL = "./ansible_linux_playbookflow_cron.php?FLOW={$FLOW}&add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}
}

?> 
