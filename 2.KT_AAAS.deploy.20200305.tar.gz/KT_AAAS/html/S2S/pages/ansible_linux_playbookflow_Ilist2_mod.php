<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->



<script>
function GetCellValues5(f_name,playbook_list) {
    var res = '';
    var str1 = '' ;
    var table = document.getElementById('table_source1');
    for (var r = 1, n = table.rows.length; r < n; r++) {
            	str1 = table.rows[r].cells[2].innerHTML;
            	if(table.rows[r].cells[0].getElementsByTagName('input')[0].checked == true) {

			str1 = table.rows[r].cells[2].innerHTML;
               		if ( res == '') {
                 	       res = str1;
                	}
                	else {
                        	res = res + '|' + str1;
                	}

		}
    }

    var table = document.getElementById('table_source2');
    for (var r = 1, n = table.rows.length; r < n; r++) {
                str1 = table.rows[r].cells[1].innerHTML;
                if(table.rows[r].cells[0].getElementsByTagName('input')[0].checked == true) {

                        str1 = table.rows[r].cells[1].innerHTML;
                        if ( res == '') {
                               res = str1;
                        }
                        else {
                                res = res + '|' + str1;
                        }

                }
    }

    var url1 = './ansible_linux_playbookflow_mod_oyw.php';
    var form = document.createElement("form");
    form.setAttribute("method","post");
    form.setAttribute("action",url1);
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type","hidden");
    hiddenField.setAttribute("name","MEMBER");
    hiddenField.setAttribute("value",res);
    form.appendChild(hiddenField);

    var hiddenField1 = document.createElement("input");
    hiddenField1.setAttribute("type","hidden");
    hiddenField1.setAttribute("name","F_NAME");
    hiddenField1.setAttribute("value",f_name);
    form.appendChild(hiddenField1);

    var hiddenField2 = document.createElement("input");
    hiddenField2.setAttribute("type","hidden");
    hiddenField2.setAttribute("name","PLAYBOOKLIST");
    hiddenField2.setAttribute("value",playbook_list);
    form.appendChild(hiddenField2);

    document.body.appendChild(form);
    form.submit();
}

</script>

</head>

<body>

    <div id="wrapper">


<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>


<?php

        if (preg_match("/[^a-z.\d_-]/i", $_GET['F_NAME'])) {
                $FAULT = 'Y';
        }

        if (preg_match("/[^a-z+-\/=\d_]/i", $_GET['PLAYBOOKLIST'])) {
                $FAULT = 'Y';
        }

        if ($FAULT != 'Y') {

		$F_NAME = trim($_GET['F_NAME']);
		$PLAYBOOKLIST = base64_decode(trim($_GET['PLAYBOOKLIST']));
		echo "
                        <div class='panel-body'>
            		  <div class='row'>
                	    <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3 color=blue></font><font size=3>Ansible 호스트 </font></b>
                              </div>

				<br>
				<div class='table-responsive scrollClass-sm'>
                                <table id='table_source1' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>체크</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";


        	$cmd_sql = "select * from Ansible_linux_host order by hostname";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        	$hostname = $newArray['hostname'];
                        	$nodename= $newArray['nodename'];
                        	$ip = $newArray['ip'];
                        	$linux_ver = $newArray['linux_ver'];
                        	$kernel_ver = $newArray['kernel_ver'];

                        	echo "<tr><td><input type='checkbox' name=NODE value=$nodename></td><td>$hostname</td><td>$nodename</td></tr>";
                	}
        	}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";  //scrollClass-sm
        	echo "</div>";  // <div class='col-lg-6'>


        	echo "
                            <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3 color=blue></font><font size=3>Ansible 그룹</font></b>
                              </div>

				<br>
				<div class='table-responsive scrollClass-sm'>
                                <table id='table_source2' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>체크</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";

        	$cmd_sql = "select * from Ansible_linux_group order by groupname";
        	$res = mysqli_query($mysqli,$cmd_sql);
        	if ($res) {
                	while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        	$groupname = $newArray['groupname'];
                        	$member= $newArray['member'];
                        	$member = str_replace("|","<br>",$member);

                        	echo "<tr><td><input type='checkbox' name=NODE value=$groupname></td><td>$groupname</td><td>$member</td></tr>";
                	}
        	}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";  //scrollClass-sm
        	echo "<br>";




        	echo "<div>";
		echo "<button id=button_click class='btn btn-success' onclick='GetCellValues5(\"$F_NAME\",\"$PLAYBOOKLIST\")'>선택 완료시 Click</button>";
        	echo "</div>";


                echo "
                         </div>
                       </div>
                   </div>
                <br>
                ";


        }
        else {

                echo "
                        <br>
                        <br>
                        <br>
                        <br>
                        <div class='panel-body'>
                          <div class='row'>
                                <b><font color=red>잘못된 값이 입력되었습니다. 확인 바랍니다!!</font></b>
                          </div>
                        </div>
                        <br>
                ";
        }



?>


                    </div>


    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




