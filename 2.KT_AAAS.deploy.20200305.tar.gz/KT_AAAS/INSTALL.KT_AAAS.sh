sysctl -w net.ipv4.conf.all.forwarding=1
docker rm -f KT_AAAS
docker run --privileged --name KT_AAAS --restart=always -d -p 8443:443 \
-v /Project/KT_AAAS/html:/var/www/html \
-v /Project/KT_AAAS/mysql:/var/lib/mysql \
-v /Project/KT_AAAS/ansible/playbook/:/home/ansible/playbook \
gzone2000/ktaaas:deploy.v1
