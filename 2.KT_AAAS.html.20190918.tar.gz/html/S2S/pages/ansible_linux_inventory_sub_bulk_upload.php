<?php

session_start();
if (!$_SESSION[ss_id]) {
        header('Location: ./logout.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
include "ip.inc" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];





	echo "
	  <br>
          <div class='row'>
             <div class='col-lg-12'>
                 <div class='label_warning' style='margin-bottom: 5px;padding: 4px 12px;'>
                     <b><font size=3>Inventory 호스트 리스트 여러개 추가 결과</font></b>
                 </div>

                 <div class='panel-body'>

                    <table width='100%' class='table table-striped table-bordered table-hover'>
                    <thead>
                          <tr>
                             <th>입력값</th>
                             <th>결과값</th>
                             <th>호스트 정보획득 여부</th>
                             <th>최종 DB 추가 여부</th>
                          </tr>
                    </thead>
                    <tbody>

	";



$HOST_FILE = "/home/ansible/host/bulk_host.txt";

$fp = fopen($HOST_FILE,"r");
$COUNT = 0;
$DB_SUCC_CNT = 0;
while(! feof($fp)) {
	$INPUT_STR = fgets($fp);
	$PIECES = explode("|", $INPUT_STR);
	$IP = $PIECES[0];
	$PORT = $PIECES[1];
	//echo "$INPUT_STR , $IP , $PORT <br>";


        if ($IP and $PORT)
	{


/*

# Ansible Directory
$ANSIBLE_DIR = "/home/ansible";
$ANSIBLE_PLAYBOOK_DIR = "$ANSIBLE_DIR/playbook";
$ANSIBLE_HOST_DIR = "$ANSIBLE_DIR/host";
$ANSIBLE_LOG_DIR = "$ANSIBLE_DIR/log";
$ANSIBLE_EXEC_DIR = "$ANSIBLE_DIR/exec";

*/


                $RANDOM_NUM = mt_rand(1,1000);
                $UTIME_F = explode('.',microtime(true));
                $UTIME = $UTIME_F[0] . $UTIME_F[1] . $RANDOM_NUM ;

		//$CMD_LINE = shell_exec("cp $ANSIBLE_PLAYBOOK_DIR/cmd.yml.copy $ANSIBLE_PLAYBOOK_DIR/");
		//$CMD_LINE = shell_exec("cp $ANSIBLE_PLAYBOOK_DIR/cmd.yml $ANSIBLE_PLAYBOOK_DIR/");

		$ANSIBLE_PLAYBOOK_ORG = "${ANSIBLE_PLAYBOOK_DIR}/setup.yml.copy" ;
		$ANSIBLE_PLAYBOOK_NICK_FILE = "${ANSIBLE_EXEC_DIR}/setup.yml" ;
		$ANSIBLE_PLAYBOOK_FILE = "${ANSIBLE_EXEC_DIR}/setup.yml" . $UTIME ;
	
		$FULLSTR = "sed \"s|#IP#|{$IP}|\" $ANSIBLE_PLAYBOOK_ORG > $ANSIBLE_PLAYBOOK_FILE";
        	$REPLACE_STR = exec($FULLSTR,$output,$return) ;

		//$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");
		//echo "<pre>$RESULT_DISPLAY</pre>";

		$CHECK_FILE = exec("cat $ANSIBLE_PLAYBOOK_FILE | grep '#IP#' | wc -l");
		if ($return == 0 and $CHECK_FILE == 0) {
			$COUNT++;
			$ANSIBLE_HOST_FILE = "$ANSIBLE_HOST_DIR/hosts" . $UTIME ;
			$ANSIBLE_HOST_NICK_FILE = "$ANSIBLE_HOST_DIR/hosts" ;
			$ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log.txt" . $UTIME ;
			$ANSIBLE_LOG_NICK_FILE = "$ANSIBLE_LOG_DIR/log.txt" ;

                        $HOST_STR = "
[linux_test]
$IP ansible_ssh_port=$PORT
                        ";

                        $fp1 = fopen($ANSIBLE_HOST_FILE,'w');
                        fputs($fp1,$HOST_STR);
                        fclose($fp1);

			$CMD_LINE = shell_exec("ansible-playbook -i $ANSIBLE_HOST_FILE $ANSIBLE_PLAYBOOK_FILE > $ANSIBLE_LOG_FILE 2>&1");
                        $Fail_CNT1 = shell_exec("cat $ANSIBLE_LOG_FILE | grep 'failed=' | wc -l");
                        $Fail_CNT2 = shell_exec("cat $ANSIBLE_LOG_FILE | grep 'failed=0' | wc -l");
                        $OK_0_CNT = shell_exec("cat $ANSIBLE_LOG_FILE | grep 'ok=0' | wc -l");

                        if ($Fail_CNT1 == 0) {
				$MSG1 = "<font color=red>실패</font>";
                                $SUCC = 'N';
                        }
                        else if ($OK_0_CNT == 0 and $Fail_CNT1 == $Fail_CNT2) {
				$MSG1 = "<font color=blue>성공</font>";
                                $SUCC = 'Y';
                        }
                        else {
				$MSG1 = "<font color=red>실패</font>";
                                $SUCC = 'N';
                        }

			//$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
			//echo "<pre>$RESULT_DISPLAY</pre>";
			$RESULT_INFO = shell_exec("cat $ANSIBLE_LOG_FILE | grep '#MSGM#'");

			$DB_RESULT = '';	
			if ($SUCC == 'Y') {

				$RESULT_INFO = str_replace("#MSGM#","$IP",$RESULT_INFO);
				$RESULT_INFO = preg_replace('/\t|\r\n|\r|\n|\"/','',$RESULT_INFO);
				$RESULT_INFO = str_replace('msg: ','',$RESULT_INFO);
				$RESULT_INFO = strtolower($RESULT_INFO);
				$RESULT_INFO = trim($RESULT_INFO);
				//echo "<pre>$RESULT_INFO</pre>";
				
				$RESULT_INFO = $RESULT_INFO . "|" . $PORT;
				$PIECES = explode("|", $RESULT_INFO);
				$IPADDR = $PIECES[0];
				$HOSTNAME = $PIECES[1];
				$NODENAME = $PIECES[2];
				$ID = $PIECES[3];
				$RELEASE = $PIECES[4];
				$KERNEL_VER = $PIECES[5];


		// DB insert Add

               	$select_sql = "select ip from Ansible_linux_host where nodename = '{$NODENAME}' or ip = '{$IPADDR}'" ;
                $res5 = mysqli_query($mysqli,$select_sql);
                #echo "# SQL: {$select_sql} " ;

                $data = mysqli_fetch_array($res5);
                $isset_num = $data['ip'];

                if (!isset($isset_num)) {

                        # Insert Ansible_linux_host table
                        $insert_sql = "INSERT into Ansible_linux_host values ('{$HOSTNAME}', '{$NODENAME}', '{$IPADDR}', '{$PORT}', '{$ID}{$RELEASE}', '{$KERNEL_VER}')" ;
                        $res = mysqli_query($mysqli,$insert_sql);
			$DB_RESULT = "<b><font color=blue>성공</font></b>";
			$DB_SUCC_CNT++;
                }
                else {
			$DB_RESULT = "<b><font color=red>실패</font></b> : 이미 호스트 등록 되어 있음";
                }



				echo "<tr><td>$INPUT_STR</td><td>$RESULT_INFO</td><td>$MSG1</td><td>$DB_RESULT</td></tr>";
			}
			else {
				echo "<tr><td>$INPUT_STR</td><td>$RESULT_INFO</td><td>$MSG1</td><td>$DB_RESULT</td></tr>";

			}


		}
		else {
			echo "NOT Success!! <br>";
			foreach($output as $line) {
				echo "$line <br>";
			}
		}

                $DELETE1 = shell_exec("rm -f $ANSIBLE_HOST_FILE");
                $DELETE2 = shell_exec("rm -f $ANSIBLE_LOG_FILE");
                $DELETE2 = shell_exec("rm -f $ANSIBLE_PLAYBOOK_FILE");

	}

}  // while

fclose($fp);



	echo "
				</tbody>
				</table>

				<div>
				<br>
				<b><font size=3>총입력 건수 : </font><font size=3 color=blue>$COUNT</font><font size=3> , 최종 성공건수 : </font><font size=3 color=red>$DB_SUCC_CNT</font></b>
				</div>

                              </div>
                            </div>
                          </div>
	";


mysqli_free_result($res);
mysqli_close($mysqli);


?> 

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>




</body>

</html>




