<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
function myFunction() {
    var String = "./ansible_linux_playbookflow_list_oyw.php";
    $("#list1").load(String);
}
</script>

<script>
function myFunction5() {

    var f_name = document.getElementById('button_flow').value;
    if (f_name) {

    	document.getElementsByName("btn_flow")[0].disabled = true;
    	document.getElementsByName("btn1")[0].disabled = true;
    	document.getElementsByName("btn_popup")[0].disabled = true;

    	var table = document.getElementById('table_source');
    	for (var r = 0, n = table.rows.length; r < n - 1; r++) {
    		document.getElementsByName("PLY_BTN")[r].disabled = true;
    	}

    	$(document).ajaxStart(function(){
      		$("#wait").css("display", "block");
    	});
    	$(document).ajaxComplete(function(){
      		$("#wait").css("display", "none");
      		document.getElementsByName("btn_flow")[0].disabled = false;
      		document.getElementsByName("btn1")[0].disabled = false;
      		document.getElementsByName("btn_popup")[0].disabled = false;
    		for (var r = 0, n = table.rows.length; r < n - 1; r++) {
    			document.getElementsByName("PLY_BTN")[r].disabled = false;
    		}
    	});

    	var String = "./ansible_linux_playbookflow_execSUB_oyw.php?F_NAME=" + f_name ;
    	$("#txt5").load(String);
    }
    else {
	alert("Flow 항목이 비어 있습니다. 확인 바랍니다!!");
    }

}
    document.getElementsByName("btn_flow")[0].disabled = false;
    document.getElementsByName("btn1")[0].disabled = false;
    document.getElementsByName("btn_popup")[0].disabled = false;
    for (var r = 0, n = table.rows.length; r < n -1; r++) {
    		document.getElementsByName("PLY_BTN")[r].disabled = false;
    }

</script>

<script>
function popitup1(f_name) {
    var url = "./ansible_linux_playbookflow_content_popup_oyw.php?F_NAME=" + f_name;
    window.open(url,"Flow Show","width=1200,height=700,left=100,top=60");
}
</script>

<script>
function popitup_ply1(p_name) {
    var url = "./ansible_linux_playbook_content_popup.php?P_NAME=" + p_name;
    window.open(url,"Playbook Contents","width=900,height=600,left=100,top=60");
}
</script>


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Flow > Linux > Flow 실행</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
                        echo "<table>";
                        echo "<tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible Playbook Flow 통한 Linux 업무 자동화</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->


                        <div class="panel-body">

            		  <div class="row">
                	    <div class="col-lg-3">
                              <div class="label_info" style="margin-bottom: 5px;padding: 4px 12px;">

			       <table>
                               <tr><td width=70><font size=3><b>1.&nbsp;Flow&nbsp;&nbsp;</b></font></td>

<?php
                               echo "<td><button id=button1 name=btn1 class='btn btn-primary' onclick='myFunction()'><b>선택</b></button></td></tr> ";
?>

			       </table>

                              </div>
                	    </div>
                	    <div class="col-lg-9">
			    </div>
            		  </div>


            		  <div class="row">
                            <div class="col-lg-12">
			      <div id="list1">

<?php
	$F_NAME = '';
        if ($_POST['F_NAME']) {
                $F_NAME = $_POST['F_NAME'];
                echo "<div class='panel-body'>";
                echo "<div>";

		echo "
				<div class='table-responsive scrollClass-vsm'>
                                <table id='table1' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                ";

                $cmd_sql = "select * from Ansible_linux_playbookflow_Save2 where f_name = '{$F_NAME}'";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_playbook_list = $newArray['f_playbook_list'];
                                $f_member_list = $newArray['f_member_list'];
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                echo "<tr><td><b><font color=blue>$f_name</font></b></td><td>$f_explain</td><td>$gubun_name</td><td><button id=btn_popup name=btn_popup value={$f_name} class='btn btn-success btn-xs' onclick='popitup1(\"$f_name\")'>$f_name 내용보기</button></td>";
                        }
                }

        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";  //scrollClass-vsm

                echo "</div>";
                echo "</div>";

        }
        else echo "<br>";

?>




			      </div>
                            </div>
			  </div>

			  <br>

            		  <div class="row">
                            <div class="col-lg-3">
                              <div class="label_warning" style="margin-bottom: 5px;padding: 4px 12px;">

                               <table>
                               <tr><td width=105><font size=3><b>2.&nbsp;Flow 실행&nbsp;&nbsp;</b></font></td>
<?php
 			       echo "<td><button id='button_flow' name=btn_flow value='{$F_NAME}' class='btn btn-primary' onclick='myFunction5()'><b>실행 선택</b></button></td></tr>";
?>
                               </table>

                              </div>

                            </div>
                            <div class="col-lg-9">
                            </div>
                          </div>



                          <div class="row">
                            <div class="col-lg-12">




<?php

if($F_NAME) {


                echo "<div id=wrapper>";
                echo "<div class='panel-body'>";

                echo "<div class='row'>";
                echo "<div class='col-lg-12'>";


	// ansible_linux_playbookflow_content_popup_oyw.php //

        $cmd_sql = "select * from Ansible_linux_playbookflow_Save2 where f_name = '{$F_NAME}'";
        $res = mysqli_query($mysqli,$cmd_sql);

        $newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
        $f_seq = $newArray['f_seq'];
        $f_name = $newArray['f_name'];
        $f_explain= $newArray['f_explain'];
        $f_explain_dec = base64_decode($f_explain);
        $f_gubun = $newArray['f_gubun'];
        $f_gubun1 = $newArray['f_gubun1'];
        $f_playbook_list = $newArray['f_playbook_list'];
        $f_member_list = $newArray['f_member_list'];

	$SELECT_STR5 = '';
        $cmd_sql5 = "select * from Ansible_playbookflow_gubun";
        $res5 = mysqli_query($mysqli,$cmd_sql5);
        if ($res5) {
		$cnt=1;
               	while ($newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                       	$gubun5 = $newArray5['gubun'];
                	$gubun_name5 = $newArray5['gubun_name'];

			if($f_gubun == $gubun5) $SELECT_OPT = "selected";
			else $SELECT_OPT = '';

			$STR5 = "<option value=$cnt $SELECT_OPT>$gubun_name5</option>";
			$SELECT_STR5 = $SELECT_STR5 . $STR5 ;

			$cnt = $cnt + 1;
		}
	}

        $SELECT_STR7 = '';
        $cmd_sql7 = "select * from Ansible_playbookflow_gubun1";
        $res7 = mysqli_query($mysqli,$cmd_sql7);
        if ($res7) {
                $cnt=1;
                while ($newArray7 = mysqli_fetch_array($res7,MYSQLI_ASSOC)) {
                        $gubun7 = $newArray7['gubun'];
                        $gubun_name7 = $newArray7['gubun_name'];

			if($f_gubun1 == $gubun7) $SELECT_OPT = "selected";
			else $SELECT_OPT = '';

                        $STR7 = "<option value=$cnt>$gubun_name7</option>";
                        $SELECT_STR7 = $SELECT_STR7 . $STR7 ;

                        $cnt = $cnt + 1;
                }
        }




	echo "

            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div id='P_mod' class='panel-body'>


			 <div class='row'>
                            <div class='col-lg-5'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>

                               <table id=table1 value='$F_NAME'>
                               <tr><td style='height:33px'><font size=2><b>Flow 이름:&nbsp;$F_NAME</b></font></td></tr>
                               </table>

                              </div>
                            </div>

                            <div class='col-lg-7'>
                            </div>
			 </div>


                      <div id=wrapper>
                        <div class='panel-body'>

            		  <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_danger' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Flow 실행 Host, Group 리스트</font></b>
                              </div>
			    </div>
                            <div class='col-lg-9'>
			    </div>
		          </div>

            		  <div class='row'>
                	    <div class='col-lg-11'>
	";

	
		// Host, Group List display //
		$T_CNT = 0;
		$HOST_LIST = '';
		$G_LIST = '';
        	$T_MEMBER = explode('|',$f_member_list);
        	foreach($T_MEMBER as $SubMember) {

                	$NODENAME = $SubMember;

                	$cmd_sql = "select * from Ansible_linux_host where nodename = '{$NODENAME}'";
                	$res = mysqli_query($mysqli,$cmd_sql);

                       	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
                	$data = mysqli_fetch_array($res);
                        $hostname = $newArray['hostname'];

                	if (isset($hostname)) {

                                $hostname = $newArray['hostname'];
                                $nodename= $newArray['nodename'];
                                $ip = $newArray['ip'];
				if(!$HOST_LIST) $HOST_LIST = "<a title='Nodename: {$nodename}\nIP: {$ip}'>" . $hostname . "</a>";
                                else {
                                        $MOD = $T_CNT % 15;
                                        if($MOD == 0) $BR = "<br>";
                                        else $BR = "";

                                        $HOST_LIST = $HOST_LIST . "{$BR}&nbsp;<font color=red><b>,</b></font>&nbsp;" . "<a title='Nodename: {$nodename}\nIP: {$ip}'>" . $hostname . "</a>";
                                }

			}
			else {
				if(!$G_LIST) $G_LIST = $NODENAME;
				else $G_LIST = $G_LIST . '|' . $NODENAME;
			}

			$T_CNT = $T_CNT + 1;
		}

                $T_CNT = 0;
		if($G_LIST) {

			$GROUP_LIST = '';
                	$G_MEMBER = explode('|',$G_LIST);
                	foreach($G_MEMBER as $SubGroup) {

                        	$GROUPNAME = $SubGroup;

                        	$cmd_sql = "select * from Ansible_linux_group where groupname = '{$GROUPNAME}'";
                        	$res = mysqli_query($mysqli,$cmd_sql);
                        	if ($res) {
                                	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);

                                	$groupname = $newArray['groupname'];
                                	$member= $newArray['member'];

					$SubGroup_Member_list = '';
					$G_member = explode('|',$member);
					foreach($G_member as $subgroup_member) {
						if(!$SubGroup_Member_list) $SubGroup_Member_list = $subgroup_member;
						else $SubGroup_Member_list = $SubGroup_Member_list . "\n" . $subgroup_member;
					}

					if(!$GROUP_LIST) $GROUP_LIST = "<a title='{$SubGroup_Member_list}'>" . $groupname . "</a>";
                                        else {
                                                $MOD = $T_CNT % 13;
                                                if($MOD == 0) $BR = "<br>";
                                                else $BR = "";

                                                $GROUP_LIST =  $GROUP_LIST . "{$BR}&nbsp;<font color=red><b>,</b></font>&nbsp;" . "<a title='{$SubGroup_Member_list}'>" . $groupname . "</a>";
					}

				}

			        $T_CNT = $T_CNT + 1;
			}

		}


		if($HOST_LIST or $GROUP_LIST) {

			echo "<table border=1 width='100%' class='table table-striped table-bordered table-hover'>";
			if($HOST_LIST and $GROUP_LIST) {
				echo "
				<tr><td>ㅇ 호스트 리스트: </td>
				<td>$HOST_LIST</td></tr>
				<tr><td>ㅇ 그룹 리스트: </td>
				<td>$GROUP_LIST</td></tr>
				";

			}
			else if($HOST_LIST) {
				echo "
				<tr><td>ㅇ 호스트 리스트: </td>
				<td>$HOST_LIST</td></tr>
				";
			}
			else if($GROUP_LIST) {
				echo "
				<tr><td>ㅇ 그룹 리스트: </td>
				<td>$GROUP_LIST</td></tr>
				";
			}

			echo "</table>";

		}






	echo "
			    </div>
                	    <div class='col-lg-1'>
			    </div>

		 	    <div id='Inventory_Modify_Div'>
		 	    </div>


			  </div>
			  
	";


	echo "

            		  <div class='row'>
                            <div class='col-lg-3'>
                              <div class='label_danger' style='margin-bottom: 5px;padding: 4px 12px;'>
				  <table>
                                  <tr><td width=400><b><font size=3>Flow 실행 Playbook 리스트</font></b></td></tr>
				  </table>
                              </div>
			    </div>
                            <div class='col-lg-9'>
			    </div>
			  </div>

            		  <div class='row'>
                	    <div class='col-lg-11'>
				<div id='txt1'>

                                <div class='table-responsive'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>순서</th>
                                        <th>Playbook<br>구분</th>
                                        <th>Playbook<br>분류</th>
                                        <th>Playbook 이름</th>
                                        <th>Playbook 설명</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable_flow_exec'>

        ";

	$TMP_CNT = 1;
        $T_FLOW = explode('|',$f_playbook_list);
        foreach($T_FLOW as $SubFlow) {

                $P_NAME = $SubFlow;

                $cmd_sql = "select * from Ansible_linux_playbook where p_name = '{$P_NAME}'";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                                $newArray = mysqli_fetch_array($res,MYSQLI_ASSOC) ;

                                $p_name = $newArray['p_name'];
                                $p_explain= $newArray['p_explain'];
                                $p_explain= base64_decode($p_explain);
                                $p_gubun = $newArray['p_gubun'];
                                $p_gubun1 = $newArray['p_gubun1'];

				if($BEFPLAYBOOK == $p_name) {
					$p_name = $SELECTPLY;
					$BTN_STR1 = "btn btn-danger btn-xs";

                			$cmd_sql1 = "select * from Ansible_linux_playbook where p_name = '{$p_name}'";
                			$res1 = mysqli_query($mysqli,$cmd_sql1);
                			if ($res) {
                                		$newArray1 = mysqli_fetch_array($res1,MYSQLI_ASSOC) ;
                                		$p_explain= $newArray1['p_explain'];
                                		$p_explain= base64_decode($p_explain);
                                		$p_gubun = $newArray1['p_gubun'];
                                		$p_gubun1 = $newArray1['p_gubun1'];
					}

				}
                                else {
					$p_name = $newArray['p_name'];
					$BTN_STR1 = "btn btn-success btn-xs";
				}

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

                                echo "<tr id='ROW{$TMP_CNT}'><td>$TMP_CNT</td><td>$gubun_name</td><td>$gubun_name1</td><td><a title='{$p_explain}'><button id=PLY_BTN name=PLY_BTN class='{$BTN_STR1}' onclick='popitup_ply1(\"$p_name\")'>$p_name</button></a></td><td>$p_explain</td></tr>";
                }

		$TMP_CNT = $TMP_CNT + 1;

        }

                echo "</tbody>";
                echo "</table>";
                echo "</div>";






?>




<?php
	echo "


                                </div>
				<div class='col-lg-1'>
                                </div>
                              </div>




                         </div>

			</div>




        ";





                echo "</div>"; 
                echo "</div>"; 
                echo "</div>";  //panel-body
                echo "</div>";  //wrapper
}

?>




                              </div>
                            </div>




                          <div class="row">
                            <div class="col-lg-12">
                              <div id="txt5" class="panel-body">
                              </div>

<div id='wait' style='display:none;position:absolute;top:-650px;left:800px;padding:2px;'>
<img src='../vendor/login/loading2.gif' width=110 height=110 />
<br>
<font size=4 color=red><b> Loading.....</b></font>
</div>



                              </div>
                            </div>



                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

	    <div>
		<a style='display:scroll;position:fixed;bottom:30px;right:20px;' href='#' title=Top><font color=red size=5><b>TOP</b></font></a>
	    </div>

        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




