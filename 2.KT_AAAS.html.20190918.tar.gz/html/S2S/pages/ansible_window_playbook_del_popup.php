<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
function PlaybookDelete1(p_name) {
        var total_str = p_name + '|YES';
        window.opener.sendMeData_PlyDel(total_str);
        window.close();
}
</script>

<script>
function PlaybookDelete2(p_name) {
        window.close();
}
</script>


</head>

<body>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>





<?php

	$P_NAME = trim($_GET['P_NAME']);

	echo "

            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div id='P_mod' class='panel-body'>


			 <div class='row'>
                            <div class='col-lg-6'>
                              <div class='label_danger' style='margin-bottom: 5px;padding: 4px 12px;'>
				  <table><tr>
                                  <td width=300><b><font size=3>$P_NAME</font></b></td>
				  </tr></table>
                              </div>
                            </div>

                            <div class='col-lg-6'>
                            </div>
			 </div>


                      <div id=wrapper>
                        <div class='panel-body'>


	";


	echo "
			  
            		  <div class='row'>
                	    <div class='col-lg-11'>
				<div id='txt1'>

                                <div class='table-responsive'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Playbook ID </th>
                                        <th>Playbook 이름</th>
                                        <th>Playbook 설명</th>
                                        <th>Playbook 구분</th>
                                        <th>Playbook 분류</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable_flow_mod'>

        ";
                $cmd_sql = "select * from Ansible_window_playbook where p_name = '{$P_NAME}'";
                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
                                $p_seq = $newArray['p_seq'];
                                $p_name = $newArray['p_name'];
                                $p_explain= $newArray['p_explain'];
                                $p_explain= base64_decode($p_explain);
                                $p_content = $newArray['p_content'];
                                $p_content_dec = base64_decode($p_content);
                                $p_gubun = $newArray['p_gubun'];
                                $p_gubun1 = $newArray['p_gubun1'];
                                $p_gubun2 = $newArray['p_gubun2'];

                                $p_seq = sprintf('%09d',$p_seq);
                                $p_seq = 'PLY' . $p_seq;

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun where gubun = '{$p_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbook_gubun1 where gubun = '{$p_gubun1}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name1 = $newArray3['gubun_name'];

				echo "<tr><td>$p_seq</td><td>$p_name</td><td>$p_explain</td><td>$gubun_name</td><td>$gubun_name1</td></tr>";
		}


        echo "</tbody>";
        echo "</table>";
	echo "
	<br>
	<br>
	<p align=center><font size=4 color=blue><b>정말로 $P_NAME 삭제하겠습니까?i</b></font></p>
	<table align=center>
	<tr><td width=70><button class='btn btn-danger btn-sm' onclick='PlaybookDelete1(\"$P_NAME\")'><b>YES</b></button></td>
	<td width=70><button class='btn btn-info btn-sm' onclick='PlaybookDelete2(\"$P_NAME\")'><b>NO</b></button></td></tr>
	</table>


	";


        echo "</div>";


	echo "


                                </div>
				<div class='col-lg-1'>
                                </div>
                              </div>




                         </div>

			</div>






        ";


?>



                    </div>


                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>
