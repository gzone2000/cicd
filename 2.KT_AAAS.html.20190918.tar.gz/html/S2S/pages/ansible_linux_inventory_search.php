<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
function myFunction() {

    document.getElementsByName("btn1")[0].disabled = true;

    var table = document.getElementById('table_source');
    for (var r = 0, n = table.rows.length; r < n - 1; r++) {
        document.getElementsByName("L_DATA")[r].disabled = true;
    }

    $(document).ajaxStart(function(){
      $("#wait").css("display", "block");
    });
    $(document).ajaxComplete(function(){
      	$("#wait").css("display", "none");
      	document.getElementsByName("btn1")[0].disabled = false;
        for (var r = 0, n = table.rows.length; r < n - 1; r++) {
                document.getElementsByName("L_DATA")[r].disabled = false;
        }
    });

    var ip = document.getElementsByName("ip")[0].value;
    var port = document.getElementsByName("PORT")[0].value;

    var concat = ip + '|' + port;
    var String = "./ansible_linux_inventory_sub.php?STR=" + "'" + btoa(concat) + "'";
    $("#txt").load(String);
}
    document.getElementsByName("btn1")[0].disabled = false;
    for (var r = 0, n = table.rows.length; r < n -1; r++) {
                document.getElementsByName("L_DATA")[r].disabled = false;
    }
</script>



</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Inventory > Linux > 호스트 검색, 추가, 삭제</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
                        echo "<table>";
                        echo "<tr><td width=350><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible setup 모듈을 통한 호스트 정보 수집</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->



<?php

if(!$_GET['add'] and !$_GET['del']){

	echo "
                        <div class='panel-body'>
            		  <div class='row'>
                	    <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>

			       <table colnum=4>
                               <tr><td><font size=3>Search IP:&nbsp;&nbsp;&nbsp;</font></td>
                               <td><input type='text' class='form-control' name='ip' size='50' placeholder='Enter IP'></td></tr>

                               <tr><td><font size=3>Ansible Port:&nbsp;&nbsp;&nbsp;</font></td>
                               <td><input type='text' class='form-control' name='PORT' size='50' value=22></td>
                               <td>&nbsp;&nbsp;&nbsp;</td>
                               <td><button id=button1 name=btn1 class='btn btn-primary' onclick='myFunction()'><b>실행</b></button></td></tr> 
			       </table>

                              </div>
                	    </div>
                	    <div class='col-lg-6'>
			    </div>
            		  </div>

            		  <div class='row'>
                            <div class='col-lg-12'>
			      <br>
                            </div>
			  </div>


            		  <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>실행 결과</font></b>
			      </div>

                              <div id='txt' class='panel-body'>
                              </div>

<div id='wait' style='display:none;position:absolute;top:30px;left:550px;padding:2px;'>
<img src='../vendor/login/loading2.gif' width=110 height=110 />
<br>
<font size=4 color=red><b> Loading...</b></font>
</div>


                	    </div>
            		  </div>


                        </div>
                        <!-- /.panel-body -->

	";  //echo




		echo "
                    </div>
                </div>
            </div>

<br>
<br>
            <div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>

                        <table>
                        <tr><td width=350><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible Linux 호스트 리스트</font></td>
                        </tr>
                        </table>

                        </div>

                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-10'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Ansible Linux 호스트 리스트 및 삭제</font></b>
                              </div>


                            </div>
                            <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                            </div>
                          </div>

                          <div class='row'>
                            <div class='col-lg-12'>
                              <br>
                            </div>
                          </div>


                          <div class='row'>
                            <div class='col-lg-12'>

				<div class='table-responsive scrollClass-sm'>
                                <table id='table_source' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                        <th>Linux 버젼</th>
                                        <th>Kernel 버젼</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                ";


        $cmd_sql = "select * from Ansible_linux_host order by nodename";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $hostname = $newArray['hostname'];
                        $nodename= $newArray['nodename'];
                        $ip = $newArray['ip'];
                        $linux_ver = $newArray['linux_ver'];
                        $kernel_ver = $newArray['kernel_ver'];

                        echo "<tr><td>Linux</td><td>$hostname</td><td>$nodename</td><td>$ip</td><td>$linux_ver</td><td>$kernel_ver</td>";
                        echo "<td width=50><form action=./ansible_linux_inventory_host_del.php>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=L_DATA value={$ip}><b><font size=2>호스트 삭제</font></b></button></center></form></td>";
			echo "</tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";



                echo "

                            </div>
                          </div>


                        </div>
                ";





}

else if($_GET['add']) {

	if($_GET['add'] != "2"){
	
		$INPUT_IP = $_GET['add'];
		echo "
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>호스트 추가 결과 : </font><font size=3 color=blue>성공</font></b>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

				<div class='table-responsive scrollClass-sm'>
                                <table width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                        <th>Linux 버젼</th>
                                        <th>Kernel 버젼</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
		";


	$cmd_sql = "select * from Ansible_linux_host where ip = '$INPUT_IP' order by nodename";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $hostname = $newArray['hostname'];
                        $nodename= $newArray['nodename'];
                        $ip = $newArray['ip'];
                        $linux_ver = $newArray['linux_ver'];
                        $kernel_ver = $newArray['kernel_ver'];

                        echo "<tr><td>Linux</td><td>$hostname</td><td>$nodename</td><td>$ip</td><td>$linux_ver</td><td>$kernel_ver</td>";
                        echo "<td width=50><form action=./ansible_linux_inventory_host_del.php>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=L_DATA value={$ip}><b><font size=2>호스트 삭제</font></b></button></center></form></td>";
			echo "</tr>";
		}
	}

        $cmd_sql = "select * from Ansible_linux_host where ip <> '$INPUT_IP' order by nodename";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $hostname = $newArray['hostname'];
                        $nodename= $newArray['nodename'];
                        $ip = $newArray['ip'];
                        $linux_ver = $newArray['linux_ver'];
                        $kernel_ver = $newArray['kernel_ver'];

                        echo "<tr><td>Linux</td><td>$hostname</td><td>$nodename</td><td>$ip</td><td>$linux_ver</td><td>$kernel_ver</td>";
                        echo "<td width=50><form action=./ansible_linux_inventory_host_del.php>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=L_DATA value={$ip}><b><font size=2>호스트 삭제</font></b></button></center></form></td>";
			echo "</tr>";
                }
        }


        echo "</tbody>";
        echo "</table>";
        echo "</div>";



		echo "

			<br>
			<a href=./ansible_linux_inventory_search.php>
			<button type='button' class='btn btn-primary'>
			<b><font size=3> 다른 호스트 검색 </font></b>
			</button></a>
			
                            </div>
                          </div>


                        </div>
        	";  


	}
	else if($_GET['add'] == "2"){

		echo "
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>호스트 추가 결과 : </font><font size=3 color=red>실패</font></b>
				  <br><font size=2 color=blue>이미 IP나 호스트 이름이 중복 됩니다.!!</font>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

				<div class='table-responsive scrollClass-sm'>
                                <table width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                        <th>Linux 버젼</th>
                                        <th>Kernel 버젼</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";


        $cmd_sql = "select * from Ansible_linux_host order by nodename";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $hostname = $newArray['hostname'];
                        $nodename= $newArray['nodename'];
                        $ip = $newArray['ip'];
                        $linux_ver = $newArray['linux_ver'];
                        $kernel_ver = $newArray['kernel_ver'];

                        echo "<tr><td>Linux</td><td>$hostname</td><td>$nodename</td><td>$ip</td><td>$linux_ver</td><td>$kernel_ver</td>";
                        echo "<td width=50><form action=./ansible_linux_inventory_host_del.php>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=L_DATA value={$ip}><b><font size=2>호스트 삭제</font></b></button></center></form></td>";
			echo "</tr>";
                }
        }



        echo "</tbody>";
        echo "</table>";
        echo "</div>";



                echo "
			<br><br>
                        <a href=./ansible_linux_inventory_search.php>
                        <button type='button' class='btn btn-primary'>
                        <b><font size=3>다른 호스트 추가</font></b>
                        </button></a>


			
                            </div>
                          </div>


                        </div>
        	";  

	}

}


else if($_GET['del']) {

	if($_GET['del'] != "2"){
	
		$INPUT_IP = $_GET['del'];
		echo "
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>호스트 삭제 결과 : </font><font size=3 color=blue>성공</font></b>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

				<div class='table-responsive scrollClass-sm'>
                                <table width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                        <th>Linux 버젼</th>
                                        <th>Kernel 버젼</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
		";


	$cmd_sql = "select * from Ansible_linux_host order by nodename";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $hostname = $newArray['hostname'];
                        $nodename= $newArray['nodename'];
                        $ip = $newArray['ip'];
                        $linux_ver = $newArray['linux_ver'];
                        $kernel_ver = $newArray['kernel_ver'];

                        echo "<tr><td>Linux</td><td>$hostname</td><td>$nodename</td><td>$ip</td><td>$linux_ver</td><td>$kernel_ver</td>";
                        echo "<td width=50><form action=./ansible_linux_inventory_host_del.php>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=L_DATA value={$ip}><b><font size=2>호스트 삭제</font></b></button></center></form></td>";
			echo "</tr>";
		}
	}

        echo "</tbody>";
        echo "</table>";
        echo "</div>";



		echo "
			<br><br>
                        <a href=./ansible_linux_inventory_search.php>
                        <button type='button' class='btn btn-primary'>
                        <b><font size=3>다른 호스트 추가</font></b>
                        </button></a>

			
                            </div>
                          </div>


                        </div>
        	";  


	}
	else if($_GET['del'] == "2"){

		echo "
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-12'>
                              <div class='label_success' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>호스트 삭제 결과 : </font><font size=3 color=red>실패</font></b>
				  <br><font size=2 color=blue>삭제할 호스트가 없습니다.!!</font>
                              </div>

                              <div id='txt' class='panel-body'>
                              </div>

				<div class='table-responsive scrollClass-sm'>
                                <table width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>호스트 이름</th>
                                        <th>노드 이름</th>
                                        <th>IP</th>
                                        <th>Linux 버젼</th>
                                        <th>Kernel 버젼</th>
                                        <th>비고</th>
                                    </tr>
                                </thead>
                                <tbody>
                ";


        $cmd_sql = "select * from Ansible_linux_host order by nodename";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $hostname = $newArray['hostname'];
                        $nodename= $newArray['nodename'];
                        $ip = $newArray['ip'];
                        $linux_ver = $newArray['linux_ver'];
                        $kernel_ver = $newArray['kernel_ver'];

                        echo "<tr><td>Linux</td><td>$hostname</td><td>$nodename</td><td>$ip</td><td>$linux_ver</td><td>$kernel_ver</td>";
                        echo "<td width=50><form action=./ansible_linux_inventory_host_del.php>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=L_DATA value={$ip}><b><font size=2>호스트 삭제</font></b></button></center></form></td>";
			echo "</tr>";
                }
        }



        echo "</tbody>";
        echo "</table>";
        echo "</div>";



                echo "
			
                            </div>
                          </div>


                        </div>
        	";  

	}


}

?>



                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




