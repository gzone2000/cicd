<?php

echo ("

<style>

.box {
    padding: 5px;
    border: 4px;
    border-bottom: 5px solid blue;
    width:1600px;
}

.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 3px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 1px 1px;
    border-radius: 6px;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */
.button4 {background-color: #e7e7e7;} /* Gray */
.button5 {background-color: #555555;} /* Black */
.button6 {background-color: #008000;} /* Green */
.button7 {background-color: #800080;} /* Purple */
.button8 {background-color: #800000;} /* Maroon */

.button_p2 {background-color: #008CBA; cursor: pointer;} /* Blue */
.button_p3 {background-color: #f44336; cursor: pointer;} /* Red */
.button_p4 {background-color: #e7e7e7; color: black;} /* Gray */
.button_p6 {background-color: #008000; cursor: pointer;} /* Green */


/* text-decoration : OFF */
.txtDecoOff {
  text-decoration: none;
}


/* sliding Button */
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: \"\";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

.slider:after
{
 content:'OFF';
 color: red;
 display: block;
 position: absolute;
 transform: translate(-50%,-50%);
 top: 50%;
 left: 50%;
 font-size: 15px;
 font-family: Verdana, sans-serif;
}

input:checked + .slider:after
{
  content:'ON';
}


.btn_x {
  border: 2px solid black;
  background-color: white;
  color: black;
  padding: 4px 16px;
  font-size: 16px;
  cursor: pointer;
}

/* Green */
.success {
  border-color: #4CAF50;
  color: green;
}

.success:hover {
  background-color: #4CAF50;
  color: white;
}

.default:hover {
  background: #e7e7e7;
}



.scrollClass {
  height:510px;
  overflow-y:auto;
}

.scrollClass-xy {
  height:510px;
  overflow-x:auto;
  overflow-y:auto;
}

.scrollClass-vsm {
  height:110px;
  overflow-y:auto;
}

.scrollClass-sm {
  height:220px;
  overflow-y:auto;
}

.scrollClass-md {
  height:360px;
  overflow-y:auto;
}

.scrollClass-lg {
  height:520px;
  overflow-y:auto;
}


/* Progress bar */
#myProgress {
  width: 100%;
  background-color: #ddd;
}

#myBar {
  width: 10%;
  height: 20px;
  background-color: #4CAF50;
  text-align: center;
  line-height: 20px;
  color: white;
}


/* label */

.label_danger {
  background-color: #ffdddd;
  border-left: 6px solid #f44336;
}

.label_success {
  background-color: #ddffdd;
  border-left: 6px solid #4CAF50;
}

.label_info {
  background-color: #e7f3fe;
  border-left: 6px solid #2196F3;
}


.label_warning {
  background-color: #ffffcc;
  border-left: 6px solid #ffeb3b;
}


.table-wrapper-scroll-y {
  display: block;
  max-height: 340px;
  overflow-y: auto;
  -ms-overflow-style: -ms-autohiding-scollbar;
}


/* TableDnD */
tr.myDragClass td {
    /*position: fixed;*/
    color: yellow;
    text-shadow: 0 0 10px black, 0 0 10px black, 0 0 8px black, 0 0 6px black, 0 0 6px black;
    background-color: #999;
    -webkit-box-shadow: 0 12px 14px -12px #111 inset, 0 -2px 2px -1px #333 inset;
}
tr.myDragClass td:first-child {
    -webkit-box-shadow: 0 12px 14px -12px #111 inset, 12px 0 14px -12px #111 inset, 0 -2px 2px -1px #333 inset;
}
tr.myDragClass td:last-child {
    -webkit-box-shadow: 0 12px 14px -12px #111 inset, -12px 0 14px -12px #111 inset, 0 -2px 2px -1px #333 inset;
}




</style>


");

?>
