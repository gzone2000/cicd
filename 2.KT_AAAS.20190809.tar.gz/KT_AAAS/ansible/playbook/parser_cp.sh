#!/bin/bash

FILE1=$1
IFS='
'
#DIR=/home/cloudapp/playbook
#STR_START='TASK [debug]'
#STR_LINE2='ok:'
#STR_LINE3='MSG:'
#STR_LINE4='TASK ['

START_OK='N'
END_Y='Y'
CNT=1

F_START_OK='N'
F_END_Y='Y'
F_CNT=1

echo
for LINE in $(cat $FILE1)
do

#echo $LINE
LC1=$(echo $LINE | grep 'ok:' | wc -l)
LC2=$(echo $LINE | grep 'MSG:' | wc -l)
LC3=$(echo $LINE | grep 'TASK \[' | wc -l)
LC4=$(echo $LINE | grep 'fatal:' | wc -l)
LC5=$(echo $LINE | grep 'STDERR:' | wc -l)
LC7=$(echo $LINE | grep 'PLAY RECAP' | wc -l)
LC8=$(echo $LINE | grep 'failed=' | wc -l)

if [ "$END_Y" == "N" ] ; then
        if [ $CNT -eq 1 ] ; then
                echo "$SERVER_NAME"
                CNT=$(($CNT+1))
        fi
        if [ $LC1 -eq 1 -o $LC3 -eq 1 ] ; then
                END_Y='Y'
                START_OK='N'
                CNT=1
                echo
                echo
        else
                if [ $LC7 -ne 1 -a $LC8 -ne 1 ] ; then
                        echo "$LINE" | sed -e "s/u'//g" -e "s/'//g" -e "s/\[//g" -e "s/\]//g" -e "s/{//g" -e "s/}//g"
                fi
        fi
fi

if [ "$START_OK" == "Y" ] ; then 

	if [ $LC2 -eq 1 ] ; then
        	END_Y='N'
	else
        	END_Y='Y'
	fi
       	START_OK='N'
fi

if [ $LC1 -eq 1 ] ; then
        START_OK='Y'
        SERVER_NAME=$(echo $LINE | awk '{print $2}')
fi


if [ "$F_END_Y" == "N" ] ; then
        if [ $F_CNT -eq 1 ] ; then
                echo "$SERVER_NAME"
                F_CNT=$(($F_CNT+1))
        fi
        if [ $LC2 -eq 1 ] ; then
                F_END_Y='Y'
                F_START_OK='N'
                F_CNT=1
                echo
                echo
        else
                echo "$LINE" | sed -e "s/u'//g" -e "s/'//g" -e "s/\[//g" -e "s/\]//g" -e "s/{//g" -e "s/}//g"
        fi
fi

if [ "$F_START_OK" == "Y" -a $LC5 -eq 1 ] ; then
        F_END_Y='N'
fi

if [ $LC4 -eq 1 ] ; then
        F_START_OK='Y'
        SERVER_NAME=$(echo $LINE | awk '{print $2}')
fi

done
