<?php

session_start();
if (!$_SESSION[ss_id]) {
        header('Location: ./logout.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
include "ip.inc" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];
$id  = $_SESSION[id];

$FNAME = trim($_GET['FNAME']);
//echo " #{$FNAME}# <br>";

if ($FNAME)
{


/*

# Ansible Directory
$ANSIBLE_DIR = "/home/ansible";
$ANSIBLE_PLAYBOOK_DIR = "$ANSIBLE_DIR/playbook";
$ANSIBLE_HOST_DIR = "$ANSIBLE_DIR/host";
$ANSIBLE_LOG_DIR = "$ANSIBLE_DIR/log";
$ANSIBLE_EXEC_DIR = "$ANSIBLE_DIR/exec";

*/


// 저장 파일 초기화 //
$MAX=$FLOW_MAX;
for($i=1;$i <= $MAX; $i++) {
	$FILE_INIT = shell_exec("cp /dev/null $ANSIBLE_LOG_DIR/Flow_{$i}.txt");
}

date_default_timezone_set("Asia/Seoul");
$RANDOM_NUM = mt_rand(1,1000);
$UTIME_F = explode('.',microtime(true));
$UTIME = $UTIME_F[0] . $UTIME_F[1] . $RANDOM_NUM ;

$STOP_STEP = 0;

	$FLOW_starttime = date("Y-m-d H:i:s");
        $cmd_sql = "select * from Ansible_window_playbookflow_Save where f_name = '{$FNAME}'";
        $res = mysqli_query($mysqli,$cmd_sql);

        $newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
        $f_seq = $newArray['f_seq'];
        $f_name = $newArray['f_name'];
        $f_explain= $newArray['f_explain'];
        $f_explain_dec = base64_decode($f_explain);
        $f_content = $newArray['f_content'];
        $f_gubun = $newArray['f_gubun'];



	// flow 안의 내용을 임시 테이블에 넣음 //

	$PARTIAL_SUCC = "";
        $cmd_sql = "CREATE TABLE Ansible_window_playbookflow_imsi_SF_$UTIME (step varchar(3) unique key, result varchar(5) default NULL, p_name varchar(100) default NULL, starttime datetime default NULL, endtime datetime default NULL, succ_cnt int, fail_cnt int, skip_cnt int, succ_member varchar(5000) default NULL, fail_member varchar(5000) default NULL, skip_member varchar(5000) default NULL);";
        $res = mysqli_query($mysqli,$cmd_sql);

        $cmd_sql = "CREATE TABLE Ansible_window_playbookflow_imsi_$UTIME (step varchar(3) unique key,p_name varchar(100) default NULL,member varchar(5000) default NULL);";
        $res = mysqli_query($mysqli,$cmd_sql);

        $T_FLOW = explode('||',$f_content);
        foreach($T_FLOW as $SubFlow) {
                $SUBFLOW = explode('|',$SubFlow);
                $STEP = $SUBFLOW[0];
                $P_NAME = $SUBFLOW[1];
                $MEMBERS = $SUBFLOW[2];

                $cmd_sql = "insert into Ansible_window_playbookflow_imsi_$UTIME values('{$STEP}','{$P_NAME}','{$MEMBERS}')";
                $res = mysqli_query($mysqli,$cmd_sql);
        }


	// flow 내의 playbook을 하나씩 실행//

        $cmd_sql5 = "select * from Ansible_window_playbookflow_imsi_$UTIME";
        $res5 = mysqli_query($mysqli,$cmd_sql5);
        if ($res5) {
            while ($newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                $T_step = $newArray5['step'];
                $PLAYBOOK_NAME = $newArray5['p_name'];
                $MEMBERS = $newArray5['member'];

		//echo "STEP : $T_step , Playbook : $PLAYBOOK_NAME , Member : $MEMBERS <br>";
		
		//*********************************************************************************************//
		// playbook Inventory 스트링으로 만들어 파일로 만들고 playbook도 DB에서 읽어 파일로 만들고 실행//
		//*********************************************************************************************//

		$PIECES = explode(",", $MEMBERS);

                $cnt = 0;
		$HOST_STR = '';
		$HOST_STR_T = '';
                while ($PIECES[$cnt]) {

			//host
                        $cmd_sql1 = "select * from Ansible_window_host where nodename = '$PIECES[$cnt]'";
                        $res1 = mysqli_query($mysqli,$cmd_sql1);

                	$data = mysqli_fetch_array($res1);
                	$isset_check1 = $data['nodename'];

                	if ($isset_check1 != '') {
                               	$hostname = $data['hostname'];
                               	$nodename= $data['nodename'];
                               	$ip = $data['ip'];

				$SKIP_HOST_YN = "N";
				for ($x=1;$x < $T_step ; $x++) {

				  $cmd_sqlA = "select fail_member from Ansible_window_playbookflow_imsi_SF_$UTIME where step = '$x'";
                        	  $resA = mysqli_query($mysqli,$cmd_sqlA);
                		  $dataA = mysqli_fetch_array($resA);
                		  $isset_checkA = $dataA['fail_member'];
                		  if ($isset_checkA != '') {

					$cntA = 0;
        				$T_HOSTLIST = explode('|',$isset_checkA);
					while ($T_HOSTLIST[$cntA]) {
						$T_HOSTA = $T_HOSTLIST[$cntA];
                				if($T_HOSTA == $nodename) { 
							$SKIP_HOST_YN = "Y";
							break;
						}
						$cntA = $cntA + 1;
        				}

				  }

				}

				if ($SKIP_HOST_YN == 'N') {
                                	$username = $data['username'];
                                	$password = base64_decode($data['password']);
                                	$HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_connection=winrm ansible_user=$username ansible_password=$password  ansible_winrm_server_cert_validation=ignore\n";
                                	$HOST_STR_T = $HOST_STR_T . "$nodename ansible_host=$ip ansible_connection=winrm ansible_user=$username ansible_password=*********  ansible_winrm_server_cert_validation=ignore\n";
				}
				
                        }
			else {
				//group
                        	$cmd_sql1 = "select * from Ansible_window_group where groupname = '$PIECES[$cnt]'";
                        	$res1 = mysqli_query($mysqli,$cmd_sql1);
                		$data = mysqli_fetch_array($res1);
                		$isset_check1 = $data['groupname'];

                		if ($isset_check1 != '') {

					$HOST_STR = $HOST_STR . "\n";
					$HOST_STR = $HOST_STR . "[{$PIECES[$cnt]}]\n";
					$HOST_STR_T = $HOST_STR_T . "\n";
					$HOST_STR_T = $HOST_STR_T . "[{$PIECES[$cnt]}]\n";
                                	$groupname = $data['groupname'];
                                	$member5= $data['member'];
					$PIECES5 = explode("|", $member5);

                        		$cnt5 = 0;
                        		while ($PIECES5[$cnt5]) {

                                		$cmd_sql1 = "select * from Ansible_window_host where nodename = '$PIECES5[$cnt5]'";
                                		$res1 = mysqli_query($mysqli,$cmd_sql1);
                				$data = mysqli_fetch_array($res1);
                				$isset_check1 = $data['nodename'];

                				if ($isset_check1 != '') {
                                        		$hostname = $data['hostname'];
                                        		$nodename= $data['nodename'];
                                        		$ip = $data['ip'];

							$SKIP_HOST_YN = "N";
							for ($x=1;$x < $T_step ; $x++) {

							  $cmd_sqlB = "select fail_member from Ansible_window_playbookflow_imsi_SF_$UTIME where step = '$x'";
                        				  $resB = mysqli_query($mysqli,$cmd_sqlB);
                					  $dataB = mysqli_fetch_array($resB);
                					  $isset_checkB = $dataB['fail_member'];
                					  if ($isset_checkB != '') {

								$cntB = 0;
        							$T_HOSTLIST = explode('|',$isset_checkB);
								while ($T_HOSTLIST[$cntB]) {
									//$T_HOSTB = str_replace("\n","",trim($T_HOSTLIST[$cntB]));
									//$T_HOSTB = str_replace(" ","",$T_HOSTLIST[$cntB]);
									$T_HOSTB = $T_HOSTLIST[$cntB];
                							if($T_HOSTB == $nodename) { 
										$SKIP_HOST_YN = "Y";
										break;
									}
									$cntB = $cntB + 1;
        							}

							  }

							}

							if ($SKIP_HOST_YN == 'N') {
                                				$username = $data['username'];
                                				$password = base64_decode($data['password']);
                                				$HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_connection=winrm ansible_user=$username ansible_password=$password  ansible_winrm_server_cert_validation=ignore\n";
                                				$HOST_STR_T = $HOST_STR_T . "$nodename ansible_host=$ip ansible_connection=winrm ansible_user=$username ansible_password=*********  ansible_winrm_server_cert_validation=ignore\n";
							}
				

                                		}

                                		$cnt5 = $cnt5 + 1;

                        		}


                        	}
			}

                        $cnt = $cnt + 1;

                }



                $ANSIBLE_HOST_FILE = "$ANSIBLE_HOST_DIR/hosts" . $UTIME ;
                $ANSIBLE_HOST_NICK_FILE = "$ANSIBLE_HOST_DIR/hosts" ;

		if($HOST_STR != '') {
			$HOST_CREATE = shell_exec("echo '$HOST_STR' > $ANSIBLE_HOST_FILE");
		}
		else {
			$HOST_STR_T = "<font color=red>해당 Inventory(Host, Group)가 없습니다. 확인 바랍니다.</font>";
		}

        	$cmd_sql = "select p_content from Ansible_window_playbook where p_name = '{$PLAYBOOK_NAME}'";
        	$res = mysqli_query($mysqli,$cmd_sql);
		$data = mysqli_fetch_array($res);
                $p_content = base64_decode($data['p_content']);


                $ANSIBLE_PLAYBOOK_NICK_FILE = "${ANSIBLE_EXEC_DIR}/$PLAYBOOK_NAME" ;
                $ANSIBLE_PLAYBOOK_FILE = "${ANSIBLE_EXEC_DIR}/$PLAYBOOK_NAME" . $UTIME ;
                $ANSIBLE_PLAYBOOK_FILE_DIS = "${ANSIBLE_EXEC_DIR}/$PLAYBOOK_NAME" . $UTIME . "DIS" ;
		$FULLSTR = "ansible-playbook -i $ANSIBLE_HOST_FILE $ANSIBLE_PLAYBOOK_FILE";
		$DISPALY_FULLSTR = "ansible-playbook -i $ANSIBLE_HOST_DIR/hosts $ANSIBLE_PLAYBOOK_NICK_FILE";

		if (!$p_content) {
			$T_FILE = "$ANSIBLE_LOG_DIR/Flow_{$T_step}.txt" . $UTIME ;
			$S_FILE = "$ANSIBLE_LOG_DIR/Flow_Short_{$T_step}.txt" . $UTIME ;
                	$T_STRING = "
                      <div id=wrapper>
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Inventory 파일명: $ANSIBLE_HOST_DIR/hosts</font>
                              </div>

			      <pre>$HOST_STR_T</pre>

                              <br>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Playbook 파일명: $PLAYBOOK_NAME</font>
			      </div>
			      <pre><font color=red>해당 Playbook이 없습니다. 확인 바랍니다.</font></pre>

                            </div>

                            <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Playbook 실행결과: <b><font color=blue>실패 </font></b></font>
                              </div>
			      ㅇ Ansible Playbook Command : <font color=blue>{$DISPALY_FULLSTR}</font><br>
			      ㅇ 선택된 호스트/그룹: {$MEMBERS} <br>
			      ㅇ 결과 내용:<br>
			      <pre><font color=red>'{$PLAYBOOK_NAME}'</font> Playbook이 없습니다. 확인 바랍니다!! </pre>
                            </div>

                          </div>
                        </div>
                      </div>
              	  ";

                	$S_STRING = "
<font color=red>$PLAYBOOK_NAME Playbook이 없습니다. 확인 바랍니다.</font>
			";

			$fp = fopen($T_FILE,'w');
			fputs($fp,$T_STRING);
			fclose($fp);
		
                        $fp_S = fopen($S_FILE,'w');
                        fputs($fp_S,$S_STRING);
                        fclose($fp_S);

			$STOP_STEP = $T_step;
			$TOTAL_SUCC = 'N';

			break;
		}

		$STRING = "- hosts: " . $MEMBERS ;

		$p_content = str_replace("$","UUaU",$p_content);
		$p_content = str_replace("'","UUbU",$p_content);

                $PB_DELETE = shell_exec("rm -f $ANSIBLE_PLAYBOOK_FILE");
                $PB_CREATE = shell_exec("echo  '$p_content' > $ANSIBLE_PLAYBOOK_FILE");
                $PB_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");

		$EXEC1 = "sed -i '/- hosts:/c $STRING' $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC1");

		$EXEC2 = "sed -i \"s|UUaU|$|g\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC2");

		$EXEC3 = "sed -i \"s|UUbU|'|g\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC3");

                $EXEC3 = "sed -i \"s|UUcU|>|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");


                // add 2019.6.17
                $EXEC3 = "sed \"s|UUeU|\&lt;|g\" $ANSIBLE_PLAYBOOK_FILE > $ANSIBLE_PLAYBOOK_FILE_DIS";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");
                $EXEC3 = "sed -i \"s|UUeU|<|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");

                $PLAYBOOK_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");
                $PLAYBOOK_DISPLAY_DIS = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE_DIS");


                $ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log.txt" . $UTIME ;
                $ANSIBLE_LOG_FILE_S = "$ANSIBLE_LOG_DIR/log_S.txt" . $UTIME ;
                $ANSIBLE_LOG_NICK_FILE = "$ANSIBLE_LOG_DIR/log.txt" ;

		$starttime = date("Y-m-d H:i:s");
		$CMD_LINE = shell_exec("$FULLSTR > $ANSIBLE_LOG_FILE 2>&1");
		$endtime = date("Y-m-d H:i:s");

		$EXTRACT_HOST = shell_exec("$ANSIBLE_PLAYBOOK_DIR/extract_host.sh $ANSIBLE_LOG_FILE");

		$SUCC_HOST_CNT  = 0;
		$FAIL_HOST_CNT  = 0;
		$SUCC_HOST_LIST = "";
		$FAIL_HOST_LIST = "";
		if($EXTRACT_HOST != "") {
			$TEMP_HOST_LIST = explode(':',$EXTRACT_HOST);
			$SUCC_HOST_CNT = $TEMP_HOST_LIST[0];
			$FAIL_HOST_CNT = $TEMP_HOST_LIST[1];
			$SUCC_HOST_LIST = str_replace("\n","",$TEMP_HOST_LIST[2]);
			$SUCC_HOST_LIST = str_replace(" ","",$SUCC_HOST_LIST);
			$FAIL_HOST_LIST = str_replace("\n","",$TEMP_HOST_LIST[3]);
			$FAIL_HOST_LIST = str_replace(" ","",$FAIL_HOST_LIST);
		}


		$total_skip_cnt = 0;
		$skip_member = '';
                for ($x=1;$x < $T_step ; $x++) {

                	$cmd_sqlC = "select fail_member from Ansible_window_playbookflow_imsi_SF_$UTIME where step = '$x'";
                        $resC = mysqli_query($mysqli,$cmd_sqlC);
                        $dataC = mysqli_fetch_array($resC);
                        $isset_checkC = $dataC['fail_member'];
                        if ($isset_checkC != '') {

                              $cntC = 0;
                              $T_HOSTLIST = explode('|',$isset_checkC);
                              while ($T_HOSTLIST[$cntC]) {
                                      $T_HOSTC = $T_HOSTLIST[$cntC];
                                      $cntC = $cntC + 1;
                                      $total_skip_cnt = $total_skip_cnt + 1;
                              }

			      if( $total_skip_cnt == 1 ) $skip_member = $isset_checkC; 
			      else $skip_member = $skip_member . '|' . $isset_checkC;  

                       }

              }

		if ($SUCC_HOST_CNT == 0 and $FAIL_HOST_CNT != 0) {
			$MSG1 = "실패";
			$SUCC = 'N';
		}
		else if ($SUCC_HOST_CNT != 0 and $FAIL_HOST_CNT == 0) {
			$MSG1 = "성공";
			$SUCC = 'Y';
		}
		else {
			$MSG1 = "일부 성공";
			$SUCC = 'PY'; //partial success
		}

        	$insert_sql = "insert into Ansible_window_playbookflow_imsi_SF_$UTIME values ('$T_step', '$SUCC','$PLAYBOOK_NAME', '$starttime', '$endtime', '$SUCC_HOST_CNT', '$FAIL_HOST_CNT', '$total_skip_cnt', '$SUCC_HOST_LIST', '$FAIL_HOST_LIST', '$skip_member');";
       		$res = mysqli_query($mysqli,$insert_sql);

		$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
		$RESULT_EXE = shell_exec("$ANSIBLE_PLAYBOOK_DIR/parser.sh $ANSIBLE_LOG_FILE > $ANSIBLE_LOG_FILE_S");
		$RESULT_DEL = shell_exec("sed -i '/^$/d' $ANSIBLE_LOG_FILE_S");
		$RESULT_S = shell_exec("cat $ANSIBLE_LOG_FILE_S");

		$T_FILE = "$ANSIBLE_LOG_DIR/Flow_{$T_step}.txt" . $UTIME ;
		$S_FILE = "$ANSIBLE_LOG_DIR/Flow_Short_{$T_step}.txt" . $UTIME ;
                $T_STRING = "
                      <div id=wrapper>
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Inventory 파일명: $ANSIBLE_HOST_DIR/hosts</font>
                              </div>

			      <pre>$HOST_STR_T</pre>

                              <br>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Playbook 파일명: $PLAYBOOK_NAME</font>
			      </div>
			      <pre>$PLAYBOOK_DISPLAY_DIS</pre>

                            </div>

                            <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Playbook 실행결과: <b><font color=blue>{$MSG1} </font></b></font>
                              </div>
			      ㅇ Ansible Playbook Command : <font color=blue>{$DISPALY_FULLSTR}</font><br>
			      ㅇ 선택된 호스트/그룹: {$MEMBERS} <br>
			      ㅇ 결과 내용:<br>
			      <pre>$RESULT_DISPLAY</pre>
                            </div>

                          </div>
                        </div>
                      </div>
                ";

		$S_STRING = "
$T_step) $PLAYBOOK_NAME Playbook 결과 : $MSG1
$RESULT_S
		";

		$fp = fopen($T_FILE,'w');
		fputs($fp,$T_STRING);
		fclose($fp);

                $fp_S = fopen($S_FILE,'w');
                fputs($fp_S,$S_STRING);
                fclose($fp_S);

		if($SUCC == "N") {
			$TOTAL_SUCC = 'N';
			$STOP_STEP = $T_step;
			break;
		}
		else if ($SUCC == "PY") {
			$TOTAL_SUCC = 'PY';
			$PARTIAL_SUCC = 'YES';
		}
		else $TOTAL_SUCC = 'Y';

		//*********************************************************************************************//
		//*********************************************************************************************//

		} //while

	} //if($res5)

	

	$RESULT_FILE = "$ANSIBLE_LOG_DIR/Flow_Result.txt" . $UTIME ;
	$RESULT_FILE_S = "$ANSIBLE_LOG_DIR/Flow_Result_S.txt" . $UTIME ;
        $RESULT_FILE_C = "$ANSIBLE_LOG_DIR/Flow_Result_C.txt" . $UTIME ;
        $fp = fopen($RESULT_FILE,'w');
        $fp_S = fopen($RESULT_FILE_S,'w');
        $fp_C = fopen($RESULT_FILE_C,'w');


	if($TOTAL_SUCC == 'N') {
		$MSG1 = "실패";
		$T_SUCC_YN = 'N';
	}
	else if($TOTAL_SUCC == 'PY') {
		$MSG1 = "일부 성공";
		$T_SUCC_YN = 'PY';
	}
	else {
		if ($PARTIAL_SUCC == 'YES') {
			$MSG1 = "일부 성공";
			$T_SUCC_YN = 'PY';
		}
		else {
			$MSG1 = "성공";
			$T_SUCC_YN = 'Y';
		}
	}


	$FLOW_ID = $UTIME;
	$flow_seq = sprintf('%09d',$f_seq);
	$flow_seq = 'FLOW' . $flow_seq;
	$FLOW_endtime = date("Y-m-d H:i:s");
        $T_SUMMARY_HEAD = "
        			<br><div>
        			<font size=4 color=blue><b>ㅇ 단계별 Flow Summary</b></font><br>
				<font><br>
					     - Flow ID : $flow_seq <br>
					     - Flow 시각시간 : $FLOW_starttime <br>
					     - Flow 종료시간 : $FLOW_endtime <br>
					     - Flow 작업자 : $id <br><br>
				</font>
                                <div class='table-responsive scrollClass-sm'>
                                <table id='table1' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 단계</th>
                                        <th>Flow 결과</th>
                                        <th>실행 Playbook</th>
                                        <th>시작시간</th>
                                        <th>종료시간</th>
                                        <th>Total 호스트</th>
                                        <th>성공 호스트</th>
                                        <th>실패 호스트</th>
                                        <th>제외 호스트</th>
                                        <th>성공 호스트 리스트</th>
                                        <th>실패 호스트 리스트</th>
                                        <th>제외 호스트 리스트</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
        ";

	$T_SUMMARY_CONT = '';
	$cmd_sql = "select * from Ansible_window_playbookflow_imsi_SF_$UTIME";
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $step = $newArray['step'];
                        $result = $newArray['result'];
                        $p_name = $newArray['p_name'];
                        $starttime = $newArray['starttime'];
                        $endtime = $newArray['endtime'];
                        $succ_cnt = $newArray['succ_cnt'];
                        $fail_cnt = $newArray['fail_cnt'];
                        $skip_cnt = $newArray['skip_cnt'];
                        $succ_member = $newArray['succ_member'];
                        $fail_member = $newArray['fail_member'];
                        $skip_member = $newArray['skip_member'];

			$total_cnt = $succ_cnt + $fail_cnt +  $skip_cnt ;

                        if ($result == 'Y') $MSG_T = "<font color=blue><b>성공</b></font>";
                        else if ($result == 'N') $MSG_T = "<font color=red>실패</font>";
                        else $MSG_T = "<font color=green><b>일부 성공</b></font>";

                        $T_SUMMARY_CONT = $T_SUMMARY_CONT . "<tr><td>$step</td><td>$MSG_T</td><td>$p_name</td><td>$starttime</td><td>$endtime</td><td>$total_cnt</td><td>$succ_cnt</td><td>$fail_cnt</td><td>$skip_cnt</td><td>$succ_member</td><td>$fail_member</td><td>$skip_member</td>";
                }
        }

        $T_SUMMARY_TAIL = "
		</tbody>
        	</table>
        	</div>
        	</div> 
		<br><br>
	";

	$HEAD_STR = "
			  <br><br>
                          <div class='row'>
                            <div class='col-lg-5'>
                              <div class='label_danger' style='margin-bottom: 5px;padding: 4px 12px;'>
                               <table>
                               <tr><td width=1250><font size=3><b>&nbsp;$FNAME<br>실행결과:&nbsp;</b></font><font size=3 color=blue><b>$MSG1</b></font></td>
                               </table>
                              </div>
                            </div>
                            <div class='col-lg-7'>
                            </div>
                          </div>
	";

        $S_HEAD_STR = "
<pre>
<b>$FNAME Flow 실행결과: <font color=blue>$MSG1</font></b>

        ";

	fputs($fp,$HEAD_STR);
	fputs($fp,$T_SUMMARY_HEAD);
	fputs($fp,$T_SUMMARY_CONT);
	fputs($fp,$T_SUMMARY_TAIL);
        fputs($fp_S,$S_HEAD_STR);

	if($STOP_STEP == 0) $cmd_sql5 = "select * from Ansible_window_playbookflow_imsi_$UTIME";
        else $cmd_sql5 = "select * from Ansible_window_playbookflow_imsi_$UTIME where step <= '{$STOP_STEP}'";

        $res5 = mysqli_query($mysqli,$cmd_sql5);
        if ($res5) {
                while ($newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                        $T_step = $newArray5['step'];

                        $STEP_HEAD = "
                                <table id='table1' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Flow 단계</th>
                                        <th>Flow 결과</th>
                                        <th>실행 Playbook</th>
                                        <th>시작시간</th>
                                        <th>종료시간</th>
                                        <th>Total 호스트</th>
                                        <th>성공 호스트</th>
                                        <th>실패 호스트</th>
                                        <th>제외 호스트</th>
                                        <th>성공 호스트 리스트</th>
                                        <th>실패 호스트 리스트</th>
                                        <th>제외 호스트 리스트</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                        ";

                        $STEP_CONT = '';
                        $cmd_sql = "select * from Ansible_window_playbookflow_imsi_SF_$UTIME where step = '{$T_step}'";
                        $resT = mysqli_query($mysqli,$cmd_sql);
                        if ($resT) {
                                $newArray = mysqli_fetch_array($resT,MYSQLI_ASSOC);
                                $step = $newArray['step'];
                                $result = $newArray['result'];
                                $p_name = $newArray['p_name'];
                                $starttime = $newArray['starttime'];
                                $endtime = $newArray['endtime'];
                                $succ_cnt = $newArray['succ_cnt'];
                                $fail_cnt = $newArray['fail_cnt'];
                                $skip_cnt = $newArray['skip_cnt'];
                                $succ_member = $newArray['succ_member'];
                                $fail_member = $newArray['fail_member'];
                                $skip_member = $newArray['skip_member'];

                                $total_cnt = $succ_cnt + $fail_cnt +  $skip_cnt ;

                        	if ($result == 'Y') $MSG_T = "<font color=blue><b>성공</b></font>";
                        	else if ($result == 'N') $MSG_T = "<font color=red>실패</font>";
                        	else $MSG_T = "<font color=green><b>일부 성공</b></font>";

                                $STEP_CONT = $STEP_CONT . "<tr><td>$step</td><td>$MSG_T</td><td>$p_name</td><td>$starttime</td><td>$endtime</td><td>$total_cnt</td><td>$succ_cnt</td><td>$fail_cnt</td><td>$skip_cnt</td><td>$succ_member</td><td>$fail_member</td><td>$skip_member</td>";

                        }

                        $STEP_TAIL = "
                                </tbody>
                                </table>
                        ";

                	$SUB_STR1 = "
                      		<div id=wrapper>
                        	<div class='panel-body'>
				<button type='button' class='btn btn-primary btn-circle btn-lg'><i class='fa fa-list'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=red size=5><b>{$T_step} 단계</b></font></i></button>
                                $STEP_HEAD
                                $STEP_CONT
                                $STEP_TAIL
			";

			fputs($fp_C,$SUB_STR1);

			$T_FILE = "$ANSIBLE_LOG_DIR/Flow_{$T_step}.txt" . $UTIME ;
			$RESULT_DISPLAY = shell_exec("cat $T_FILE");
			fputs($fp_C,$RESULT_DISPLAY);

                        $S_FILE = "$ANSIBLE_LOG_DIR/Flow_Short_{$T_step}.txt" . $UTIME ;
                        $RESULT_DISPLAY_S = shell_exec("cat $S_FILE");
                        fputs($fp_S,$RESULT_DISPLAY_S);

                	$TAIL_STR1 = "
                      		</div>
                        	</div>
			";

		}

		$S_TAIL_STR1 = "
</pre>
		";
		fputs($fp_S,$S_TAIL_STR1);

	}

        fclose($fp);
        fclose($fp_S);
        fclose($fp_C);

	$T_RESULT_DISPLAY = shell_exec("cat $RESULT_FILE");
	echo "$T_RESULT_DISPLAY";

	$S_RESULT_DISPLAY = shell_exec("cat $RESULT_FILE_S");
	echo "$S_RESULT_DISPLAY";

	$C_RESULT_DISPLAY = shell_exec("cat $RESULT_FILE_C");
	echo "$C_RESULT_DISPLAY";

        // flow history Save
	$T_RESULT_DISPLAY = $T_RESULT_DISPLAY . $S_RESULT_DISPLAY . $C_RESULT_DISPLAY;
        $FLOW_RESULT_ENC = base64_encode(gzdeflate($T_RESULT_DISPLAY, 9));

        $insert_sql = "insert into Ansible_window_playbookflow_history values ('$FLOW_ID', '$flow_seq', '$FLOW_starttime', '$FLOW_endtime', '$id','$FNAME', '$f_explain', '$f_content', '$f_gubun', '$T_SUCC_YN', '$FLOW_RESULT_ENC');";

        $res = mysqli_query($mysqli,$insert_sql);

        $drop_sql = "drop table Ansible_window_playbookflow_imsi_$UTIME";
        $res = mysqli_query($mysqli,$drop_sql);

        $drop_sql = "drop table Ansible_window_playbookflow_imsi_SF_$UTIME";
        $res = mysqli_query($mysqli,$drop_sql);

        $DELETE1 = shell_exec("rm -f $ANSIBLE_HOST_FILE");
        $DELETE2 = shell_exec("rm -f $ANSIBLE_LOG_FILE");
        $DELETE3 = shell_exec("rm -f ${ANSIBLE_EXEC_DIR}/*{$UTIME}*");
        $DELETE4 = shell_exec("rm -f $RESULT_FILE");
        $DELETE5 = shell_exec("rm -f $RESULT_FILE_S");
        $DELETE5 = shell_exec("rm -f $T_FILE");
        $DELETE5 = shell_exec("rm -f $S_FILE");

}
else {

	echo "<br><font color=red>ㅇ Flow 항목이 비어 있습니다. 확인 바랍니다!! </font><br>";

}





?> 

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>




</body>

</html>




