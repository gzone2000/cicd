<?php
include "session_chk.inc" ;

$INPUT_GROUPNAME = trim($_GET['L_DATA']);
//echo "# Argument: DATA > {$INPUT_GROUPNAME}<br>";


	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		# del=INPUT_GROUPNAME : delete Group > Success
		$FULLURL = "./ansible_window_inventory_group.php?del=$INPUT_GROUPNAME";

		$select_sql = "select groupname from Ansible_window_group where groupname = '{$INPUT_GROUPNAME}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['groupname'];

		if (isset($isset_num)) {

			# delete Ansible_window_group table
			$delete_sql = "delete from Ansible_window_group where groupname = '{$INPUT_GROUPNAME}'" ;
			$res = mysqli_query($mysqli,$delete_sql);
			//echo "# SQL : {$delete_sql} , Result : $res";
			//echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			# del=2 : ip not found
			$FULLURL = "./ansible_window_inventory_group.php?del=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}

?> 
