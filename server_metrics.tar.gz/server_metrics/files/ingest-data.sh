#!/bin/bash

## To create with security disabled remove -u username:password to curl commands

HOST='localhost'
PORT=9200
VER=6.8.2
INDEX_NAME='server-metrics'
URL="http://${HOST}:${PORT}"
USERNAME=elastic
PASSWORD=changeme
printf "\n== Script for creating index and uploading data == \n \n"
printf "\n== Deleting old index == \n\n"
curl -s -X DELETE ${URL}/${INDEX_NAME}

printf "\n== Bulk uploading data to index... \n"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_1.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_2.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_3.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_4.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_5.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_6.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_7.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_8.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_9.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_10.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_11.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_12.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_13.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_14.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_15.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_16.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_17.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_18.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_19.json"
curl -s  -X POST -H "Content-Type: application/json" ${URL}/_bulk --data-binary "@server-metrics_20.json"
