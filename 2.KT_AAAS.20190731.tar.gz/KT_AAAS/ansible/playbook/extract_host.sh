#!/bin/bash

START="NO"
FILE=$1
IFS='
'
T_HOST_SUM=0
S_HOST_SUM=0
F_HOST_SUM=0
S_HOST_CNT=0
F_HOST_CNT=0
SUCC_HOST=''
FAIL_HOST=''

for LINE in $(cat $FILE)
do

LINE_CNT=$(echo $LINE | awk '/^PLAY RECAP */' | wc -l)
if [[ "$START" == "YES" ]] ; then
        #echo $LINE
        HOST=$(echo $LINE | awk '{print $1}')
        OK=$(echo $LINE | awk '{print $3}' | awk -F'=' '{print $2}')
        CHANGED=$(echo $LINE | awk '{print $4}' | awk -F'=' '{print $2}')
        UNREACH=$(echo $LINE | awk '{print $5}' | awk -F'=' '{print $2}')
        FAILED=$(echo $LINE | awk '{print $6}' | awk -F'=' '{print $2}')
        #echo "$HOST|$OK|$CHANGED|$UNREACH|$FAILED"

        if [[ $FAILED -ne 0 || $UNREACH -ne 0 ]] ; then
                F_HOST_CNT=$((F_HOST_CNT+1))
                if [ $F_HOST_SUM -eq 0 ] ; then
                        FAIL_HOST=$HOST
                else
                        FAIL_HOST=$(echo "${FAIL_HOST}|${HOST}")
                fi
		F_HOST_SUM=$((F_HOST_SUM+1))

        else 
                S_HOST_CNT=$((S_HOST_CNT+1))
                if [ $S_HOST_SUM -eq 0 ] ; then
                        SUCC_HOST=$HOST
                else
                        SUCC_HOST=$(echo "${SUCC_HOST}|${HOST}")
                fi
		S_HOST_SUM=$((S_HOST_SUM+1))

        fi


        T_HOST_SUM=$((T_HOST_SUM+1))


fi

if [[ $LINE_CNT -eq 1 ]] ; then
        START="YES"
fi

done

echo "$S_HOST_CNT:$F_HOST_CNT:$SUCC_HOST:$FAIL_HOST"
