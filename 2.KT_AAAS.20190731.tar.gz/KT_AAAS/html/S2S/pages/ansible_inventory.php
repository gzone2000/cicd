<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Inventory</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
                        echo "<table>";
                        echo "<tr><td width=450><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Ansible Playbook의 실행 대상인 Inventory 관리하기</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->


                        <div class="panel-body">
            		  <div class="row">
                	    <div class="col-lg-6">

			       <table>
                               <form action="./ansible_inventory.php">
                               <tr><td><button name=action value=host_add class='btn btn-primary' type=submit><b>Host 추가</b></button></td></tr>
                               </form>
			       </table>

                	    </div>
            		  <div>

            		  <div class="row">
                            <div class="col-lg-12">
			      <br>
                            </div>
			  </div>

            		  <div class="row">
                            <div class="col-lg-12">
                              <div class="panel panel-warning">
                                 <div class="panel-heading">
                                 Inventory 작업 
                                 </div>
                              <div class="panel-body">



<?php

	if ($_GET['action'] == "host_add")
	{
		echo "

              	    <div class=row>
               	    <div class='col-lg-4'>

                    <form action='./ansible_inventory_addhost.php' role='form'>
                       <div class='form-group has-success'>
                          <label class='control-label'>HOST</label>
                          <input type='text' class='form-control' name='HOST' size='100' placeholder='Enter Host'>
                       </div>
                       <div class='form-group has-success'>
                          <label class='control-label'>IP</label>
                          <input type='text' class='form-control' name='IP' size='100' placeholder='Enter IP'>
                       </div>
                       <div class='form-group has-success'>
		          <button type='submit' class='btn btn-success'>HOST 만들기</button>
                       </div>
                    </form>

		    </div>
		    </div>

		";

	}

	elseif ($_GET['add'])
	{


		if ($_GET['add'] == 9999){


			echo "
                            	<table width='100%' class='table table-striped table-bordered table-hover' id='dataTables-example'>
                                	<thead>
                                    	<tr>
                                        	<th>아이디</th>
                                        	<th>구분</th>
                                        	<th>IP Address / Host List</th>
                                    	</tr>
                                	</thead>
                                	<tbody>
			";

        		$cmd_sql = "select * from Ansible_host_list order by gubun asc, id asc";
        		$res = mysqli_query($mysqli,$cmd_sql);
        		if ($res) {
                		while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        		$id = $newArray['id'];
                        		$gubun= $newArray['gubun'];
                        		$ip = $newArray['ip'];
                        		$hostlist= $newArray['hostlist'];
                        		echo "<tr>";

					if($gubun == 'G') {
						$GUBUN = "Group";
						$DISPLAY = $hostlist;
                        			echo "<td width=100>{$id}</td><td>{$GUBUN}</td><td>{$DISPLAY}</td>";
					}
					else {
						$GUBUN = "Host";
						$DISPLAY = $ip;
                        			echo "<td width=100>{$id}</td><td>{$GUBUN}</td><td>{$DISPLAY}</td>";
					}
				}
			}

                	echo "</tr>";
                	echo "</tbody>";
                	echo "</table>";

        		mysqli_free_result($res);
        		mysqli_close($mysqli);

		}

		elseif($_GET['add'] == 1) {
                	echo "<div id=header>";
                	echo "<FONT SIZE=5 COLOR=red><b><i class='glyphicon glyphicon-plus'></i>Error </b></font>";
                	echo "<br>";
                	echo "<br>";
                	echo "<FONT SIZE=4 COLOR=blue><b>빈항목이 있습니다. 채우주시기 바랍니다..!! </b></font>";
                	echo "</div>";

		}

		elseif($_GET['add'] == 2) {
                	echo "<div id=header>";
                	echo "<FONT SIZE=5 COLOR=red><b><i class='glyphicon glyphicon-plus'></i>Error </b></font>";
                	echo "<br>";
                	echo "<br>";
                	echo "<FONT SIZE=4 COLOR=blue><b>아이디가 중복 됩니다.!! </b></font>";
                	echo "</div>";

		}


	}



?> 




                              </div>
                	    </div>
            		  </div>


                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>




