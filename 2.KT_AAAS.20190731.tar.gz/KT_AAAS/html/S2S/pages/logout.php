<?php

session_start();
$mysqli = new mysqli("localhost","root","mysql_123","syslog");

if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}
else {
        $logouttime = date("Y-m-d H:i:s");
        $query = "UPDATE User_history SET logouttime='$logouttime' WHERE session_id='$_SESSION[ss_id]'";
        $res = mysqli_query($mysqli,$query);
	//echo "$query" ;
}

$res=session_destroy(); //모든 세션 변수 지우기
if($res){
    header('Location: ./login.php'); // 로그아웃 성공 시 로그인 페이지로 이동
    exit();
}


?>
