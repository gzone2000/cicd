<?php
include "session_chk.inc" ;

$ID = trim($_POST['ID']);
$PWD = trim($_POST['PWD']);
$OPER_NAME = trim($_POST['OPER_NAME']);
$LEVEL = trim($_POST['LEVEL']);
$STATUS = trim($_POST['STATUS']);
#echo "# Argument: ID > {$ID}\n";

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {


function dec_enc($action, $string) {
    $output = false;

    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my SECRET key';
    $secret_iv = 'This is my SECRET iv';

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}


	$FULLURL = "./user_mgmt.php?modify=1";

	# 설정 수정 화면
	# Update User table

	$encrypted_string = dec_enc('encrypt',$PWD);

	$update_sql = "UPDATE User set pwd = '{$encrypted_string}' , oper_name = '{$OPER_NAME}' , level = '{$LEVEL}', status = '{$STATUS}' where id = '{$ID}'" ;

	#echo "# SQL : {$update_sql}";
	#echo "<br>";
	$res = mysqli_query($mysqli,$update_sql);

	header('Location: '.$FULLURL);

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
