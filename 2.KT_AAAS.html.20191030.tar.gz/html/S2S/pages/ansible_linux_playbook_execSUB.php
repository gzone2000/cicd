<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
include "ip.inc" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>


<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];



	date_default_timezone_set("Asia/Seoul");
        $ARG = trim(base64_decode($_GET['ARG']));
	$ARG_LIST = explode(" ",$ARG);
	$PLAYBOOK_NAME = $ARG_LIST[0];
	$MEMBERS = $ARG_LIST[1];

	//echo " #{$PLAYBOOK_NAME}# , #{$MEMBERS}#<br>";

	if ($PLAYBOOK_NAME != '' and $MEMBERS !='')
	{


/*

# Ansible Directory
$ANSIBLE_DIR = "/home/ansible";
$ANSIBLE_PLAYBOOK_DIR = "$ANSIBLE_DIR/playbook";
$ANSIBLE_HOST_DIR = "$ANSIBLE_DIR/host";
$ANSIBLE_LOG_DIR = "$ANSIBLE_DIR/log";
$ANSIBLE_EXEC_DIR = "$ANSIBLE_DIR/exec";

*/


		$PIECES = explode(",", $MEMBERS);

                $cnt = 0;
		$HOST_STR = '';
                while ($PIECES[$cnt]) {

			//host
                        $cmd_sql1 = "select * from Ansible_linux_host where nodename = '$PIECES[$cnt]'";
                        $res1 = mysqli_query($mysqli,$cmd_sql1);

                	$data = mysqli_fetch_array($res1);
                	$isset_check1 = $data['nodename'];

                	if ($isset_check1 != '') {
                                $hostname = $data['hostname'];
                                $nodename= $data['nodename'];
                                $ip = $data['ip'];
				$port = $data['port'];
                                $HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_ssh_port=$port \n";
                        }
			else {
				//group
                        	$cmd_sql1 = "select * from Ansible_linux_group where groupname = '$PIECES[$cnt]'";
                        	$res1 = mysqli_query($mysqli,$cmd_sql1);
                		$data = mysqli_fetch_array($res1);
                		$isset_check1 = $data['groupname'];

                		if ($isset_check1 != '') {

					$HOST_STR = $HOST_STR . "\n";
					$HOST_STR = $HOST_STR . "[{$PIECES[$cnt]}]\n";
                                	$groupname = $data['groupname'];
                                	$member5= $data['member'];
					$PIECES5 = explode("|", $member5);

                        		$cnt5 = 0;
                        		while ($PIECES5[$cnt5]) {

                                		$cmd_sql1 = "select * from Ansible_linux_host where nodename = '$PIECES5[$cnt5]'";
                                		$res1 = mysqli_query($mysqli,$cmd_sql1);
                				$data = mysqli_fetch_array($res1);
                				$isset_check1 = $data['nodename'];

                				if ($isset_check1 != '') {
                                        		$hostname = $data['hostname'];
                                        		$nodename= $data['nodename'];
                                        		$ip = $data['ip'];
							$port = $data['port'];
							$HOST_STR = $HOST_STR . "$nodename ansible_host=$ip ansible_ssh_port=$port \n";
                                		}

                                		$cnt5 = $cnt5 + 1;

                        		}


                        	}
			}

                        $cnt = $cnt + 1;

                }


                $RANDOM_NUM = mt_rand(1,1000);
                $UTIME_F = explode('.',microtime(true));
                $UTIME = $UTIME_F[0] . $UTIME_F[1] . $RANDOM_NUM ;

                $ANSIBLE_HOST_FILE = "$ANSIBLE_HOST_DIR/host5" . $UTIME ;
                $ANSIBLE_HOST_NICK_FILE = "$ANSIBLE_HOST_DIR/host5" ;

		$HOST_CREATE = shell_exec("echo  '$HOST_STR' > $ANSIBLE_HOST_FILE");
		$HOST_DISPLAY = shell_exec("cat $ANSIBLE_HOST_FILE");

        	$cmd_sql = "select * from Ansible_linux_playbook where p_name = '{$PLAYBOOK_NAME}'";
        	$res = mysqli_query($mysqli,$cmd_sql);
                $data = mysqli_fetch_array($res);
                $p_seq = $data['p_seq'];
		$p_seq = sprintf('%09d',$p_seq);
		$p_seq = 'PLY' . $p_seq;
                $p_content = base64_decode($data['p_content']);
		#$STRING = "- hosts: " . $MEMBERS ;
		$STRING = $MEMBERS ;

		$ANSIBLE_PLAYBOOK_NICK_FILE = "${ANSIBLE_EXEC_DIR}/$PLAYBOOK_NAME" ;
                $ANSIBLE_PLAYBOOK_FILE = "${ANSIBLE_EXEC_DIR}/$PLAYBOOK_NAME" . $UTIME ;
                $ANSIBLE_PLAYBOOK_FILE_DIS = "${ANSIBLE_EXEC_DIR}/$PLAYBOOK_NAME" . $UTIME . "DIS" ;

		$p_content = str_replace("$","UUaU",$p_content);
		$p_content = str_replace("'","UUbU",$p_content);

                $PB_CREATE = shell_exec("echo  '$p_content' > $ANSIBLE_PLAYBOOK_FILE");
                $PB_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");

		#$EXEC1 = "sed -i '/- hosts:/c $STRING' $ANSIBLE_PLAYBOOK_FILE";
		$EXEC1 = "sed -i \"s/- hosts: .*/- hosts: $STRING/\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC1");

		$EXEC2 = "sed -i \"s|UUaU|$|g\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC2");

		$EXEC3 = "sed -i \"s|UUbU|'|g\" $ANSIBLE_PLAYBOOK_FILE";
		$PLAYBOOK_CREATE = shell_exec("$EXEC3");

                $EXEC3 = "sed -i \"s|UUcU|>|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");

		// Linux
                $EXEC3 = "sed -i \"s|UUdU|~|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");


		// add 2019.6.17
                $EXEC3 = "sed \"s|UUeU|\&lt;|g\" $ANSIBLE_PLAYBOOK_FILE > $ANSIBLE_PLAYBOOK_FILE_DIS";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");
                $EXEC3 = "sed -i \"s|UUeU|<|g\" $ANSIBLE_PLAYBOOK_FILE";
                $PLAYBOOK_CREATE = shell_exec("$EXEC3");

		$PLAYBOOK_DISPLAY = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE");
		$PLAYBOOK_DISPLAY_DIS = shell_exec("cat $ANSIBLE_PLAYBOOK_FILE_DIS");


		$FULLSTR = "timeout $CMD_TIMEOUT ansible-playbook -i $ANSIBLE_HOST_FILE $ANSIBLE_PLAYBOOK_FILE";
		$DISPLAY_FULLSTR = "ansible-playbook -i $ANSIBLE_HOST_DIR/host5 $ANSIBLE_PLAYBOOK_NICK_FILE";

                $ANSIBLE_LOG_FILE = "$ANSIBLE_LOG_DIR/log.txt" . $UTIME ;
                $ANSIBLE_LOG_NICK_FILE = "$ANSIBLE_LOG_DIR/log.txt" ;

		$p_starttime = date("Y-m-d H:i:s");
		$CMD_LINE = shell_exec("$FULLSTR > $ANSIBLE_LOG_FILE 2>&1");
		$p_endtime = date("Y-m-d H:i:s");

		$EXTRACT_HOST = shell_exec("$ANSIBLE_PLAYBOOK_DIR/extract_host.sh $ANSIBLE_LOG_FILE");

                $SUCC_HOST_CNT  = 0;
                $FAIL_HOST_CNT  = 0;
                $SUCC_HOST_LIST = "";
                $FAIL_HOST_LIST = "";
                if($EXTRACT_HOST != "") {
                        $TEMP_HOST_LIST = explode(':',$EXTRACT_HOST);
                        $SUCC_HOST_CNT = $TEMP_HOST_LIST[0];
                        $FAIL_HOST_CNT = $TEMP_HOST_LIST[1];
                        $SUCC_HOST_LIST = str_replace("\n","",$TEMP_HOST_LIST[2]);
                        $SUCC_HOST_LIST = str_replace(" ","",$SUCC_HOST_LIST);
                        $FAIL_HOST_LIST = str_replace("\n","",$TEMP_HOST_LIST[3]);
                        $FAIL_HOST_LIST = str_replace(" ","",$FAIL_HOST_LIST);
                }

		$total_cnt = $SUCC_HOST_CNT + $FAIL_HOST_CNT;	


                if ($SUCC_HOST_CNT == 0 and $FAIL_HOST_CNT != 0) {
                        $MSG1 = "<font color=red><b>실패</b></font>";
                        $SUCC = 'N';
                }
                else if ($SUCC_HOST_CNT == 0 and $FAIL_HOST_CNT == 0) {
                        $MSG1 = "<font color=red><b>실패</b></font>";
                        $SUCC = 'N';
                }
                else if ($SUCC_HOST_CNT != 0 and $FAIL_HOST_CNT == 0) {
                        $MSG1 = "<font color=blue><b>성공</b></font>";
                        $SUCC = 'Y';
                }
                else {
                        $MSG1 = "<font color=green><b>일부 성공</b></font>";
                        $SUCC = 'PY'; //partial success
                }


		$P_ID = 'PLY' . $UTIME;
                $T_FILE = "$ANSIBLE_LOG_DIR/Playbook_result_{$UTIME}.txt";
                $fp = fopen($T_FILE,'w');

        	$P_RESULT_HEAD1 = "
	    	      <br>
                      <div id=wrapper>
                        <div class='panel-body'>
                          <div class='row'>
                            <div class='col-lg-6'>
                              <div class='label_danger' style='margin-bottom: 5px;padding: 4px 12px;'>
                               <table>
                               <tr><td width=1250><font size=3><b>&nbsp;$PLAYBOOK_NAME<br>실행결과:&nbsp;</b></font><font size=3 color=blue><b>$MSG1</b></font></td>
                               </table>
                              </div>
                            </div>
                            <div class='col-lg-6'>
                            </div>
                          </div>
				<br>
                                <table id='table1' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Playbook ID</th>
                                        <th width=50>Playbook 결과</th>
                                        <th>실행 Playbook</th>
                                        <th>시작 시간</th>
                                        <th>종료 시간</th>
                                        <th width=60>Total 호스트</th>
                                        <th width=60>성공 호스트</th>
                                        <th width=60>실패 호스트</th>
                                        <th>성공 호스트 리스트</th>
                                        <th>실패 호스트 리스트</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                                <tr><td>$p_seq</td><td>$MSG1</td><td>$PLAYBOOK_NAME</td><td>$p_starttime</td><td>$p_endtime</td><td>$total_cnt</td><td>$SUCC_HOST_CNT</td><td>$FAIL_HOST_CNT</td><td>$SUCC_HOST_LIST</td><td>$FAIL_HOST_LIST</td></tr>
	                        </tbody>
        	                </table>
                ";

                fputs($fp,$P_RESULT_HEAD1);

		$RESULT_DISPLAY = shell_exec("cat $ANSIBLE_LOG_FILE");
		$RESULT = shell_exec("$ANSIBLE_PLAYBOOK_DIR/parser.sh $ANSIBLE_LOG_FILE 2>&1");

        	$P_RESULT_PRE1 = "
<pre>
<b>$PLAYBOOK_NAME Playbook 실행결과: <font color=blue>$MSG1</font></b>

$RESULT
</pre>
        ";

                fputs($fp,$P_RESULT_PRE1);

                $P_RESULT_CONT1 = "
                      <br><br>
		      <button type='button' class='btn btn-primary btn-circle btn-md'><i class='fa fa-list'></i></button><font size=3><b>&nbsp;&nbsp;&nbsp;$PLAYBOOK_NAME Playbook 상세 실행 내용</b></font><br><br>
                          <div class='row'>
                            <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Inventory 파일명: $ANSIBLE_HOST_DIR/host5</font>
                              </div>

			      <pre>$HOST_DISPLAY</pre>

                              <br>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Playbook 파일명: $PLAYBOOK_NAME</font>
			      </div>
			      <pre>$PLAYBOOK_DISPLAY_DIS</pre>

                            </div>

                            <div class='col-lg-6'>
                              <div class='label_info' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <font size=3>Playbook 실행결과: <b><font color=blue>{$MSG1} </font></b></font>
                              </div>
			      ㅇ Ansible Playbook Command : <font color=blue>{$DISPLAY_FULLSTR}</font><br>
			      ㅇ 선택된 호스트/그룹: {$MEMBERS} <br>
			      ㅇ 결과 내용:<br>
			      <pre>$RESULT_DISPLAY</pre>
                            </div>

                          </div>
                        </div>
                      </div>
                ";

                fputs($fp,$P_RESULT_CONT1);
                fclose($fp);

                $P_RESULT_DISPLAY = shell_exec("cat $T_FILE");
                echo "$P_RESULT_DISPLAY";

		// playbook history Save
		$user = $_SESSION[id];
        	$PLAYBOOK_DISPLAY_ENC = base64_encode($PLAYBOOK_DISPLAY);
        	$PLAYBOOK_RESULT_ENC = base64_encode($P_RESULT_DISPLAY);

		//echo "<br> 1.playbook result <br>";
		//echo "###{$RESULT_DISPLAY}###<br><br>";
		//echo "<br> 2.playbook result encode <br>";
		//echo "###{$PLAYBOOK_RESULT_ENC}###<br><br>";

                $insert_sql = "insert into Ansible_linux_playbook_history values ('$P_ID', '$p_seq', '$p_starttime', '$p_endtime', '$user','$PLAYBOOK_NAME', '$PLAYBOOK_DISPLAY_ENC', '$SUCC', '$PLAYBOOK_RESULT_ENC');";

		//echo "<br>3. insert sql <br>";
		//echo "$insert_sql <br>";
                $res = mysqli_query($mysqli,$insert_sql);

                $DELETE1 = shell_exec("rm -f $ANSIBLE_HOST_FILE");
                $DELETE2 = shell_exec("rm -f $ANSIBLE_LOG_FILE");
                $DELETE2 = shell_exec("rm -f $ANSIBLE_PLAYBOOK_FILE");		
                $DELETE2 = shell_exec("rm -f $ANSIBLE_PLAYBOOK_FILE_DIS");		
                $DELETE2 = shell_exec("rm -f $T_FILE");		


	}
	else {

        	if ($PLAYBOOK_NAME == '') {
			echo "<br><font color=red>ㅇ Playbook 항목이 비어 있습니다. 확인 바랍니다!! </font><br>";
		}
        	else if ($MEMBERS == '') {
			echo "<br><font color=red>ㅇ Inventory 항목이 비어 있습니다. 확인 바랍니다!! </font><br>";
		}

	}



?> 

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>




</body>

</html>




