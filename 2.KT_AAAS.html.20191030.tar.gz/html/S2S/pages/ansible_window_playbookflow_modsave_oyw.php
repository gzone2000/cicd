<?php
include "session_chk.inc" ;

$FNAME = trim($_POST['FNAME']);
$EXPALIN_ORG = trim($_GET['EXPALIN']);
$EXPALIN = base64_encode($EXPALIN_ORG);
$GUBUN = trim($_POST['GUBUN']);
$GUBUN1 = trim($_POST['GUBUN1']);
$PLAYBOOKLIST = trim($_POST['PLAYBOOKLIST']);
$MEMBERLIST = trim($_POST['MEMBERLIST']);
//echo "# Argument: FNAME > {$FNAME}<br>";
//echo "# Argument: EXPALIN > {$EXPALIN}<br>";
//echo "# Argument: GUBUN > {$GUBUN}<br>";
//echo "# Argument: PLAYBOOKLIST > {$PLAYBOOKLIST}<br>";
//echo "# Argument: MEMBERLIST > {$MEMBERLIST}<br>";


	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

                # Update flow
		$FULLURL = "./ansible_window_playbookflow_oyw.php?mod=$FNAME";

                $select_sql = "select f_name from Ansible_window_playbookflow_Save2 where f_name = '{$FNAME}'" ;
                $res5 = mysqli_query($mysqli,$select_sql);
                #echo "# SQL: {$select_sql} " ;

                $data = mysqli_fetch_array($res5);
                $isset_num = $data['f_name'];

                if (isset($isset_num)) {

			$update_sql = "UPDATE Ansible_window_playbookflow_Save2 set f_explain='{$EXPALIN}', f_playbook_list='{$PLAYBOOKLIST}', f_member_list ='{$MEMBERLIST}', f_gubun ='{$GUBUN}', f_gubun1 ='{$GUBUN1}' where f_name = '{$FNAME}'" ;
			$res = mysqli_query($mysqli,$update_sql);
			//echo "# SQL : {$update_sql} <br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 

                }
                else {
                        # add=2 : host or ip duplicate : Fail
                        $FULLURL = "./ansible_window_playbookflow_oyw.php?mod=2";
                        #echo "# URL : {$FULLURL}";
                        header('Location: '.$FULLURL);
                }

	}

?> 
