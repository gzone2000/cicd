<?php
include "session_chk.inc" ;

$PNAME = trim($_POST['PNAME']);
$PLAYBOOK = trim($_POST['PLAYBOOK']);
$EXPALIN = trim($_POST['EXPALIN']);
$EXPALIN = base64_encode($EXPALIN);
$GUBUN = trim($_POST['GUBUN']);
$GUBUN1 = trim($_POST['GUBUN1']);
$GUBUN2 = trim($_POST['GUBUN2']);
//echo "# Argument: PNAME > {$PNAME}<br>";
//echo "# Argument: PLAYBOOK > {$PLAYBOOK}<br>";
//echo "# Argument: EXPALIN > {$EXPALIN}<br>";
//echo "# Argument: GUBUN > {$GUBUN}<br>";


	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		# insert playbook
		$FULLURL = "./ansible_window_playbook_CRUD.php?add=$PNAME";

		$select_sql = "select p_name from Ansible_window_playbook where p_name = '{$PNAME}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['p_name'];

		if (!isset($isset_num)) {

			# 설정 추가 화면
			# Insert Ansible_window_playbook table
                        $insert_sql = "INSERT into Ansible_window_playbook(p_name,p_explain,p_content,p_gubun,p_gubun1,p_gubun2) values ('{$PNAME}', '{$EXPALIN}', '{$PLAYBOOK}', '{$GUBUN}', '{$GUBUN1}', '{$GUBUN2}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			//echo "# SQL : {$insert_sql} , Result : $res";
			//echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			# add=2 : host or ip duplicate : Fail
			$FULLURL = "./ansible_window_playbook_CRUD.php?add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}

?> 
