<?php
include "session_chk.inc" ;

$NUM = trim($_POST['NUM']);
$ORG_NUM = trim($_POST['ORG_NUM']);
$IP = trim($_POST['IP']);
$BLOCK_CONECT = trim($_POST['BLOCK_CONECT']);
$SESSION_TIME = trim($_POST['SESSION_TIME']);
#echo "# Argument: NUM > {$NUM}\n";
#echo "# Argument: Client IP > {$IP}\n";
#echo "# Argument: BLOCK_CONECT > {$BLOCK_CONECT}\n";
#echo "# Argument: SESSION_TIME > {$SESSION_TIME}\n";

if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

	$FULLURL = "./set_mgmt_ip.php?modify=1";

	# 설정 수정 화면
	# Update MGMT_IP_chk table

	if( $NUM == 9999) {
		$update_sql = "UPDATE MGMT_IP_chk set block_conect = '{$BLOCK_CONECT}' , session_time = '{$SESSION_TIME}' where num = {$NUM}" ;
	}
	else {
		if($NUM == $ORG_NUM) $update_sql = "UPDATE MGMT_IP_chk set client_ip = '{$IP}' , block_conect = '{$BLOCK_CONECT}',session_time = '{$SESSION_TIME}' where num = {$NUM}" ;
		else {

                	$select_sql = "select num from MGMT_IP_chk where num = {$NUM}" ;
                	$res5 = mysqli_query($mysqli,$select_sql);
                	#echo "# SQL: {$select_sql} " ;

                	$data = mysqli_fetch_array($res5);
                	$isset_num = $data['num'];

                	if (!isset($isset_num)) {
				$update_sql = "UPDATE MGMT_IP_chk set num = {$NUM} , client_ip = '{$IP}' , block_conect = '{$BLOCK_CONECT}',session_time = '{$SESSION_TIME}' where num = {$NUM}" ;
			}
			else {
                        	$FULLURL = "./set_mgmt_ip.php?modify=2";
                        	#echo "# URL : {$FULLURL}";
                        	header('Location: '.$FULLURL);
			}

		}
	}

	#echo "# SQL : {$update_sql}";
	#echo "<br>";
	$res = mysqli_query($mysqli,$update_sql);

	header('Location: '.$FULLURL);

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
