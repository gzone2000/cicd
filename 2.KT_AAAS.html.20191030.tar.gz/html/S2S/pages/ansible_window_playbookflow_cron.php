<?php
include "session_chk.inc" ;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script src="../vendor/jquery/jquery.min.js"></script>
<script>
function popitup1(f_name) {
    var url = "./ansible_window_playbookflow_content_popup_oyw.php?F_NAME=" + f_name;
    window.open(url,"Flow Show","width=1200,height=700,left=100,top=60");
}
</script>

<script>
function DB_CRON_DEL_ALL() {
    var newWindow;
    var url = "./ansible_window_playbookflow_cron_del_popup.php";
    newWindow = window.open(url, "DB and Cron Delete All", "width=1200,height=400,left=100,top=60");
}
</script>

<script>
function sendMeData_DB_CRON_Del(data) {

    if (data == 'YES') {
        var url1 = './ansible_window_playbookflow_cron_del_all.php';
        var form = document.createElement("form");

        form.setAttribute("method","post");
        form.setAttribute("action",url1);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type","hidden");
        hiddenField.setAttribute("name","DEL_ALL");
        hiddenField.setAttribute("value","9999");
        form.appendChild(hiddenField);

        document.body.appendChild(form);
        form.submit();
    }

}
</script>


<script>
function MyFunction5(number,act) {

    var flowName = document.getElementsByName('FLOW_NAME');
    var flowValue;
    for(var i=0;i < flowName.length; i++) {
        if(flowName[i].checked) {
                flowValue = flowName[i].value;
        }
    }

    var url1 = './ansible_window_playbookflow_cron.php?FLOW=' + flowValue + '&ACT=' + act + '&NUMBER=' + number;
    location.replace(url1);
}
</script>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo "<a href='index.php'><img src='../vendor/login/$LOGO' width=250></a>"; ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">

<?php
if($HIDDEN != "true") {
include "top_header.php" ;
}
?>

                <li>
<?php
echo "<font color=blue>$_SESSION[id]</font>";
?>
                </li>



                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

<?php
include "sidemenu_display.php" ;
?>

                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

<?php

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];

if($_SESSION[auth_level] != '0') {
        echo "<center><font color=red size=5><b>접근권한이 없습니다. 확인해 보시기 바랍니다!!</b></font></center>";
        exit(0);
}

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Job 등록, 수정, 삭제 > Window</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">

<?php
                        echo "<table>";
                        echo "<tr><td width=600><font size=3><i class='fa fa-calendar fa-fw'></i>&nbsp;Window에서 Ansible Playbook Flow을 Cron에 등록하여 주기적으로 실행함.</font></td>";
                        echo "</tr>";
                        echo "</table>";
?>

                        </div>
                        <!-- /.panel-heading -->


                        <div class="panel-body">

            		  <div class="row">
                            <div class="col-lg-4">
                              <div class="label_info" style="margin-bottom: 5px;padding: 4px 12px;">

                               <table>
                               <tr><td width=200 height=35><font size=3><b>1.&nbsp;Job Cron 리스트&nbsp;&nbsp;</b></font></td>

<?php
				echo "<form action=./ansible_window_playbookflow_cron.php>";
				//echo "<td width=20><input type=hidden name=FLOW value={$FLOW}></input></td>";
                        	echo "<td><button class='btn btn-primary btn-sm' type=submit name='ADD_NUM' value=9999><b>등록</b></button></td></form>";
                                $cmd_sql = "select * from Ansible_window_playbookflow_cron" ;
                                $res5 = mysqli_query($mysqli,$cmd_sql);
                                $num_rows = mysqli_num_rows($res5);
                                //echo "ROWS : $num_rows";
                                $CRONTAB_WC = shell_exec("crontab -l | grep 'WIN_' | wc -l");
                                //echo "CRONTAB WC : $CRONTAB_WC";

                                if($num_rows != $CRONTAB_WC) {
                                        echo "<form action=./ansible_window_playbookflow_cron_sync.php>";
                                        echo "<td width=20></td><td><button class='btn btn-danger btn-sm' type=submit name='SYNC' value=9999><b>DB & Cron 불일치: Sync하기!! </b></button></td></form>";
                                }

?>
			       </tr>
                               </table>

                              </div>

                            </div>
                            <div class="col-lg-9">
                            </div>
                          </div>


                          <div class="row">
                            <div class="col-lg-12">



<?php

                echo "<div id=wrapper>";
                echo "<div class='panel-body'>";

                echo "<div class='row'>";
                echo "<div class='col-lg-6'>";

		echo "
                                 <table width='100%' class='table table-striped table-bordered table-hover' id='dataTables-example'>
                                 <thead>
                                    <tr>
                                        <th>번호</th>
                                        <th>Minute</th>
                                        <th>Hour</th>
                                        <th>Day</th>
                                        <th>Month</th>
                                        <th>Week</th>
                                        <th>Command</th>
                                        <th>수정</th>
                                        <th>삭제</th>
                                        <th>메일 발송</th>
                                    </tr>
                                 </thead>
                                 <tbody>
		";


	$cmd_sql = "select * from Ansible_window_playbookflow_cron" ;
        $res = mysqli_query($mysqli,$cmd_sql);
        if ($res) {
                while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                        $c_num = $newArray['c_num'];
                        $c_min = $newArray['c_min'];
                        $c_min_chk = $newArray['c_min_chk'];
                        $c_hour = $newArray['c_hour'];
                        $c_hour_chk = $newArray['c_hour_chk'];
                        $c_day = $newArray['c_day'];
                        $c_month = $newArray['c_month'];
                        $c_week = $newArray['c_week'];
                        $c_cmd = $newArray['c_cmd'];
                        $c_mail = $newArray['c_mail'];

			if($c_min_chk == 'Y' and $c_min != '*') $c_min = '* / ' . $c_min;
			if($c_hour_chk == 'Y' and $c_hour != '*') $c_hour = '* / ' . $c_hour;

                	if($c_week == "*") $S_MSG="*";
                	else if($c_week == '0') $S_MSG="Sun";
                	else if($c_week == '1') $S_MSG="Mon";
                	else if($c_week == '2') $S_MSG="Tus";
                	else if($c_week == '3') $S_MSG="Wed";
                	else if($c_week == '4') $S_MSG="Thu";
                	else if($c_week == '5') $S_MSG="Fri";
                	else if($c_week == '6') $S_MSG="Sat";

                        echo "<tr>";
                        echo "<td>{$c_num}</td><td>{$c_min}</td><td>{$c_hour}</td><td>{$c_day}</td><td>{$c_month}</td><td>{$S_MSG}</td><td>{$c_cmd}</td>";

                        echo "<td width=50><form action=./ansible_window_playbookflow_cron.php>";
			//echo "<input type=hidden name=FLOW value={$FLOW}></input>";
                        echo "<center><button class='btn btn-warning btn-xs' type=submit name=MOD_NUM value={$c_num}><b><font size=2>수정</font></b></button></center></form></td>";

                        echo "<td width=50><form action=./ansible_window_playbookflow_cron.php>";
			//echo "<input type=hidden name=FLOW value={$FLOW}></input>";
                        echo "<center><button class='btn btn-danger btn-xs' type=submit name=DEL_NUM value={$c_num}><b><font size=2>삭제</font></b></button></center></form></td>";

                        if($c_mail == 'Y') $MSG5 = "YES";
                        else $MSG5 = "NO";
                        echo"<td align=center>$MSG5</td>";

                        echo "</tr>";   
                }
        }

	echo "</table>"	;




                echo "</div>"; //col-lg-6

                echo "<div class='col-lg-1'>";
                echo "</div>"; //col-lg-1

                echo "<div class='col-lg-5'>";



// Cron 등록 수정 삭제 루틴 Start //

$END = "NO";
$FLOW = $_GET['FLOW'];
$ACT = $_GET['ACT'] ;
$NUMBER = $_GET['NUMBER'] ;

if($_GET['MOD_NUM'] || $ACT == "MOD"){

	$num1 = trim($_GET['MOD_NUM']);

	if($NUMBER) $cmd_sql = "select * from Ansible_window_playbookflow_cron where c_num = {$NUMBER} " ;
	else $cmd_sql = "select * from Ansible_window_playbookflow_cron where c_num = {$num1} " ;

	###echo "# SQL : {$cmd_sql}";
	###echo "<br>";
	$res5 = mysqli_query($mysqli,$cmd_sql);

        if ($res5) {
                while ($newArray = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                        $c_num = $newArray['c_num'];
                        $c_min = $newArray['c_min'];
                        $c_min_chk = $newArray['c_min_chk'];
                        $c_hour = $newArray['c_hour'];
                        $c_hour_chk = $newArray['c_hour_chk'];
                        $c_day = $newArray['c_day'];
                        $c_month = $newArray['c_month'];
                        $c_week = $newArray['c_week'];
                        $c_cmd = $newArray['c_cmd'];
                        $c_mail = $newArray['c_mail'];

                }
        }

	$DISABLED ='';
	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 수정 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<form action=./ansible_window_playbookflow_cron_mod.php method=POST>";

	echo "<table border=1>";

        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 번호 : </label>";
        	echo "</td>";
        	echo "<td width=350 colspan=2>";
        	echo "<input type='text' class='form-control' name=NUM value={$c_num} readonly>";
        	echo "</td><td><input type=hidden name=FLOW value={$FLOW}></input></td></tr>";

        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ Minute : </label>";
        	echo "</td>";
        	echo "<td width=200>";
                echo "<select class='form-control' name=MIN>";

                if($c_min == '*') {
                        echo "<option value='*' selected=selected>*</option>";
                        for($i=0;$i < 60; $i++) echo "<option value=$i>$i</option>";
                }
                else {
                        echo "<option value='*'>*</option>";
                        for($i=0;$i < 60; $i++) {
                                if($i == $c_min) echo "<option value=$i selected=selected>$i</option>";
                                else echo "<option value=$i>$i</option>";
                        }
                }

                echo "</select>";
		echo "</td>";
        	echo "<td align=center>";
		if($c_min_chk == 'Y') echo "<div class=checkbox><label><input type=checkbox name=EVERY_MIN_CHK value=Y checked>Every Minutes</label></div>";
                else echo "<div class=checkbox><label><input type=checkbox name=EVERY_MIN_CHK value=Y>Every Minutes</label></div>";
		echo "</td>";
        	echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Hour : </label>";
                echo "</td>";
                echo "<td>";
                echo "<select class='form-control' name=HOUR>";
		if($c_hour == '*') {
			echo "<option value='*' selected=selected>*</option>";
                	for($i=0;$i < 24; $i++) echo "<option value=$i>$i</option>";
		}
                else {
			echo "<option value='*'>*</option>";
                	for($i=0;$i < 24; $i++) {
				if($i == $c_hour) echo "<option value=$i selected=selected>$i</option>";
                        	else echo "<option value=$i>$i</option>";
                	}
		}
                echo "</select>";
                echo "</td>";
                echo "<td align=center>";
		if($c_hour_chk == 'Y') echo "<div class=checkbox><label><input type=checkbox name=EVERY_HOUR_CHK value=Y checked>Every Minutes</label></div>";
                else echo "<div class=checkbox><label><input type=checkbox name=EVERY_HOUR_CHK value=Y>Every Minutes</label></div>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Day : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=DAY>";
		if($c_day == '*') echo "<option value='*' selected=selected>*</option>";
                else echo "<option value='*'>*</option>";
                for($i=1;$i < 32; $i++) {
			if($i == $c_day) echo "<option value=$i selected=selected>$i</option>";
                        else echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Month : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=MONTH>";
		if($c_month == '*') echo "<option value='*' selected=selected>*</option>";
                else echo "<option value='*'>*</option>";
                for($i=1;$i <= 12; $i++) {
			if($i == $c_month) echo "<option value=$i selected=selected>$i</option>";
                        else echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Week : </label>";
                echo "</td>";
                echo "<td colspan=2>";
		if($c_week == '*') $S_MSG1="selected=selected";
		else if($c_week == '0') $S_MSG2="selected=selected";
		else if($c_week == '1') $S_MSG3="selected=selected";
		else if($c_week == '2') $S_MSG4="selected=selected";
		else if($c_week == '3') $S_MSG5="selected=selected";
		else if($c_week == '4') $S_MSG6="selected=selected";
		else if($c_week == '5') $S_MSG7="selected=selected";
		else if($c_week == '6') $S_MSG8="selected=selected";
                echo "<select class='form-control' name=WEEK>";
                	echo "<option value='*' $S_MSG1>*</option>";
                        echo "<option value=0 $S_MSG2>Sun</option>";
                        echo "<option value=1 $S_MSG3>Mon</option>";
                        echo "<option value=2 $S_MSG4>Tus</option>";
                        echo "<option value=3 $S_MSG5>Wed</option>";
                        echo "<option value=4 $S_MSG6>Thu</option>";
                        echo "<option value=5 $S_MSG7>Fri</option>";
                        echo "<option value=6 $S_MSG8>Sat</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>¤· 메일 발송: </label>";
                echo "</td>";
                echo "<td colspan=2>";
                if($c_mail == 'Y') $M_MSG1="selected=selected";
                else $M_MSG2="selected=selected";
                echo "<select class='form-control' name=MAIL_SEND>";
                        echo "<option value=Y $M_MSG1>YES</option>";
                        echo "<option value=N $M_MSG2>NO</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ 등록할 Flow : </label>";
                echo "</td>";
                echo "<td colspan=2>";

		if($ACT) echo "<input type='text' class='form-control' name=COMMAND value='{$FLOW}' readonly>";
                else echo "<input type='text' class='form-control' name=COMMAND value='{$c_cmd}' readonly>";
                echo "</td>";
                echo "<td></td></tr>";


        echo "</table>";

	echo "<br>";
	echo "수정 하시겠습니까? &nbsp;&nbsp;&nbsp;";
	echo "<button type=submit class='btn btn-success'>수정</button>";
	echo "</form>";

	echo "</div>";

}

elseif($_GET['modify']){
	if($_GET['modify'] == 1) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 수정 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 수정 완료되었습니다.!! </b></font>";
		echo "</div>";
	}
	elseif($_GET['modify'] == 2) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 수정 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>번호가 중복됩니다. 확인 바랍니다.!! </b></font>";
		echo "</div>";
	}

	$END = "YES";

}

elseif($_GET['ADD_NUM'] || $ACT == "ADD"){

	$cmd_sql = "select count(c_num) AS max_num from Ansible_window_playbookflow_cron";
	//echo "# SQL : {$cmd_sql}";
	//echo "<br>";
	$res5 = mysqli_query($mysqli,$cmd_sql);
        $data = mysqli_fetch_array($res5);
        $isset_check2 = $data["max_num"];

	if ($isset_check2 >= 0) {

		if($isset_check2 != 0) {
			$cmd_sql = "select max(c_num) AS max_num from Ansible_window_playbookflow_cron";
			$res5 = mysqli_query($mysqli,$cmd_sql);
        		$data = mysqli_fetch_array($res5);
        		$isset_check2 = $data["max_num"];

        		$isset_check2 = $isset_check2 + 1;
		}
		else $isset_check2 = 1;

        	echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 등록 화면 </b></font>";
        	echo "<br>";
        	echo "<br>";
		echo "<form action=./ansible_window_playbookflow_cron_add.php method=POST>";

        	echo "<table border=1>";
        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 번호 : </label>";
        	echo "</td>";
        	echo "<td width=350 colspan=2>";
        	echo "<input type='text' class='form-control' name=NUM value={$isset_check2} readonly>";
        	echo "</td><td><input type=hidden name=FLOW value={$FLOW}></input></td></tr>";

        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ Minute : </label>";
        	echo "</td>";
        	echo "<td width=200>";
                echo "<select class='form-control' name=MIN>";
                echo "<option value='*'>*</option>";
                for($i=0;$i < 60; $i++) {
                        echo "<option value=$i>$i</option>";
                }
                echo "</select>";
		echo "</td>";
        	echo "<td align=center>";
                echo "<div class=checkbox><label><input type=checkbox name=EVERY_MIN_CHK value=Y>Every Minutes</label></div>";
		echo "</td>";
        	echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Hour : </label>";
                echo "</td>";
                echo "<td>";
                echo "<select class='form-control' name=HOUR>";
                echo "<option value='*'>*</option>";
                for($i=0;$i < 24; $i++) {
                        echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td align=center>";
                echo "<div class=checkbox><label><input type=checkbox name=EVERY_HOUR_CHK value=Y>Every Hours</label></div>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Day : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=DAY>";
                echo "<option value='*'>*</option>";
                for($i=1;$i < 32; $i++) {
                        echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Month : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=MONTH>";
                echo "<option value='*'>*</option>";
                for($i=1;$i <= 12; $i++) {
                        echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Week : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=WEEK>";
                echo "<option value='*'>*</option>";
                        echo "<option value=0>Sun</option>";
                        echo "<option value=1>Mon</option>";
                        echo "<option value=2>Tus</option>";
                        echo "<option value=3>Wed</option>";
                        echo "<option value=4>Thu</option>";
                        echo "<option value=5>Fri</option>";
                        echo "<option value=6>Sat</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ 메일 발송 : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=MAIL_SEND>";
                echo "<option value=Y>YES</option>";
                echo "<option value=N>NO</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ 등록할 Flow : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<input type='text' class='form-control' name=COMMAND value='{$FLOW}' required>";
                echo "</td>";
                echo "<td></td></tr>";


        	echo "</table>";

        	echo "<br>";
		echo "추가 하시겠습니까? &nbsp;&nbsp;&nbsp;";
        	echo "<button type=submit class='btn btn-success'>추가</button>";
        	echo "</form>";

        	echo "</div>";

        }


}

elseif($_GET['add']){
	if ($_GET['add'] == 9999){
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 추가 완료되었습니다.!! </b></font>";
		echo "</div>";
	}
	elseif($_GET['add'] == 1) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>Flow 항목이 비어 있습니다. 채워주시기 바랍니다.!! </b></font>";
		echo "</div>";
	}
	elseif($_GET['add'] == 2) {
		echo "<div id=header>";
		echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-plus'></i> 추가 화면 </b></font>";
		echo "<br>";
		echo "<br>";
		echo "<FONT SIZE=3 COLOR=blue><b>클라이언트 IP가 중복됩니다. 확인 바랍니다.!! </b></font>";
		echo "</div>";
	}

	$END = "YES";

}

elseif($_GET['DEL_NUM'] || $ACT == "DEL"){

	$num1 = trim($_GET['DEL_NUM']);

	if($NUMBER) $cmd_sql = "select * from Ansible_window_playbookflow_cron where c_num = {$NUMBER} " ;
	else $cmd_sql = "select * from Ansible_window_playbookflow_cron where c_num = {$num1} " ;

	###echo "# SQL : {$cmd_sql}";
	###echo "<br>";
	$res5 = mysqli_query($mysqli,$cmd_sql);

        if ($res5) {
                while ($newArray = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                        $c_num = $newArray['c_num'];
                        $c_min = $newArray['c_min'];
                        $c_min_chk = $newArray['c_min_chk'];
                        $c_hour = $newArray['c_hour'];
                        $c_hour_chk = $newArray['c_hour_chk'];
                        $c_day = $newArray['c_day'];
                        $c_month = $newArray['c_month'];
                        $c_week = $newArray['c_week'];
                        $c_cmd = $newArray['c_cmd'];
                        $c_mail = $newArray['c_mail'];

                }
        }

	$DISABLED ='';
	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='glyphicon glyphicon-wrench'></i> 삭제 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<form action=./ansible_window_playbookflow_cron_del.php method=POST>";

	echo "<table border=1>";

        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ 번호 : </label>";
        	echo "</td>";
        	echo "<td width=350 colspan=2>";
        	echo "<input type='text' class='form-control' name=NUM value={$c_num} readonly>";
        	echo "</td><td><input type=hidden name=FLOW value={$FLOW}></input></td></tr>";

        	echo "<tr><td width=150>";
        	echo "<label class='control-label' for='inputSuccess'>ㅇ Minute : </label>";
        	echo "</td>";
        	echo "<td width=200>";
                echo "<select class='form-control' name=MIN disabled>";

                if($c_min == '*') {
                        echo "<option value='*' selected=selected>*</option>";
                        for($i=0;$i < 60; $i++) echo "<option value=$i>$i</option>";
                }
                else {
                        echo "<option value='*'>*</option>";
                        for($i=0;$i < 60; $i++) {
                                if($i == $c_min) echo "<option value=$i selected=selected>$i</option>";
                                else echo "<option value=$i>$i</option>";
                        }
                }

                echo "</select>";
		echo "</td>";
        	echo "<td align=center>";
		if($c_min_chk == 'Y') echo "<div class=checkbox><label><input type=checkbox name=EVERY_MIN_CHK value=Y checked disabled>Every Minutes</label></div>";
                else echo "<div class=checkbox><label><input type=checkbox name=EVERY_MIN_CHK value=Y disable disabledd>Every Minutes</label></div>";
		echo "</td>";
        	echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Hour : </label>";
                echo "</td>";
                echo "<td>";
                echo "<select class='form-control' name=HOUR disabled>";
		if($c_hour == '*') {
			echo "<option value='*' selected=selected>*</option>";
                	for($i=0;$i < 24; $i++) echo "<option value=$i>$i</option>";
		}
                else {
			echo "<option value='*'>*</option>";
                	for($i=0;$i < 24; $i++) {
				if($i == $c_hour) echo "<option value=$i selected=selected>$i</option>";
                        	else echo "<option value=$i>$i</option>";
                	}
		}
                echo "</select>";
                echo "</td>";
                echo "<td align=center>";
		if($c_hour_chk == 'Y') echo "<div class=checkbox><label><input type=checkbox name=EVERY_HOUR_CHK value=Y checked disabled>Every Minutes</label></div>";
                else echo "<div class=checkbox><label><input type=checkbox name=EVERY_HOUR_CHK value=Y disabled>Every Minutes</label></div>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Day : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=DAY disabled>";
		if($c_day == '*') echo "<option value='*' selected=selected>*</option>";
                else echo "<option value='*'>*</option>";
                for($i=1;$i < 32; $i++) {
			if($i == $c_day) echo "<option value=$i selected=selected>$i</option>";
                        else echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Month : </label>";
                echo "</td>";
                echo "<td colspan=2>";
                echo "<select class='form-control' name=MONTH disabled>";
		if($c_month == '*') echo "<option value='*' selected=selected>*</option>";
                else echo "<option value='*'>*</option>";
                for($i=1;$i <= 12; $i++) {
			if($i == $c_month) echo "<option value=$i selected=selected>$i</option>";
                        else echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ Week : </label>";
                echo "</td>";
                echo "<td colspan=2>";
		if($c_week == '*') $S_MSG1="selected=selected";
		else if($c_week == '0') $S_MSG2="selected=selected";
		else if($c_week == '1') $S_MSG3="selected=selected";
		else if($c_week == '2') $S_MSG4="selected=selected";
		else if($c_week == '3') $S_MSG5="selected=selected";
		else if($c_week == '4') $S_MSG6="selected=selected";
		else if($c_week == '5') $S_MSG7="selected=selected";
		else if($c_week == '6') $S_MSG8="selected=selected";
                echo "<select class='form-control' name=WEEK disabled>";
                	echo "<option value='*' $S_MSG1>*</option>";
                        echo "<option value=0 $S_MSG2>Sun</option>";
                        echo "<option value=1 $S_MSG3>Mon</option>";
                        echo "<option value=2 $S_MSG4>Tus</option>";
                        echo "<option value=3 $S_MSG5>Wed</option>";
                        echo "<option value=4 $S_MSG6>Thu</option>";
                        echo "<option value=5 $S_MSG7>Fri</option>";
                        echo "<option value=6 $S_MSG8>Sat</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ 메일 발송: </label>";
                echo "</td>";
                echo "<td colspan=2>";
                if($c_mail == 'Y') $M_MSG1="selected=selected";
                else $M_MSG2="selected=selected";
                echo "<select class='form-control' name=MAIL_SEND disabled>";
                        echo "<option value=Y $M_MSG1>YES</option>";
                        echo "<option value=N $M_MSG2>NO</option>";
                echo "</select>";
                echo "</td>";
                echo "<td></td></tr>";

                echo "<tr><td width=150>";
                echo "<label class='control-label' for='inputSuccess'>ㅇ 등록할 Flow : </label>";
                echo "</td>";
                echo "<td colspan=2>";

		if($ACT) echo "<input type='text' class='form-control' name=COMMAND value='{$FLOW}' disabled>";
                else echo "<input type='text' class='form-control' name=COMMAND value='{$c_cmd}' disabled>";
                echo "</td>";
                echo "<td></td></tr>";


        echo "</table>";

	echo "<br>";
	echo "정말로 삭제하시겠습니다까? &nbsp;&nbsp;&nbsp;";
	echo "<button type=submit class='btn btn-success'>삭제</button>";
	echo "</form>";

	echo "</div>";

}

elseif($_GET['delete']){
	echo "<div id=header>";
	echo "<FONT SIZE=4 COLOR=red><b><i class='fa fa-trash-o'></i> 삭제 화면 </b></font>";
	echo "<br>";
	echo "<br>";
	echo "<FONT SIZE=3 COLOR=blue><b>ㅇ 삭제 완료되었습니다.!! </b></font>";
	echo "</div>";
	$END = "YES";

}



// Cron 등록 수정 삭제 루틴 Start //





                echo "</div>"; //col-lg-6
                echo "</div>";  //row



	if($_GET['ADD_NUM'] || $_GET['MOD_NUM'] || $_GET['DEL_NUM'] || $FLOW) {


		if($END != "YES") {

		echo "

		<br>
                <div class='row'>
                <div class='col-lg-12'>

		";




		echo "
                        <div class='panel-body'>
            		  <div class='row'>
                	    <div class='col-lg-6'>
                              <div class='label_warning' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>ㅇ 등록할 Flow 리스트 </font></b>
                              </div>
                	    </div> 
                	    <div class='col-lg-2'>
                                  <input id='myInput' class='form-control' type='text' placeholder='Search..'>
                	    </div> 
			    <div class='col-lg-4'>
                	    </div> 
            		  </div>

            		  <div class='row'>
                	    <div class='col-lg-12'>
			 

				<div class='table-responsive scrollClass-sm'>
                                <table id='table_source1' width='100%' class='table table-striped table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>체크</th>
                                        <th>Flow 이름</th>
                                        <th>Flow 설명</th>
                                        <th>Flow 종류</th>
                                        <th>Flow 내용</th>
                                    </tr>
                                </thead>
                                <tbody id='myTable'>
                ";


		if($_GET['DEL_NUM']) $cmd_sql = "select * from Ansible_window_playbookflow_Save2 where f_name = '{$c_cmd}'";
                else $cmd_sql = "(select * from Ansible_window_playbookflow_Save2 where f_name = '{$c_cmd}') union (select * from Ansible_window_playbookflow_Save2 where f_name <> '{$c_cmd}' order by f_name asc)";

                $res = mysqli_query($mysqli,$cmd_sql);
                if ($res) {
                        while ($newArray = mysqli_fetch_array($res,MYSQLI_ASSOC)) {
                                $f_name = $newArray['f_name'];
                                $f_explain= $newArray['f_explain'];
                                $f_explain= base64_decode($f_explain);
                                $f_gubun = $newArray['f_gubun'];

                                $cmd_sql3 = "select gubun_name from Ansible_playbookflow_gubun where gubun = '{$f_gubun}'";
                                $res3 = mysqli_query($mysqli,$cmd_sql3);
                                $newArray3 = mysqli_fetch_array($res3,MYSQLI_ASSOC);
                                $gubun_name = $newArray3['gubun_name'];


				if($_GET['MOD_NUM'] || $_GET['DEL_NUM']) {
					if($f_name == $c_cmd) $BTN1 = "btn btn-danger btn-sm";
					else $BTN1 = "btn btn-success btn-sm";
				}
				else $BTN1 = "btn btn-success btn-sm";

                                echo "<tr><td><input type='radio' name=FLOW_NAME value=$f_name></td><td>$f_name</td><td>$f_explain</td><td>$gubun_name</td><td><button id=$f_name name=$f_name value={$f_name} class='$BTN1' onclick='popitup1(\"$f_name\")'>$f_name 내용보기</button></td>";
                        }
                }


		if($_GET['ADD_NUM']) {
			$ACT = "ADD";
			$NUMBER = $_GET['ADD_NUM'];
		}
		else if($_GET['MOD_NUM']) {
			$ACT = "MOD";
			$NUMBER = $_GET['MOD_NUM'];
		}


        	echo "</tbody>";
        	echo "</table>";
        	echo "</div>";  //scrollClass-sm
		if(! $_GET['DEL_NUM']) 
			echo "<br><button  class='btn btn-info' onclick=MyFunction5(\"$NUMBER\",\"$ACT\")>선택 완료시 Click</button><br><br><br>";
        	echo "</div>";  // <div class='col-lg-12'>


		echo "


                    </div>
                </div>
            </div>
		";


		}



	}




                echo "</div>";  //row 
                echo "</div>";  //col-lg-12


                echo "</div>";  //panel-body
                echo "</div>";  //wrapper

		echo "<br>";

?>

				<br>
<div>
<?php

if(! $_GET['ADD_NUM'] and ! $_GET['MOD_NUM'] and ! $_GET['DEL_NUM'] and ! $_GET['ACT']) {
        echo "<table><tr>";
        echo "<form action=./ansible_window_playbookflow_cron_del_all.php>";
        //echo "<td><button class='btn btn-danger btn-sm' type=submit name='DEL_ALL' value=9999><b>Linux/Window JOB DB와 Cron 모두 삭제하기!!</b></button></td></form>";
        echo "<td><button class='btn btn-danger btn-sm' type=submit name='DEL_ALL' value=9999 onclick='DB_CRON_DEL_ALL()'><b>Linux/Window JOB DB와 Cron 모두 삭제하기!!</b></button></td></form>";
        echo "</tr></table>";
}

?>
</div>

                            </div>
                          </div>




                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>





</body>

</html>




