<?php


$PLY_SEQ = $_GET['playbook_seq'];
if (preg_match("/[^a-z\d]/i", $PLY_SEQ)) {
	echo "<script>alert('잘못된 파일 정보 입니다 확인 바랍니다!!')</script>";
}
else {

	include "session_chk.inc" ;
	//echo "Playbook Seq : $PLY_SEQ <br>";

	$PLY_SEQ = (int)str_replace("PLY","",$PLY_SEQ);
	$cmd_sql = "select * from Ansible_linux_playbook where p_seq = '{$PLY_SEQ}' ";

	echo "SQL : $cmd_sql <br>";

	$res = mysqli_query($mysqli,$cmd_sql);
	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
	$p_name = $newArray['p_name'];

	if ($p_name) {
		$p_content = $newArray['p_content'];
		$p_content_dec = base64_decode($p_content);

		$LOG_DIR = "/var/www/html/S2S/temp";
		$filepath = "$LOG_DIR/$p_name";

		$fp = fopen($filepath,'w');
		fputs($fp,$p_content_dec);
		fclose($fp);

		$filesize = filesize($filepath);
		$path_parts = pathinfo($filepath);
		$filename = $path_parts['basename'];
		$extension = $path_parts['extension'];

		header("Pragma: public");
		header("Expires: 0");
		header("Content-Type: application/octet-stream");
		header("Content-Disposition: attachment; filename=$filename");
		header("Content-Transfer-Encoding: binary");
		header("Content-Length: $filesize");

		ob_clean();
		flush();
		readfile($filepath);

		$FILE_RM = shell_exec("rm -f $filepath");

	}

}

?>
