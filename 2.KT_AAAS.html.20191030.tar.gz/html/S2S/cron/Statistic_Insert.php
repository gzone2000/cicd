<?php


function SQL_EXE($sql) {

include "Acase.php";

////// dec_enc Function Start //////

    $output = false;

    $encrypt_method = "AES-256-CBC";
    $action = "decrypt";
    $string = $MYSQL_PWD;
    $secret_key = $S_KEY;
    $secret_iv = $S_IV;

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

////// dec_enc Function End //////


$mysqli = new mysqli($MYSQL_HST,$MYSQL_USR,$output,$MYSQL_DBI);
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}



        $res = mysqli_query($mysqli,$sql);
        $row = mysqli_fetch_array($res);

        return $row["count"];
}


include "Acase.php";

////// dec_enc Function Start //////

    $output = false;

    $encrypt_method = "AES-256-CBC";
    $action = "decrypt";
    $string = $MYSQL_PWD;
    $secret_key = $S_KEY;
    $secret_iv = $S_IV;

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

////// dec_enc Function End //////

$mysqli = new mysqli($MYSQL_HST,$MYSQL_USR,$output,$MYSQL_DBI);
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

date_default_timezone_set("Asia/Seoul");
$DAYS = -1;
$INPUT_DATE = date("Y-m-d",strtotime("$DAYS days"));

# Inventory Count
$sql = "select count(*) as count from Ansible_linux_host";
$s_inventory_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_host";
$s_inventory_win = SQL_EXE($sql);

# Playbook Count
$sql = "select count(*) as count from Ansible_linux_playbook";
$s_playbook_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_playbook";
$s_playbook_win = SQL_EXE($sql);

# Flow Count
$sql = "select count(*) as count from Ansible_linux_playbookflow_Save2";
$s_flow_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_playbookflow_Save2";
$s_flow_win = SQL_EXE($sql);

# Ad-hoc Execution Count
$sql = "select count(*) as count from Ansible_linux_adhoc_history where date_format(ah_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_adhoc_exe_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_adhoc_history where date_format(ah_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_adhoc_exe_win = SQL_EXE($sql);

# Playbook Execution Count
$sql = "select count(*) as count from Ansible_linux_playbook_history where date_format(p_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_playbook_exe_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_playbook_history where date_format(p_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_playbook_exe_win = SQL_EXE($sql);

# Flow Execution Count
$sql = "select count(*) as count from Ansible_linux_playbookflow_history2 where date_format(flow_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_flow_exe_lin = SQL_EXE($sql);
$sql = "select count(*) as count from Ansible_window_playbookflow_history2 where date_format(flow_starttime,'%Y-%m-%d') = '{$INPUT_DATE}'";
$s_flow_exe_win = SQL_EXE($sql);


$insert_sql = "INSERT into Ansible_statistic values ('{$INPUT_DATE}', '{$s_inventory_lin}', '{$s_inventory_win}', '{$s_playbook_lin}', '{$s_playbook_win}', '{$s_flow_lin}', '{$s_flow_win}', '{$s_adhoc_exe_lin}', '{$s_adhoc_exe_win}', '{$s_playbook_exe_lin}', '{$s_playbook_exe_win}', '{$s_flow_exe_lin}', '{$s_flow_exe_win}')" ;

//echo "$insert_sql \n";
$res = mysqli_query($mysqli,$insert_sql);


?>
