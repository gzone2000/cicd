<?php
include "session_chk.inc" ;

$MAIL_ID = trim($_POST['MAIL_ID']);
$NAME = trim($_POST['NAME']);
$DEPARTMENT = trim($_POST['DEPARTMENT']);
$MAIL_SEND = trim($_POST['MAIL_SEND']);
#echo "# Argument: ID > {$ID}\n";

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

	$FULLURL = "./set_mgmt_mail.php?modify=1";

	# 설정 수정 화면
	# Update User table

	$update_sql = "UPDATE Mail_list set name = '{$NAME}' , department = '{$DEPARTMENT}' , mail_send = '{$MAIL_SEND}' where mail_id = '{$MAIL_ID}'" ;

	#echo "# SQL : {$update_sql}";
	#echo "<br>";
	$res = mysqli_query($mysqli,$update_sql);

	header('Location: '.$FULLURL);

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
