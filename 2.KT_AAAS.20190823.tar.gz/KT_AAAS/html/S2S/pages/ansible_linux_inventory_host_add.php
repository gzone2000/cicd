<?php
include "session_chk.inc" ;

$DATA = trim($_GET['L_DATA']);
$DATA = base64_decode($DATA);
//echo "# Argument: DATA > {$DATA}<br>";

$PIECES = explode("|", $DATA);

$IPADDR = $PIECES[0];
$HOSTNAME = $PIECES[1];
$NODENAME = $PIECES[2];
$ID = $PIECES[3];
$RELEASE = $PIECES[4];
$KERNEL_VER = $PIECES[5];
$PORT = $PIECES[6];
//echo "$IPADDR , $HOSTNAME , $NODENAME , $ID , $RELEASE , $KERNEL_VER , $PORT<br>";



	$mysqli = new mysqli("localhost","root","mysql_123","syslog");
	if (mysqli_connect_errno()) {
        	printf("Connect failed: %s\n", mysqli_connect_error());
        	exit();
	} 
	else {

		# add=IP : insert Success
		$FULLURL = "./ansible_linux_inventory_search.php?add=$IPADDR";

		$select_sql = "select ip from Ansible_linux_host where nodename = '{$NODENAME}' or ip = '{$IPADDR}'" ;
		$res5 = mysqli_query($mysqli,$select_sql);
		#echo "# SQL: {$select_sql} " ;

		$data = mysqli_fetch_array($res5);
		$isset_num = $data['ip'];

		if (!isset($isset_num)) {

			# 설정 추가 화면
			# Insert Ansible_linux_host table
			$insert_sql = "INSERT into Ansible_linux_host values ('{$HOSTNAME}', '{$NODENAME}', '{$IPADDR}', '{$PORT}', '{$ID}{$RELEASE}', '{$KERNEL_VER}')" ;
			$res = mysqli_query($mysqli,$insert_sql);
			//echo "# SQL : {$insert_sql} , Result : $res";
			//echo "<br>";

			header('Location: '.$FULLURL);

			mysqli_free_result($res);
			mysqli_close($mysqli); 
		}
		else {
			# add=2 : host or ip duplicate : Fail
			$FULLURL = "./ansible_linux_inventory_search.php?add=2";
			#echo "# URL : {$FULLURL}";
			header('Location: '.$FULLURL);
		}
	}

?> 
