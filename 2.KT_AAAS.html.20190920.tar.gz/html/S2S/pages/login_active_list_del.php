<?php
include "session_chk.inc" ;

$SESS_ID = trim($_GET['DEL']);
//echo "# Argument: SESS_ID > {$SESS_ID}\n";

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
} 
else {

	$FULLURL = "./login_active_list.php";

	session_start();
	if($_SESSION[ss_id] != $SESS_ID) { 

		//echo "$_SESSION[ss_id] , $SESS_ID Not match<br>";}

		# 설정 삭제 화면
		# Delete User_history table
		$delete_sql = "Delete from User_history where session_id = '{$SESS_ID}'" ;
		//echo "# SQL : {$delete_sql}";
		//echo "<br>";
		$res = mysqli_query($mysqli,$delete_sql);

		header('Location: '.$FULLURL);
	}
	else {
		$FULLURL = "./login_active_list.php?del=2";
		header('Location: '.$FULLURL);
	}

	mysqli_free_result($res);
	mysqli_close($mysqli); 
}

?> 
