<?php

session_start();
if (!$_SESSION[ss_id]) {
        header('Location: ./logout.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<?php
include "css.php" ;
include "sidemenu.php" ;
include "ip.inc" ;
?>

    <title><?php echo $TITLE; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="../vendor/datatables/js/html5shiv.js"></script>
        <script src="../vendor/datatables/js/respond.min.js"></script>
    <![endif]-->

<script>
function Button_Click1() {
    var F_name = document.getElementById('FNAME').value;
    var F_gubun = document.getElementById('GUBUN').value;
    var F_gubun1 = document.getElementById('GUBUN1').value;
    var F_explain = document.getElementById('EXPALIN').value;
    F_explain =  encodeURIComponent(F_explain);

    var url1 = "./ansible_window_playbookflow_modsave.php?FNAME=" + F_name + "&EXPALIN=" + F_explain + "&GUBUN=" + F_gubun + "&GUBUN1=" + F_gubun1;
    location.replace(url1);
}
</script>


</head>

<body>


<?php

$mysqli = new mysqli("localhost","root","mysql_123","syslog");
if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
}

$sql="SELECT * FROM User WHERE id='$_SESSION[ss_id]'";
$res = mysqli_query($mysqli,$sql);

$row = mysqli_fetch_array($res);
$db_name  = $row["oper_name"];


	        $ACT = trim($_GET['ACT']);
       	 	$F_NAME = trim($_GET['F_NAME']);


        	$cmd_sql = "select * from Ansible_window_playbookflow_Save where f_name = '{$F_NAME}'";
        	$res = mysqli_query($mysqli,$cmd_sql);

        	$newArray = mysqli_fetch_array($res,MYSQLI_ASSOC);
        	$f_name = $newArray['f_name'];
        	$f_explain= $newArray['f_explain'];
        	$f_explain_dec = base64_decode($f_explain);
        	$f_content = $newArray['f_content'];
        	$f_gubun = $newArray['f_gubun'];
        	$f_gubun1 = $newArray['f_gubun1'];

        	echo "
                      <div id=wrapper>
                        <div class='panel-body'>
                          <div class='row'>

                            <div class='col-lg-3'>

                              <div class='label_warning' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Flow 문법 체크</font></b>
                              </div>

		";

		echo "<br>ㅇ Flow Syntax 체크 결과 : <b><font color=blue>성공</font></b><br>";


        	$SELECT_STR5 = '';
        	$cmd_sql5 = "select * from Ansible_playbookflow_gubun";
        	$res5 = mysqli_query($mysqli,$cmd_sql5);
        	if ($res5) {
                	$cnt=1;
                	while ($newArray5 = mysqli_fetch_array($res5,MYSQLI_ASSOC)) {
                        	$gubun5 = $newArray5['gubun'];
                        	$gubun_name5 = $newArray5['gubun_name'];

                        	if($f_gubun == $gubun5) $SELECT_OPT = "selected";
                        	else $SELECT_OPT = '';

                        	$STR5 = "<option value=$cnt $SELECT_OPT>$gubun_name5</option>";
                        	$SELECT_STR5 = $SELECT_STR5 . $STR5 ;

                        	$cnt = $cnt + 1;
                	}
        	}

                $SELECT_STR7 = '';
                $cmd_sql7 = "select * from Ansible_playbookflow_gubun1";
                $res7 = mysqli_query($mysqli,$cmd_sql7);
                if ($res7) {
                        $cnt=1;
                        while ($newArray7 = mysqli_fetch_array($res7,MYSQLI_ASSOC)) {
                                $gubun7 = $newArray7['gubun'];
                                $gubun_name7 = $newArray7['gubun_name'];

                                if($f_gubun1 == $gubun7) $SELECT_OPT = "selected";
                                else $SELECT_OPT = '';

                                $STR7 = "<option value=$cnt $SELECT_OPT>$gubun_name7</option>";
                                $SELECT_STR7 = $SELECT_STR7 . $STR7 ;

                                $cnt = $cnt + 1;
                        }
                }


        		echo "
                            </div>
                            <div class='col-lg-9'>
                            </div>
                          </div>


			      <br>
			      <br>

                          <div class='row'>

                            <div class='col-lg-3'>

                              <div class='label_warning' style='margin-bottom: 5px;padding: 4px 12px;'>
                                  <b><font size=3>Flow 수정</font></b>
                              </div>

                            </div>
                            <div class='col-lg-9'>
                            </div>
                          </div>

			      <br>

                          <div class='row'>
                            <div class='col-lg-6'>

			      <table border=1>
			      <tr><td width=150><label class='control-label' for='inputSuccess'>ㅇ 이름: </label></td>
			      <td width=400><input type='text' class='form-control' id=FNAME name=FNAME value='$f_name' readonly></td>
			      <tr><td width=150><label class='control-label' for='inputSuccess'>ㅇ 설명: </label></td>
			      <td width=400><input type='text' class='form-control' id=EXPALIN name=EXPALIN value='$f_explain_dec'></td><td></td></tr>
			      <tr><td width=150><label class='control-label' for='inputSuccess'>ㅇ Flow 종류: </label></td>
			      <td width=400><select class=form-control id=GUBUN name=GUBUN>
			      {$SELECT_STR5}
			      </select></td><td></td></tr>

                              <tr><td width=150><label class='control-label' for='inputSuccess'>ㅇ Flow 사용범위: </label></td>
                              <td width=400><select class=form-control id=GUBUN1 name=GUBUN1>
                              {$SELECT_STR7}
                              </select></td><td></td></tr>

			      <tr><td align=center colspan=3>
			      <button id=button1_save name=btn1_save class='btn btn-success' onclick='Button_Click1()' style='width:100%'>Flow 수정 Click!!</button>
			      </td></tr>
			      </table>

		";

		echo "
                            </div>

                            <div class='col-lg-6'>
                            </div>

                          </div>
                        </div>
                      </div>

		";


?> 

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>




</body>

</html>




